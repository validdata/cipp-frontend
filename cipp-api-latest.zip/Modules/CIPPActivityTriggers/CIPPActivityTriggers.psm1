#Region './Public/Entrypoints/Activity Triggers/Applications/Push-GetApplicationQueue.ps1' -1

function Push-GetApplicationQueue {
    param()
    $Table = Get-CippTable -tablename 'apps'
    Get-CIPPAzDataTableEntity @Table | Select-Object @{Name = 'Name'; Expression = { $_.RowKey } }, @{Name = 'FunctionName'; Expression = { 'UploadApplication' } }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Applications/Push-GetApplicationQueue.ps1' 6
#Region './Public/Entrypoints/Activity Triggers/Applications/Push-UploadApplication.ps1' -1

function Push-UploadApplication {
    <#
        .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)

    try {
        $Table = Get-CippTable -tablename 'apps'
        $Filter = "PartitionKey eq 'apps' and RowKey eq '$($Item.Name)'"

        $AppConfig = (Get-CIPPAzDataTableEntity @Table -filter $Filter).JSON | ConvertFrom-Json
        $intuneBody = $AppConfig.IntuneBody
        $tenants = if ($AppConfig.tenant -eq 'AllTenants') {
            (Get-Tenants -IncludeErrors).defaultDomainName
        } else {
            $AppConfig.tenant
        }
        $assignTo = $AppConfig.assignTo
        $AssignToIntent = $AppConfig.InstallationIntent
        $ClearRow = Get-CIPPAzDataTableEntity @Table -Filter $Filter
        if ($AppConfig.tenant -ne 'AllTenants') {
            $null = Remove-AzDataTableEntity -Force @Table -Entity $clearRow
        } else {
            $Table.Force = $true
            $null = Add-CIPPAzDataTableEntity @Table -Entity @{
                JSON         = "$($AppConfig | ConvertTo-Json)"
                RowKey       = "$($ClearRow.RowKey)"
                PartitionKey = 'apps'
                status       = 'Deployed'
            }
        }

        # Determine app type (default to 'Choco' if not specified)
        $AppType = if ($AppConfig.type) { $AppConfig.type } else { 'Choco' }

        # Load files based on app type (only for types that need them)
        $Intunexml = $null
        $Infile = $null
        if ($AppType -eq 'MSPApp') {
            [xml]$Intunexml = Get-Content (Join-Path $env:CIPPRootPath "AddMSPApp\$($AppConfig.MSPAppName).app.xml")
            $Infile = Join-Path $env:CIPPRootPath "AddMSPApp\$($AppConfig.MSPAppName).intunewin"
        } elseif ($AppType -in @('Choco', 'Win32ScriptApp')) {
            [xml]$Intunexml = Get-Content (Join-Path $env:CIPPRootPath 'AddChocoApp\Choco.App.xml')
            $Infile = Join-Path $env:CIPPRootPath "AddChocoApp\$($Intunexml.ApplicationInfo.FileName)"
        }


        $baseuri = 'https://graph.microsoft.com/beta/deviceAppManagement/mobileApps'
        foreach ($tenant in $tenants) {
            try {
                # Check if app already exists
                $ApplicationList = New-GraphGetRequest -Uri $baseuri -tenantid $tenant | Where-Object { $_.DisplayName -eq $AppConfig.Applicationname -and ($_.'@odata.type' -eq '#microsoft.graph.win32LobApp' -or $_.'@odata.type' -eq '#microsoft.graph.winGetApp') }
                if ($ApplicationList.displayname.count -ge 1) {
                    Write-LogMessage -api 'AppUpload' -tenant $tenant -message "$($AppConfig.Applicationname) exists. Skipping this application" -Sev 'Info'
                    continue
                }

                # Route to appropriate handler based on app type
                $NewApp = $null
                switch ($AppType) {
                    'WinGet' {
                        $NewApp = Add-CIPPWinGetApp -AppBody $intuneBody -TenantFilter $tenant
                    }
                    'Choco' {
                        # Prepare encryption info from XML
                        $EncryptionInfo = @{
                            EncryptionKey        = $Intunexml.ApplicationInfo.EncryptionInfo.EncryptionKey
                            MacKey               = $Intunexml.ApplicationInfo.EncryptionInfo.MacKey
                            InitializationVector = $Intunexml.ApplicationInfo.EncryptionInfo.InitializationVector
                            Mac                  = $Intunexml.ApplicationInfo.EncryptionInfo.Mac
                            ProfileIdentifier    = $Intunexml.ApplicationInfo.EncryptionInfo.ProfileIdentifier
                            FileDigest           = $Intunexml.ApplicationInfo.EncryptionInfo.FileDigest
                            FileDigestAlgorithm  = $Intunexml.ApplicationInfo.EncryptionInfo.FileDigestAlgorithm
                        }

                        # Build parameters dynamically
                        $Params = @{
                            AppBody         = $intuneBody
                            TenantFilter    = $tenant
                            FilePath        = $Infile
                            FileName        = $Intunexml.ApplicationInfo.FileName
                            UnencryptedSize = [int64]$Intunexml.ApplicationInfo.UnencryptedContentSize
                            EncryptionInfo  = $EncryptionInfo
                        }
                        if ($AppConfig.Applicationname) { $Params.DisplayName = $AppConfig.Applicationname }

                        $NewApp = Add-CIPPPackagedApplication @Params
                    }
                    'MSPApp' {
                        # Prepare encryption info from XML
                        $EncryptionInfo = @{
                            EncryptionKey        = $Intunexml.ApplicationInfo.EncryptionInfo.EncryptionKey
                            MacKey               = $Intunexml.ApplicationInfo.EncryptionInfo.MacKey
                            InitializationVector = $Intunexml.ApplicationInfo.EncryptionInfo.InitializationVector
                            Mac                  = $Intunexml.ApplicationInfo.EncryptionInfo.Mac
                            ProfileIdentifier    = $Intunexml.ApplicationInfo.EncryptionInfo.ProfileIdentifier
                            FileDigest           = $Intunexml.ApplicationInfo.EncryptionInfo.FileDigest
                            FileDigestAlgorithm  = $Intunexml.ApplicationInfo.EncryptionInfo.FileDigestAlgorithm
                        }

                        # Build parameters dynamically
                        $Params = @{
                            AppBody         = $intuneBody
                            TenantFilter    = $tenant
                            FilePath        = $Infile
                            FileName        = $Intunexml.ApplicationInfo.FileName
                            UnencryptedSize = [int64]$Intunexml.ApplicationInfo.UnencryptedContentSize
                            EncryptionInfo  = $EncryptionInfo
                        }
                        if ($AppConfig.Applicationname) { $Params.DisplayName = $AppConfig.Applicationname }

                        $NewApp = Add-CIPPPackagedApplication @Params
                    }
                    'Win32ScriptApp' {
                        # Prepare encryption info from XML
                        $EncryptionInfo = @{
                            EncryptionKey        = $Intunexml.ApplicationInfo.EncryptionInfo.EncryptionKey
                            MacKey               = $Intunexml.ApplicationInfo.EncryptionInfo.MacKey
                            InitializationVector = $Intunexml.ApplicationInfo.EncryptionInfo.InitializationVector
                            Mac                  = $Intunexml.ApplicationInfo.EncryptionInfo.Mac
                            ProfileIdentifier    = $Intunexml.ApplicationInfo.EncryptionInfo.ProfileIdentifier
                            FileDigest           = $Intunexml.ApplicationInfo.EncryptionInfo.FileDigest
                            FileDigestAlgorithm  = $Intunexml.ApplicationInfo.EncryptionInfo.FileDigestAlgorithm
                        }

                        # Build properties dynamically
                        $Properties = @{
                            displayName   = $AppConfig.Applicationname
                            installScript = $AppConfig.installScript
                        }

                        # A few of these are probably mandatory
                        if ($AppConfig.description) { $Properties['description'] = $AppConfig.description }
                        if ($AppConfig.publisher) { $Properties['publisher'] = $AppConfig.publisher }
                        if ($AppConfig.uninstallScript) { $Properties['uninstallScript'] = $AppConfig.uninstallScript }
                        if ($AppConfig.detectionScript) { $Properties['detectionScript'] = $AppConfig.detectionScript }
                        if ($AppConfig.detectionPath) { $Properties['detectionPath'] = $AppConfig.detectionPath }
                        if ($AppConfig.detectionFile) { $Properties['detectionFile'] = $AppConfig.detectionFile }
                        if ($AppConfig.runAsAccount) { $Properties['runAsAccount'] = $AppConfig.runAsAccount }
                        if ($AppConfig.deviceRestartBehavior) { $Properties['deviceRestartBehavior'] = $AppConfig.deviceRestartBehavior }
                        if ($null -ne $AppConfig.runAs32Bit) { $Properties['runAs32Bit'] = $AppConfig.runAs32Bit }
                        if ($null -ne $AppConfig.enforceSignatureCheck) { $Properties['enforceSignatureCheck'] = $AppConfig.enforceSignatureCheck }

                        $NewApp = Add-CIPPW32ScriptApplication -TenantFilter $tenant -Properties ([PSCustomObject]$Properties)
                    }
                    'WinGetNew' {
                        # I think we don't need a separate WinGetNew type, just use WinGet?
                    }
                    default {
                        throw "Unsupported app type: $($AppConfig.type)"
                    }
                }

                # Log success and assign app if requested
                if ($NewApp) {
                    Write-LogMessage -api 'AppUpload' -tenant $tenant -message "$($AppConfig.Applicationname) Successfully created" -Sev 'Info'

                    if ($assignTo -and $assignTo -ne 'On') {
                        $intent = if ($AssignToIntent) { 'Uninstall' } else { 'Required' }
                        $AppTypeForAssignment = switch ($AppType) {
                            'WinGet' { 'WinGet' }
                            'WinGetNew' { 'WinGet' }
                            default { 'Win32Lob' }
                        }
                        Start-Sleep -Milliseconds 200
                        Set-CIPPAssignedApplication -ApplicationId $NewApp.Id -TenantFilter $tenant -groupName $assignTo -Intent $intent -AppType $AppTypeForAssignment -APIName 'AppUpload'
                    }
                }
            } catch {
                "Failed to add Application for $tenant : $($_.Exception.Message)"
                Write-LogMessage -api 'AppUpload' -tenant $tenant -message "Failed adding Application $($AppConfig.Applicationname). Error: $($_.Exception.Message)" -LogData (Get-CippException -Exception $_) -Sev 'Error'
                continue
            }
        }
    } catch {
        Write-Host "Error pushing application: $($_.Exception.Message)"
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Applications/Push-UploadApplication.ps1' 181
#Region './Public/Entrypoints/Activity Triggers/BEC/Push-BECRun.ps1' -1

function Push-BECRun {
    <#
        .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $TenantFilter = $Item.TenantFilter
    $SuspectUser = $Item.UserID
    $UserName = $Item.userName

    if (!$TenantFilter -or !$SuspectUser) {
        Write-Information 'BEC: No user or tenant specified'
        return
    }
    $Table = Get-CippTable -tablename 'cachebec'

    Write-Information "Working on $UserName"
    try {
        $startDate = (Get-Date).AddDays(-7).ToUniversalTime()
        $endDate = (Get-Date)
        Write-Information 'Getting audit logs'
        $auditLog = (New-ExoRequest -tenantid $TenantFilter -cmdlet 'Get-AdminAuditLogConfig').UnifiedAuditLogIngestionEnabled
        $7dayslog = if ($auditLog -eq $false) {
            $ExtractResult = 'AuditLog is disabled. Cannot perform full analysis'
        } else {
            $sessionid = Get-Random -Minimum 10000 -Maximum 99999
            $operations = @(
                'Remove-MailboxPermission',
                'Add-MailboxPermission',
                'UpdateCalendarDelegation',
                'AddFolderPermissions',
                'MailboxLogin',
                'UserLoggedIn'
            )
            $startDate = (Get-Date).AddDays(-7)
            $endDate = (Get-Date)
            $SearchParam = @{
                SessionCommand = 'ReturnLargeSet'
                Operations     = $operations
                sessionid      = $sessionid
                startDate      = $startDate
                endDate        = $endDate
            }
            do {
                New-ExoRequest -tenantid $TenantFilter -cmdlet 'Search-unifiedAuditLog' -cmdParams $SearchParam -Anchor $Username
                Write-Information "Retrieved $($logsTenant.count) logs"
                $logsTenant
            } while ($LogsTenant.count % 5000 -eq 0 -and $LogsTenant.count -ne 0)
            $ExtractResult = 'Successfully extracted logs from auditlog'
        }
        Write-Information 'Getting last sign-in'
        try {
            $URI = "https://graph.microsoft.com/beta/auditLogs/signIns?`$filter=(userId eq '$SuspectUser')&`$top=1&`$orderby=createdDateTime desc"
            $LastSignIn = New-GraphGetRequest -uri $URI -tenantid $TenantFilter -noPagination $true -verbose | Select-Object @{ Name = 'CreatedDateTime'; Expression = { $(($_.createdDateTime | Out-String) -replace '\r\n') } },
            id,
            @{ Name = 'AppDisplayName'; Expression = { $_.resourceDisplayName } },
            @{ Name = 'Status'; Expression = { if (($_.conditionalAccessStatus -eq 'Success' -or 'Not Applied') -and $_.status.errorCode -eq 0) { 'Success' } else { 'Failed' } } },
            @{ Name = 'IPAddress'; Expression = { $_.ipAddress } }
        } catch {
            $LastSignIn = [PSCustomObject]@{
                AppDisplayName  = 'Unknown - could not retrieve information. No access to sign-in logs'
                CreatedDateTime = 'Unknown'
                Id              = '0'
                Status          = 'Could not retrieve additional details'
            }
        }
        Write-Information 'Getting user devices'
        #List all users devices
        $Bytes = [System.Text.Encoding]::UTF8.GetBytes($SuspectUser)
        $base64IdentityParam = [Convert]::ToBase64String($Bytes)
        try {
            $Devices = New-GraphGetRequest -uri "https://outlook.office365.com:443/adminapi/beta/$($TenantFilter)/mailbox('$($base64IdentityParam)')/MobileDevice/Exchange.GetMobileDeviceStatistics()/?IsEncoded=True" -Tenantid $TenantFilter -scope ExchangeOnline
        } catch {
            $Devices = $null
        }

        try {
            $PermissionsLog = ($7dayslog | Where-Object -Property Operations -In 'Remove-MailboxPermission', 'Add-MailboxPermission', 'UpdateCalendarDelegation', 'AddFolderPermissions' ).AuditData | ConvertFrom-Json -ErrorAction Stop | ForEach-Object {
                $perms = if ($_.Parameters) {
                    $_.Parameters | ForEach-Object { if ($_.Name -eq 'AccessRights') { $_.Value } }
                } else
                { $_.item.ParentFolder.MemberRights }
                $objectID = if ($_.ObjectID) { $_.ObjectID } else { $($_.MailboxOwnerUPN) + $_.item.ParentFolder.Path }
                [pscustomobject]@{
                    Operation   = $_.Operation
                    UserKey     = $_.UserKey
                    ObjectId    = $objectId
                    Permissions = $perms
                }
            }
        } catch {
            $PermissionsLog = @()
        }

        Write-Information 'Getting rules'

        try {
            $RulesLog = New-ExoRequest -cmdlet 'Get-InboxRule' -tenantid $TenantFilter -cmdParams @{ Mailbox = $Username; IncludeHidden = $true } -Anchor $Username |
                Where-Object { $_.Name -ne 'Junk E-Mail Rule' -and $_.Name -notlike 'Microsoft.Exchange.OOF.*' }
        } catch {
            Write-Host 'Failed to get rules: ' + $_.Exception.Message
            $RulesLog = @()
        }

        Write-Information 'Getting last 50 logons'
        try {
            $Last50Logons = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/auditLogs/signIns?`$filter=userDisplayName ne 'On-Premises Directory Synchronization Service Account'&`$top=50&`$orderby=createdDateTime desc" -tenantid $TenantFilter -noPagination $true | Select-Object @{ Name = 'CreatedDateTime'; Expression = { $(($_.createdDateTime | Out-String) -replace '\r\n') } },
            id,
            @{ Name = 'AppDisplayName'; Expression = { $_.resourceDisplayName } },
            @{ Name = 'Status'; Expression = { if (($_.conditionalAccessStatus -eq 'Success' -or 'Not Applied') -and $_.status.errorCode -eq 0) { 'Success' } else { 'Failed' } } },
            @{ Name = 'IPAddress'; Expression = { $_.ipAddress } }, UserPrincipalName, UserDisplayName
        } catch {
            $Last50Logons = @(
                [PSCustomObject]@{
                    AppDisplayName  = 'Unknown - could not retrieve information. No access to sign-in logs'
                    CreatedDateTime = 'Unknown'
                    Id              = '0'
                    Status          = 'Could not retrieve additional details'
                    Exception       = $_.Exception.Message
                }
            )
        }

        $Requests = @(
            @{
                id     = 'Users'
                url    = "users?`$select=id,displayName,userPrincipalName,createdDateTime,lastPasswordChangeDateTime"
                method = 'GET'
            }
            @{
                id     = 'MFADevices'
                url    = "users/$($SuspectUser)/authentication/methods"
                method = 'GET'
            }
            @{
                id     = 'NewSPs'
                url    = "servicePrincipals?`$select=displayName,createdDateTime,appId,appDisplayName,publisher&`$filter=createdDateTime ge $($startDate.ToString('yyyy-MM-ddTHH:mm:ssZ'))"
                method = 'GET'
            }
        )

        Write-Information 'Getting bulk requests'
        $GraphResults = New-GraphBulkRequest -Requests $Requests -tenantid $TenantFilter -asapp $true

        $PasswordChanges = (($GraphResults | Where-Object { $_.id -eq 'Users' }).body.value | Where-Object { $_.lastPasswordChangeDateTime -ge $startDate }) ?? @()
        $NewUsers = (($GraphResults | Where-Object { $_.id -eq 'Users' }).body.value | Where-Object { $_.createdDateTime -ge $startDate }) ?? @()
        $MFADevices = ($GraphResults | Where-Object { $_.id -eq 'MFADevices' }).body.value ?? @()
        $NewSPs = ($GraphResults | Where-Object { $_.id -eq 'NewSPs' }).body.value ?? @()


        $Results = [PSCustomObject]@{
            AddedApps                = @($NewSPs)
            SuspectUserMailboxLogons = @($Last50Logons)
            LastSuspectUserLogon     = @($LastSignIn)
            SuspectUserDevices       = @($Devices)
            NewRules                 = @($RulesLog)
            MailboxPermissionChanges = @($PermissionsLog)
            NewUsers                 = @($NewUsers)
            MFADevices               = @($MFADevices | Where-Object { $_.'@odata.type' -ne '#microsoft.graph.passwordAuthenticationMethod' })
            ChangedPasswords         = @($PasswordChanges)
            ExtractedAt              = (Get-Date)
            ExtractResult            = $ExtractResult
        }

        $Entity = @{
            UserId       = $SuspectUser
            Results      = [string]($Results | ConvertTo-Json -Depth 10 -Compress)
            RowKey       = $SuspectUser
            PartitionKey = 'bec'
            Status       = 'Completed'
        }
        Add-CIPPAzDataTableEntity @Table -Entity $Entity -Force
        Write-LogMessage -API 'BECRun' -message "BEC Check run for $UserName" -tenant $TenantFilter -sev 'Info'
    } catch {
        $errMessage = Get-NormalizedError -message $_.Exception.Message
        $CippError = Get-CippException -Exception $_
        $results = [pscustomobject]@{'Results' = "$errMessage"; Exception = $CippError }
        Write-LogMessage -API 'BECRun' -message "Error Running BEC for $($UserName): $errMessage" -tenant $TenantFilter -sev 'Error' -LogData $CIPPError
        $Entity = @{
            UserId       = $SuspectUser
            Results      = [string]($Results | ConvertTo-Json -Depth 10 -Compress)
            RowKey       = $SuspectUser
            PartitionKey = 'bec'
            Status       = 'Error'
        }
        Add-CIPPAzDataTableEntity @Table -Entity $Entity -Force
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/BEC/Push-BECRun.ps1' 190
#Region './Public/Entrypoints/Activity Triggers/BPA/Push-BPACollectData.ps1' -1

function Push-BPACollectData {
    <#
    .FUNCTIONALITY
    Entrypoint
    #>
    param($Item)

    $TenantName = Get-Tenants | Where-Object -Property defaultDomainName -EQ $Item.Tenant
    $BPATemplateTable = Get-CippTable -tablename 'templates'
    $Filter = "PartitionKey eq 'BPATemplate'"
    $TemplatesLoc = (Get-CIPPAzDataTableEntity @BPATemplateTable -Filter $Filter).JSON | ConvertFrom-Json

    $Templates = $TemplatesLoc | ForEach-Object {
        $Template = $_
        [PSCustomObject]@{
            Data  = $Template
            Name  = $Template.Name
            Style = $Template.Style
        }
    }
    $Table = Get-CippTable -tablename 'cachebpav2'

    $Rerun = Test-CIPPRerun -Type 'BPA' -Tenant $Item.Tenant -API $Item.Template
    if ($Rerun) {
        Write-Host 'Detected rerun for BPA. Exiting cleanly'
        return
    }
    Write-Host "Working on BPA for $($TenantName.defaultDomainName) with GUID $($TenantName.customerId) - Report ID $($Item.Template)"
    $Template = $Templates | Where-Object -Property Name -EQ -Value $Item.Template
    # Build up the result object that will be stored in tables
    $Result = @{
        Tenant       = "$($TenantName.displayName)"
        GUID         = "$($TenantName.customerId)"
        RowKey       = "$($Template.Name)"
        PartitionKey = "$($TenantName.customerId)"
        LastRefresh  = [string]$(Get-Date (Get-Date).ToUniversalTime() -UFormat '+%Y-%m-%dT%H:%M:%S.000Z')
    }
    foreach ($field in $Template.Data.Fields) {
        if ($field.UseExistingInfo) { continue }
        if ($Field.Where) { $filterscript = [scriptblock]::Create($Field.Where) } else { $filterscript = { $true } }
        try {
            switch ($field.API) {
                'Graph' {
                    $paramsField = @{
                        uri      = $field.URL
                        tenantid = $TenantName.defaultDomainName
                    }
                    if ($Field.Parameters.PSObject.properties.name) {
                        $field.Parameters | ForEach-Object {
                            $paramsField[$_.PSObject.properties.name] = $_.PSObject.properties.value
                        }
                    }
                    $FieldInfo = New-GraphGetRequest @paramsField | Where-Object $filterscript | Select-Object $field.ExtractFields
                }
                'Exchange' {
                    Write-Host "Trying to execute $($field.Command) for $($TenantName.displayName) with GUID $($TenantName.customerId)"
                    if ($field.Command -notlike 'get-*') {
                        Write-LogMessage -API 'BPA' -tenant $TenantName.defaultDomainName -message 'The BPA only supports get- exchange commands. A set or update command was used.' -sev Error
                        break
                    } else {
                        $paramsField = @{
                            tenantid = $TenantName.defaultDomainName
                            cmdlet   = $field.Command
                        }
                        if ($Field.Parameters) { $paramsField.'cmdParams' = $field.parameters }
                        $FieldInfo = New-ExoRequest @paramsField | Where-Object $filterscript | Select-Object $field.ExtractFields
                    }
                }
                'CIPPFunction' {
                    if ($field.Command -notlike 'get-CIPP*') {
                        Write-LogMessage -API 'BPA' -tenant $TenantName.defaultDomainName -message 'The BPA only supports get-CIPP commands. A set or update command was used, or a command that is not allowed.' -sev Error
                        break
                    }
                    $paramsField = @{
                        TenantFilter = $TenantName.defaultDomainName
                    }
                    if ($field.Parameters.PSObject.properties.name) {
                        $field.Parameters | ForEach-Object {
                            $paramsField[$_.PSObject.properties.name] = $_.PSObject.properties.value
                        }
                    }
                    $FieldInfo = & $field.Command @paramsField | Where-Object $filterscript | Select-Object $field.ExtractFields
                }
            }
        } catch {
            Write-Information "Error getting $($field.Name) in $($field.api) for $($TenantName.displayName) with GUID $($TenantName.customerId). Error: $($_.Exception.Message)"
            Write-LogMessage -API 'BPA' -tenant $TenantName.defaultDomainName -message "Error getting $($field.Name) for $($TenantName.displayName) with GUID $($TenantName.customerId). Error: $($_.Exception.Message)" -sev Error -LogData (Get-CippException -Exception $_)
            $FieldInfo = 'FAILED'
            $field.StoreAs = 'string'
        }
        try {
            switch -Wildcard ($field.StoreAs) {
                '*bool' {
                    if ($field.ExtractFields.Count -gt 1) {
                        Write-LogMessage -API 'BPA' -tenant $TenantName.defaultDomainName -message "The BPA only supports 1 field for a bool. $($field.ExtractFields.Count) fields were specified." -sev Error
                        break
                    }
                    if ($null -eq $FieldInfo.$($field.ExtractFields)) { $FieldInfo = $false }

                    $Result.Add($field.Name, [bool]$FieldInfo.$($field.ExtractFields))
                }
                'JSON' {
                    if ($null -eq $FieldInfo) { $JsonString = '{}' } else { $JsonString = (ConvertTo-Json -Depth 15 -InputObject $FieldInfo -Compress) }
                    Write-Host "Adding $($field.Name) to table with value $JsonString"
                    $Result.Add($field.Name, $JSONString)
                }
                'string' {
                    $Result.Add($field.Name, [string]$FieldInfo)
                }
                'percentage' {

                }
            }
        } catch {
            Write-LogMessage -API 'BPA' -tenant $TenantName.defaultDomainName -message "Error storing $($field.Name) for $($TenantName.displayName) with GUID $($TenantName.customerId). Error: $($_.Exception.Message)" -sev Error -LogData (Get-CippException -Exception $_)
            $Result.Add($field.Name, 'FAILED')
        }

    }

    if ($Result) {
        try {
            Add-CIPPAzDataTableEntity @Table -Entity $Result -Force
        } catch {
            Write-LogMessage -API 'BPA' -tenant $TenantName.defaultDomainName -message "Error getting saving data for $($template.Name) - $($TenantName.customerId). Error: $($_.Exception.Message)" -LogData (Get-CippException -Exception $_) -sev Error
        }
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/BPA/Push-BPACollectData.ps1' 129
#Region './Public/Entrypoints/Activity Triggers/CIPPDBCache/Push-ExecCIPPDBCache.ps1' -1

function Push-ExecCIPPDBCache {
    <#
    .SYNOPSIS
        Generic wrapper to execute CIPP DB cache functions

    .DESCRIPTION
        Supports two modes:
        - Grouped collection: When CollectionType is specified, delegates to Invoke-CIPPDBCacheCollection
          which runs all cache functions for that license group sequentially in one activity.
        - Single type (legacy): When Name is specified, executes a single Set-CIPPDBCache* function.
          Used by the HTTP endpoint for on-demand single-type cache refreshes.

    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)

    $TenantFilter = $Item.TenantFilter
    $QueueId = $Item.QueueId

    try {
        # Grouped collection mode — runs all cache types for a license category in one activity
        if ($Item.CollectionType) {
            Write-Information "Collecting $($Item.CollectionType) group for tenant $TenantFilter"

            $Params = @{
                CollectionType = $Item.CollectionType
                TenantFilter   = $TenantFilter
            }
            if ($QueueId) { $Params.QueueId = $QueueId }

            $Result = Invoke-CIPPDBCacheCollection @Params

            Write-Information "Completed $($Item.CollectionType) group for $TenantFilter - $($Result.Success)/$($Result.Total) succeeded"
            return "Successfully executed $($Item.CollectionType) collection for $TenantFilter ($($Result.Success)/$($Result.Total))"
        }

        # Single-type mode (legacy) — used by HTTP endpoint for on-demand cache refresh
        $Name = $Item.Name
        $Types = @($Item.Types | Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and $_ -ne 'None' })

        Write-Information "Collecting $Name for tenant $TenantFilter"

        # Build the full function name
        $FullFunctionName = "Set-CIPPDBCache$Name"

        # Check if function exists
        $Function = Get-Command -Name $FullFunctionName -ErrorAction SilentlyContinue
        if (-not $Function) {
            throw "Function $FullFunctionName does not exist"
        }

        # Build parameters for the cache function
        $CacheFunctionParams = @{
            TenantFilter = $TenantFilter
        }

        # Add QueueId if provided
        if ($QueueId) {
            $CacheFunctionParams.QueueId = $QueueId
        }

        # Add Types if provided (for Mailboxes function)
        $FunctionSupportsTypes = $Function.Parameters.ContainsKey('Types')
        if ($Types.Count -gt 0 -and $FunctionSupportsTypes) {
            $CacheFunctionParams.Types = $Types
        }

        Write-Information "Executing $FullFunctionName with parameters: $(($CacheFunctionParams.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join ', '))"

        # Execute the cache function
        & $FullFunctionName @CacheFunctionParams

        Write-Information "Completed $Name for tenant $TenantFilter"
        return "Successfully executed $Name for tenant $TenantFilter"

    } catch {
        $ErrorMsg = "Failed to execute $(if ($Item.CollectionType) { "$($Item.CollectionType) collection" } else { $Item.Name }) for tenant $TenantFilter : $($_.Exception.Message)"
        Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message $ErrorMsg -sev Error
        throw $ErrorMsg
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/CIPPDBCache/Push-ExecCIPPDBCache.ps1' 84
#Region './Public/Entrypoints/Activity Triggers/Domain Analyser/Push-DomainAnalyserDomain.ps1' -1

function Push-DomainAnalyserDomain {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)
    $DomainTable = Get-CippTable -tablename 'Domains'
    $Filter = "PartitionKey eq 'TenantDomains' and RowKey eq '{0}'" -f $Item.RowKey
    $DomainObject = Get-CIPPAzDataTableEntity @DomainTable -Filter $Filter | Select-Object * -ExcludeProperty table

    try {
        $ConfigTable = Get-CippTable -tablename Config
        $Filter = "PartitionKey eq 'Domains' and RowKey eq 'Domains'"
        $Config = Get-CIPPAzDataTableEntity @ConfigTable -Filter $Filter

        $ValidResolvers = @('Google', 'CloudFlare')
        if ($ValidResolvers -contains $Config.Resolver) {
            $Resolver = $Config.Resolver
        } else {
            $Resolver = 'Google'
            $Config = @{
                PartitionKey = 'Domains'
                RowKey       = 'Domains'
                Resolver     = $Resolver
            }
            Add-CIPPAzDataTableEntity @ConfigTable -Entity $Config -Force
        }
    } catch {
        $Resolver = 'Google'
    }
    Set-DnsResolver -Resolver $Resolver

    $Domain = $DomainObject.RowKey

    try {
        $Tenant = $DomainObject.TenantDetails | ConvertFrom-Json -ErrorAction Stop
    } catch {
        $Tenant = @{ Tenant = 'None' }
    }

    $Result = [PSCustomObject]@{
        Tenant                 = $Tenant.Tenant
        TenantID               = $Tenant.TenantGUID
        GUID                   = $($Domain.Replace('.', ''))
        LastRefresh            = $(Get-Date (Get-Date).ToUniversalTime() -UFormat '+%Y-%m-%dT%H:%M:%S.000Z')
        Domain                 = $Domain
        NSRecords              = (Read-NSRecord -Domain $Domain).Records
        ExpectedSPFRecord      = ''
        ActualSPFRecord        = ''
        SPFPassAll             = ''
        ActualMXRecords        = ''
        MXPassTest             = ''
        DMARCPresent           = ''
        DMARCFullPolicy        = ''
        DMARCActionPolicy      = ''
        DMARCReportingActive   = ''
        DMARCPercentagePass    = ''
        DNSSECPresent          = ''
        MailProvider           = ''
        DKIMEnabled            = ''
        DKIMRecords            = ''
        MSCNAMEDKIMSelectors   = ''
        EnterpriseEnrollment   = ''
        EnterpriseRegistration = ''
        Score                  = ''
        MaximumScore           = 160
        ScorePercentage        = ''
        ScoreExplanation       = ''
    }

    $Scores = [PSCustomObject]@{
        SPFPresent           = 10
        SPFCorrectAll        = 20
        MXRecommended        = 10
        DMARCPresent         = 10
        DMARCSetQuarantine   = 20
        DMARCSetReject       = 30
        DMARCReportingActive = 20
        DMARCPercentageGood  = 20
        DNSSECPresent        = 20
        DKIMActiveAndWorking = 20
    }

    $ScoreDomain = 0
    # Setup Score Explanation
    $ScoreExplanation = [System.Collections.Generic.List[string]]::new()

    #Region MX Check
    $MXRecord = Read-MXRecord -Domain $Domain -ErrorAction Stop

    $Result.ExpectedSPFRecord = $MXRecord.ExpectedInclude
    $Result.MXPassTest = $false
    $Result.ActualMXRecords = $MXRecord.Records

    # Check fail counts to ensure all tests pass
    #$MXWarnCount = $MXRecord.ValidationWarns | Measure-Object | Select-Object -ExpandProperty Count
    $MXFailCount = $MXRecord.ValidationFails | Measure-Object | Select-Object -ExpandProperty Count

    if ($MXFailCount -eq 0) {
        $Result.MXPassTest = $true
        $ScoreDomain += $Scores.MXRecommended
    } else {
        $ScoreExplanation.Add('MX record did not pass validation') | Out-Null
    }

    if ([string]::IsNullOrEmpty($MXRecord.MailProvider)) {
        $Result.MailProvider = 'Unknown'
    } else {
        $Result.MailProvider = $MXRecord.MailProvider.Name
    }
    #EndRegion MX Check

    #Region SPF Check
    try {
        $SPFRecord = Read-SpfRecord -Domain $Domain -ErrorAction Stop
        if ($SPFRecord.RecordCount -gt 0) {
            $Result.ActualSPFRecord = $SPFRecord.Record
            if ($SPFRecord.RecordCount -eq 1) {
                $ScoreDomain += $Scores.SPFPresent
            } else {
                $ScoreExplanation.Add('Multiple SPF records detected') | Out-Null
            }
        } else {
            $Result.ActualSPFRecord = 'No SPF Record'
            $ScoreExplanation.Add('No SPF Record Found') | Out-Null
        }
    } catch {
        $Message = 'SPF Error'
        Write-LogMessage -API 'DomainAnalyser' -tenant $DomainObject.TenantId -message $Message -LogData (Get-CippException -Exception $_) -sev Error
    }


    # Check warning + fail counts to ensure all tests pass
    #$SPFWarnCount = $SPFRecord.ValidationWarns | Measure-Object | Select-Object -ExpandProperty Count
    $SPFFailCount = $SPFRecord.ValidationFails | Measure-Object | Select-Object -ExpandProperty Count
    $Result.SPFPassAll = $false

    if ($SPFFailCount -eq 0) {
        $ScoreDomain += $Scores.SPFCorrectAll
        $Result.SPFPassAll = $true
    } else {
        $ScoreExplanation.Add('SPF record did not pass validation') | Out-Null
    }
    #EndRegion SPF Check

    #Region DMARC Check
    try {
        $DMARCPolicy = Read-DmarcPolicy -Domain $Domain -ErrorAction Stop

        if ([string]::IsNullOrEmpty($DMARCPolicy.Record)) {
            $Result.DMARCPresent = $false
            $ScoreExplanation.Add('No DMARC Records Found') | Out-Null
        } else {
            $Result.DMARCPresent = $true
            $ScoreDomain += $Scores.DMARCPresent

            $Result.DMARCFullPolicy = $DMARCPolicy.Record
            if ($DMARCPolicy.Policy -eq 'reject' -and $DMARCPolicy.SubdomainPolicy -eq 'reject') {
                $Result.DMARCActionPolicy = 'Reject'
                $ScoreDomain += $Scores.DMARCSetReject
            }
            if ($DMARCPolicy.Policy -eq 'none') {
                $Result.DMARCActionPolicy = 'None'
                $ScoreExplanation.Add('DMARC is not being enforced') | Out-Null
            }
            if ($DMARCPolicy.Policy -eq 'quarantine') {
                $Result.DMARCActionPolicy = 'Quarantine'
                $ScoreDomain += $Scores.DMARCSetQuarantine
                $ScoreExplanation.Add('DMARC Partially Enforced with quarantine') | Out-Null
            }

            $ReportEmailCount = $DMARCPolicy.ReportingEmails | Measure-Object | Select-Object -ExpandProperty Count
            if ($ReportEmailCount -gt 0) {
                $Result.DMARCReportingActive = $true
                $ScoreDomain += $Scores.DMARCReportingActive
            } else {
                $Result.DMARCReportingActive = $False
                $ScoreExplanation.Add('DMARC Reporting not Configured') | Out-Null
            }

            if ($DMARCPolicy.Percent -eq 100) {
                $Result.DMARCPercentagePass = $true
                $ScoreDomain += $Scores.DMARCPercentageGood
            } else {
                $Result.DMARCPercentagePass = $false
                $ScoreExplanation.Add('DMARC Not Checking All Messages') | Out-Null
            }
        }
    } catch {
        $Message = 'DMARC Error'
        Write-LogMessage -API 'DomainAnalyser' -tenant $DomainObject.TenantId -message $Message -LogData (Get-CippException -Exception $_) -sev Error
        #return $Message
    }
    #EndRegion DMARC Check

    #Region DNS Sec Check
    try {
        $DNSSECResult = Test-DNSSEC -Domain $Domain -ErrorAction Stop
        $DNSSECFailCount = $DNSSECResult.ValidationFails | Measure-Object | Select-Object -ExpandProperty Count
        $DNSSECWarnCount = $DNSSECResult.ValidationFails | Measure-Object | Select-Object -ExpandProperty Count
        if (($DNSSECFailCount + $DNSSECWarnCount) -eq 0) {
            $Result.DNSSECPresent = $true
            $ScoreDomain += $Scores.DNSSECPresent
        } else {
            $Result.DNSSECPresent = $false
            $ScoreExplanation.Add('DNSSEC Not Configured or Enabled') | Out-Null
        }
    } catch {
        $Message = 'DNSSEC Error'
        Write-LogMessage -API 'DomainAnalyser' -tenant $DomainObject.TenantId -message $Message -LogData (Get-CippException -Exception $_) -sev Error
        #return $Message
    }
    #EndRegion DNS Sec Check

    #Region DKIM Check
    try {
        $DkimParams = @{
            Domain                       = $Domain
            FallbackToMicrosoftSelectors = $true
        }
        if (![string]::IsNullOrEmpty($DomainObject.DkimSelectors)) {
            $DkimParams.Selectors = $DomainObject.DkimSelectors | ConvertFrom-Json
        }
        # Check if its a onmicrosoft.com domain and add special selectors for these
        if ($Domain -match 'onmicrosoft.com' -and $Domain -notmatch 'mail.onmicrosoft.com') {
            $DKIMSelector1Value = "selector1-$($Domain -replace '\.', '-' )"
            $DKIMSelector2Value = "selector2-$($Domain -replace '\.', '-' )"
            $DkimParams.Add('Selectors', @("$DKIMSelector1Value", "$DKIMSelector2Value"))
        }

        $DkimRecord = Read-DkimRecord @DkimParams -ErrorAction Stop

        $DkimRecordCount = $DkimRecord.Records | Measure-Object | Select-Object -ExpandProperty Count
        $DkimFailCount = $DkimRecord.ValidationFails | Measure-Object | Select-Object -ExpandProperty Count
        #$DkimWarnCount = $DkimRecord.ValidationWarns | Measure-Object | Select-Object -ExpandProperty Count
        if ($DkimRecordCount -gt 0 -and $DkimFailCount -eq 0) {
            $Result.DKIMEnabled = $true
            $ScoreDomain += $Scores.DKIMActiveAndWorking
            $Result.DKIMRecords = $DkimRecord.Records | Select-Object Selector, Record
        } else {
            $Result.DKIMEnabled = $false
            $ScoreExplanation.Add('DKIM Not Configured') | Out-Null
        }
    } catch {
        $Message = 'DKIM Exception'
        Write-LogMessage -API 'DomainAnalyser' -tenant $DomainObject.TenantId -message $Message -LogData (Get-CippException -Exception $_) -sev Error
        #return $Message
    }
    #EndRegion DKIM Check

    #Region Intune Enrollment CNAME Check
    try {
        # Check enterpriseenrollment CNAME
        $EnrollmentResult = Resolve-DnsHttpsQuery -Domain "enterpriseenrollment.$Domain" -RecordType CNAME
        if ($EnrollmentResult.Answer) {
            $EnrollmentCNAME = ($EnrollmentResult.Answer | Where-Object { $_.type -eq 5 }).data -replace '\.$'
            if ($EnrollmentCNAME -eq 'enterpriseenrollment-s.manage.microsoft.com') {
                $Result.EnterpriseEnrollment = 'Correct'
            } elseif ($EnrollmentCNAME -eq 'enterpriseenrollment.manage.microsoft.com') {
                $Result.EnterpriseEnrollment = 'Legacy'
                $ScoreExplanation.Add('Enterprise Enrollment CNAME points to legacy endpoint (enterpriseenrollment.manage.microsoft.com)') | Out-Null
            } else {
                $Result.EnterpriseEnrollment = "Unexpected: $EnrollmentCNAME"
                $ScoreExplanation.Add('Enterprise Enrollment CNAME points to unexpected target') | Out-Null
            }
        } else {
            $Result.EnterpriseEnrollment = 'No CNAME'
            $ScoreExplanation.Add('No Enterprise Enrollment CNAME record found') | Out-Null
        }
    } catch {
        $Result.EnterpriseEnrollment = 'Error'
        Write-LogMessage -API 'DomainAnalyser' -tenant $DomainObject.TenantId -message "Enterprise Enrollment CNAME error for $Domain" -LogData (Get-CippException -Exception $_) -sev Error
    }

    try {
        # Check enterpriseregistration CNAME
        $RegistrationResult = Resolve-DnsHttpsQuery -Domain "enterpriseregistration.$Domain" -RecordType CNAME
        if ($RegistrationResult.Answer) {
            $RegistrationCNAME = ($RegistrationResult.Answer | Where-Object { $_.type -eq 5 }).data -replace '\.$'
            if ($RegistrationCNAME -eq 'enterpriseregistration.windows.net') {
                $Result.EnterpriseRegistration = 'Correct'
            } else {
                $Result.EnterpriseRegistration = "Unexpected: $RegistrationCNAME"
                $ScoreExplanation.Add('Enterprise Registration CNAME points to unexpected target') | Out-Null
            }
        } else {
            $Result.EnterpriseRegistration = 'No CNAME'
            $ScoreExplanation.Add('No Enterprise Registration CNAME record found') | Out-Null
        }
    } catch {
        $Result.EnterpriseRegistration = 'Error'
        Write-LogMessage -API 'DomainAnalyser' -tenant $DomainObject.TenantId -message "Enterprise Registration CNAME error for $Domain" -LogData (Get-CippException -Exception $_) -sev Error
    }
    #EndRegion Intune Enrollment CNAME Check

    #Region MSCNAME DKIM Records
    # Get Microsoft DKIM CNAME selector Records
    # Ugly, but i needed to create a scope/loop i could break out of without breaking the rest of the function
    foreach ($d in $Domain) {
        try {
            # Test if DKIM is enabled, skip domain if it is
            if ($Result.DKIMEnabled -eq $true) {
                continue
            }
            # Test if its a onmicrosoft.com domain, skip domain if it is
            if ($Domain -match 'onmicrosoft.com') {
                continue
            }
            # Test if there are already MSCNAME values set, skip domain if there is
            if ($null -ne $DomainObject.DomainAnalyser) {
                $CurrentMSCNAMEInfo = ConvertFrom-Json $DomainObject.DomainAnalyser -Depth 10
                if (![string]::IsNullOrWhiteSpace($CurrentMSCNAMEInfo.MSCNAMEDKIMSelectors.selector1.Value) -and
                    ![string]::IsNullOrWhiteSpace($CurrentMSCNAMEInfo.MSCNAMEDKIMSelectors.selector2.Value)) {
                    $Result.MSCNAMEDKIMSelectors = $CurrentMSCNAMEInfo.MSCNAMEDKIMSelectors
                    continue
                }
            }

            # Get the DKIM record from EXO. This is the only way to get the correct values for the MSCNAME records since the new format was introduced in May 2025.
            $DKIM = (New-ExoRequest -tenantid $Tenant.Tenant -cmdlet 'Get-DkimSigningConfig' -Select 'Domain,Selector1CNAME,Selector2CNAME') | Where-Object { $_.Domain -eq $Domain }

            # If no DKIM signing record is found, create a new disabled one
            if ($null -eq $DKIM) {
                Write-Information 'No DKIM record found in EXO - Creating new signing'
                $NewDKIMSigningRequest = New-ExoRequest -tenantid $Tenant.Tenant -cmdlet 'New-DkimSigningConfig' -cmdParams @{  KeySize = 2048; DomainName = $Domain; Enabled = $false }
                $Selector1Value = $NewDKIMSigningRequest.Selector1CNAME
                $Selector2Value = $NewDKIMSigningRequest.Selector2CNAME
            } else {
                $Selector1Value = $DKIM.Selector1CNAME
                $Selector2Value = $DKIM.Selector2CNAME
            }


            # Create the MSCNAME object
            $MSCNAMERecords = [PSCustomObject]@{
                Domain    = $Domain
                selector1 = @{
                    Hostname = 'selector1._domainkey'
                    Value    = $Selector1Value
                }
                selector2 = @{
                    Hostname = 'selector2._domainkey'
                    Value    = $Selector2Value
                }
            }
            $Result.MSCNAMEDKIMSelectors = $MSCNAMERecords
        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            Write-LogMessage -API 'DomainAnalyser' -tenant $DomainObject.TenantId -message "MS CNAME DKIM error: $($ErrorMessage.NormalizedError)" -LogData $ErrorMessage -sev Error
        }
    }
    #EndRegion MSCNAME DKIM Records
    # Final Score
    $Result.Score = $ScoreDomain
    $Result.ScorePercentage = [int](($Result.Score / $Result.MaximumScore) * 100)
    $Result.ScoreExplanation = ($ScoreExplanation) -join ', '

    $Json = (ConvertTo-Json -InputObject $Result -Depth 5 -Compress).ToString()

    if ($DomainObject.PSObject.Properties.Name -notcontains 'DomainAnalyser') {
        $DomainObject | Add-Member -MemberType NoteProperty -Name DomainAnalyser -Value $Json
    } else {
        $DomainObject.DomainAnalyser = $Json
    }

    try {
        $DomainTable.Entity = $DomainObject
        $DomainTable.Force = $true
        Add-CIPPAzDataTableEntity @DomainTable -Entity $DomainObject -Force
    } catch {
        Write-LogMessage -API 'DomainAnalyser' -tenant $DomainObject.TenantId -message "Error saving domain $Domain to table " -sev Error -LogData (Get-CippException -Exception $_)
    }
    return $Result
}
#EndRegion './Public/Entrypoints/Activity Triggers/Domain Analyser/Push-DomainAnalyserDomain.ps1' 375
#Region './Public/Entrypoints/Activity Triggers/Domain Analyser/Push-DomainAnalyserTenant.ps1' -1

function Push-DomainAnalyserTenant {
    <#
        .FUNCTIONALITY
            Entrypoint
        #>
    param($Item)

    $Tenant = Get-Tenants -TenantFilter $Item.customerId -IncludeAll
    $DomainTable = Get-CippTable -tablename 'Domains'

    if ($Tenant.Excluded -eq $true) {
        $Filter = "PartitionKey eq 'TenantDomains' and TenantId eq '{0}'" -f $Tenant.defaultDomainName
        $CleanupRows = Get-CIPPAzDataTableEntity @DomainTable -Filter $Filter
        $CleanupCount = ($CleanupRows | Measure-Object).Count
        if ($CleanupCount -gt 0) {
            Write-LogMessage -API 'DomainAnalyser' -tenant $Tenant.defaultDomainName -tenantid $Tenant.customerId -message "Cleaning up $CleanupCount domain(s) for excluded tenant" -sev Info
            Remove-AzDataTableEntity -Force @DomainTable -Entity $CleanupRows
        }
    } elseif ($Tenant.GraphErrorCount -gt 50) {
        return
    } else {
        try {
            # Get domains from cached database instead of making Graph API calls
            $Domains = New-CIPPDbRequest -TenantFilter $Tenant.defaultDomainName -Type 'Domains'

            if (-not $Domains) {
                Write-LogMessage -API 'DomainAnalyser' -tenant $Tenant.defaultDomainName -tenantid $Tenant.customerId -message 'No cached domain data found. Domain analysis will be skipped until data collection completes.' -sev Info
                return
            }

            # Remove domains that are not wanted, and used for cloud signature services. Same exclusions also found in Invoke-CIPPStandardAddDKIM
            $ExclusionDomains = @(
                '*.microsoftonline.com'
                '*.mail.onmicrosoft.com'
                '*.exclaimer.cloud'
                '*.excl.cloud'
                '*.codetwo.online'
                '*.call2teams.com'
                '*.signature365.net'
                '*.myteamsconnect.io'
                '*.teams.dstny.com'
                '*.msteams.8x8.com'
                '*.ucconnect.co.uk'
                '*.teams-sbc.dk'
            )
            $Domains = $Domains | Where-Object { $_.isVerified -eq $true } | ForEach-Object {
                $Domain = $_
                foreach ($ExclusionDomain in $ExclusionDomains) {
                    if ($Domain.id -like $ExclusionDomain) {
                        $Domain = $null
                    }
                }
                $Domain
            } | Where-Object { $_ -ne $null }

            $TenantDomains = foreach ($d in $Domains) {
                [PSCustomObject]@{
                    Tenant             = $Tenant.defaultDomainName
                    TenantGUID         = $Tenant.customerId
                    InitialDomainName  = $Tenant.initialDomainName
                    Domain             = $d.id
                    AuthenticationType = $d.authenticationType
                    IsAdminManaged     = $d.isAdminManaged
                    IsDefault          = $d.isDefault
                    IsInitial          = $d.isInitial
                    IsRoot             = $d.isRoot
                    IsVerified         = $d.isVerified
                    SupportedServices  = $d.supportedServices
                }
            }

            $DomainCount = ($TenantDomains | Measure-Object).Count
            if ($DomainCount -gt 0) {
                Write-Host "############# $DomainCount tenant Domains"
                $TenantDomainObjects = [System.Collections.Generic.List[object]]::new()
                try {
                    foreach ($TenantDomain in $TenantDomains) {
                        $TenantDetails = ($TenantDomain | ConvertTo-Json -Compress).ToString()
                        $Filter = "PartitionKey eq '{0}' and RowKey eq '{1}'" -f $TenantDomain.Tenant, $TenantDomain.Domain
                        $OldDomain = Get-CIPPAzDataTableEntity @DomainTable -Filter $Filter

                        if ($OldDomain) {
                            Remove-AzDataTableEntity -Force @DomainTable -Entity $OldDomain | Out-Null
                        }

                        $Filter = "PartitionKey eq 'TenantDomains' and RowKey eq '{0}'" -f $TenantDomain.Domain
                        $Domain = Get-CIPPAzDataTableEntity @DomainTable -Filter $Filter

                        if (!$Domain -or $null -eq $TenantDomain.TenantGUID) {
                            $Domain = [pscustomobject]@{
                                DomainAnalyser = ''
                                TenantDetails  = $TenantDetails
                                TenantId       = $TenantDomain.Tenant
                                TenantGUID     = $TenantDomain.TenantGUID
                                DkimSelectors  = ''
                                MailProviders  = ''
                                RowKey         = $TenantDomain.Domain
                                PartitionKey   = 'TenantDomains'
                            }

                            if ($OldDomain) {
                                $DomainObject.DkimSelectors = $OldDomain.DkimSelectors
                                $DomainObject.MailProviders = $OldDomain.MailProviders
                            }
                        } else {
                            $Domain.TenantDetails = $TenantDetails
                            if ($OldDomain) {
                                $Domain.DkimSelectors = $OldDomain.DkimSelectors
                                $Domain.MailProviders = $OldDomain.MailProviders
                            }
                            # Fix tenant info in the event of a default domain name change in a tenant
                            $Domain | Add-Member -MemberType NoteProperty -Name 'TenantId' -Value $TenantDomain.Tenant -Force
                            $Domain | Add-Member -MemberType NoteProperty -Name 'TenantGUID' -Value $TenantDomain.TenantGUID -Force
                        }
                        # Return domain object to list
                        $TenantDomainObjects.Add($Domain)
                    }

                    # Batch insert tenant domains
                    try {
                        Add-CIPPAzDataTableEntity @DomainTable -Entity $TenantDomainObjects -Force
                        $InputObject = [PSCustomObject]@{
                            QueueFunction    = @{
                                FunctionName = 'GetTenantDomains'
                                TenantGUID   = $Tenant.customerId
                            }
                            OrchestratorName = "DomainAnalyser_$($Tenant.defaultDomainName)"
                            PostExecution    = @{
                                FunctionName = 'GetDomainAnalyserResults'
                                Parameters   = @{
                                    Tenant = $Tenant
                                }
                            }
                        }
                        Start-CIPPOrchestrator -InputObject $InputObject
                        Write-Host "Started analysis for $DomainCount tenant domains in $($Tenant.defaultDomainName)"
                        Write-LogMessage -Tenant $Tenant.defaultDomainName -TenantId $Tenant.customerId -API 'DomainAnalyser' -message "Started analysis for $DomainCount tenant domains" -sev Info
                    } catch {
                        Write-LogMessage -Tenant $Tenant.defaultDomainName -TenantId $Tenant.customerId -API 'DomainAnalyser' -message 'Domain Analyser GetTenantDomains error' -sev 'Error' -LogData (Get-CippException -Exception $_)
                    }
                } catch {
                    Write-LogMessage -Tenant $Tenant.defaultDomainName -TenantId $Tenant.customerId -API 'DomainAnalyser' -message 'GetTenantDomains loop error' -sev 'Error' -LogData (Get-CippException -Exception $_)
                }
            }
        } catch {
            #Write-Host (Get-CippException -Exception $_ | ConvertTo-Json)
            Write-LogMessage -Tenant $Tenant.defaultDomainName -TenantId $Tenant.customerId -API 'DomainAnalyser' -message 'DNS Analyser GraphGetRequest' -LogData (Get-CippException -Exception $_) -sev Error
        }
    }
    return $null
}
#EndRegion './Public/Entrypoints/Activity Triggers/Domain Analyser/Push-DomainAnalyserTenant.ps1' 152
#Region './Public/Entrypoints/Activity Triggers/Domain Analyser/Push-GetDomainAnalyserResults.ps1' -1

function Push-GetDomainAnalyserResults {
    [CmdletBinding()]
    param (
        $Item
    )

    $Tenant = $Item.Parameters.Tenant
    $Results = if ($Item.Results -is [array]) { $Item.Results } else { @($Item.Results) }
    $DomainCount = $Results | Measure-Object | Select-Object -ExpandProperty Count

    # Create summary for logging
    $Summary = [system.collections.generic.list[object]]::new()
    $Results | ForEach-Object {
        $Summary.Add([PSCustomObject]@{
                Domain     = $_.Domain
                Score      = "$($_.Score)/$($_.MaximumScore)"
                Percentage = "$($_.ScorePercentage)%"
            }
        )
    }

    $Message = "Domain Analyser completed for $DomainCount domain(s) in tenant $($Tenant.defaultDomainName)"
    Write-LogMessage -API 'DomainAnalyser' -Tenant $Tenant.defaultDomainName -TenantId $Tenant.customerId -message $Message -sev Info -LogData $Summary

    return
}
#EndRegion './Public/Entrypoints/Activity Triggers/Domain Analyser/Push-GetDomainAnalyserResults.ps1' 27
#Region './Public/Entrypoints/Activity Triggers/Domain Analyser/Push-GetTenantDomains.ps1' -1

function Push-GetTenantDomains {
    Param($Item)
    $DomainTable = Get-CippTable -tablename 'Domains'
    $Filter = "PartitionKey eq 'TenantDomains' and TenantGUID eq '{0}'" -f $Item.TenantGUID
    $Domains = Get-CIPPAzDataTableEntity @DomainTable -Filter $Filter -Property PartitionKey, RowKey | Select-Object RowKey, @{n = 'FunctionName'; exp = { 'DomainAnalyserDomain' } }
    return @($Domains)
}
#EndRegion './Public/Entrypoints/Activity Triggers/Domain Analyser/Push-GetTenantDomains.ps1' 8
#Region './Public/Entrypoints/Activity Triggers/Graph Requests/Push-ListGraphRequestQueue.ps1' -1

function Push-ListGraphRequestQueue {
    <#
    .FUNCTIONALITY
    Entrypoint
    #>
    param($Item)

    Write-Information "PowerShell durable function processed work item: $($Item.Endpoint) - $($Item.TenantFilter)"

    try {
        $ParamCollection = [System.Web.HttpUtility]::ParseQueryString([String]::Empty)

        $Parameters = $Item.Parameters | ConvertTo-Json -Depth 5 | ConvertFrom-Json -AsHashtable
        foreach ($Param in ($Parameters.GetEnumerator() | Sort-Object -CaseSensitive -Property Key)) {
            $ParamCollection.Add($Param.Key, $Param.Value)
        }

        $PartitionKey = $Item.PartitionKey

        $TableName = ('cache{0}' -f ($Item.Endpoint -replace '[^A-Za-z0-9]'))[0..62] -join ''
        Write-Information "Queue Table: $TableName"
        $Table = Get-CIPPTable -TableName $TableName

        $Filter = "PartitionKey eq '{0}' and (RowKey eq '{1}' or OriginalEntityId eq '{1}')" -f $PartitionKey, $Item.TenantFilter
        Write-Information "Filter: $Filter"
        $Existing = Get-CIPPAzDataTableEntity @Table -Filter $Filter -Property PartitionKey, RowKey, OriginalEntityId
        if ($Existing) {
            $null = Remove-AzDataTableEntity -Force @Table -Entity $Existing
        }
        $GraphRequestParams = @{
            TenantFilter                = $Item.TenantFilter
            Endpoint                    = $Item.Endpoint
            Parameters                  = $Parameters
            NoPagination                = $Item.NoPagination
            ReverseTenantLookupProperty = $Item.ReverseTenantLookupProperty
            ReverseTenantLookup         = $Item.ReverseTenantLookup
            AsApp                       = $Item.AsApp ?? $false
            Caller                      = 'Push-ListGraphRequestQueue'
            SkipCache                   = $true
        }

        $RawGraphRequest = try {
            $Results = Get-GraphRequestList @GraphRequestParams
            if ($Results[-1].PSObject.Properties.Name -contains 'nextLink') {
                $Results | Select-Object -First ($Results.Count - 1)
            } else {
                $Results
            }
        } catch {
            $CippException = Get-CippException -Exception $_.Exception
            [PSCustomObject]@{
                Tenant        = $Item.TenantFilter
                CippStatus    = "Could not connect to tenant. $($CippException.NormalizedMessage)"
                CippException = [string]($CippException | ConvertTo-Json -Depth 10 -Compress)
            }
        }
        $Json = ConvertTo-Json -Depth 10 -Compress -InputObject $RawGraphRequest
        $GraphResults = [PSCustomObject]@{
            PartitionKey = [string]$PartitionKey
            RowKey       = [string]$Item.TenantFilter
            QueueId      = [string]$Item.QueueId
            QueueType    = [string]$Item.QueueType
            Data         = [string]$Json
        }
        Add-CIPPAzDataTableEntity @Table -Entity $GraphResults -Force | Out-Null
        return $true
    } catch {
        Write-Warning "Queue Error: $($_.Exception.Message)"
        #Write-Information ($GraphResults | ConvertTo-Json -Depth 10 -Compress)
        throw $_
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Graph Requests/Push-ListGraphRequestQueue.ps1' 73
#Region './Public/Entrypoints/Activity Triggers/Mailbox Permissions/Push-GetCalendarPermissionsBatch.ps1' -1

function Push-GetCalendarPermissionsBatch {
    <#
    .SYNOPSIS
        Process a batch of calendar permission queries

    .DESCRIPTION
        Queries calendar permissions for a batch of mailboxes using bulk Exchange
        requests. Splits into two phases:
          Phase 1: Bulk Get-MailboxFolderStatistics for cache-miss mailboxes
          Phase 2: Bulk Get-MailboxFolderPermission for all mailboxes
        Uses a folder name cache to skip Phase 1 on subsequent runs.

    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $TenantFilter = $Item.TenantFilter
    $Mailboxes = $Item.Mailboxes
    $BatchNumber = $Item.BatchNumber
    $TotalBatches = $Item.TotalBatches

    try {
        Write-Information "Processing calendar permissions batch $BatchNumber of $TotalBatches for tenant $TenantFilter with $($Mailboxes.Count) mailboxes"

        # Load cached calendar folder names for this tenant
        $FolderCacheTable = Get-CippTable -tablename 'CalendarFolderCache'
        $CachedFolders = @{}
        try {
            $CacheEntries = Get-CIPPAzDataTableEntity @FolderCacheTable -Filter "PartitionKey eq '$TenantFilter'"
            foreach ($Entry in $CacheEntries) {
                $CachedFolders[$Entry.RowKey] = $Entry.FolderName
            }
            Write-Information "CAL Cached Folders count is $($CachedFolders.Count)"
        } catch {
            Write-Information "Could not load folder name cache for $TenantFilter, will discover all folder names"
        }

        # Separate mailboxes into cache hits and misses
        $CacheMissMailboxes = [System.Collections.Generic.List[string]]::new()
        $FolderNameMap = @{}

        foreach ($MailboxUPN in $Mailboxes) {
            $FolderName = $CachedFolders[$MailboxUPN]
            if ($FolderName) {
                $FolderNameMap[$MailboxUPN] = $FolderName
            } else {
                $CacheMissMailboxes.Add($MailboxUPN)
            }
        }

        Write-Information "Cache hits: $($FolderNameMap.Count), cache misses: $($CacheMissMailboxes.Count)"

        # Phase 1: Bulk discover calendar folder names for cache misses
        if ($CacheMissMailboxes.Count -gt 0) {
            $FolderStatsRequests = foreach ($MailboxUPN in $CacheMissMailboxes) {
                @{
                    CmdletInput   = @{
                        CmdletName = 'Get-MailboxFolderStatistics'
                        Parameters = @{
                            Identity    = $MailboxUPN
                            FolderScope = 'Calendar'
                        }
                    }
                    OperationGuid = $MailboxUPN
                }
            }

            Write-Information "Phase 1: Bulk Get-MailboxFolderStatistics for $($CacheMissMailboxes.Count) mailboxes"
            $FolderStatsResults = New-ExoBulkRequest -tenantid $TenantFilter -cmdletArray @($FolderStatsRequests)

            $NewCacheEntries = [System.Collections.Generic.List[hashtable]]::new()
            foreach ($Result in $FolderStatsResults) {
                if ($Result.error) {
                    Write-Information "Failed to get folder stats for $($Result.OperationGuid): $($Result.error)"
                    continue
                }
                $MailboxUPN = $Result.OperationGuid
                $FolderName = $Result.name
                if ($MailboxUPN -and $FolderName) {
                    $FolderNameMap[$MailboxUPN] = $FolderName
                    $NewCacheEntries.Add(@{
                            PartitionKey = $TenantFilter
                            RowKey       = $MailboxUPN
                            FolderName   = $FolderName
                        })
                }
            }

            # Persist newly discovered folder names to cache
            if ($NewCacheEntries.Count -gt 0) {
                try {
                    Add-CIPPAzDataTableEntity @FolderCacheTable -Entity $NewCacheEntries -Force
                    Write-Information "Cached $($NewCacheEntries.Count) new calendar folder names for $TenantFilter"
                } catch {
                    Write-Information "Failed to write folder name cache for $TenantFilter : $($_.Exception.Message)"
                }
            }
        }

        # Phase 2: Bulk get calendar permissions for all mailboxes with known folder names
        $PermissionRequests = foreach ($MailboxUPN in $Mailboxes) {
            $FolderName = $FolderNameMap[$MailboxUPN]
            if ($FolderName) {
                @{
                    CmdletInput   = @{
                        CmdletName = 'Get-MailboxFolderPermission'
                        Parameters = @{
                            Identity = "$($MailboxUPN):\$($FolderName)"
                        }
                    }
                    OperationGuid = $MailboxUPN
                }
            } else {
                Write-Information "Skipping $MailboxUPN - no calendar folder name available"
            }
        }

        $AllCalendarPermissions = [System.Collections.Generic.List[object]]::new()

        if ($PermissionRequests) {
            Write-Information "Phase 2: Bulk Get-MailboxFolderPermission for $(@($PermissionRequests).Count) mailboxes"
            $PermissionResults = New-ExoBulkRequest -tenantid $TenantFilter -cmdletArray @($PermissionRequests) -useSystemMailbox $true

            foreach ($Perm in $PermissionResults) {
                if ($Perm.error) {
                    Write-Information "Failed to get calendar permissions for $($Perm.OperationGuid): $($Perm.error)"
                    continue
                }
                $AccessStr = if ($Perm.AccessRights -is [array]) { $Perm.AccessRights -join ',' } else { $Perm.AccessRights }
                $AllCalendarPermissions.Add([PSCustomObject]@{
                        id           = "CAL-$($Perm.Identity)-$($Perm.User)-$AccessStr"
                        Identity     = $Perm.Identity
                        User         = $Perm.User
                        AccessRights = $Perm.AccessRights
                        FolderName   = $Perm.FolderName
                    })
            }
        }

        Write-Information "Completed calendar permissions batch $BatchNumber of $TotalBatches - processed $($Mailboxes.Count) mailboxes: $($AllCalendarPermissions.Count) permissions (cache hits: $($FolderNameMap.Count - $NewCacheEntries.Count), misses: $($CacheMissMailboxes.Count))"

        return @{
            'Get-MailboxFolderPermission' = $AllCalendarPermissions
        }

    } catch {
        $ErrorMsg = "Failed to process calendar permissions batch $BatchNumber of $TotalBatches for tenant $TenantFilter : $($_.Exception.Message)"
        Write-Information "ERROR in Push-GetCalendarPermissionsBatch: $ErrorMsg"
        Write-Information "Stack trace: $($_.ScriptStackTrace)"
        Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message $ErrorMsg -sev Error
        throw $ErrorMsg
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Mailbox Permissions/Push-GetCalendarPermissionsBatch.ps1' 155
#Region './Public/Entrypoints/Activity Triggers/Mailbox Permissions/Push-GetMailboxPermissionsBatch.ps1' -1

function Push-GetMailboxPermissionsBatch {
    <#
    .SYNOPSIS
        Process a batch of mailbox permission queries

    .DESCRIPTION
        Queries mailbox permissions for a batch of mailboxes and stores in the reporting database

    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $TenantFilter = $Item.TenantFilter
    $Mailboxes = $Item.Mailboxes
    $MailboxData = @($Item.MailboxData)
    $BatchNumber = $Item.BatchNumber
    $TotalBatches = $Item.TotalBatches

    try {
        Write-Information "Processing batch $BatchNumber of $TotalBatches for tenant $TenantFilter with $($Mailboxes.Count) mailboxes"
        Write-Information "Mailbox UPNs in batch: $($Mailboxes -join ', ')"

        # Build bulk requests for this batch (2 queries per mailbox: MailboxPermission + RecipientPermission)
        # Calendar permissions require locale-specific folder names and will be collected separately if needed
        $ExoBulkRequests = foreach ($MailboxUPN in $Mailboxes) {
            @{
                CmdletInput = @{
                    CmdletName = 'Get-MailboxPermission'
                    Parameters = @{ Identity = $MailboxUPN }
                }
            }
            @{
                CmdletInput = @{
                    CmdletName = 'Get-RecipientPermission'
                    Parameters = @{ Identity = $MailboxUPN }
                }
            }
        }

        Write-Information "Built $($ExoBulkRequests.Count) bulk requests for batch $BatchNumber"

        # Execute bulk request for this batch with ReturnWithCommand to separate permission types
        $MailboxPermissions = New-ExoBulkRequest -cmdletArray @($ExoBulkRequests) -tenantid $TenantFilter -ReturnWithCommand $true

        Write-Information "Bulk request completed. Result type: $($MailboxPermissions.GetType().Name)"
        if ($MailboxPermissions -is [hashtable]) {
            Write-Information "Result keys: $($MailboxPermissions.Keys -join ', ')"
            if ($MailboxPermissions['Get-MailboxPermission']) {
                Write-Information "Sample MailboxPermission: $($MailboxPermissions['Get-MailboxPermission'][0] | ConvertTo-Json -Depth 2 -Compress)"
            }
            if ($MailboxPermissions['Get-RecipientPermission']) {
                Write-Information "Sample RecipientPermission: $($MailboxPermissions['Get-RecipientPermission'][0] | ConvertTo-Json -Depth 2 -Compress)"
            }
        }

        # Normalize MailboxPermission results
        if ($MailboxPermissions['Get-MailboxPermission']) {
            $NormalizedMailboxPerms = foreach ($Perm in $MailboxPermissions['Get-MailboxPermission']) {
                $AccessStr = if ($Perm.AccessRights -is [array]) { $Perm.AccessRights -join ',' } else { $Perm.AccessRights }
                [PSCustomObject]@{
                    id           = "MBP-$($Perm.Identity)-$($Perm.User)-$AccessStr"
                    Identity     = $Perm.Identity
                    User         = $Perm.User
                    AccessRights = $Perm.AccessRights
                    IsInherited  = $Perm.IsInherited
                    Deny         = $Perm.Deny
                }
            }
            $MailboxPermissions['Get-MailboxPermission'] = $NormalizedMailboxPerms
        }

        # Normalize the results - RecipientPermission uses 'Trustee' instead of 'User'
        if ($MailboxPermissions['Get-RecipientPermission']) {
            $NormalizedRecipientPerms = foreach ($Perm in $MailboxPermissions['Get-RecipientPermission']) {
                $UserVal = if ($Perm.Trustee) { $Perm.Trustee } else { $Perm.User }
                $AccessStr = if ($Perm.AccessRights -is [array]) { $Perm.AccessRights -join ',' } else { $Perm.AccessRights }
                [PSCustomObject]@{
                    id           = "RCP-$($Perm.Identity)-$UserVal-$AccessStr"
                    Identity     = $Perm.Identity
                    User         = $UserVal
                    AccessRights = $Perm.AccessRights
                    IsInherited  = $Perm.IsInherited
                    Deny         = $Perm.Deny
                }
            }
            $MailboxPermissions['Get-RecipientPermission'] = $NormalizedRecipientPerms
        }

        $MailboxIdentityLookup = @{}
        foreach ($MappedMailbox in ($MailboxData | Where-Object { $_.Id -and $_.UPN })) {
            $MailboxIdentityLookup[[string]$MappedMailbox.Id] = [string]$MappedMailbox.UPN
        }

        # Normalize SendOnBehalf permissions from passed mailbox metadata
        $NormalizedSendOnBehalfPerms = foreach ($Mailbox in ($MailboxData | Where-Object { $_.GrantSendOnBehalfTo -and ($Mailboxes -contains $_.UPN) })) {
            foreach ($Delegate in (@($Mailbox.GrantSendOnBehalfTo) | Where-Object { $_ -and $MailboxIdentityLookup.ContainsKey([string]$_) })) {
                $DelegateUPN = $MailboxIdentityLookup[[string]$Delegate]
                [PSCustomObject]@{
                    id           = "SOB-$($Mailbox.UPN)-$DelegateUPN"
                    Identity     = $Mailbox.UPN
                    User         = $DelegateUPN
                    AccessRights = @('SendOnBehalf')
                    IsInherited  = $false
                    Deny         = $false
                }
            }
        }
        $MailboxPermissions['Get-Mailbox'] = @($NormalizedSendOnBehalfPerms)

        $MailboxPermCount = if ($MailboxPermissions['Get-MailboxPermission']) { $MailboxPermissions['Get-MailboxPermission'].Count } else { 0 }
        $RecipientPermCount = if ($MailboxPermissions['Get-RecipientPermission']) { $MailboxPermissions['Get-RecipientPermission'].Count } else { 0 }
        $SendOnBehalfPermCount = if ($MailboxPermissions['Get-Mailbox']) { $MailboxPermissions['Get-Mailbox'].Count } else { 0 }

        Write-Information "Completed batch $BatchNumber of $TotalBatches - processed $($Mailboxes.Count) mailboxes: $MailboxPermCount mailbox permissions, $RecipientPermCount recipient permissions, $SendOnBehalfPermCount send-on-behalf permissions"

        # Return results to be aggregated by post-execution function
        return $MailboxPermissions

    } catch {
        $ErrorMsg = "Failed to process batch $BatchNumber of $TotalBatches for tenant $TenantFilter : $($_.Exception.Message)"
        Write-Information "ERROR in Push-GetMailboxPermissionsBatch: $ErrorMsg"
        Write-Information "Stack trace: $($_.ScriptStackTrace)"
        Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message $ErrorMsg -sev Error
        throw $ErrorMsg
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Mailbox Permissions/Push-GetMailboxPermissionsBatch.ps1' 128
#Region './Public/Entrypoints/Activity Triggers/Mailbox Permissions/Push-StoreMailboxPermissions.ps1' -1

function Push-StoreMailboxPermissions {
    <#
    .SYNOPSIS
        Post-execution function to aggregate and store all mailbox and calendar permissions

    .DESCRIPTION
        Collects results from all batches and stores them in the reporting database

    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)

    $TenantFilter = $Item.Parameters.TenantFilter
    $Results = $Item.Results

    try {
        Write-Information "Storing mailbox and calendar permissions for tenant $TenantFilter"
        Write-Information "Received $($Results.Count) batch results"

        # Log each result for debugging
        for ($i = 0; $i -lt $Results.Count; $i++) {
            $result = $Results[$i]
            Write-Information "Result $i type: $($result.GetType().Name), value: $($result | ConvertTo-Json -Depth 2 -Compress)"
        }

        # Aggregate results by command type from all batches
        $AllMailboxPermissions = [System.Collections.Generic.List[object]]::new()
        $AllRecipientPermissions = [System.Collections.Generic.List[object]]::new()
        $AllSendOnBehalfPermissions = [System.Collections.Generic.List[object]]::new()
        $AllCalendarPermissions = [System.Collections.Generic.List[object]]::new()

        foreach ($BatchResult in $Results) {
            # Activity functions may return an array [hashtable, "status message"]
            # Extract the actual hashtable if result is an array
            $ActualResult = $BatchResult
            if ($BatchResult -is [array] -and $BatchResult.Count -gt 0) {
                Write-Information "Result is array with $($BatchResult.Count) elements, extracting first element"
                $ActualResult = $BatchResult[0]
            }

            if ($ActualResult -and ($ActualResult -is [hashtable] -or $ActualResult -is [System.Collections.IDictionary])) {
                Write-Information "Processing hashtable result with keys: $($ActualResult.Keys -join ', ')"
                # Results are grouped by cmdlet name due to ReturnWithCommand
                if ($ActualResult['Get-MailboxPermission']) {
                    $MailboxPerms = @($ActualResult['Get-MailboxPermission'])
                    Write-Information "Adding $($MailboxPerms.Count) mailbox permissions"
                    $AllMailboxPermissions.AddRange($MailboxPerms)
                }
                if ($ActualResult['Get-RecipientPermission']) {
                    $RecipientPerms = @($ActualResult['Get-RecipientPermission'])
                    Write-Information "Adding $($RecipientPerms.Count) recipient permissions"
                    $AllRecipientPermissions.AddRange($RecipientPerms)
                }
                if ($ActualResult['Get-Mailbox']) {
                    $SendOnBehalfRows = @($ActualResult['Get-Mailbox'])
                    Write-Information "Adding $($SendOnBehalfRows.Count) send-on-behalf permissions"
                    $AllSendOnBehalfPermissions.AddRange($SendOnBehalfRows)
                }
                if ($ActualResult['Get-MailboxFolderPermission']) {
                    $CalendarPerms = @($ActualResult['Get-MailboxFolderPermission'])
                    Write-Information "Adding $($CalendarPerms.Count) calendar permissions"
                    $AllCalendarPermissions.AddRange($CalendarPerms)
                }
            } else {
                Write-Information "Skipping non-hashtable result: $($ActualResult.GetType().Name)"
            }
        }

        # Combine all permissions (mailbox and recipient) into a single collection
        $AllPermissions = [System.Collections.Generic.List[object]]::new()
        $AllPermissions.AddRange($AllMailboxPermissions)
        $AllPermissions.AddRange($AllRecipientPermissions)
        $AllPermissions.AddRange($AllSendOnBehalfPermissions)

        Write-Information "Aggregated $($AllPermissions.Count) total permissions ($($AllMailboxPermissions.Count) mailbox + $($AllRecipientPermissions.Count) recipient + $($AllSendOnBehalfPermissions.Count) send-on-behalf)"
        Write-Information "Aggregated $($AllCalendarPermissions.Count) calendar permissions"

        # Store all permissions together as MailboxPermissions
        if ($AllPermissions.Count -gt 0) {
            $AllPermissions | Add-CIPPDbItem -TenantFilter $TenantFilter -Type 'MailboxPermissions' -AddCount
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message "Cached $($AllPermissions.Count) mailbox permission records" -sev Info
        } else {
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message 'No mailbox permissions found to cache' -sev Info
        }

        # Store calendar permissions separately
        if ($AllCalendarPermissions.Count -gt 0) {
            $AllCalendarPermissions | Add-CIPPDbItem -TenantFilter $TenantFilter -Type 'CalendarPermissions' -AddCount
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message "Cached $($AllCalendarPermissions.Count) calendar permission records" -sev Info
        } else {
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message 'No calendar permissions found to cache' -sev Info
        }

        return

    } catch {
        $ErrorMsg = "Failed to store mailbox permissions for tenant $TenantFilter : $($_.Exception.Message)"
        Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message $ErrorMsg -sev Error
        throw $ErrorMsg
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Mailbox Permissions/Push-StoreMailboxPermissions.ps1' 104
#Region './Public/Entrypoints/Activity Triggers/Maintenance/Push-TableCleanupTask.ps1' -1

function Push-TableCleanupTask {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param (
        [Parameter(Mandatory = $true)]
        $Item
    )

    $Type = $Item.Type
    Write-Information "#### Starting $($Type) task..."
    if ($PSCmdlet.ShouldProcess('Start-TableCleanup', 'Starting Table Cleanup')) {
        if ($Type -eq 'DeleteTable') {
            $DeleteTables = $Item.Tables
            foreach ($Table in $DeleteTables) {
                try {
                    $Table = Get-CIPPTable -tablename $Table
                    if ($Table) {
                        Write-Information "Deleting table $($Table.Context.TableName)"
                        try {
                            Remove-AzDataTable -Context $Table.Context -Force
                        } catch {
                            #Write-LogMessage -API 'TableCleanup' -message "Failed to delete table $($Table.Context.TableName)" -sev Error -LogData (Get-CippException -Exception $_)
                        }
                    }
                } catch {
                    Write-Information "Table $Table not found"
                }
            }
            Write-Information "#### $($Type) task complete for $($Item.TableName)"
        } elseif ($Type -eq 'CleanupRule') {
            if ($Item.Where) {
                $Where = [scriptblock]::Create($Item.Where)
            } else {
                $Where = { $true }
            }

            $DataTableProps = $Item.DataTableProps | ConvertTo-Json | ConvertFrom-Json -AsHashtable
            $Table = Get-CIPPTable -tablename $Item.TableName
            $CleanupCompleted = $false

            $RowsRemoved = 0
            do {
                Write-Information "Fetching entities from $($Item.TableName) with filter: $($DataTableProps.Filter)"
                try {
                    $Entities = Get-AzDataTableEntity @Table @DataTableProps | Where-Object $Where
                    if ($Entities) {
                        Write-Information "Removing $($Entities.Count) entities from $($Item.TableName)"
                        try {
                            Remove-AzDataTableEntity @Table -Entity $Entities -Force
                            $RowsRemoved += $Entities.Count
                            if ($DataTableProps.First -and $Entities.Count -lt $DataTableProps.First) {
                                $CleanupCompleted = $true
                            }
                        } catch {
                            Write-LogMessage -API 'TableCleanup' -message "Failed to remove entities from $($Item.TableName)" -sev Error -LogData (Get-CippException -Exception $_)
                            $CleanupCompleted = $true
                        }
                    } else {
                        Write-Information "No entities found for cleanup in $($Item.TableName)"
                        $CleanupCompleted = $true
                    }
                } catch {
                    Write-Warning "Failed to fetch entities from $($Item.TableName): $($_.Exception.Message)"
                    $CleanupCompleted = $true
                }
            } while (!$CleanupCompleted)
            Write-Information "#### $($Type) task complete for $($Item.TableName). Rows removed: $RowsRemoved"
        } else {
            Write-Warning "Unknown task type: $Type"
        }
    }

}
#EndRegion './Public/Entrypoints/Activity Triggers/Maintenance/Push-TableCleanupTask.ps1' 73
#Region './Public/Entrypoints/Activity Triggers/Push-CIPPAccessTenantTest.ps1' -1

function Push-CIPPAccessTenantTest {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    Param($Item)

    Test-CIPPAccessTenant -Tenant $Item.customerId -Headers 'CIPP'
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-CIPPAccessTenantTest.ps1' 10
#Region './Public/Entrypoints/Activity Triggers/Push-CIPPDBCacheApplyBatch.ps1' -1

function Push-CIPPDBCacheApplyBatch {
    <#
    .SYNOPSIS
        Aggregate cache tasks from all tenants and start a flat execution orchestrator (Phase 2)

    .DESCRIPTION
        PostExecution function for the DBCache pipeline. Receives aggregated results from the
        per-tenant CIPPDBCacheData list activities, flattens them into a single batch, and starts
        one orchestrator to execute all cache collection tasks across all tenants in parallel.

    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    try {
        # Aggregate all cache tasks from all tenant list activities
        $AllTasks = [System.Collections.Generic.List[object]]::new()

        foreach ($TenantResult in $Item.Results) {
            foreach ($Batch in $TenantResult) {
                foreach ($Task in $Batch) {
                    if ($Task -and $Task.FunctionName) {
                        $AllTasks.Add($Task)
                    }
                }
            }
        }

        if ($AllTasks.Count -eq 0) {
            Write-Information 'No cache tasks to execute across all tenants'
            return @{ Success = $true; TaskCount = 0 }
        }

        Write-Information "Aggregated $($AllTasks.Count) cache tasks from all tenants"

        # Start a single flat orchestrator to execute all cache tasks
        $InputObject = [PSCustomObject]@{
            OrchestratorName = 'CIPPDBCacheExecute'
            Batch            = @($AllTasks)
            SkipLog          = $true
        }

        # Add test run post-execution if flagged
        if ($Item.Parameters -and $Item.Parameters.TestRun -eq $true -and $Item.Parameters.TenantFilter) {
            $InputObject | Add-Member -NotePropertyName PostExecution -NotePropertyValue @{
                FunctionName = 'CIPPDBTestsRun'
                Parameters   = @{
                    TenantFilter = $Item.Parameters.TenantFilter
                }
            }
        }

        $InstanceId = Start-CIPPOrchestrator -InputObject $InputObject
        Write-Information "Started flat cache execution orchestrator with ID = '$InstanceId' for $($AllTasks.Count) tasks"

        return @{
            Success    = $true
            TaskCount  = $AllTasks.Count
            InstanceId = $InstanceId
        }

    } catch {
        Write-Warning "Error in DBCache apply batch aggregation: $($_.Exception.Message)"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-CIPPDBCacheApplyBatch.ps1' 68
#Region './Public/Entrypoints/Activity Triggers/Push-CIPPDBCacheData.ps1' -1

function Push-CIPPDBCacheData {
    <#
    .SYNOPSIS
        List cache collection tasks for a single tenant (Phase 1 of fan-out/fan-in)

    .DESCRIPTION
        Checks tenant license capabilities and returns a list of grouped cache collection work items.
        Each item represents one collection type (Graph, ExchangeConfig, ExchangeData, etc.) that
        will run all its cache functions sequentially within a single activity invocation.

        This grouped approach reduces activity count from ~50-67 per tenant down to ~2-6 per tenant,
        dramatically cutting orchestrator replay overhead and table storage I/O.

        Does NOT start sub-orchestrators. The returned items are aggregated by the PostExecution
        function (CIPPDBCacheApplyBatch) and executed in a single flat orchestrator.

    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)
    Write-Host "Building cache task list for tenant: $($Item.TenantFilter)"
    $TenantFilter = $Item.TenantFilter
    $QueueId = $Item.QueueId

    try {
        # Check tenant capabilities for license-specific features
        $IntuneCapable = $false
        try {
            $IntuneCapable = Test-CIPPStandardLicense -StandardName 'IntuneLicenseCheck' -TenantFilter $TenantFilter -RequiredCapabilities @('INTUNE_A', 'MDM_Services', 'EMS', 'SCCM', 'MICROSOFTINTUNEPLAN1') -SkipLog
        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message "Intune license check failed: $($_.Exception.Message)" -sev Warning -LogData $ErrorMessage
        }

        $ConditionalAccessCapable = $false
        try {
            $ConditionalAccessCapable = Test-CIPPStandardLicense -StandardName 'ConditionalAccessLicenseCheck' -TenantFilter $TenantFilter -RequiredCapabilities @('AAD_PREMIUM', 'AAD_PREMIUM_P2') -SkipLog
        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message "Conditional Access license check failed: $($_.Exception.Message)" -sev Warning -LogData $ErrorMessage
        }

        $AzureADPremiumP2Capable = $false
        try {
            $AzureADPremiumP2Capable = Test-CIPPStandardLicense -StandardName 'AzureADPremiumP2LicenseCheck' -TenantFilter $TenantFilter -RequiredCapabilities @('AAD_PREMIUM_P2') -SkipLog
        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message "Azure AD Premium P2 license check failed: $($_.Exception.Message)" -sev Warning -LogData $ErrorMessage
        }

        $ExchangeCapable = $false
        try {
            $ExchangeCapable = Test-CIPPStandardLicense -StandardName 'ExchangeLicenseCheck' -TenantFilter $TenantFilter -RequiredCapabilities @('EXCHANGE_S_STANDARD', 'EXCHANGE_S_ENTERPRISE', 'EXCHANGE_S_STANDARD_GOV', 'EXCHANGE_S_ENTERPRISE_GOV', 'EXCHANGE_LITE') -SkipLog
        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message "Exchange license check failed: $($_.Exception.Message)" -sev Warning -LogData $ErrorMessage
        }

        $ComplianceCapable = $false
        try {
            $ComplianceCapable = Test-CIPPStandardLicense -StandardName 'ComplianceLicenseCheck' -TenantFilter $TenantFilter -RequiredCapabilities @('RMS_S_PREMIUM', 'RMS_S_PREMIUM2', 'MIP_S_CLP1', 'MIP_S_CLP2') -SkipLog
        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message "Compliance license check failed: $($_.Exception.Message)" -sev Warning -LogData $ErrorMessage
        }

        Write-Information "License capabilities for $TenantFilter - Intune: $IntuneCapable, CA: $ConditionalAccessCapable, P2: $AzureADPremiumP2Capable, Exchange: $ExchangeCapable, Compliance: $ComplianceCapable"

        # Build grouped collection tasks — one activity per license category instead of one per cache type
        $Tasks = [System.Collections.Generic.List[object]]::new()

        # CopilotUsage always runs — endpoints return empty when no Copilot licenses are in use
        $Tasks.Add(@{
                FunctionName   = 'ExecCIPPDBCache'
                CollectionType = 'CopilotUsage'
                TenantFilter   = $TenantFilter
                QueueId        = $QueueId
                QueueName      = "DB Cache CopilotUsage - $TenantFilter"
            })

        # Graph collection always runs (no special license needed) — 25 cache types in one activity
        $Tasks.Add(@{
                FunctionName   = 'ExecCIPPDBCache'
                CollectionType = 'Graph'
                TenantFilter   = $TenantFilter
                QueueId        = $QueueId
                QueueName      = "DB Cache Graph - $TenantFilter"
            })
        # MFAState runs as its own activity — it makes 6+ API calls, bulk group/role member
        # resolution, and O(users × policies) CPU work that can take minutes on large tenants
        $Tasks.Add(@{
                FunctionName = 'ExecCIPPDBCache'
                Name         = 'MFAState'
                TenantFilter = $TenantFilter
                QueueId      = $QueueId
                QueueName    = "DB Cache MFAState - $TenantFilter"
            })

        # Exchange collections — split into config (quick policy calls), data (usage reports), and mailboxes (heavy, spawns permission/rule child orchestrators)
        if ($ExchangeCapable) {
            $Tasks.Add(@{
                    FunctionName   = 'ExecCIPPDBCache'
                    CollectionType = 'ExchangeConfig'
                    TenantFilter   = $TenantFilter
                    QueueId        = $QueueId
                    QueueName      = "DB Cache ExchangeConfig - $TenantFilter"
                })
            $Tasks.Add(@{
                    FunctionName   = 'ExecCIPPDBCache'
                    CollectionType = 'ExchangeData'
                    TenantFilter   = $TenantFilter
                    QueueId        = $QueueId
                    QueueName      = "DB Cache ExchangeData - $TenantFilter"
                })
            # Mailboxes runs as its own activity — it's heavy (fetches all mailboxes) and spawns
            # child orchestrators for permission/calendar/rules batching that need their own time
            $Tasks.Add(@{
                    FunctionName = 'ExecCIPPDBCache'
                    Name         = 'Mailboxes'
                    TenantFilter = $TenantFilter
                    QueueId      = $QueueId
                    QueueName    = "DB Cache Mailboxes - $TenantFilter"
                })
        } else {
            Write-Host "Skipping Exchange Online data collection for $TenantFilter - no required license"
        }

        if ($ConditionalAccessCapable) {
            $Tasks.Add(@{
                    FunctionName   = 'ExecCIPPDBCache'
                    CollectionType = 'ConditionalAccess'
                    TenantFilter   = $TenantFilter
                    QueueId        = $QueueId
                    QueueName      = "DB Cache ConditionalAccess - $TenantFilter"
                })
        } else {
            Write-Host "Skipping Conditional Access data collection for $TenantFilter - no required license"
        }

        if ($AzureADPremiumP2Capable) {
            $Tasks.Add(@{
                    FunctionName   = 'ExecCIPPDBCache'
                    CollectionType = 'IdentityProtection'
                    TenantFilter   = $TenantFilter
                    QueueId        = $QueueId
                    QueueName      = "DB Cache IdentityProtection - $TenantFilter"
                })
        } else {
            Write-Host "Skipping Azure AD Premium P2 data collection for $TenantFilter - no required license"
        }

        if ($IntuneCapable) {
            $Tasks.Add(@{
                    FunctionName   = 'ExecCIPPDBCache'
                    CollectionType = 'Intune'
                    TenantFilter   = $TenantFilter
                    QueueId        = $QueueId
                    QueueName      = "DB Cache Intune - $TenantFilter"
                })
        } else {
            Write-Host "Skipping Intune data collection for $TenantFilter - no required license"
        }

        if ($ComplianceCapable) {
            $Tasks.Add(@{
                    FunctionName   = 'ExecCIPPDBCache'
                    CollectionType = 'Compliance'
                    TenantFilter   = $TenantFilter
                    QueueId        = $QueueId
                    QueueName      = "DB Cache Compliance - $TenantFilter"
                })
        } else {
            Write-Host "Skipping Compliance data collection for $TenantFilter - no required license"
        }

        Write-Information "Built $($Tasks.Count) grouped cache tasks for tenant $TenantFilter (down from individual per-type tasks)"

        # Return the task list — the PostExecution function will aggregate and start a flat orchestrator
        return @($Tasks)

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message "Failed to build cache task list: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        return @()
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-CIPPDBCacheData.ps1' 188
#Region './Public/Entrypoints/Activity Triggers/Push-CIPPOffboardingComplete.ps1' -1

function Push-CIPPOffboardingComplete {
    <#
    .SYNOPSIS
        Post-execution handler for offboarding orchestration completion

    .DESCRIPTION
        Updates the scheduled task state when offboarding completes

    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)

    $TaskInfo = $Item.Parameters.TaskInfo
    $TenantFilter = $Item.Parameters.TenantFilter
    $Username = $Item.Parameters.Username
    $Headers = $Item.Parameters.Headers
    $Results = $Item.Results  # Results come from orchestrator, not Parameters

    try {
        Write-Information "Completing offboarding orchestration for $Username in tenant $TenantFilter"
        Write-Information "Raw results from orchestrator: $($Results | ConvertTo-Json -Depth 10)"

        # Flatten nested arrays from orchestrator results
        # Activity functions may return arrays like [result, "status message"]
        $FlattenedResults = @(
            foreach ($BatchResult in $Results) {
                if ($BatchResult -is [array] -and $BatchResult.Count -gt 0) {
                    Write-Information "Result is array with $($BatchResult.Count) elements, extracting elements"
                    # Output all elements from the array
                    foreach ($element in $BatchResult) {
                        if ($null -ne $element -and $element -ne '') {
                            $element
                        }
                    }
                } elseif ($null -ne $BatchResult -and $BatchResult -ne '') {
                    # Single item - output it
                    $BatchResult
                }
            }
        )

        # Process results in the same way as Push-ExecScheduledCommand
        if ($FlattenedResults.Count -eq 0) {
            $ProcessedResults = "Offboarding completed successfully for $Username"
        } else {
            Write-Information "Processing $($FlattenedResults.Count) flattened results: $($FlattenedResults | ConvertTo-Json -Depth 10)"

            # Normalize results format
            if ($FlattenedResults -is [string]) {
                $ProcessedResults = @{ Results = $FlattenedResults }
            } elseif ($FlattenedResults -is [array]) {
                # Filter and process string or resultText items
                $StringResults = $FlattenedResults | Where-Object { $_ -is [string] -or $_.resultText -is [string] }
                if ($StringResults) {
                    $ProcessedResults = $StringResults | ForEach-Object {
                        $Message = if ($_ -is [string]) { $_ } else { $_.resultText }
                        @{ Results = $Message }
                    }
                } else {
                    # Keep structured results as-is
                    $ProcessedResults = $FlattenedResults
                }
            } else {
                $ProcessedResults = $FlattenedResults
            }
        }

        Write-Information "Results after processing: $($ProcessedResults | ConvertTo-Json -Depth 10)"

        # Prepare results for storage
        if ($ProcessedResults -is [string]) {
            $StoredResults = $ProcessedResults
        } else {
            $ProcessedResults = $ProcessedResults | Select-Object * -ExcludeProperty RowKey, PartitionKey
            $StoredResults = $ProcessedResults | ConvertTo-Json -Compress -Depth 20 | Out-String
        }

        if ($TaskInfo) {
            # Update scheduled task to completed state
            $Table = Get-CippTable -tablename 'ScheduledTasks'
            $currentUnixTime = [int64](([datetime]::UtcNow) - (Get-Date '1/1/1970')).TotalSeconds

            # Check if results are too large and need separate storage
            if ($StoredResults.Length -gt 64000) {
                Write-Information 'Results exceed 64KB limit. Storing in ScheduledTaskResults table.'
                $TaskResultsTable = Get-CippTable -tablename 'ScheduledTaskResults'
                $TaskResults = @{
                    PartitionKey = $TaskInfo.RowKey
                    RowKey       = $TenantFilter
                    Results      = [string](ConvertTo-Json -Compress -Depth 20 $ProcessedResults)
                }
                $null = Add-CIPPAzDataTableEntity @TaskResultsTable -Entity $TaskResults -Force
                $StoredResults = @{ Results = 'Offboarding completed, details are available in the More Info pane' } | ConvertTo-Json -Compress
            }

            $null = Update-AzDataTableEntity -Force @Table -Entity @{
                PartitionKey = $TaskInfo.PartitionKey
                RowKey       = $TaskInfo.RowKey
                Results      = "$StoredResults"
                ExecutedTime = "$currentUnixTime"
                TaskState    = 'Completed'
            }

            Write-LogMessage -API 'Offboarding' -tenant $TenantFilter -message "Offboarding completed successfully for $Username" -sev Info -headers $Headers

            # Send post-execution alerts if configured
            if ($TaskInfo.PostExecution -and $ProcessedResults) {
                Send-CIPPScheduledTaskAlert -Results $ProcessedResults -TaskInfo $TaskInfo -TenantFilter $TenantFilter -TaskType 'User Offboarding'
            }
        }
        Write-LogMessage -API 'Offboarding' -tenant $TenantFilter -message "Offboarding completed for $Username" -sev Info -headers $Headers
        return "Offboarding completed for $Username"

    } catch {
        $ErrorMsg = "Failed to complete offboarding for $Username : $($_.Exception.Message)"
        Write-LogMessage -API 'Offboarding' -tenant $TenantFilter -message $ErrorMsg -sev Error -headers $Headers -LogData (Get-CippException -Exception $_)
        throw $ErrorMsg
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-CIPPOffboardingComplete.ps1' 122
#Region './Public/Entrypoints/Activity Triggers/Push-CIPPOffboardingTask.ps1' -1

function Push-CIPPOffboardingTask {
    <#
    .SYNOPSIS
        Generic wrapper to execute individual offboarding task cmdlets

    .DESCRIPTION
        Executes the specified cmdlet with the provided parameters as part of user offboarding

    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)

    $Cmdlet = $Item.Cmdlet
    $Parameters = $Item.Parameters | ConvertTo-Json -Depth 5 | ConvertFrom-Json -AsHashtable

    try {
        Write-Information "Executing offboarding cmdlet: $Cmdlet"

        # Check if cmdlet exists
        $CmdletInfo = Get-Command -Name $Cmdlet -Module CIPPCore -ErrorAction SilentlyContinue
        if (-not $CmdletInfo) {
            throw "Cmdlet $Cmdlet does not exist"
        }

        # Execute the cmdlet with splatting
        $Result = & $Cmdlet @Parameters

        Write-Information "Completed $Cmdlet successfully"
        return $Result

    } catch {
        $ErrorMsg = "Failed to execute $Cmdlet : $($_.Exception.Message)"
        Write-Information $ErrorMsg
        return $ErrorMsg
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-CIPPOffboardingTask.ps1' 39
#Region './Public/Entrypoints/Activity Triggers/Push-ExecAddMultiTenantApp.ps1' -1

function Push-ExecAddMultiTenantApp {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)
    try {
        $Item = $Item | ConvertTo-Json -Depth 10 | ConvertFrom-Json
        Write-Host "$($Item | ConvertTo-Json -Depth 10)"
        $ServicePrincipalList = New-GraphGETRequest -uri "https://graph.microsoft.com/beta/servicePrincipals?`$select=AppId,id,displayName&`$top=999" -tenantid $Item.Tenant
        if ($Item.AppId -Notin $ServicePrincipalList.appId) {
            $PostResults = New-GraphPostRequest 'https://graph.microsoft.com/beta/servicePrincipals' -type POST -tenantid $Item.tenant -body "{ `"appId`": `"$($Item.appId)`" }"
            Write-LogMessage -message "Added $($Item.AppId) to tenant $($Item.Tenant)" -tenant $Item.Tenant -API 'Add Multitenant App' -sev Info
        } else {
            Write-LogMessage -message "This app already exists in tenant $($Item.Tenant). We're adding the required permissions." -tenant $Item.Tenant -API 'Add Multitenant App' -sev Info
        }
        Add-CIPPApplicationPermission -RequiredResourceAccess ($Item.applicationResourceAccess) -ApplicationId $Item.AppId -Tenantfilter $Item.Tenant
        Add-CIPPDelegatedPermission -RequiredResourceAccess ($Item.DelegateResourceAccess) -ApplicationId $Item.AppId -Tenantfilter $Item.Tenant
    } catch {
        Write-LogMessage -message "Error adding application to tenant $($Item.Tenant) - $($_.Exception.Message)" -tenant $Item.Tenant -API 'Add Multitenant App' -sev Error
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecAddMultiTenantApp.ps1' 24
#Region './Public/Entrypoints/Activity Triggers/Push-ExecAlertsListAllTenants.ps1' -1

function Push-ExecAlertsListAllTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)

    $Tenant = Get-Tenants -TenantFilter $Item.customerId
    $domainName = $Tenant.defaultDomainName
    $Table = Get-CIPPTable -TableName 'cachealertsandincidents'

    try {
        $Alerts = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/security/alerts' -tenantid $domainName
        foreach ($Alert in $Alerts) {
            $GUID = (New-Guid).Guid
            $alertJson = $Alert | ConvertTo-Json
            $GraphRequest = @{
                Alert        = [string]$alertJson
                RowKey       = [string]$GUID
                Tenant       = $domainName
                PartitionKey = 'alert'
            }
            Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null
        }

    } catch {
        $GUID = (New-Guid).Guid
        $AlertText = ConvertTo-Json -InputObject @{
            Title             = "Could not connect to tenant to retrieve data: $($_.Exception.Message)"
            Id                = ''
            Category          = ''
            EventDateTime     = ''
            Severity          = ''
            Status            = ''
            userStates        = @('None')
            vendorInformation = @{
                vendor   = 'CIPP'
                provider = 'CIPP'
            }
        }
        $GraphRequest = @{
            Alert        = [string]$AlertText
            RowKey       = [string]$GUID
            PartitionKey = 'alert'
            Tenant       = $domainName
        }
        Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecAlertsListAllTenants.ps1' 51
#Region './Public/Entrypoints/Activity Triggers/Push-ExecAppApprovalTemplate.ps1' -1

function Push-ExecAppApprovalTemplate {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    try {
        $Item = $Item | ConvertTo-Json -Depth 10 | ConvertFrom-Json
        $TemplateId = $Item.templateId
        if (!$TemplateId) {
            Write-LogMessage -message 'No template specified' -tenant $Item.Tenant -API 'Add Multitenant App' -sev Error
            return $false
        }

        # Get the template data to determine if it's a Gallery Template or Enterprise App
        $Table = Get-CIPPTable -TableName 'templates'
        $Template = Get-CIPPAzDataTableEntity @Table -Filter "PartitionKey eq 'AppApprovalTemplate' and RowKey eq '$TemplateId'"

        if (!$Template) {
            Write-LogMessage -message "Template $TemplateId not found" -tenant $Item.Tenant -API 'Add Multitenant App' -sev Error
            return $false
        }

        $TemplateData = $Template.JSON | ConvertFrom-Json
        # Default to EnterpriseApp for backward compatibility with older templates
        $AppType = $TemplateData.AppType
        if (-not $AppType) {
            $AppType = 'EnterpriseApp'
        }

        # Handle Gallery Templates
        if ($AppType -eq 'GalleryTemplate') {
            Write-Information "Deploying Gallery Template $($TemplateData.AppName) to tenant $($Item.Tenant)."

            # Use the Gallery Template instantiation API
            $GalleryTemplateId = $TemplateData.GalleryTemplateId
            if (!$GalleryTemplateId) {
                Write-LogMessage -message 'Gallery Template ID not found in template data' -tenant $Item.Tenant -API 'Add Multitenant App' -sev Error
                return $false
            }

            # Check if the app already exists in the tenant
            $ServicePrincipalList = New-GraphGETRequest -uri "https://graph.microsoft.com/beta/servicePrincipals?`$select=AppId,id,displayName&`$top=999" -tenantid $Item.Tenant
            if ($TemplateData.GalleryTemplateId -in $ServicePrincipalList.applicationTemplateId) {
                Write-LogMessage -message "Gallery Template app $($TemplateData.AppName) already exists in tenant $($Item.Tenant)" -tenant $Item.Tenant -API 'Add Gallery App' -sev Info
                return $true
            }

            # Instantiate the gallery template
            $InstantiateBody = @{
                displayName = $TemplateData.AppName
            } | ConvertTo-Json -Depth 10

            $InstantiateResult = New-GraphPostRequest -uri "https://graph.microsoft.com/beta/applicationTemplates/$GalleryTemplateId/instantiate" -type POST -tenantid $Item.tenant -body $InstantiateBody

            if ($InstantiateResult.application.appId) {
                Write-LogMessage -message "Successfully deployed Gallery Template $($TemplateData.AppName) to tenant $($Item.Tenant). Application ID: $($InstantiateResult.application.appId)" -tenant $Item.Tenant -API 'Add Gallery App' -sev Info
                # Get application registration
                $App = $InstantiateResult.application.appId
                $Application = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/applications(appId='$App')" -tenantid $Item.tenant -AsApp $true
                if ($Application.requiredResourceAccess) {
                    Add-CIPPDelegatedPermission -RequiredResourceAccess $Application.requiredResourceAccess -ApplicationId $App -Tenantfilter $Item.Tenant
                    Add-CIPPApplicationPermission -RequiredResourceAccess $Application.requiredResourceAccess -ApplicationId $App -Tenantfilter $Item.Tenant
                }
                if ($TemplateData.IncludeInEnterpriseAppList -and $InstantiateResult.servicePrincipal.id) {
                    $null = New-GraphPostRequest -uri "https://graph.microsoft.com/beta/servicePrincipals/$($InstantiateResult.servicePrincipal.id)" -type PATCH -tenantid $Item.Tenant -body '{"tags":["WindowsAzureActiveDirectoryIntegratedApp"]}'
                }
            } else {
                Write-LogMessage -message "Gallery Template deployment completed but application ID not returned for $($TemplateData.AppName) in tenant $($Item.Tenant)" -tenant $Item.Tenant -API 'Add Gallery App' -sev Warning
            }

        } elseif ($AppType -eq 'ApplicationManifest') {
            Write-Information "Deploying Application Manifest $($TemplateData.AppName) to tenant $($Item.Tenant)."

            # Get the application manifest from template data
            $ApplicationManifest = $TemplateData.ApplicationManifest
            if (!$ApplicationManifest) {
                Write-LogMessage -message 'Application Manifest not found in template data' -tenant $Item.Tenant -API 'Add Multitenant App' -sev Error
                return $false
            }

            $ForbiddenManifestProperties = @('keyCredentials', 'passwordCredentials')
            $ManifestProperties = @($ApplicationManifest.PSObject.Properties.Name)
            $ForbiddenPropertiesFound = @($ForbiddenManifestProperties | Where-Object { $_ -in $ManifestProperties })
            if ($ForbiddenPropertiesFound.Count -gt 0) {
                try {
                    $SanitizedManifest = $ApplicationManifest | ConvertTo-Json -Depth 20 | ConvertFrom-Json
                    foreach ($Property in $ForbiddenPropertiesFound) {
                        $SanitizedManifest.PSObject.Properties.Remove($Property)
                    }

                    $ApplicationManifest = $SanitizedManifest
                    $TemplateData.ApplicationManifest = $SanitizedManifest

                    $Table.Force = $true
                    Add-CIPPAzDataTableEntity @Table -Entity @{
                        JSON         = [string]($TemplateData | ConvertTo-Json -Depth 20 -Compress)
                        RowKey       = "$($Template.RowKey)"
                        PartitionKey = 'AppApprovalTemplate'
                    } | Out-Null
                } catch {
                    $ErrorMessage = Get-CippException -Exception $_
                    Write-LogMessage -message "Failed to sanitize and persist manifest template '$TemplateId': $($ErrorMessage.NormalizedError)" -tenant $Item.Tenant -API 'Add App Manifest' -sev Error -LogData $ErrorMessage
                }
            }

            # Check for existing application by display name
            $ServicePrincipalList = New-GraphGETRequest -uri "https://graph.microsoft.com/beta/servicePrincipals?`$select=AppId,id,displayName&`$top=999" -tenantid $Item.Tenant
            $ExistingApp = $ServicePrincipalList | Where-Object { $_.displayName -eq $TemplateData.AppName }
            if ($ExistingApp) {
                Write-LogMessage -message "Application with name '$($TemplateData.AppName)' already exists in tenant $($Item.Tenant)" -tenant $Item.Tenant -API 'Add App Manifest' -sev Info

                # get existing application
                $App = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/applications(appId='$($ExistingApp.appId)')" -tenantid $Item.Tenant

                # compare permissions
                $ExistingPermissions = $App.requiredResourceAccess | ConvertTo-Json -Depth 10
                $NewPermissions = $ApplicationManifest.requiredResourceAccess | ConvertTo-Json -Depth 10
                if ($ExistingPermissions -ne $NewPermissions) {
                    Write-LogMessage -message "Updating permissions for existing application '$($TemplateData.AppName)' in tenant $($Item.Tenant)" -tenant $Item.Tenant -API 'Add App Manifest' -sev Info

                    # Update permissions for existing application
                    $UpdateBody = @{
                        requiredResourceAccess = $ApplicationManifest.requiredResourceAccess
                    } | ConvertTo-Json -Depth 10
                    $null = New-GraphPostRequest -type PATCH -uri "https://graph.microsoft.com/beta/applications(appId='$($ExistingApp.appId)')" -tenantid $Item.Tenant -body $UpdateBody

                    # consent new permissions
                    Add-CIPPDelegatedPermission -RequiredResourceAccess $ApplicationManifest.requiredResourceAccess -ApplicationId $ExistingApp.appId -Tenantfilter $Item.Tenant
                    Add-CIPPApplicationPermission -RequiredResourceAccess $ApplicationManifest.requiredResourceAccess -ApplicationId $ExistingApp.appId -Tenantfilter $Item.Tenant
                }

                return $true
            }

            $PropertiesToRemove = @('appId', 'id', 'createdDateTime', 'deletedDateTime', 'createdByAppId', 'publisherDomain', 'servicePrincipalLockConfiguration', 'identifierUris', 'applicationIdUris', 'keyCredentials', 'passwordCredentials')

            # Strip tenant-specific data that might cause conflicts
            $CleanManifest = $ApplicationManifest | ConvertTo-Json -Depth 10 | ConvertFrom-Json
            foreach ($Property in $PropertiesToRemove) {
                $CleanManifest.PSObject.Properties.Remove($Property)
            }

            # Create the application from manifest
            try {
                $CreateBody = $CleanManifest | ConvertTo-Json -Depth 10
                $CreatedApp = New-GraphPostRequest -uri 'https://graph.microsoft.com/beta/applications' -type POST -tenantid $Item.tenant -body $CreateBody

                if ($CreatedApp.appId) {
                    # Create service principal for the application
                    $ServicePrincipalBody = @{ appId = $CreatedApp.appId }
                    if ($TemplateData.IncludeInEnterpriseAppList) {
                        $ServicePrincipalBody.tags = @('WindowsAzureActiveDirectoryIntegratedApp')
                    }
                    $null = New-GraphPostRequest -uri 'https://graph.microsoft.com/beta/servicePrincipals' -type POST -tenantid $Item.tenant -body ($ServicePrincipalBody | ConvertTo-Json)

                    Write-LogMessage -message "Successfully deployed Application Manifest $($TemplateData.AppName) to tenant $($Item.Tenant). Application ID: $($CreatedApp.appId)" -tenant $Item.Tenant -API 'Add App Manifest' -sev Info

                    if ($CreatedApp.requiredResourceAccess) {
                        Add-CIPPDelegatedPermission -RequiredResourceAccess $CreatedApp.requiredResourceAccess -ApplicationId $CreatedApp.appId -Tenantfilter $Item.Tenant
                        Add-CIPPApplicationPermission -RequiredResourceAccess $CreatedApp.requiredResourceAccess -ApplicationId $CreatedApp.appId -Tenantfilter $Item.Tenant
                    }
                } else {
                    Write-LogMessage -message "Application Manifest deployment failed - no application ID returned for $($TemplateData.AppName) in tenant $($Item.Tenant)" -tenant $Item.Tenant -API 'Add App Manifest' -sev Error
                }
            } catch {
                Write-LogMessage -message "Error creating application from manifest in tenant $($Item.Tenant) - $($_.Exception.Message)" -tenant $Item.Tenant -API 'Add App Manifest' -sev Error
                throw $_.Exception.Message
            }

        } else {
            # Handle Enterprise Apps (existing logic)
            $ServicePrincipalList = New-GraphGETRequest -uri "https://graph.microsoft.com/beta/servicePrincipals?`$select=AppId,id,displayName,tags&`$top=999" -tenantid $Item.Tenant
            if ($Item.AppId -notin $ServicePrincipalList.appId) {
                Write-Information "Adding $($Item.AppId) to tenant $($Item.Tenant)."
                $SpBody = [ordered]@{ appId = $Item.appId }
                if ($TemplateData.IncludeInEnterpriseAppList) {
                    $SpBody.tags = @('WindowsAzureActiveDirectoryIntegratedApp')
                }
                $PostResults = New-GraphPostRequest 'https://graph.microsoft.com/beta/servicePrincipals' -type POST -tenantid $Item.tenant -body ($SpBody | ConvertTo-Json)
                Write-LogMessage -message "Added $($Item.AppId) to tenant $($Item.Tenant)" -tenant $Item.Tenant -API 'Add Multitenant App' -sev Info
            } else {
                Write-LogMessage -message "This app already exists in tenant $($Item.Tenant). We're adding the required permissions." -tenant $Item.Tenant -API 'Add Multitenant App' -sev Info
                if ($TemplateData.IncludeInEnterpriseAppList) {
                    $ExistingSP = $ServicePrincipalList | Where-Object { $_.appId -eq $Item.AppId }
                    if ($ExistingSP -and 'WindowsAzureActiveDirectoryIntegratedApp' -notin $ExistingSP.tags) {
                        $UpdatedTags = @($ExistingSP.tags) + 'WindowsAzureActiveDirectoryIntegratedApp'
                        $null = New-GraphPostRequest -uri "https://graph.microsoft.com/beta/servicePrincipals/$($ExistingSP.id)" -type PATCH -tenantid $Item.Tenant -body (@{ tags = $UpdatedTags } | ConvertTo-Json)
                    }
                }
            }
            Add-CIPPApplicationPermission -TemplateId $TemplateId -Tenantfilter $Item.Tenant
            Add-CIPPDelegatedPermission -TemplateId $TemplateId -Tenantfilter $Item.Tenant
        }
    } catch {
        Write-LogMessage -message "Error adding application to tenant $($Item.Tenant) - $($_.Exception.Message)" -tenant $Item.Tenant -API 'Add Multitenant App' -sev Error
        Write-Error $_.Exception.Message
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecAppApprovalTemplate.ps1' 201
#Region './Public/Entrypoints/Activity Triggers/Push-ExecApplicationCopy.ps1' -1

function Push-ExecApplicationCopy {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)
    try {
        Write-Host "$($Item | ConvertTo-Json -Depth 10)"
        New-CIPPApplicationCopy -App $Item.AppId -Tenant $Item.Tenant
    } catch {
        Write-LogMessage -message "Error adding application to tenant $($Item.Tenant) - $($_.Exception.Message)" -tenant $Item.Tenant -API 'Add Multitenant App' -sev Error
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecApplicationCopy.ps1' 15
#Region './Public/Entrypoints/Activity Triggers/Push-ExecGDAPInviteQueue.ps1' -1

function Push-ExecGDAPInviteQueue {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    # Write out the queue message and metadata to the information log.
    Write-Host "PowerShell queue trigger function processed work item: $($Item.customer.displayName)"

    Set-CIPPGDAPInviteGroups -Relationship $Item
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecGDAPInviteQueue.ps1' 13
#Region './Public/Entrypoints/Activity Triggers/Push-ExecIncidentsListAllTenants.ps1' -1

function Push-ExecIncidentsListAllTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $Tenant = Get-Tenants -TenantFilter $Item.customerId
    $domainName = $Tenant.defaultDomainName
    $Table = Get-CIPPTable -TableName 'cachealertsandincidents'

    try {
        $incidents = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/security/incidents' -tenantid $domainName -AsApp $true
        $GraphRequest = foreach ($incident in $incidents) {
            $GUID = (New-Guid).Guid
            $GraphRequest = @{
                Incident     = [string]($incident | ConvertTo-Json -Depth 10)
                RowKey       = [string]$GUID
                PartitionKey = 'Incident'
                Tenant       = [string]$domainName
            }
            Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null
        }

    } catch {
        $GUID = (New-Guid).Guid
        $AlertText = ConvertTo-Json -InputObject @{
            Tenant         = $domainName
            displayName    = "Could not connect to Tenant: $($_.Exception.Message)"
            comments       = @{
                createdDateTime      = (Get-Date).ToString('s')
                createdbyDisplayName = 'CIPP'
                comment              = 'Could not connect'
            }
            classification = 'Unknown'
            determination  = 'Unknown'
            severity       = 'CIPP'
        }
        $GraphRequest = @{
            Incident     = [string]$AlertText
            RowKey       = [string]$GUID
            PartitionKey = 'Incident'
            Tenant       = [string]$domainName
        }
        Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null
    }
}

#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecIncidentsListAllTenants.ps1' 49
#Region './Public/Entrypoints/Activity Triggers/Push-ExecJITAdminListAllTenants.ps1' -1

function Push-ExecJITAdminListAllTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $Tenant = Get-Tenants -TenantFilter $Item.customerId
    $DomainName = $Tenant.defaultDomainName
    $Table = Get-CIPPTable -TableName CacheJITAdmin

    try {
        # Get schema extensions
        $Schema = Get-CIPPSchemaExtensions | Where-Object { $_.id -match '_cippUser' } | Select-Object -First 1

        # Query users with JIT Admin enabled using bulk request
        $BulkRequests = [System.Collections.Generic.List[object]]::new()
        $BulkRequests.Add(@{
                id     = 'users'
                method = 'GET'
                url    = "users?`$count=true&`$select=id,accountEnabled,displayName,userPrincipalName,$($Schema.id)&`$filter=$($Schema.id)/jitAdminEnabled eq true or $($Schema.id)/jitAdminEnabled eq false&`$top=999"
            })

        $BulkResults = New-GraphBulkRequest -tenantid $DomainName -Requests $BulkRequests
        $Users = ($BulkResults | Where-Object { $_.id -eq 'users' }).body.value | Where-Object { $_.id }

        if ($Users) {
            # Get role memberships
            $BulkRequests.Clear()
            foreach ($User in $Users) {
                $BulkRequests.Add(@{
                        id     = $User.id
                        method = 'GET'
                        url    = "users/$($User.id)/memberOf/microsoft.graph.directoryRole/?`$select=id,displayName"
                    })
            }
            # Ensure $BulkRequests is not empty or null before making the bulk request
            if ($BulkRequests -and $BulkRequests.Count -gt 0) {
                $RoleResults = New-GraphBulkRequest -tenantid $DomainName -Requests @($BulkRequests)

                # Format the data
                $Results = $Users | ForEach-Object {
                    $currentUser = $_ # Capture current user in the loop
                    $MemberOf = @() # Initialize as empty array
                    if ($RoleResults) {
                        $userRoleResult = $RoleResults | Where-Object -Property id -EQ $currentUser.id
                        if ($userRoleResult -and $userRoleResult.body -and $userRoleResult.body.value) {
                            $MemberOf = $userRoleResult.body.value | Select-Object displayName, id
                        }
                    }

                    $jitAdminData = $currentUser.($Schema.id)
                    $jitAdminEnabled = if ($jitAdminData -and $jitAdminData.PSObject.Properties['jitAdminEnabled']) { $jitAdminData.jitAdminEnabled } else { $false }
                    $jitAdminExpiration = if ($jitAdminData -and $jitAdminData.PSObject.Properties['jitAdminExpiration']) { $jitAdminData.jitAdminExpiration } else { $null }

                    [PSCustomObject]@{
                        id                 = $currentUser.id
                        displayName        = $currentUser.displayName
                        userPrincipalName  = $currentUser.userPrincipalName
                        accountEnabled     = $currentUser.accountEnabled
                        jitAdminEnabled    = $jitAdminEnabled
                        jitAdminExpiration = $jitAdminExpiration
                        memberOf           = ($MemberOf | ConvertTo-Json -Depth 5 -Compress)
                    }
                }

                # Add to Azure Table
                foreach ($result in $Results) {
                    $GUID = (New-Guid).Guid
                    Write-Host ($result | ConvertTo-Json -Depth 10 -Compress)
                    $GraphRequest = @{
                        JITAdminUser = [string]($result | ConvertTo-Json -Depth 10 -Compress)
                        RowKey       = [string]$GUID
                        PartitionKey = 'JITAdminUser'
                        Tenant       = [string]$DomainName
                        UserId       = [string]$result.id # Add UserId for easier querying if needed
                        UserUPN      = [string]$result.userPrincipalName # Add UserUPN for easier querying
                    }
                    Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null
                }
            } else {
                # No users with JIT Admin attributes found, or no users at all
                Write-Host "No JIT Admin users or no users found to process for tenant $DomainName."
            }
        } else {
            Write-Host "No users found for tenant $DomainName."
        }

    } catch {
        $GUID = (New-Guid).Guid
        $ErrorMessage = "Could not process JIT Admin users for Tenant: $($DomainName). Error: $($_.Exception.Message)"
        if ($_.ScriptStackTrace) {
            $ErrorMessage += " StackTrace: $($_.ScriptStackTrace)"
        }
        $ErrorJson = ConvertTo-Json -InputObject @{
            Tenant    = $DomainName
            Error     = $ErrorMessage
            Exception = ($_.Exception.Message | ConvertTo-Json -Depth 3 -Compress)
            Timestamp = (Get-Date).ToString('s')
        }
        $GraphRequest = @{
            JITAdminUser = [string]$ErrorJson
            RowKey       = [string]$GUID
            PartitionKey = 'JITAdminUser'
            Tenant       = [string]$DomainName
        }
        Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null
        Write-Error ('Error processing JIT Admin for {0}: {1}' -f $DomainName, $_.Exception.Message)
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecJITAdminListAllTenants.ps1' 111
#Region './Public/Entrypoints/Activity Triggers/Push-ExecMdoAlertsListAllTenants.ps1' -1

function Push-ExecMdoAlertsListAllTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $Tenant = Get-Tenants -TenantFilter $Item.customerId
    $domainName = $Tenant.defaultDomainName
    $Table = Get-CIPPTable -TableName 'cachealertsandincidents'

    try {
        # Get MDO alerts using the specific endpoint and filter
        $Alerts = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/security/alerts_v2?`$filter=serviceSource eq 'microsoftDefenderForOffice365'" -tenantid $domainName

        foreach ($Alert in $Alerts) {
            $GUID = (New-Guid).Guid
            $GraphRequest = @{
                MdoAlert     = [string]($Alert | ConvertTo-Json -Depth 10)
                RowKey       = [string]$GUID
                PartitionKey = 'MdoAlert'
                Tenant       = [string]$domainName
            }
            Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null
        }

    } catch {
        $GUID = (New-Guid).Guid
        $AlertText = ConvertTo-Json -InputObject @{
            Tenant          = $domainName
            displayName     = "Could not connect to Tenant: $($_.Exception.Message)"
            id              = ''
            severity        = 'CIPP'
            status          = 'Failed'
            createdDateTime = (Get-Date).ToString('s')
            category        = 'Unknown'
            description     = 'Could not connect'
            serviceSource   = 'microsoftDefenderForOffice365'
        }
        $GraphRequest = @{
            MdoAlert     = [string]$AlertText
            RowKey       = [string]$GUID
            PartitionKey = 'MdoAlert'
            Tenant       = [string]$domainName
        }
        Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecMdoAlertsListAllTenants.ps1' 49
#Region './Public/Entrypoints/Activity Triggers/Push-ExecOffboardingMailboxPermissions.ps1' -1

function Push-ExecOffboardingMailboxPermissions {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param(
        $Item
    )

    Remove-CIPPMailboxPermissions -PermissionsLevel @('FullAccess', 'SendAs', 'SendOnBehalf') -userid 'AllUsers' -AccessUser $Item.User -TenantFilter $Item.TenantFilter -APIName $Item.APINAME -Headers $Item.Headers
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecOffboardingMailboxPermissions.ps1' 12
#Region './Public/Entrypoints/Activity Triggers/Push-ExecOnboardTenantQueue.ps1' -1

function Push-ExecOnboardTenantQueue {
    <#
    .FUNCTIONALITY
    Entrypoint
    #>
    [CmdletBinding()]
    param($Item)
    try {
        $Id = $Item.id
        $Start = Get-Date
        $Logs = [System.Collections.Generic.List[object]]::new()
        $OnboardTable = Get-CIPPTable -TableName 'TenantOnboarding'
        $TenantOnboarding = Get-CIPPAzDataTableEntity @OnboardTable -Filter "RowKey eq '$Id'"

        $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = "Starting onboarding for relationship $Id" })
        $OnboardingSteps = $TenantOnboarding.OnboardingSteps | ConvertFrom-Json
        $OnboardingSteps.Step1.Status = 'running'
        $OnboardingSteps.Step1.Message = 'Checking GDAP invite status'
        $OnboardingSteps.Step2.Status = 'pending'
        $OnboardingSteps.Step2.Message = 'Waiting for Step 1'
        $OnboardingSteps.Step3.Status = 'pending'
        $OnboardingSteps.Step3.Message = 'Waiting for Step 2'
        $OnboardingSteps.Step4.Status = 'pending'
        $OnboardingSteps.Step4.Message = 'Waiting for Step 3'
        $OnboardingSteps.Step5.Status = 'pending'
        $OnboardingSteps.Step5.Message = 'Waiting for Step 4'
        $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
        $TenantOnboarding.Status = 'running'
        $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress -AsArray)
        Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop

        try {
            $Relationship = $TenantOnboarding.Relationship | ConvertFrom-Json -ErrorAction Stop
        } catch {
            $Relationship = ''
        }

        $ExpectedRoles = @(
            @{ Name = 'Application Administrator'; Id = '9b895d92-2cd3-44c7-9d02-a6ac2d5ea5c3' },
            @{ Name = 'User Administrator'; Id = 'fe930be7-5e62-47db-91af-98c3a49a38b1' },
            @{ Name = 'Intune Administrator'; Id = '3a2c62db-5318-420d-8d74-23affee5d9d5' },
            @{ Name = 'Exchange Administrator'; Id = '29232cdf-9323-42fd-ade2-1d097af3e4de' },
            @{ Name = 'Security Administrator'; Id = '194ae4cb-b126-40b2-bd5b-6091b380977d' },
            @{ Name = 'Cloud App Security Administrator'; Id = '892c5842-a9a6-463a-8041-72aa08ca3cf6' },
            @{ Name = 'Cloud Device Administrator'; Id = '7698a772-787b-4ac8-901f-60d6b08affd2' },
            @{ Name = 'Teams Administrator'; Id = '69091246-20e8-4a56-aa4d-066075b2a7a8' },
            @{ Name = 'SharePoint Administrator'; Id = 'f28a1f50-f6e7-4571-818b-6a12f2af6b6c' },
            @{ Name = 'Authentication Policy Administrator'; Id = '0526716b-113d-4c15-b2c8-68e3c22b9f80' },
            @{ Name = 'Privileged Role Administrator'; Id = 'e8611ab8-c189-46e8-94e1-60213ab1f814' },
            @{ Name = 'Privileged Authentication Administrator'; Id = '7be44c8a-adaf-4e2a-84d6-ab2649e08a13' },
            @{ Name = 'Billing Administrator'; Id = 'b0f54661-2d74-4c50-afa3-1ec803f12efe'; Optional = $true },
            @{ Name = 'Global Reader'; Id = 'f2ef992c-3afb-46b9-b7cf-a126ee74c451'; Optional = $true },
            @{ Name = 'Domain Name Administrator'; Id = '8329153b-31d0-4727-b945-745eb3bc5f31'; Optional = $true }
        )

        if ($OnboardingSteps.Step1.Status -ne 'succeeded') {
            $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Checking relationship status' })
            $x = 0
            do {
                $Relationship = New-GraphGetRequest -Uri "https://graph.microsoft.com/beta/tenantRelationships/delegatedAdminRelationships/$Id"
                $x++
                Start-Sleep -Seconds 30
            } while ($Relationship.status -ne 'active' -and $x -lt 6)

            if ($Relationship.status -eq 'active') {
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'GDAP Invite Accepted' })
                $OnboardingSteps.Step1.Status = 'succeeded'
                $OnboardingSteps.Step1.Message = "GDAP Invite accepted for $($Relationship.customer.displayName)"
                $TenantOnboarding.CustomerId = $Relationship.customer.tenantId
            } else {
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'GDAP Invite Failed' })
                $OnboardingSteps.Step1.Status = 'failed'
                $OnboardingSteps.Step1.Message = 'GDAP Invite timeout, retry onboarding after accepting the invite with a GA account in the customer tenant.'
                $TenantOnboarding.Status = 'failed'
            }
            $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
            $TenantOnboarding.Relationship = [string](ConvertTo-Json -InputObject $Relationship -Compress -Depth 10)
            $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
            Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
        }

        if ($OnboardingSteps.Step1.Status -eq 'succeeded') {
            $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Starting role check' })
            $OnboardingSteps.Step2.Status = 'running'
            $OnboardingSteps.Step2.Message = 'Checking role mapping'
            $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
            $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
            Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop

            $MissingRoles = [System.Collections.Generic.List[string]]::new()
            foreach ($Role in $ExpectedRoles) {
                $RoleFound = $false
                foreach ($AvailableRole in $Relationship.accessDetails.unifiedRoles) {
                    if ($AvailableRole.roleDefinitionId -eq $Role.Id) {
                        $RoleFound = $true
                        break
                    }
                }
                if (!$RoleFound) {
                    $MissingRoles.Add($Role.Name)
                }
            }
            if (($MissingRoles | Measure-Object).Count -gt 0) {
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Missing roles for relationship' })
                $RequiredMissingRoles = $ExpectedRoles | Where-Object { $_.Optional -ne $true -and $MissingRoles -contains $_.Name }
                if ($Item.IgnoreMissingRoles -ne $true -and ($RequiredMissingRoles | Measure-Object).Count -gt 0) {
                    $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = "Missing the following required roles: $($MissingRoles -join ', ')" })
                    $TenantOnboarding.Status = 'failed'
                    $OnboardingSteps.Step2.Status = 'failed'
                    $OnboardingSteps.Step2.Message = "Your GDAP relationship is missing the following roles: $($MissingRoles -join ', ')"
                } else {
                    $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Ignoring missing roles' })
                    $OnboardingSteps.Step2.Status = 'succeeded'
                    $OnboardingSteps.Step2.Message = "Your GDAP relationship is missing some roles, but the onboarding will continue. Missing roles: $($MissingRoles -join ', ')"
                }
            } else {
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Required roles found' })
                $OnboardingSteps.Step2.Status = 'succeeded'
                $OnboardingSteps.Step2.Message = 'Your GDAP relationship has the required roles'
            }
            $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
            $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
            Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
        }

        if ($OnboardingSteps.Step2.Status -eq 'succeeded') {
            $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Checking group mapping' })
            $AccessAssignments = New-GraphGetRequest -Uri "https://graph.microsoft.com/beta/tenantRelationships/delegatedAdminRelationships/$Id/accessAssignments"
            $AccessAssignments = $AccessAssignments | Where-Object { $_.status -notin @('deleted', 'deleting') }
            if ($AccessAssignments.id -and $Item.AutoMapRoles -ne $true) {
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Groups mapped' })
                $OnboardingSteps.Step3.Status = 'succeeded'
                $OnboardingSteps.Step3.Message = 'Your GDAP relationship already has mapped security groups'
            } else {
                $GroupSuccess = $false
                $OnboardingSteps.Step3.Status = 'running'
                $OnboardingSteps.Step3.Message = 'Mapping security groups'
                $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
                $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
                Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop

                $InviteTable = Get-CIPPTable -TableName 'GDAPInvites'
                $Invite = Get-CIPPAzDataTableEntity @InviteTable -Filter "RowKey eq '$Id'"

                if ($AccessAssignments.id -and !$Invite) {
                    $MissingRoles = [System.Collections.Generic.List[object]]::new()
                    $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Relationship has existing access assignments, checking for missing mappings' })

                    if ($Item.Roles -and $Item.AutoMapRoles -eq $true) {
                        foreach ($Role in $Item.Roles) {
                            if ($AccessAssignments.accessContainer.accessContainerid -notcontains $Role.GroupId -and $Relationship.accessDetails.unifiedRoles.roleDefinitionId -contains $Role.roleDefinitionId) {
                                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = "Adding missing group to relationship: $($Role.GroupName)" })
                                $MissingRoles.Add([PSCustomObject]$Role)
                            }
                        }

                        if (($MissingRoles | Measure-Object).Count -gt 0) {
                            $Invite = [PSCustomObject]@{
                                'PartitionKey' = 'invite'
                                'RowKey'       = $Id
                                'InviteUrl'    = 'https://admin.microsoft.com/AdminPortal/Home#/partners/invitation/granularAdminRelationships/{0}' -f $Id
                                'RoleMappings' = [string](@($MissingRoles) | ConvertTo-Json -Depth 10 -Compress)
                            }
                            Add-CIPPAzDataTableEntity @InviteTable -Entity $Invite
                        } else {
                            $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'All roles have been mapped to the M365 GDAP security groups' })
                            $OnboardingSteps.Step3.Status = 'succeeded'
                            $OnboardingSteps.Step3.Message = 'Groups mapped successfully'
                            $GroupSuccess = $true
                        }
                    }
                }

                if (!$AccessAssignments.id -and $Item.Roles) {
                    $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'No access assignments found, using defined role mapping.' })
                    $MatchingRoles = [System.Collections.Generic.List[object]]::new()
                    foreach ($Role in $Item.Roles) {
                        if ($Relationship.accessDetails.unifiedRoles.roleDefinitionId -contains $Role.roleDefinitionId) {
                            $MatchingRoles.Add([PSCustomObject]$Role)
                        }
                    }

                    if (($MatchingRoles | Measure-Object).Count -gt 0 -and $Item.AutoMapRoles -eq $true) {
                        $Invite = [PSCustomObject]@{
                            'PartitionKey' = 'invite'
                            'RowKey'       = $Id
                            'InviteUrl'    = 'https://admin.microsoft.com/AdminPortal/Home#/partners/invitation/granularAdminRelationships/{0}' -f $Id
                            'RoleMappings' = [string](@($MatchingRoles) | ConvertTo-Json -Depth 10 -Compress)
                        }
                        Add-CIPPAzDataTableEntity @InviteTable -Entity $Invite -Force
                        $GroupSuccess = $true
                    } else {
                        $TenantOnboarding.Status = 'failed'
                        $OnboardingSteps.Step3.Status = 'failed'
                        $OnboardingSteps.Step3.Message = 'No matching roles found, check the relationship and try again.'
                        $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
                        $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
                        Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
                        return
                    }
                }

                if ($Invite) {
                    $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'GDAP invite found, starting group/role mapping' })
                    $GroupMapStatus = Set-CIPPGDAPInviteGroups -Relationship $Relationship
                    if ($GroupMapStatus) {
                        $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Groups mapped successfully' })
                        $OnboardingSteps.Step3.Message = 'Groups mapped successfully, checking access assignment status'
                        $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
                        $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
                        Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop

                    } else {
                        $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Group mapping failed' })
                        $TenantOnboarding.Status = 'failed'
                        $OnboardingSteps.Step3.Status = 'failed'
                        $OnboardingSteps.Step3.Message = 'Group mapping failed, check the log book for details.'
                        $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
                        $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
                        Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
                        return
                    }
                } elseif (!$GroupSuccess) {
                    $TenantOnboarding.Status = 'failed'
                    $OnboardingSteps.Step3.Status = 'failed'
                    $OnboardingSteps.Step3.Message = 'Failed to map security groups, no pending invite available'
                }
            }

            do {
                $AccessAssignments = New-GraphGetRequest -Uri "https://graph.microsoft.com/beta/tenantRelationships/delegatedAdminRelationships/$Id/accessAssignments"
                $AccessAssignments = $AccessAssignments | Where-Object { $_.status -notin @('deleted', 'deleting') }
                Start-Sleep -Seconds 15
            } while ($AccessAssignments.status -contains 'pending' -and (Get-Date) -lt $Start.AddMinutes(8))

            if ($AccessAssignments.status -notcontains 'pending') {
                $OnboardingSteps.Step3.Message = 'Group check: Access assignments are mapped and active'
                $OnboardingSteps.Step3.Status = 'succeeded'

                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Checking for missing groups for SAM user' })
                $BulkRequests = @(
                    @{
                        id     = 'samUserId'
                        method = 'GET'
                        url    = "/me?`$select=id"
                    },
                    @{
                        id     = 'currentMemberships'
                        method = 'GET'
                        url    = "/me/transitiveMemberOf?`$select=id,displayName"
                    }
                )
                $BulkResults = New-GraphBulkRequest -Requests $BulkRequests -NoAuthCheck $true
                $SamUserId = ($BulkResults | Where-Object { $_.id -eq 'samUserId' }).body.id
                $CurrentMemberships = ($BulkResults | Where-Object { $_.id -eq 'currentMemberships' }).body.value
                $ExpectedCippRoles = $Item.Roles | Where-Object { $_.roleDefinitionId -in $ExpectedRoles.Id }

                # Build bulk requests for missing group memberships
                $GroupMembershipRequests = [System.Collections.Generic.List[object]]::new()
                $GroupMembershipLogs = [System.Collections.Generic.List[object]]::new()

                foreach ($Role in $ExpectedCippRoles) {
                    if ($CurrentMemberships.id -notcontains $Role.GroupId) {
                        $GroupMembershipRequests.Add(@{
                                id      = "addSamUser-$($Role.GroupId)"
                                method  = 'POST'
                                url     = "groups/$($Role.GroupId)/members/`$ref"
                                body    = @{
                                    '@odata.id' = 'https://graph.microsoft.com/v1.0/directoryObjects/{0}' -f $SamUserId
                                }
                                headers = @{
                                    'Content-Type' = 'application/json'
                                }
                            })
                        $GroupMembershipLogs.Add(@{
                                id        = "addSamUser-$($Role.GroupId)"
                                GroupName = $Role.GroupName
                            })
                    }
                }

                # Execute bulk group membership additions if any are needed
                if ($GroupMembershipRequests.Count -gt 0) {
                    $GroupMembershipResults = New-GraphBulkRequest -Requests $GroupMembershipRequests -AsApp $true -NoAuthCheck $true

                    foreach ($LogEntry in $GroupMembershipLogs) {
                        $Result = $GroupMembershipResults | Where-Object { $_.id -eq $LogEntry.id }
                        if ($Result.status -match '^2[0-9]+') {
                            $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = "Added SAM user to $($LogEntry.GroupName)" })
                        } else {
                            $ErrorMessage = if ($Result.body.error.message) { $Result.body.error.message } else { 'Unknown error' }
                            $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = "Failed to add SAM user to $($LogEntry.GroupName) - $ErrorMessage" })
                        }
                    }
                }
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'SAM user group check completed' })
            } else {
                $OnboardingSteps.Step3.Message = 'Group check: Access assignments are still pending, try again later'
                $OnboardingSteps.Step3.Status = 'failed'
                $TenantOnboarding.Status = 'failed'
                Write-LogMessage -API 'Onboarding' -message "Tenant onboarding failed at group mapping step for $($Relationship.customer.displayName)" -Sev 'Error'
            }

            $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
            $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
            Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
        }

        if ($OnboardingSteps.Step3.Status -eq 'succeeded') {
            # Check if the relationship was recently activated — Microsoft propagation may not have settled yet
            if ($Relationship.activatedDateTime) {
                try {
                    $ActivatedTimeUtc = ([DateTimeOffset]$Relationship.activatedDateTime).UtcDateTime
                    $MinutesSinceActivation = ([datetime]::UtcNow - $ActivatedTimeUtc).TotalMinutes
                    if ($MinutesSinceActivation -lt 15) {
                        $RetryAtUtc = [Cronos.CronExpression]::Parse('* * * * *').GetNextOccurrence([DateTime]::UtcNow.AddMinutes(15), [TimeZoneInfo]::Utc)
                        $RetryEpoch = ([DateTimeOffset]$RetryAtUtc).ToUnixTimeSeconds()
                        $RetryDelayMinutes = ($RetryAtUtc - [DateTime]::UtcNow).TotalMinutes
                        $MinutesSinceActivationDisplay = ('{0:N1}' -f $MinutesSinceActivation)
                        $RetryDelayMinutesDisplay = ('{0:N1}' -f $RetryDelayMinutes)
                        $RetryLogMessage = "GDAP relationship was activated $MinutesSinceActivationDisplay minutes ago. Rescheduling onboarding in $RetryDelayMinutesDisplay minutes to allow Microsoft propagation to settle."
                        $Logs.Add([PSCustomObject]@{
                            Date = (Get-Date).ToUniversalTime()
                                Log  = $RetryLogMessage
                        })
                        $RetryParams = [PSCustomObject]@{
                            Item = [PSCustomObject]@{
                                id                         = $Item.id
                                Roles                      = $Item.Roles
                                AutoMapRoles               = $Item.AutoMapRoles
                                IgnoreMissingRoles         = $Item.IgnoreMissingRoles
                                StandardsExcludeAllTenants = $Item.StandardsExcludeAllTenants
                            }
                        }
                        $RetryTask = [PSCustomObject]@{
                            Name          = "GDAP Onboarding retry: $($Relationship.customer.displayName)"
                            Command       = [PSCustomObject]@{ value = 'Push-ExecOnboardTenantQueue' }
                            Parameters    = $RetryParams
                            TenantFilter  = $env:TenantID
                            Recurrence    = ''
                            ScheduledTime = $RetryEpoch
                        }
                        $null = Add-CIPPScheduledTask -Task $RetryTask -DesiredStartTime ([string]$RetryEpoch)
                        $RetryMessage = "Rescheduled: GDAP relationship was activated $MinutesSinceActivationDisplay minutes ago. Retrying in $RetryDelayMinutesDisplay minutes to allow Microsoft propagation to settle."
                        $OnboardingSteps.Step4.Status = 'pending'
                        $OnboardingSteps.Step4.Message = $RetryMessage
                        $TenantOnboarding.Status = 'running'
                        $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
                        $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
                        Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
                        Write-LogMessage -API 'Onboarding' -message $RetryMessage -Sev 'Info'
                        return
                    }
                } catch {
                    Write-Warning "Failed to check activatedDateTime for relationship ${Id}: $($_.Exception.Message)"
                }
            }

            $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Setting up CPV consent' })
            $OnboardingSteps.Step4.Status = 'running'
            $OnboardingSteps.Step4.Message = 'Setting up CPV consent'
            $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
            $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
            Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop

            $ExcludedTenant = Get-Tenants -SkipList | Where-Object { $_.customerId -eq $Relationship.customer.tenantId }
            $IsExcluded = ($ExcludedTenant | Measure-Object).Count -gt 0
            if ($IsExcluded) {
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = ('Tenant is excluded from CIPP, onboarding cannot continue. Remove the exclusion from "{0}" ({1})' -f $ExcludedTenant.displayName, $ExcludedTenant.customerId) })
                $TenantOnboarding.Status = 'failed'
                $OnboardingSteps.Step4.Status = 'failed'
                $OnboardingSteps.Step4.Message = 'Tenant excluded from CIPP, remove the exclusion and retry onboarding.'
            } else {
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Clearing tenant cache' })
                $y = 0
                do {
                    $Tenant = Get-Tenants -TriggerRefresh -TenantFilter $Relationship.customer.tenantId | Select-Object -First 1
                    $y++
                    Start-Sleep -Seconds 20
                } while (!$Tenant -and $y -le 10)

                if ($Tenant) {
                    $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Tenant found in customer list' })
                    try {
                        $CPVConsentParams = @{
                            TenantFilter = $Relationship.customer.tenantId
                        }
                        $Consent = Set-CIPPCPVConsent @CPVConsentParams
                        if ($Consent -match 'Could not add our Service Principal to the client tenant') {
                            throw
                        }
                        $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Added initial CPV consent permissions' })
                    } catch {
                        $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = ('CPV Consent Failed, error: {0}' -f $Consent) })
                        $TenantOnboarding.Status = 'failed'
                        $OnboardingSteps.Step4.Status = 'failed'
                        $OnboardingSteps.Step4.Message = 'CPV Consent failed, check the logs for more details.'
                        $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
                        $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
                        Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
                        Write-LogMessage -API 'Onboarding' -message "Tenant onboarding failed at CPV step for $($Relationship.customer.displayName)" -Sev 'Error'
                        return
                    }
                    $Refreshing = $true
                    $CPVSuccess = $false
                    $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Refreshing CPV permissions' })
                    $OnboardingSteps.Step4.Message = 'Refreshing CPV permissions'
                    $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
                    $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
                    Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
                    $LastCPVError = ''
                    do {
                        try {
                            Add-CIPPApplicationPermission -RequiredResourceAccess 'CIPPDefaults' -ApplicationId $env:ApplicationID -TenantFilter $Relationship.customer.tenantId
                            Add-CIPPDelegatedPermission -RequiredResourceAccess 'CIPPDefaults' -ApplicationId $env:ApplicationID -TenantFilter $Relationship.customer.tenantId
                            $CPVSuccess = $true
                            $Refreshing = $false
                        } catch {
                            $LastCPVError = $_.Exception.Message
                            Start-Sleep -Seconds 30
                        }
                    } while ($Refreshing -and (Get-Date) -lt $Start.AddMinutes(8))

                    if ($CPVSuccess) {
                        $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'CPV permissions refreshed' })
                        $OnboardingSteps.Step4.Status = 'succeeded'
                        $OnboardingSteps.Step4.Message = 'CPV permissions refreshed'
                        if ($Tenant.defaultDomainName -match 'Domain Error') {
                            $Tenant = Get-Tenants -TriggerRefresh -IncludeAll | Where-Object { $_.customerId -eq $Relationship.customer.tenantId } | Select-Object -First 1
                        }
                    } else {
                        $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'CPV permissions failed to refresh. {0}' -f $LastCPVError })
                        $TenantOnboarding.Status = 'failed'
                        $OnboardingSteps.Step4.Status = 'failed'
                        $OnboardingSteps.Step4.Message = 'CPV permissions failed to refresh, check the logs for more details.'
                    }
                } else {
                    $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Tenant not found' })
                    $TenantOnboarding.Status = 'failed'
                    $OnboardingSteps.Step4.Status = 'failed'
                    $OnboardingSteps.Step4.Message = 'Tenant not found in customer list, try again later'
                }
            }
            $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
            $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
            Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
        }

        if ($OnboardingSteps.Step4.Status -eq 'succeeded') {
            if ($Item.StandardsExcludeAllTenants -eq $true) {
                $GroupTable = Get-CIPPTable -tablename 'TenantGroups'
                $MembersTable = Get-CIPPTable -tablename 'TenantGroupMembers'
                $ExclusionGroupName = 'Excluded onboarded tenants'

                # Find existing exclusion group
                $ExclusionGroup = Get-CIPPAzDataTableEntity @GroupTable -Filter "PartitionKey eq 'TenantGroup'" | Where-Object { $_.Name -eq $ExclusionGroupName }
                if (-not $ExclusionGroup) {
                    $ExclusionGroupId = [guid]::NewGuid().ToString()
                    $ExclusionGroup = @{
                        PartitionKey = 'TenantGroup'
                        RowKey       = $ExclusionGroupId
                        Name         = $ExclusionGroupName
                        Description  = 'Tenants excluded from top-level standards during onboarding'
                        GroupType    = 'static'
                    }
                    Add-CIPPAzDataTableEntity @GroupTable -Entity $ExclusionGroup -Force
                    $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = "Created tenant group '$ExclusionGroupName'" })
                } else {
                    $ExclusionGroupId = $ExclusionGroup.RowKey
                }

                # Add tenant to the exclusion group if not already a member
                $MemberRowKey = '{0}-{1}' -f $ExclusionGroupId, $Tenant.customerId
                $ExistingMember = Get-CIPPAzDataTableEntity @MembersTable -Filter "PartitionKey eq 'Member' and RowKey eq '$MemberRowKey'"
                if (-not $ExistingMember) {
                    Add-CIPPAzDataTableEntity @MembersTable -Entity @{
                        PartitionKey = 'Member'
                        RowKey       = $MemberRowKey
                        GroupId      = $ExclusionGroupId
                        customerId   = $Tenant.customerId
                    } -Force
                }

                # Ensure the group is in excludedTenants of all AllTenants templates
                $GroupExclusionObj = [PSCustomObject]@{
                    label = $ExclusionGroupName
                    value = $ExclusionGroupId
                    type  = 'Group'
                }
                $TemplatesTable = Get-CIPPTable -tablename 'templates'
                $ExistingTemplates = Get-CIPPAzDataTableEntity @TemplatesTable -Filter "PartitionKey eq 'StandardsTemplateV2'" | Where-Object { $_.JSON -match 'AllTenants' }
                foreach ($AllTenantsTemplate in $ExistingTemplates) {
                    $object = $AllTenantsTemplate.JSON | ConvertFrom-Json
                    if (-not $object.excludedTenants) {
                        $object | Add-Member -MemberType NoteProperty -Name 'excludedTenants' -Value @() -Force
                    }
                    $AlreadyHasGroup = $object.excludedTenants | Where-Object { $_.value -eq $ExclusionGroupId -and $_.type -eq 'Group' }
                    if (-not $AlreadyHasGroup) {
                        $NewExcludedTenants = [System.Collections.Generic.List[object]]::new()
                        foreach ($ExcludedEntry in $object.excludedTenants) {
                            $NewExcludedTenants.Add($ExcludedEntry)
                        }
                        $NewExcludedTenants.Add($GroupExclusionObj)
                        $object.excludedTenants = $NewExcludedTenants
                        $JSON = ConvertTo-Json -InputObject $object -Compress -Depth 10
                        $TemplatesTable.Force = $true
                        Add-CIPPAzDataTableEntity @TemplatesTable -Entity @{
                            JSON         = "$JSON"
                            RowKey       = $AllTenantsTemplate.RowKey
                            GUID         = $AllTenantsTemplate.GUID
                            PartitionKey = 'StandardsTemplateV2'
                        }
                    }
                }

                # Bust the tenant groups cache so standards pick up the new member
                $null = Get-TenantGroups -SkipCache

                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Set All Tenant Standards Exclusion via group' })
            }
            $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = "Testing API access for $($Tenant.defaultDomainName)" })
            $OnboardingSteps.Step5.Status = 'running'
            $OnboardingSteps.Step5.Message = 'Testing API access'
            $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
            $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
            Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop

            try {
                #Write-Host ($Tenant | ConvertTo-Json)
                $UserCount = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/users?`$count=true&`$top=1" -ComplexFilter -tenantid $Tenant.defaultDomainName -CountOnly
            } catch {
                $UserCount = 0
                $ApiError = $_.Exception.Message
                $ApiException = $_
            }

            if ($UserCount -gt 0) {
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'API test successful' })
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Onboarding complete' })
                $OnboardingSteps.Step5.Status = 'succeeded'
                $OnboardingSteps.Step5.Message = 'API Test Successful: {0} users found' -f $UserCount
                $TenantOnboarding.Status = 'succeeded'
                $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
                $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
                Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
                Write-LogMessage -API 'Onboarding' -message "Tenant onboarding succeeded for $($Relationship.customer.displayName)" -Sev 'Info'
                Write-LogMessage -API 'NewTenant' -message "New tenant onboarded: $($Relationship.customer.displayName) ($($Relationship.customer.id))" -Sev 'Info'
            } else {
                $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'API Test failed: {0}' -f $ApiError })
                $OnboardingSteps.Step5.Status = 'failed'
                $OnboardingSteps.Step5.Message = 'API Test failed: {0}' -f $ApiError
                $TenantOnboarding.Status = 'succeeded'
                $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
                $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
                Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
                Write-LogMessage -API 'Onboarding' -message "Tenant onboarding API test failed for $($Relationship.customer.displayName)" -Sev 'Error' -LogData (Get-CippException -Exception $ApiException)
            }
        }
    } catch {
        $Logs.Add([PSCustomObject]@{ Date = (Get-Date).ToUniversalTime(); Log = 'Onboarding failed. Exception: {0}' -f $_.Exception.Message })
        $TenantOnboarding.Status = 'failed'
        $TenantOnboarding.Exception = [string]('{0} - Line {1} - {2}' -f $_.Exception.Message, $_.InvocationInfo.ScriptLineNumber, $_.InvocationInfo.ScriptName)
        $TenantOnboarding.OnboardingSteps = [string](ConvertTo-Json -InputObject $OnboardingSteps -Compress)
        $TenantOnboarding.Logs = [string](ConvertTo-Json -InputObject @($Logs) -Compress)
        Add-CIPPAzDataTableEntity @OnboardTable -Entity $TenantOnboarding -Force -ErrorAction Stop
        Write-LogMessage -API 'Onboarding' -message "Tenant onboarding failed for $Id" -Sev 'Error' -LogData (Get-CippException -Exception $_)
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecOnboardTenantQueue.ps1' 569
#Region './Public/Entrypoints/Activity Triggers/Push-ExecScheduledCommand.ps1' -1

function Push-ExecScheduledCommand {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)
    $item = $Item | ConvertTo-Json -Depth 100 | ConvertFrom-Json
    Write-Information "We are going to be running a scheduled task: $($Item.TaskInfo | ConvertTo-Json -Depth 10)"

    # Define orchestrator-based commands that handle their own post-execution and state updates
    $OrchestratorBasedCommands = @('Invoke-CIPPOffboardingJob')

    # Initialize AsyncLocal storage for thread-safe per-invocation context
    if (-not $global:CippScheduledTaskIdStorage) {
        $global:CippScheduledTaskIdStorage = [System.Threading.AsyncLocal[string]]::new()
    }
    $global:CippScheduledTaskIdStorage.Value = $Item.TaskInfo.RowKey

    $Table = Get-CippTable -tablename 'ScheduledTasks'
    $task = $Item.TaskInfo
    $commandParameters = $Item.Parameters | ConvertTo-Json -Depth 10 | ConvertFrom-Json -AsHashtable

    # Handle tenant resolution - support both direct tenant and group-expanded tenants
    $Tenant = $Item.Parameters.TenantFilter ?? $Item.TaskInfo.Tenant

    # Detect if this is a multi-tenant task that should store results per-tenant
    $IsMultiTenantTask = ($task.Tenant -eq 'AllTenants' -or $task.TenantGroup)

    # Detect if this is an individual tenant execution within a multi-tenant task
    # In this case, skip parent task state updates - the PostExecution function will handle it
    $IsMultiTenantExecution = $IsMultiTenantTask -and ($Tenant -ne $task.Tenant)

    # For tenant group tasks, the tenant will be the expanded tenant from the orchestrator
    # We don't need to expand groups here as that's handled in the orchestrator
    $TenantInfo = Get-Tenants -TenantFilter $Tenant

    $CurrentTask = Get-AzDataTableEntity @Table -Filter "PartitionKey eq '$($task.PartitionKey)' and RowKey eq '$($task.RowKey)'"
    if (!$CurrentTask) {
        Write-Information "The task $($task.Name) for tenant $($task.Tenant) does not exist in the ScheduledTasks table. Exiting."
        Remove-Variable -Name ScheduledTaskId -Scope Script -ErrorAction SilentlyContinue
        return
    }
    if ($CurrentTask.TaskState -eq 'Completed' -and !$IsMultiTenantTask) {
        Write-Information "The task $($task.Name) for tenant $($task.Tenant) is already completed. Skipping execution."
        Remove-Variable -Name ScheduledTaskId -Scope Script -ErrorAction SilentlyContinue
        return
    }
    # Task should be 'Pending' (queued by orchestrator) or 'Running' (retry/recovery)
    # We accept both to handle edge cases

    # Check for rerun protection - prevent duplicate executions within the recurrence interval
    # Do this BEFORE updating state to 'Running' to avoid getting stuck
    if ($task.Recurrence -and $task.Recurrence -ne '0' -and !$IsMultiTenantExecution) {
        # Calculate interval in seconds from recurrence string
        $IntervalSeconds = switch -Regex ($task.Recurrence) {
            '^(\d+)$' { [int64]$matches[1] * 86400 }  # Plain number = days
            '(\d+)m$' { [int64]$matches[1] * 60 }
            '(\d+)h$' { [int64]$matches[1] * 3600 }
            '(\d+)d$' { [int64]$matches[1] * 86400 }
            default { 0 }
        }

        if ($IntervalSeconds -gt 0) {
            # Round down to nearest 15-minute interval (900 seconds) since that's when orchestrator runs
            # This prevents rerun blocking issues due to slight timing variations
            $FifteenMinutes = 900
            $AdjustedInterval = [Math]::Floor($IntervalSeconds / $FifteenMinutes) * $FifteenMinutes

            # Ensure we have at least one 15-minute interval
            if ($AdjustedInterval -lt $FifteenMinutes) {
                $AdjustedInterval = $FifteenMinutes
            }
            # Use task RowKey as API identifier for rerun cache
            $RerunParams = @{
                TenantFilter = $Tenant
                Type         = 'ScheduledTask'
                API          = $task.RowKey
                Interval     = $AdjustedInterval
                BaseTime     = [int64]$task.ScheduledTime
                Headers      = $Headers
            }

            $IsRerun = Test-CIPPRerun @RerunParams
            if ($IsRerun) {
                Write-Information "Scheduled task $($task.Name) for tenant $Tenant was recently executed. Skipping to prevent duplicate execution."
                Remove-Variable -Name ScheduledTaskId -Scope Script -ErrorAction SilentlyContinue
                return
            }
        }
    }

    # Also check for one-time task rerun protection based on ExecutedTime
    if ((!$task.Recurrence -or $task.Recurrence -eq '0') -and $task.ExecutedTime -and !$IsMultiTenantExecution) {
        $currentUnixTime = [int64](([datetime]::UtcNow) - (Get-Date '1/1/1970')).TotalSeconds
        $timeSinceExecution = $currentUnixTime - [int64]$task.ExecutedTime

        # If executed within last 15 minutes, skip (likely a duplicate pickup)
        if ($timeSinceExecution -lt 900) {
            Write-Information "One-time task $($task.Name) for tenant $Tenant was recently executed ($timeSinceExecution seconds ago). Skipping to prevent duplicate execution."
            Remove-Variable -Name ScheduledTaskId -Scope Script -ErrorAction SilentlyContinue
            return
        }
    }

    if ($task.Trigger) {
        # Extract trigger data from the task and process
        $Trigger = if (Test-Json -Json $task.Trigger) { $task.Trigger | ConvertFrom-Json } else { $task.Trigger }
        $TriggerType = $Trigger.Type.value ?? $Trigger.Type
        if ($TriggerType -eq 'DeltaQuery') {
            $IsTriggerTask = $true
            $DeltaUrl = Get-DeltaQueryUrl -TenantFilter $Tenant -PartitionKey $task.RowKey
            $DeltaQuery = @{
                DeltaUrl     = $DeltaUrl
                TenantFilter = $Tenant
                PartitionKey = $task.RowKey
            }
            $Query = New-GraphDeltaQuery @DeltaQuery

            $secondsToAdd = switch -Regex ($task.Recurrence) {
                '(\d+)m$' { [int64]$matches[1] * 60 }
                '(\d+)h$' { [int64]$matches[1] * 3600 }
                '(\d+)d$' { [int64]$matches[1] * 86400 }
                default { 0 }
            }

            $Minutes = [int]($secondsToAdd / 60)

            $DeltaQueryConditions = @{
                Query        = $Query
                Trigger      = $Trigger
                TenantFilter = $Tenant
                LastTrigger  = [datetime]::UtcNow.AddMinutes(-$Minutes)
            }
            $DeltaResults = Test-DeltaQueryConditions @DeltaQueryConditions

            if (-not $DeltaResults.ConditionsMet) {
                Write-Information "Delta query conditions not met for tenant $Tenant. Skipping execution."
                # update interval
                $nextRunUnixTime = [int64]$task.ScheduledTime + [int64]$secondsToAdd
                $null = Update-AzDataTableEntity -Force @Table -Entity @{
                    PartitionKey  = $task.PartitionKey
                    RowKey        = $task.RowKey
                    TaskState     = 'Planned'
                    ScheduledTime = [string]$nextRunUnixTime
                }
                Remove-Variable -Name ScheduledTaskId -Scope Script -ErrorAction SilentlyContinue
                return
            }
        }
    } else {
        $IsTriggerTask = $false
    }

    # Only update parent task state if this is NOT a multi-tenant execution
    # Multi-tenant executions have their parent state managed by PostExecution
    if (!$IsMultiTenantExecution) {
        $null = Update-AzDataTableEntity -Force @Table -Entity @{
            PartitionKey = $task.PartitionKey
            RowKey       = $task.RowKey
            TaskState    = 'Running'
        }
    }

    if ($Item.Command -in (Get-CIPPSchedulerBlockedCommands)) {
        $Results = "Task blocked: '$($Item.Command)' is not permitted to run as a scheduled task."
        $State = 'Failed'
        Write-LogMessage -API 'Scheduler_UserTasks' -tenant $Tenant -tenantid $TenantInfo.customerId -message "Blocked execution of restricted command '$($Item.Command)' in task $($task.Name)" -sev Warning
        if (!$IsMultiTenantExecution) {
            Update-AzDataTableEntity -Force @Table -Entity @{
                PartitionKey = $task.PartitionKey
                RowKey       = $task.RowKey
                Results      = "$Results"
                TaskState    = $State
            }
        }
        Remove-Variable -Name ScheduledTaskId -Scope Script -ErrorAction SilentlyContinue
        return
    }

    $Function = Get-Command -Name $Item.Command
    if ($null -eq $Function) {
        $Results = "Task Failed: The command $($Item.Command) does not exist."
        $State = 'Failed'
        if (!$IsMultiTenantExecution) {
            Update-AzDataTableEntity -Force @Table -Entity @{
                PartitionKey = $task.PartitionKey
                RowKey       = $task.RowKey
                Results      = "$Results"
                TaskState    = $State
            }
        }

        Write-LogMessage -API 'Scheduler_UserTasks' -tenant $Tenant -tenantid $TenantInfo.customerId -message "Failed to execute task $($task.Name): The command $($Item.Command) does not exist." -sev Error
        Remove-Variable -Name ScheduledTaskId -Scope Script -ErrorAction SilentlyContinue
        return
    }

    try {
        $PossibleParams = $Function.Parameters.Keys
        $keysToRemove = [System.Collections.Generic.List[string]]@()
        foreach ($key in $commandParameters.Keys) {
            if (-not ($PossibleParams -contains $key)) {
                $keysToRemove.Add($key)
            }
        }
        foreach ($key in $keysToRemove) {
            $commandParameters.Remove($key)
        }
    } catch {
        Write-Information "Failed to remove parameters: $($_.Exception.Message)"
    }

    if ($IsTriggerTask -eq $true -and $Trigger.ExecutePerResource -ne $true) {
        # iterate through paramters looking for %variables% and replace them with matched data from the delta query
        # examples would be %id% to be the id of the result
        # if %triggerdata% is found, pass the entire matched data object
        try {
            foreach ($key in $commandParameters.Keys) {
                if ($commandParameters[$key] -is [string]) {
                    if ($commandParameters[$key] -match '^%(.*)%$') {
                        $variableName = $matches[1]
                        if ($variableName -eq 'triggerdata') {
                            Write-Information "Replacing parameter $key with full matched data object."
                            $commandParameters[$key] = $DeltaResults.MatchedData
                        } else {
                            # Replace with array of matched property values
                            Write-Information "Replacing parameter $key with matched data property '$variableName'."
                            $commandParameters[$key] = $DeltaResults.MatchedData | Select-Object -ExpandProperty $variableName
                        }
                    }
                }
            }
        } catch {
            Write-Information "Failed to process trigger data parameters: $($_.Exception.Message)"
        }
    } elseif ($IsTriggerTask -eq $true -and $Trigger.ExecutePerResource -eq $true) {
        Write-Information 'This is a trigger task with ExecutePerResource set to true. Iterating through matched data to execute command per resource.'
        $results = foreach ($dataItem in $DeltaResults.MatchedData) {
            $individualCommandParameters = $commandParameters.Clone()
            try {
                foreach ($key in $individualCommandParameters.Keys) {
                    if ($individualCommandParameters[$key] -is [string]) {
                        if ($individualCommandParameters[$key] -match '^%(.*)%$') {
                            if ($matches[1] -eq 'triggerdata') {
                                Write-Information "Replacing parameter $key with full matched data object for individual execution."
                                $individualCommandParameters[$key] = $dataItem
                            } else {
                                $variableName = $matches[1]
                                Write-Information "Replacing parameter $key with matched data property '$variableName' for individual execution."
                                $individualCommandParameters[$key] = $dataItem.$variableName
                            }
                        }
                    }
                }
            } catch {
                Write-Information "Failed to process trigger data parameters for individual execution: $($_.Exception.Message)"
            }
            try {
                Write-Information "Executing command $($Item.Command) for individual matched data item with parameters: $($individualCommandParameters | ConvertTo-Json -Depth 10)"
                & $Item.Command @individualCommandParameters
                Write-Information "Results for individual execution: $($results | ConvertTo-Json -Depth 10)"
            } catch {
                Write-Information "Failed to execute command for individual matched data item: $($_.Exception.Message)"
            }
        }
    }

    try {
        if (-not $Trigger.ExecutePerResource) {
            try {
                # For orchestrator-based commands, add TaskInfo to enable post-execution updates
                if ($Item.Command -eq 'Invoke-CIPPOffboardingJob') {
                    Write-Information 'Adding TaskInfo to command parameters for orchestrator-based offboarding'
                    $commandParameters['TaskInfo'] = $task
                }

                Write-Information "Starting task: $($Item.Command) for tenant: $Tenant with parameters: $($commandParameters | ConvertTo-Json -Depth 10)"
                $results = & $Item.Command @commandParameters
            } catch {
                $results = "Task Failed: $($_.Exception.Message)"
                $State = 'Failed'
            }
            Write-Information 'Ran the command. Processing results'
        }

        # Extract TaskAttachments from structured output before general result processing
        $TaskAttachments = $null
        if ($results -is [hashtable] -and $results.ContainsKey('TaskAttachments')) {
            $TaskAttachments = $results.TaskAttachments
            $results = $results.Results
        } elseif ($results -is [PSCustomObject] -and $null -ne $results.TaskAttachments) {
            $TaskAttachments = $results.TaskAttachments
            $results = $results.Results
        }

        Write-Information "Results: $($results | ConvertTo-Json -Depth 10)"
        if ($item.command -like 'Get-CIPPAlert*') {
            Write-Information 'This is an alert task. Processing results as alerts.'
            $results = @($results)
            $TaskType = 'Alert'
        } else {
            Write-Information 'This is a scheduled task. Processing results as scheduled task.'
            $TaskType = 'Scheduled Task'

            if (!$results) {
                $results = 'Task completed successfully'
            }

            if ($results -is [String]) {
                $results = @{ Results = $results }
            } elseif ($results -is [array] -and $results[0] -is [string] -or $results[0].resultText -is [string]) {
                $results = $results | Where-Object { $_ -is [string] -or $_.resultText -is [string] }
                $results = $results | ForEach-Object {
                    $Message = $_.resultText ?? $_
                    @{ Results = $Message }
                }
            }
            Write-Information "Results after processing: $($results | ConvertTo-Json -Depth 10)"
            Write-Information 'Moving onto storing results'
            if ($results -is [string]) {
                $StoredResults = $results
            } else {
                $results = $results | Select-Object * -ExcludeProperty RowKey, PartitionKey
                $StoredResults = $results | ConvertTo-Json -Compress -Depth 20 | Out-String
            }
        }
        Write-Information "Results: $($results | ConvertTo-Json -Depth 10)"
        if ($StoredResults.Length -gt 64000 -or $IsMultiTenantTask) {
            $TaskResultsTable = Get-CippTable -tablename 'ScheduledTaskResults'
            $TaskResults = @{
                PartitionKey = $task.RowKey
                RowKey       = $Tenant
                Results      = [string](ConvertTo-Json -Compress -Depth 20 $results)
            }
            $null = Add-CIPPAzDataTableEntity @TaskResultsTable -Entity $TaskResults -Force
            $StoredResults = @{ Results = 'Completed, details are available in the More Info pane' } | ConvertTo-Json -Compress
        }
    } catch {
        Write-Information "Failed to run task: $($_.Exception.Message)"
        $errorMessage = $_.Exception.Message
        #if recurrence is just a number, add it in days.
        if ($task.Recurrence -match '^\d+$') {
            $task.Recurrence = $task.Recurrence + 'd'
        }
        $secondsToAdd = switch -Regex ($task.Recurrence) {
            '(\d+)m$' { [int64]$matches[1] * 60 }
            '(\d+)h$' { [int64]$matches[1] * 3600 }
            '(\d+)d$' { [int64]$matches[1] * 86400 }
            default { 0 }
        }

        if ($secondsToAdd -gt 0) {
            $unixtimeNow = [int64](([datetime]::UtcNow) - (Get-Date '1/1/1970')).TotalSeconds
            if ([int64]$task.ScheduledTime -lt ($unixtimeNow - $secondsToAdd)) {
                $task.ScheduledTime = $unixtimeNow
            }
        }

        $nextRunUnixTime = [int64]$task.ScheduledTime + [int64]$secondsToAdd
        if ($task.Recurrence -ne 0) { $State = 'Failed - Planned' } else { $State = 'Failed' }
        Write-Information "The job is recurring, but failed. It was scheduled for $($task.ScheduledTime). The next runtime should be $nextRunUnixTime"
        if (!$IsMultiTenantExecution) {
            Update-AzDataTableEntity -Force @Table -Entity @{
                PartitionKey  = $task.PartitionKey
                RowKey        = $task.RowKey
                Results       = "$errorMessage"
                ScheduledTime = "$nextRunUnixTime"
                TaskState     = $State
            }
        }
        Write-LogMessage -API 'Scheduler_UserTasks' -tenant $Tenant -tenantid $TenantInfo.customerId -message "Failed to execute task $($task.Name): $errorMessage" -sev Error -LogData (Get-CippExceptionData -Exception $_.Exception)
    }

    # For orchestrator-based commands, skip post-execution alerts as they will be handled by the orchestrator's post-execution function
    if ($Results -and $Item.Command -notin $OrchestratorBasedCommands -and -not [string]::IsNullOrWhiteSpace($Task.PostExecution)) {
        Write-Information "Sending task results to post execution target(s): $($Task.PostExecution -join ', ')."
        $AlertParams = @{
            Results      = $Results
            TaskInfo     = $task
            TenantFilter = $Tenant
            TaskType     = $TaskType
        }
        if ($TaskAttachments) {
            $AlertParams.Attachments = $TaskAttachments
        }
        Send-CIPPScheduledTaskAlert @AlertParams
    }

    try {
        # For orchestrator-based commands, skip task state update as it will be handled by post-execution
        if ($Item.Command -in $OrchestratorBasedCommands) {
            Write-Information "Command $($Item.Command) is orchestrator-based. Skipping task state update - will be handled by post-execution."
            if (!$IsMultiTenantExecution) {
                if ($State -eq 'Failed') {
                    # The orchestrator command itself failed to dispatch - record the failure so the task isn't lost
                    Update-AzDataTableEntity -Force @Table -Entity @{
                        PartitionKey = $task.PartitionKey
                        RowKey       = $task.RowKey
                        Results      = "$results"
                        TaskState    = 'Failed'
                    }
                } else {
                    # Update task state to 'Processing' to indicate orchestration is in progress
                    Update-AzDataTableEntity -Force @Table -Entity @{
                        PartitionKey = $task.PartitionKey
                        RowKey       = $task.RowKey
                        Results      = 'Orchestration in progress'
                        TaskState    = 'Processing'
                    }
                }
            }
        } elseif ($IsMultiTenantExecution) {
            # For multi-tenant executions, skip parent task state updates
            # The PostExecution function will aggregate all results and update the parent task
            Write-Information "Multi-tenant execution for tenant $Tenant - parent task state will be updated by PostExecution"
        } elseif ($task.Recurrence -eq '0' -or [string]::IsNullOrEmpty($task.Recurrence) -or $Trigger.ExecutionMode.value -eq 'once' -or $Trigger.ExecutionMode -eq 'once') {
            Write-Information 'Recurrence empty or 0. Task is not recurring. Setting task state to completed.'
            Update-AzDataTableEntity -Force @Table -Entity @{
                PartitionKey = $task.PartitionKey
                RowKey       = $task.RowKey
                Results      = "$StoredResults"
                TaskState    = 'Completed'
            }
        } else {
            #if recurrence is just a number, add it in days.
            if ($task.Recurrence -match '^\d+$') {
                $task.Recurrence = $task.Recurrence + 'd'
            }
            $secondsToAdd = switch -Regex ($task.Recurrence) {
                '(\d+)m$' { [int64]$matches[1] * 60 }
                '(\d+)h$' { [int64]$matches[1] * 3600 }
                '(\d+)d$' { [int64]$matches[1] * 86400 }
                default { 0 }
            }

            if ($secondsToAdd -gt 0) {
                $unixtimeNow = [int64](([datetime]::UtcNow) - (Get-Date '1/1/1970')).TotalSeconds
                if ([int64]$task.ScheduledTime -lt ($unixtimeNow - $secondsToAdd)) {
                    $task.ScheduledTime = $unixtimeNow
                }
            }

            $nextRunUnixTime = [int64]$task.ScheduledTime + [int64]$secondsToAdd
            Write-Information "The job is recurring. It was scheduled for $($task.ScheduledTime). The next runtime should be $nextRunUnixTime"
            Update-AzDataTableEntity -Force @Table -Entity @{
                PartitionKey  = $task.PartitionKey
                RowKey        = $task.RowKey
                Results       = "$StoredResults"
                TaskState     = 'Planned'
                ScheduledTime = "$nextRunUnixTime"
            }
        }
    } catch {
        Write-Warning "Failed to update task state: $($_.Exception.Message)"
        Write-Information $_.InvocationInfo.PositionMessage
    }
    if ($TaskType -ne 'Alert') {
        Write-LogMessage -API 'Scheduler_UserTasks' -tenant $Tenant -tenantid $TenantInfo.customerId -message "Successfully executed task: $($task.Name)" -sev Info
    }
    Remove-Variable -Name ScheduledTaskId -Scope Script -ErrorAction SilentlyContinue
    return 'Task Completed Successfully.'
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ExecScheduledCommand.ps1' 463
#Region './Public/Entrypoints/Activity Triggers/Push-GetMailboxRulesBatch.ps1' -1

function Push-GetMailboxRulesBatch {
    <#
    .SYNOPSIS
        Caches mailbox rules for a batch of mailboxes

    .PARAMETER InputObject
        The batch object containing TenantFilter and Mailboxes array
    #>
    [CmdletBinding()]
    param($Item)

    $TenantFilter = $Item.TenantFilter
    $Mailboxes = $Item.Mailboxes
    $BatchNumber = $Item.BatchNumber
    $TotalBatches = $Item.TotalBatches
    $QueueId = $Item.QueueId

    try {
        Write-Information "Processing mailbox rules batch $BatchNumber/$TotalBatches for tenant $TenantFilter with $($Mailboxes.Count) mailboxes"

        # Build bulk request for mailbox rules
        $Request = $Mailboxes | ForEach-Object {
            @{
                OperationGuid = $_
                CmdletInput   = @{
                    CmdletName = 'Get-InboxRule'
                    Parameters = @{
                        Mailbox = $_
                    }
                }
            }
        }

        $Rules = New-ExoBulkRequest -tenantid $TenantFilter -cmdletArray @($Request) | Where-Object { $_.Identity }

        Write-Information "Retrieved $($Rules.Count) rules from batch $BatchNumber/$TotalBatches"

        # Add metadata and return for aggregation
        if (($Rules | Measure-Object).Count -gt 0) {
            $RulesWithMetadata = foreach ($Rule in $Rules) {
                $Rule | Add-Member -NotePropertyName 'Tenant' -NotePropertyValue $TenantFilter -Force
                $Rule | Add-Member -NotePropertyName 'UserPrincipalName' -NotePropertyValue $Rule.OperationGuid -Force
                $Rule
            }
            return , $RulesWithMetadata
        } else {
            Write-Information "No rules found in batch $BatchNumber/$TotalBatches"
            return , @()
        }

    } catch {
        Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message "Failed to process mailbox rules batch $BatchNumber/$TotalBatches : $($_.Exception.Message)" -sev Error -LogData (Get-CippException -Exception $_)
        throw
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-GetMailboxRulesBatch.ps1' 56
#Region './Public/Entrypoints/Activity Triggers/Push-GetPendingWebhooks.ps1' -1

function Push-GetPendingWebhooks {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    Param($Item)
    $Table = Get-CIPPTable -TableName WebhookIncoming
    $Webhooks = Get-CIPPAzDataTableEntity @Table -Property PartitionKey, RowKey, FunctionName -First 10000
    $WebhookCount = ($Webhooks | Measure-Object).Count
    $Message = 'Processing {0} webhooks' -f $WebhookCount
    Write-LogMessage -API 'Webhooks' -message $Message -sev Info
    return $Webhooks
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-GetPendingWebhooks.ps1' 14
#Region './Public/Entrypoints/Activity Triggers/Push-GetTenants.ps1' -1

function Push-GetTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    Param($Item)

    $Params = $Item.TenantParams | ConvertTo-Json | ConvertFrom-Json -AsHashtable
    try {
        if ($Item.QueueId) {
            Get-Tenants @Params | Select-Object customerId, @{n = 'FunctionName'; e = { $Item.DurableName } }, @{n = 'QueueId'; e = { $Item.QueueId } }, @{n = 'QueueName'; e = { $_.defaultDomainName } }
        } else {
            Get-Tenants @Params | Select-Object customerId, @{n = 'FunctionName'; e = { $Item.DurableName } }
        }
    } catch {
        Write-Host "GetTenants Exception $($_.Exception.Message)"
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-GetTenants.ps1' 19
#Region './Public/Entrypoints/Activity Triggers/Push-ListBasicAuthAllTenants.ps1' -1

function Push-ListBasicAuthAllTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)


    $Tenant = Get-Tenants -TenantFilter $Item.customerId
    $domainName = $Tenant.defaultDomainName

    # XXX; This function seems to be unused in the frontend. -Bobby

    $currentTime = Get-Date -Format 'yyyy-MM-ddTHH:MM:ss'
    $ts = (Get-Date).AddDays(-30)
    $endTime = $ts.ToString('yyyy-MM-ddTHH:MM:ss')
    $filters = "createdDateTime ge $($endTime)Z and createdDateTime lt $($currentTime)Z and (clientAppUsed eq 'AutoDiscover' or clientAppUsed eq 'Exchange ActiveSync' or clientAppUsed eq 'Exchange Online PowerShell' or clientAppUsed eq 'Exchange Web Services' or clientAppUsed eq 'IMAP4' or clientAppUsed eq 'MAPI Over HTTP' or clientAppUsed eq 'Offline Address Book' or clientAppUsed eq 'Outlook Anywhere (RPC over HTTP)' or clientAppUsed eq 'Other clients' or clientAppUsed eq 'POP3' or clientAppUsed eq 'Reporting Web Services' or clientAppUsed eq 'Authenticated SMTP' or clientAppUsed eq 'Outlook Service')"
    try {
        $GraphRequest = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/auditLogs/signIns?api-version=beta&filter=$($filters)" -tenantid $domainName -ErrorAction stop | Sort-Object -Unique -Property clientAppUsed | ForEach-Object {
            @{
                Tenant            = $domainName
                clientAppUsed     = $_.clientAppUsed
                userPrincipalName = $_.UserPrincipalName
                RowKey            = "$($_.UserPrincipalName)-$($_.clientAppUsed)"
                PartitionKey      = 'basicauth'
            }
        }
    } catch {
        $GraphRequest = @{
            Tenant            = $domainName
            clientAppUsed     = "Could not connect to Tenant: $($_.Exception.message)"
            userPrincipalName = $domainName
            RowKey            = $domainName
            PartitionKey      = 'basicauth'
        }
    }
    $Table = Get-CIPPTable -TableName cachebasicauth
    Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null

}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ListBasicAuthAllTenants.ps1' 42
#Region './Public/Entrypoints/Activity Triggers/Push-ListConditionalAccessPoliciesAllTenants.ps1' -1

function Push-ListConditionalAccessPoliciesAllTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    #Region Helper functions
    function Get-LocationNameFromId {
        param ($ID, $Locations)
        if ($id -eq 'All') { return 'All' }
        $DisplayName = $Locations | Where-Object { $_.id -eq $ID } | Select-Object -ExpandProperty DisplayName
        if ([string]::IsNullOrEmpty($displayName)) { return $ID } else { return $DisplayName }
    }

    function Get-RoleNameFromId {
        param ($ID, $RoleDefinitions)
        if ($id -eq 'All') { return 'All' }
        $DisplayName = $RoleDefinitions | Where-Object { $_.id -eq $ID } | Select-Object -ExpandProperty DisplayName
        if ([string]::IsNullOrEmpty($displayName)) { return $ID } else { return $DisplayName }
    }

    function Get-UserNameFromId {
        param ($ID, $Users)
        if ($id -eq 'All') { return 'All' }
        $DisplayName = $Users | Where-Object { $_.id -eq $ID } | Select-Object -ExpandProperty DisplayName
        if ([string]::IsNullOrEmpty($displayName)) { return $ID } else { return $DisplayName }
    }

    function Get-GroupNameFromId {
        param ($ID, $Groups)
        if ($id -eq 'All') { return 'All' }
        $DisplayName = $Groups | Where-Object { $_.id -eq $ID } | Select-Object -ExpandProperty DisplayName
        if ([string]::IsNullOrEmpty($displayName)) { return 'No Data' } else { return $DisplayName }
    }

    function Get-ApplicationNameFromId {
        param ($ID, $Applications, $ServicePrincipals)
        if ($id -eq 'All') { return 'All' }
        $return = $ServicePrincipals | Where-Object { $_.appId -eq $ID } | Select-Object -ExpandProperty DisplayName
        if ([string]::IsNullOrEmpty($return)) {
            $return = $Applications | Where-Object { $_.Appid -eq $ID } | Select-Object -ExpandProperty DisplayName
        }
        if ([string]::IsNullOrEmpty($return)) {
            $return = $Applications | Where-Object { $_.ID -eq $ID } | Select-Object -ExpandProperty DisplayName
        }
        if ([string]::IsNullOrEmpty($return)) { $return = '' }
        return $return
    }
    #EndRegion Helper functions

    $Tenant = Get-Tenants -TenantFilter $Item.customerId
    $domainName = $Tenant.defaultDomainName
    $Table = Get-CIPPTable -TableName 'cacheCAPolicies'

    try {
        $Requests = @(
            @{
                id     = 'policies'
                url    = 'identity/conditionalAccess/policies'
                method = 'GET'
            }
            @{
                id     = 'namedLocations'
                url    = 'identity/conditionalAccess/namedLocations'
                method = 'GET'
            }
            @{
                id     = 'applications'
                url    = 'applications?$top=999&$select=appId,displayName'
                method = 'GET'
            }
            @{
                id     = 'roleDefinitions'
                url    = 'roleManagement/directory/roleDefinitions?$select=id,displayName'
                method = 'GET'
            }
            @{
                id     = 'groups'
                url    = 'groups?$top=999&$select=id,displayName'
                method = 'GET'
            }
            @{
                id     = 'users'
                url    = 'users?$top=999&$select=id,displayName,userPrincipalName'
                method = 'GET'
            }
            @{
                id     = 'servicePrincipals'
                url    = 'servicePrincipals?$top=999&$select=appId,displayName'
                method = 'GET'
            }
        )

        $BulkResults = New-GraphBulkRequest -Requests $Requests -tenantid $domainName -asapp $true

        $ConditionalAccessPolicyOutput = ($BulkResults | Where-Object { $_.id -eq 'policies' }).body.value
        $AllNamedLocations = ($BulkResults | Where-Object { $_.id -eq 'namedLocations' }).body.value
        $AllApplications = ($BulkResults | Where-Object { $_.id -eq 'applications' } ).body.value
        $AllRoleDefinitions = ($BulkResults | Where-Object { $_.id -eq 'roleDefinitions' }).body.value
        $GroupListOutput = ($BulkResults | Where-Object { $_.id -eq 'groups' }).body.value
        $UserListOutput = ($BulkResults | Where-Object { $_.id -eq 'users' }).body.value
        $AllServicePrincipals = ($BulkResults | Where-Object { $_.id -eq 'servicePrincipals' }).body.value

        foreach ($cap in $ConditionalAccessPolicyOutput) {
            $GUID = (New-Guid).Guid
            $PolicyData = @{
                id                                          = $cap.id
                displayName                                 = $cap.displayName
                customer                                    = $cap.Customer
                Tenant                                      = $domainName
                createdDateTime                             = $(if (![string]::IsNullOrEmpty($cap.createdDateTime)) { [datetime]$cap.createdDateTime } else { '' })
                modifiedDateTime                            = $(if (![string]::IsNullOrEmpty($cap.modifiedDateTime)) { [datetime]$cap.modifiedDateTime } else { '' })
                state                                       = $cap.state
                clientAppTypes                              = ($cap.conditions.clientAppTypes) -join ','
                includePlatforms                            = ($cap.conditions.platforms.includePlatforms) -join ','
                excludePlatforms                            = ($cap.conditions.platforms.excludePlatforms) -join ','
                includeLocations                            = (Get-LocationNameFromId -Locations $AllNamedLocations -id $cap.conditions.locations.includeLocations) -join ','
                excludeLocations                            = (Get-LocationNameFromId -Locations $AllNamedLocations -id $cap.conditions.locations.excludeLocations) -join ','
                includeApplications                         = ($cap.conditions.applications.includeApplications | ForEach-Object { Get-ApplicationNameFromId -Applications $AllApplications -ServicePrincipals $AllServicePrincipals -id $_ }) -join ','
                excludeApplications                         = ($cap.conditions.applications.excludeApplications | ForEach-Object { Get-ApplicationNameFromId -Applications $AllApplications -ServicePrincipals $AllServicePrincipals -id $_ }) -join ','
                includeUserActions                          = ($cap.conditions.applications.includeUserActions | Out-String)
                includeAuthenticationContextClassReferences = ($cap.conditions.applications.includeAuthenticationContextClassReferences | Out-String)
                includeUsers                                = ($cap.conditions.users.includeUsers | ForEach-Object { Get-UserNameFromId -Users $UserListOutput -id $_ }) | Out-String
                excludeUsers                                = ($cap.conditions.users.excludeUsers | ForEach-Object { Get-UserNameFromId -Users $UserListOutput -id $_ }) | Out-String
                includeGroups                               = ($cap.conditions.users.includeGroups | ForEach-Object { Get-GroupNameFromId -Groups $GroupListOutput -id $_ }) | Out-String
                excludeGroups                               = ($cap.conditions.users.excludeGroups | ForEach-Object { Get-GroupNameFromId -Groups $GroupListOutput -id $_ }) | Out-String
                includeRoles                                = ($cap.conditions.users.includeRoles | ForEach-Object { Get-RoleNameFromId -RoleDefinitions $AllRoleDefinitions -id $_ }) | Out-String
                excludeRoles                                = ($cap.conditions.users.excludeRoles | ForEach-Object { Get-RoleNameFromId -RoleDefinitions $AllRoleDefinitions -id $_ }) | Out-String
                grantControlsOperator                       = ($cap.grantControls.operator) -join ','
                builtInControls                             = ($cap.grantControls.builtInControls) -join ','
                customAuthenticationFactors                 = ($cap.grantControls.customAuthenticationFactors) -join ','
                termsOfUse                                  = ($cap.grantControls.termsOfUse) -join ','
                rawjson                                     = ($cap | ConvertTo-Json -Depth 100)
            }

            $Entity = @{
                Policy       = [string]($PolicyData | ConvertTo-Json -Depth 10 -Compress)
                RowKey       = [string]$GUID
                PartitionKey = 'CAPolicy'
                Tenant       = [string]$domainName
            }
            Add-CIPPAzDataTableEntity @Table -Entity $Entity -Force | Out-Null
        }

    } catch {
        $GUID = (New-Guid).Guid
        $ErrorPolicy = ConvertTo-Json -InputObject @{
            Tenant           = $domainName
            displayName      = "Could not connect to Tenant: $($_.Exception.Message)"
            state            = 'Error'
            createdDateTime  = (Get-Date).ToString('s')
            modifiedDateTime = (Get-Date).ToString('s')
            id               = 'Error'
            clientAppTypes   = 'CIPP'
        } -Compress
        $Entity = @{
            Policy       = [string]$ErrorPolicy
            RowKey       = [string]$GUID
            PartitionKey = 'CAPolicy'
            Tenant       = [string]$domainName
        }
        Add-CIPPAzDataTableEntity @Table -Entity $Entity -Force | Out-Null
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ListConditionalAccessPoliciesAllTenants.ps1' 166
#Region './Public/Entrypoints/Activity Triggers/Push-ListLicensesQueue.ps1' -1

function Push-ListLicensesQueue {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    # Write out the queue message and metadata to the information log.
    Write-Host "PowerShell queue trigger function processed work item: $($Item.defaultDomainName)"

    $domainName = $Item.defaultDomainName
    try {
        Write-Host "Processing $domainName"
        $Licenses = Get-CIPPLicenseOverview -TenantFilter $domainName
    } catch {
        $Licenses = [pscustomobject]@{
            Tenant         = [string]$domainName
            License        = "Could not connect to client: $($_.Exception.Message)"
            'PartitionKey' = 'License'
            'RowKey'       = "$($domainName)"
        }
    } finally {
        $Table = Get-CIPPTable -TableName cachelicenses
        $JSON = ConvertTo-Json -Depth 10 -Compress -InputObject @($Licenses)
        $Overview = [pscustomobject]@{
            License        = [string]$JSON
            'PartitionKey' = 'License'
            'RowKey'       = "$($domainName)"
        }
        Add-CIPPAzDataTableEntity @Table -Entity $Overview -Force | Out-Null
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ListLicensesQueue.ps1' 33
#Region './Public/Entrypoints/Activity Triggers/Push-ListMailboxRulesQueue.ps1' -1

function Push-ListMailboxRulesQueue {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    # Write out the queue message and metadata to the information log.
    Write-Host "PowerShell queue trigger function processed work item: $($Item.defaultDomainName)"

    $domainName = $Item.defaultDomainName

    $Table = Get-CIPPTable -TableName cachembxrules
    try {
        $Mailboxes = New-ExoRequest -tenantid $domainName -cmdlet 'Get-Mailbox' -Select 'userPrincipalName,GUID'
        $Request = $Mailboxes | ForEach-Object {
            @{
                OperationGuid = $_.UserPrincipalName
                CmdletInput   = @{
                    CmdletName = 'Get-InboxRule'
                    Parameters = @{
                        Mailbox = $_.UserPrincipalName
                    }
                }
            }
        }

        $Rules = New-ExoBulkRequest -tenantid $domainName -cmdletArray @($Request) | Where-Object { $_.Identity }
        if (($Rules | Measure-Object).Count -gt 0) {
            $GraphRequest = foreach ($Rule in $Rules) {
                [PSCustomObject]@{
                    Rules        = [string]($Rule | ConvertTo-Json)
                    RowKey       = [string](New-Guid).guid
                    Tenant       = [string]$domainName
                    PartitionKey = 'MailboxRules'
                }

            }
        } else {
            $Rules = @(@{
                    Name = 'No rules found'
                }) | ConvertTo-Json
            $GraphRequest = [PSCustomObject]@{
                Rules        = [string]$Rules
                RowKey       = [string]$domainName
                Tenant       = [string]$domainName
                PartitionKey = 'MailboxRules'
            }
        }
    } catch {
        $Rules = @{
            Name = "Could not connect to tenant $($_.Exception.message)"
        } | ConvertTo-Json
        $GraphRequest = [PSCustomObject]@{
            Rules        = [string]$Rules
            RowKey       = [string]$domainName
            Tenant       = [string]$domainName
            PartitionKey = 'MailboxRules'
        }
    }
    Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ListMailboxRulesQueue.ps1' 63
#Region './Public/Entrypoints/Activity Triggers/Push-ListMailQuarantineAllTenants.ps1' -1

function Push-ListMailQuarantineAllTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $Tenant = Get-Tenants -TenantFilter $Item.customerId
    $domainName = $Tenant.defaultDomainName
    $Table = Get-CIPPTable -TableName cacheQuarantineMessages
    Write-Host "PowerShell queue trigger function processed work item: $($Tenant.defaultDomainName)"

    try {
        $quarantineMessages = New-ExoRequest -tenantid $domainName -cmdlet 'Get-QuarantineMessage' -cmdParams @{ 'PageSize' = 1000 } | Select-Object -ExcludeProperty *data.type*
        foreach ($message in $quarantineMessages) {
            $messageData = @{
                QuarantineMessage = [string]($message | ConvertTo-Json -Depth 10 -Compress)
                RowKey            = [string](New-Guid).Guid
                PartitionKey      = 'QuarantineMessage'
                Tenant            = [string]$domainName
            }
            Add-CIPPAzDataTableEntity @Table -Entity $messageData -Force | Out-Null
        }
    } catch {
        $errorData = ConvertTo-Json -InputObject @{
            Identity         = $null
            ReceivedTime     = (Get-Date).ToString('s')
            SenderAddress    = 'CIPP Error'
            RecipientAddress = 'N/A'
            Subject          = "Could not connect to Tenant: $($_.Exception.Message)"
            Size             = 0
            Type             = 'Error'
            QuarantineReason = 'ConnectionError'
        }
        $messageData = @{
            QuarantineMessage = [string]$errorData
            RowKey            = [string]$domainName
            PartitionKey      = 'QuarantineMessage'
            Tenant            = [string]$domainName
        }
        Add-CIPPAzDataTableEntity @Table -Entity $messageData -Force | Out-Null
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ListMailQuarantineAllTenants.ps1' 44
#Region './Public/Entrypoints/Activity Triggers/Push-ListMFAUsersQueue.ps1' -1

function Push-ListMFAUsersQueue {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    # Write out the queue message and metadata to the information log.
    Write-Host "PowerShell queue trigger function processed work item: $($Item.defaultDomainName)"

    try {
        #Update-CippQueueEntry -RowKey $Item.QueueId -Status 'Running' -Name $Item.displayName
        $domainName = $Item.defaultDomainName
        $Table = Get-CIPPTable -TableName cachemfa
        Try {
            $GraphRequest = Get-CIPPMFAState -TenantFilter $domainName -ErrorAction Stop
        } catch {
            $GraphRequest = $null
        }
        if (!$GraphRequest) {
            $GraphRequest = @{
                Tenant          = [string]$domainName
                UPN             = [string]$domainName
                AccountEnabled  = 'none'
                PerUser         = [string]'Could not connect to tenant'
                MFARegistration = 'none'
                CoveredByCA     = [string]'Could not connect to tenant'
                CoveredBySD     = 'none'
                RowKey          = [string]"$domainName"
                PartitionKey    = 'users'
            }
        } else {
            $GraphRequest = foreach ($Request in $GraphRequest) {
                $Request.CAPolicies = try { [string](@($Request.CAPolicies) | ConvertTo-Json -Compress -Depth 5) } catch { [string]$Request.CAPolicies }
                $Request.MFAMethods = try { [string](@($Request.MFAMethods) | ConvertTo-Json -Compress -Depth 5) } catch { [string]$Request.MFAMethods }
                $Request
            }
        }
        Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null

    } catch {
        $Table = Get-CIPPTable -TableName cachemfa
        $GraphRequest = @{
            Tenant          = [string]$domainName
            UPN             = [string]$domainName
            AccountEnabled  = 'none'
            PerUser         = [string]'Could not connect to tenant'
            MFARegistration = 'none'
            CoveredByCA     = [string]'Could not connect to tenant'
            CoveredBySD     = 'none'
            RowKey          = [string]"$domainName"
            PartitionKey    = 'users'
        }
        Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force | Out-Null
    } finally {
        #Update-CippQueueEntry -RowKey $QueueItem -Status 'Completed'
    }

}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ListMFAUsersQueue.ps1' 60
#Region './Public/Entrypoints/Activity Triggers/Push-ListTenantAllowBlockListAllTenants.ps1' -1

function Push-ListTenantAllowBlockListAllTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)

    $Tenant = Get-Tenants -TenantFilter $Item.customerId
    $domainName = $Tenant.defaultDomainName
    $Table = Get-CIPPTable -TableName 'cacheTenantAllowBlockList'
    $ListTypes = 'Sender', 'Url', 'FileHash', 'IP'

    try {
        foreach ($ListType in $ListTypes) {
            $Entries = New-ExoRequest -tenantid $domainName -cmdlet 'Get-TenantAllowBlockListItems' -cmdParams @{ ListType = $ListType }
            foreach ($Entry in $Entries) {
                $CleanEntry = $Entry | Select-Object -ExcludeProperty *'@data.type'*, *'(DateTime])'*
                $CleanEntry | Add-Member -MemberType NoteProperty -Name Tenant -Value $domainName -Force
                $CleanEntry | Add-Member -MemberType NoteProperty -Name ListType -Value $ListType -Force
                $Entity = @{
                    Entry        = [string]($CleanEntry | ConvertTo-Json -Depth 10 -Compress)
                    RowKey       = [string](New-Guid).Guid
                    PartitionKey = 'TenantAllowBlockList'
                    Tenant       = [string]$domainName
                }
                Add-CIPPAzDataTableEntity @Table -Entity $Entity -Force | Out-Null
            }
        }
    } catch {
        $ErrorEntry = [pscustomobject]@{
            Tenant      = $domainName
            ListType    = 'Error'
            Identity    = 'Error'
            DisplayName = "Could not retrieve tenant allow/block list: $($_.Exception.Message)"
            Timestamp   = (Get-Date).ToString('s')
        }
        $Entity = @{
            Entry        = [string]($ErrorEntry | ConvertTo-Json -Depth 10 -Compress)
            RowKey       = [string](New-Guid).Guid
            PartitionKey = 'TenantAllowBlockList'
            Tenant       = [string]$domainName
        }
        Add-CIPPAzDataTableEntity @Table -Entity $Entity -Force | Out-Null
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ListTenantAllowBlockListAllTenants.ps1' 47
#Region './Public/Entrypoints/Activity Triggers/Push-ListTransportRulesAllTenants.ps1' -1

function Push-ListTransportRulesAllTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $Tenant = Get-Tenants -TenantFilter $Item.customerId
    $DomainName = $Tenant.defaultDomainName
    $Table = Get-CIPPTable -TableName CacheTransportRules

    try {
        $TransportRules = New-ExoRequest -tenantid $DomainName -cmdlet 'Get-TransportRule'
        $Results = foreach ($rule in $TransportRules) {
            $GUID = (New-Guid).Guid
            $Results = @{
                TransportRule = [string]($rule | ConvertTo-Json -Depth 10)
                RowKey        = [string]$GUID
                PartitionKey  = 'TransportRule'
                Tenant        = [string]$DomainName
            }
            Add-CIPPAzDataTableEntity @Table -Entity $Results -Force | Out-Null
        }

    } catch {
        $GUID = (New-Guid).Guid
        $ErrorText = ConvertTo-Json -InputObject @{
            Tenant      = $DomainName
            Name        = "Could not connect to Tenant: $($_.Exception.Message)"
            State       = 'Error'
            Priority    = 0
            Description = "Error retrieving transport rules: $($_.Exception.Message)"
        }
        $Results = @{
            TransportRule = [string]$ErrorText
            RowKey        = [string]$GUID
            PartitionKey  = 'TransportRule'
            Tenant        = [string]$DomainName
        }
        Add-CIPPAzDataTableEntity @Table -Entity $Results -Force | Out-Null
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ListTransportRulesAllTenants.ps1' 43
#Region './Public/Entrypoints/Activity Triggers/Push-OrchestratorBatchItems.ps1' -1

function Push-OrchestratorBatchItems {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)

    if ($Item.Parameters.BatchId) {
        $Table = Get-CippTable -TableName 'CippOrchestratorBatch'
        $Entities = Get-CIPPAzDataTableEntity @Table -Filter "PartitionKey eq '$($Item.Parameters.BatchId)'"
        $BatchItems = [system.Collections.Generic.List[object]]::new()
        $Entities | ForEach-Object {
            $Item = $_.BatchItem | ConvertFrom-Json
            $BatchItems.Add($Item)
        }
        Write-Information "Retrieved $($BatchItems.Count) batch items for BatchId: $($Item.Parameters.BatchId)"
    } else {
        $BatchItems = [system.Collections.Generic.List[object]]::new()
    }
    return $BatchItems
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-OrchestratorBatchItems.ps1' 23
#Region './Public/Entrypoints/Activity Triggers/Push-ScheduledTaskPostExecution.ps1' -1

function Push-ScheduledTaskPostExecution {
    <#
    .SYNOPSIS
    Post-execution aggregation function for multi-tenant scheduled tasks

    .DESCRIPTION
    Called by orchestrator after all tenant-specific scheduled task executions complete.
    Aggregates results, updates parent task state, and handles recurrence scheduling.

    .FUNCTIONALITY
    Entrypoint
    #>
    param($Item)

    # Extract parameters and results from the item
    $Parameters = $Item.Parameters
    $Results = $Item.Results

    Write-Information "Post-execution started for scheduled task: $($Parameters.TaskRowKey)"
    Write-Information "Received $($Results.Count) tenant execution results"

    $Table = Get-CippTable -tablename 'ScheduledTasks'

    # Get the parent task
    $ParentTask = Get-AzDataTableEntity @Table -Filter "RowKey eq '$($Parameters.TaskRowKey)'"
    if (!$ParentTask) {
        Write-Warning "Parent task $($Parameters.TaskRowKey) not found in ScheduledTasks table"
        return
    }

    Write-Information "Parent task found: $($ParentTask.Name) - Current state: $($ParentTask.TaskState)"

    # Aggregate results
    $SuccessCount = 0
    $FailureCount = 0
    $TotalTenants = $Results.Count

    foreach ($Result in $Results) {
        if ($Result -and $Result -notlike '*Failed*' -and $Result -notlike '*Error*') {
            $SuccessCount++
        } else {
            $FailureCount++
        }
    }

    Write-Information "Aggregated results: $SuccessCount successful, $FailureCount failed out of $TotalTenants tenants"

    # Determine if this was a recurring task
    $IsRecurring = $ParentTask.Recurrence -and $ParentTask.Recurrence -ne '0'

    # Check trigger execution mode
    $IsTriggerOnce = $false
    if ($ParentTask.Trigger) {
        $Trigger = if (Test-Json -Json $ParentTask.Trigger) {
            $ParentTask.Trigger | ConvertFrom-Json
        } else {
            $ParentTask.Trigger
        }
        $TriggerExecutionMode = $Trigger.ExecutionMode.value ?? $Trigger.ExecutionMode
        if ($TriggerExecutionMode -eq 'once') {
            $IsTriggerOnce = $true
        }
    }

    # Prepare aggregated results message
    $AggregatedMessage = "Multi-tenant task completed: $SuccessCount successful, $FailureCount failed (Total: $TotalTenants tenants)"

    # Calculate next run time for recurring tasks
    if ($IsRecurring -and !$IsTriggerOnce) {
        # Convert recurrence to seconds
        if ($ParentTask.Recurrence -match '^\d+$') {
            $ParentTask.Recurrence = $ParentTask.Recurrence + 'd'
        }

        $secondsToAdd = switch -Regex ($ParentTask.Recurrence) {
            '(\d+)m$' { [int64]$matches[1] * 60 }
            '(\d+)h$' { [int64]$matches[1] * 3600 }
            '(\d+)d$' { [int64]$matches[1] * 86400 }
            default { 0 }
        }

        if ($secondsToAdd -gt 0) {
            $unixtimeNow = [int64](([datetime]::UtcNow) - (Get-Date '1/1/1970')).TotalSeconds
            if ([int64]$ParentTask.ScheduledTime -lt ($unixtimeNow - $secondsToAdd)) {
                $ParentTask.ScheduledTime = $unixtimeNow
            }
            $nextRunUnixTime = [int64]$ParentTask.ScheduledTime + [int64]$secondsToAdd

            Write-Information "Recurring task: next run scheduled for $nextRunUnixTime"

            # Update parent task to 'Planned' state for next execution
            $UpdateEntity = @{
                PartitionKey  = $ParentTask.PartitionKey
                RowKey        = $ParentTask.RowKey
                Results       = $AggregatedMessage
                TaskState     = if ($FailureCount -gt 0 -and $FailureCount -eq $TotalTenants) { 'Failed - Planned' } else { 'Planned' }
                ScheduledTime = "$nextRunUnixTime"
            }
        } else {
            # Invalid recurrence, mark as completed
            Write-Warning "Invalid recurrence value: $($ParentTask.Recurrence). Marking task as completed."
            $UpdateEntity = @{
                PartitionKey = $ParentTask.PartitionKey
                RowKey       = $ParentTask.RowKey
                Results      = "$AggregatedMessage - Warning: Invalid recurrence, task will not repeat"
                TaskState    = 'Completed'
            }
        }
    } else {
        # One-time task or trigger with 'once' mode - mark as completed
        Write-Information 'Non-recurring task: marking as completed'
        $UpdateEntity = @{
            PartitionKey = $ParentTask.PartitionKey
            RowKey       = $ParentTask.RowKey
            Results      = $AggregatedMessage
            TaskState    = if ($FailureCount -gt 0 -and $FailureCount -eq $TotalTenants) { 'Failed' } else { 'Completed' }
        }
    }

    # Update the parent task
    try {
        $null = Update-AzDataTableEntity -Force @Table -Entity $UpdateEntity
        Write-Information "Parent task updated successfully to state: $($UpdateEntity.TaskState)"
    } catch {
        Write-Warning "Failed to update parent task: $($_.Exception.Message)"
        Write-Information $_.InvocationInfo.PositionMessage
    }

    # Send consolidated alert/notification if results exist
    # Individual tenant alerts are already sent by Push-ExecScheduledCommand
    # This is just for overall task completion notification if needed
    try {
        if ($Parameters.SendCompletionAlert) {
            Write-Information 'Completion notification available for multi-tenant task'
            Write-Information "Task: $($ParentTask.Name)"
            Write-Information "Results: $SuccessCount successful, $FailureCount failed out of $TotalTenants tenants"
            if ($IsRecurring -and $nextRunUnixTime) {
                $nextRunDate = (Get-Date '1970-01-01').AddSeconds($nextRunUnixTime).ToUniversalTime()
                Write-Information "Next run scheduled for: $($nextRunDate.ToString('yyyy-MM-dd HH:mm:ss UTC'))"
            }
            # Note: Individual tenant results are already in ScheduledTaskResults table
        }
    } catch {
        Write-Warning "Failed to log completion info: $($_.Exception.Message)"
    }

    Write-Information "Post-execution completed for task: $($ParentTask.Name)"
    return @{
        Status            = 'Success'
        TaskState         = $UpdateEntity.TaskState
        SuccessCount      = $SuccessCount
        FailureCount      = $FailureCount
        TotalTenants      = $TotalTenants
        AggregatedMessage = $AggregatedMessage
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-ScheduledTaskPostExecution.ps1' 157
#Region './Public/Entrypoints/Activity Triggers/Push-SchedulerCIPPNotifications.ps1' -1

function Push-SchedulerCIPPNotifications {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param (
        $QueueItem, $TriggerMetadata
    )
    #Add new alert engine.
    $Table = Get-CIPPTable -TableName SchedulerConfig
    $Filter = "RowKey eq 'CippNotifications' and PartitionKey eq 'CippNotifications'"
    $Config = [pscustomobject](Get-CIPPAzDataTableEntity @Table -Filter $Filter)

    $Settings = [System.Collections.Generic.List[string]]@('Alerts')
    $Config.psobject.properties.name | ForEach-Object { if ($Config.$_ -eq $true) { $Settings.Add($_) } }
    Write-Information "Our APIs are: $($Settings -join ',')"

    $severity = $Config.Severity -split ','
    if (!$severity) {
        $severity = [System.Collections.ArrayList]@('Info', 'Error', 'Warning', 'Critical', 'Alert')
    }
    Write-Information "Our Severity table is: $severity"

    $Table = Get-CIPPTable
    $PartitionKey = Get-Date -UFormat '%Y%m%d'
    $Filter = "PartitionKey eq '{0}'" -f $PartitionKey
    $Currentlog = Get-CIPPAzDataTableEntity @Table -Filter $Filter | Where-Object {
        $_.API -in $Settings -and $_.sentAsAlert -ne $true -and $_.Severity -in $severity
    }
    $StandardsTable = Get-CIPPTable -tablename CippStandardsAlerts
    $CurrentStandardsLogs = Get-CIPPAzDataTableEntity @StandardsTable -Filter $Filter | Where-Object {
        $_.sentAsAlert -ne $true
    }
    Write-Information "Alerts: $($Currentlog.count) found"
    Write-Information "Standards: $($CurrentStandardsLogs.count) found"

    # Get the CIPP URL
    $CippConfigTable = Get-CippTable -tablename Config
    $CippConfig = Get-CIPPAzDataTableEntity @CippConfigTable -Filter "PartitionKey eq 'InstanceProperties' and RowKey eq 'CIPPURL'"
    $CIPPURL = 'https://{0}' -f $CippConfig.Value

    #email try
    try {
        if ($Config.email -like '*@*') {
            #Normal logs
            if ($Currentlog) {
                if ($config.onePerTenant) {
                    foreach ($tenant in ($CurrentLog.Tenant | Sort-Object -Unique)) {
                        $Data = ($CurrentLog | Select-Object Message, API, Tenant, Username, Severity | Where-Object -Property tenant -EQ $tenant)
                        $Subject = "$($Tenant): CIPP Alert: Alerts found starting at $((Get-Date).AddMinutes(-15))"
                        $HTMLContent = New-CIPPAlertTemplate -Data $Data -Format 'html' -InputObject 'table' -CIPPURL $CIPPURL
                        Send-CIPPAlert -Type 'email' -Title $Subject -HTMLContent $HTMLContent.htmlcontent -TenantFilter $tenant -APIName 'Alerts'
                        $UpdateLogs = $CurrentLog | ForEach-Object {
                            if ($_.PSObject.Properties.Name -contains 'sentAsAlert') {
                                $_.sentAsAlert = $true
                            } else {
                                $_ | Add-Member -MemberType NoteProperty -Name sentAsAlert -Value $true -Force
                            }
                            $_
                        }
                        if ($UpdateLogs) {
                            Add-CIPPAzDataTableEntity @Table -Entity $UpdateLogs -Force
                        }
                    }
                } else {
                    $Data = ($CurrentLog | Select-Object Message, API, Tenant, Username, Severity)
                    $Subject = "CIPP Alert: Alerts found starting at $((Get-Date).AddMinutes(-15))"
                    $HTMLContent = New-CIPPAlertTemplate -Data $Data -Format 'html' -InputObject 'table' -CIPPURL $CIPPURL
                    Send-CIPPAlert -Type 'email' -Title $Subject -HTMLContent $HTMLContent.htmlcontent -TenantFilter 'AllTenants' -APIName 'Alerts'
                    $UpdateLogs = $CurrentLog | ForEach-Object {
                        if ($_.PSObject.Properties.Name -contains 'sentAsAlert') {
                            $_.sentAsAlert = $true
                        } else {
                            $_ | Add-Member -MemberType NoteProperty -Name sentAsAlert -Value $true -Force
                        }
                        $_
                    }
                    if ($UpdateLogs) {
                        Add-CIPPAzDataTableEntity @Table -Entity $UpdateLogs -Force
                    }
                }
            }
            if ($CurrentStandardsLogs) {
                foreach ($tenant in ($CurrentStandardsLogs.Tenant | Sort-Object -Unique)) {
                    $Data = ($CurrentStandardsLogs | Where-Object -Property tenant -EQ $tenant)
                    $Subject = "$($Tenant): Standards are out of sync for $tenant"
                    $HTMLContent = New-CIPPAlertTemplate -Data $Data -Format 'html' -InputObject 'standards' -CIPPURL $CIPPURL
                    Send-CIPPAlert -Type 'email' -Title $Subject -HTMLContent $HTMLContent.htmlcontent -TenantFilter $tenant -APIName 'Alerts'
                    $updateStandards = $CurrentStandardsLogs | ForEach-Object {
                        if ($_.PSObject.Properties.Name -contains 'sentAsAlert') {
                            $_.sentAsAlert = $true
                        } else {
                            $_ | Add-Member -MemberType NoteProperty -Name sentAsAlert -Value $true -Force
                        }
                        $_
                    }
                    if ($updateStandards) { Add-CIPPAzDataTableEntity @StandardsTable -Entity $updateStandards -Force }
                }
            }
        }
    } catch {
        Write-Information "Could not send alerts to email: $($_.Exception.message)"
        Write-LogMessage -API 'Alerts' -message "Could not send alert emails: $($_.Exception.message)" -sev error -LogData (Get-CippException -Exception $_)
    }

    try {
        Write-Information $($config | ConvertTo-Json)
        Write-Information $config.webhook
        if (![string]::IsNullOrEmpty($config.webhook)) {
            if ($Currentlog) {
                $JSONContent = $Currentlog | ConvertTo-Json -Compress
                $Title = "Logbook Notification: Alerts found starting at $((Get-Date).AddMinutes(-15))"
                Send-CIPPAlert -Type 'webhook' -Title $Title -JSONContent $JSONContent -TenantFilter 'AllTenants' -APIName 'Alerts' -SchemaSource 'Logbook Notification' -InvokingCommand 'Push-SchedulerCIPPNotifications' -UseStandardizedSchema:$([boolean]$Config.UseStandardizedSchema)
                $UpdateLogs = $CurrentLog | ForEach-Object { $_.sentAsAlert = $true; $_ }
                if ($UpdateLogs) { Add-CIPPAzDataTableEntity @Table -Entity $UpdateLogs -Force }
            }

            if ($CurrentStandardsLogs) {
                $Data = $CurrentStandardsLogs
                $JSONContent = New-CIPPAlertTemplate -Data $Data -Format 'json' -InputObject 'table' -CIPPURL $CIPPURL
                $CurrentStandardsLogs | ConvertTo-Json -Compress
                $Title = "Standards Notification: Out of sync standards detected"
                Send-CIPPAlert -Type 'webhook' -Title $Title -JSONContent $JSONContent -TenantFilter 'AllTenants' -APIName 'Alerts' -SchemaSource 'Standards Notification' -InvokingCommand 'Push-SchedulerCIPPNotifications' -UseStandardizedSchema:$([boolean]$Config.UseStandardizedSchema)
                $updateStandards = $CurrentStandardsLogs | ForEach-Object {
                    if ($_.PSObject.Properties.Name -contains 'sentAsAlert') {
                        $_.sentAsAlert = $true
                    } else {
                        $_ | Add-Member -MemberType NoteProperty -Name sentAsAlert -Value $true -Force
                    }
                    $_
                }
            }

        }
    } catch {
        Write-Information "Could not send alerts to webhook $($config.webhook): $($_.Exception.message)"
        Write-LogMessage -API 'Alerts' -message "Could not send alerts to webhook $($config.webhook): $($_.Exception.message)" -tenant $Tenant -sev error -LogData (Get-CippException -Exception $_)
    }

    if ($config.sendtoIntegration) {
        try {
            foreach ($tenant in ($CurrentLog.Tenant | Sort-Object -Unique)) {
                $Data = ($CurrentLog | Select-Object Message, API, Tenant, Username, Severity | Where-Object -Property tenant -EQ $tenant)
                $HTMLContent = New-CIPPAlertTemplate -Data $Data -Format 'html' -InputObject 'table' -CIPPURL $CIPPURL
                $Title = "$tenant CIPP Alert: Alerts found starting at $((Get-Date).AddMinutes(-15))"
                Send-CIPPAlert -Type 'psa' -Title $Title -HTMLContent $HTMLContent.htmlcontent -TenantFilter $tenant -APIName 'Alerts'
                $UpdateLogs = $CurrentLog | ForEach-Object { $_.SentAsAlert = $true; $_ }
                if ($UpdateLogs) { Add-CIPPAzDataTableEntity @Table -Entity $UpdateLogs -Force }
            }
            foreach ($standardsTenant in ($CurrentStandardsLogs.Tenant | Sort-Object -Unique)) {
                $Data = ($CurrentStandardsLogs | Where-Object -Property tenant -EQ $standardsTenant)
                $Subject = "$($standardsTenant): Standards are out of sync for $standardsTenant"
                $HTMLContent = New-CIPPAlertTemplate -Data $Data -Format 'html' -InputObject 'standards' -CIPPURL $CIPPURL
                Send-CIPPAlert -Type 'psa' -Title $Subject -HTMLContent $HTMLContent.htmlcontent -TenantFilter $standardsTenant -APIName 'Alerts'
                $updateStandards = $CurrentStandardsLogs | ForEach-Object {
                    if ($_.PSObject.Properties.Name -contains 'sentAsAlert') {
                        $_.sentAsAlert = $true
                    } else {
                        $_ | Add-Member -MemberType NoteProperty -Name sentAsAlert -Value $true -Force
                    }
                    $_
                }
            }
        } catch {
            Write-Information "Could not send alerts to ticketing system: $($_.Exception.message)"
            Write-LogMessage -API 'Alerts' -tenant $Tenant -message "Could not send alerts to ticketing system: $($_.Exception.message)" -sev Error
        }
    }

}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-SchedulerCIPPNotifications.ps1' 171
#Region './Public/Entrypoints/Activity Triggers/Push-StoreMailboxRules.ps1' -1

function Push-StoreMailboxRules {
    <#
    .SYNOPSIS
        Post-execution function to aggregate and store all mailbox rules

    .DESCRIPTION
        Collects results from all batches and stores them in the reporting database

    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)

    $TenantFilter = $Item.Parameters.TenantFilter
    $Results = $Item.Results

    try {
        Write-Information "Storing mailbox rules for tenant $TenantFilter"
        Write-Information "Received $($Results.Count) batch results"

        # Aggregate all rules from batches
        $AllRules = [System.Collections.Generic.List[object]]::new()

        foreach ($BatchResult in $Results) {
            # Activity functions may return an array
            $ActualResult = $BatchResult
            if ($BatchResult -is [array] -and $BatchResult.Count -gt 0) {
                Write-Information "Result is array with $($BatchResult.Count) elements"
                # If first element is array of rules, use it
                if ($BatchResult[0] -is [array]) {
                    $ActualResult = $BatchResult[0]
                } else {
                    $ActualResult = $BatchResult
                }
            }

            if ($ActualResult) {
                if ($ActualResult -is [array]) {
                    Write-Information "Adding $($ActualResult.Count) rules from batch"
                    $AllRules.AddRange($ActualResult)
                } else {
                    Write-Information 'Adding 1 rule from batch'
                    $AllRules.Add($ActualResult)
                }
            }
        }

        Write-Information "Aggregated $($AllRules.Count) total mailbox rules"

        # Store all rules
        if ($AllRules.Count -gt 0) {
            $AllRules | Add-CIPPDbItem -TenantFilter $TenantFilter -Type 'MailboxRules' -AddCount
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message "Cached $($AllRules.Count) mailbox rules" -sev Info
        } else {
            # Store empty result to indicate successful check with no rules
            @() | Add-CIPPDbItem -TenantFilter $TenantFilter -Type 'MailboxRules' -AddCount
            Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message 'No mailbox rules found to cache' -sev Info
        }

        return

    } catch {
        $ErrorMsg = "Failed to store mailbox rules for tenant $TenantFilter : $($_.Exception.Message)"
        Write-LogMessage -API 'CIPPDBCache' -tenant $TenantFilter -message $ErrorMsg -sev Error
        throw $ErrorMsg
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-StoreMailboxRules.ps1' 69
#Region './Public/Entrypoints/Activity Triggers/Push-UpdatePermissionsQueue.ps1' -1

function Push-UpdatePermissionsQueue {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    try {
        $DomainRefreshRequired = $false

        if (!$Item.defaultDomainName) {
            $DomainRefreshRequired = $true
        }

        Write-Information "Applying permissions for $($Item.displayName)"
        $Table = Get-CIPPTable -TableName cpvtenants
        $CPVRows = Get-CIPPAzDataTableEntity @Table | Where-Object -Property Tenant -EQ $Item.customerId

        $Tenant = Get-Tenants -TenantFilter $Item.customerId -IncludeErrors

        if ((!$CPVRows -or $env:ApplicationID -notin $CPVRows.applicationId) -and $Tenant.delegatedPrivilegeStatus -ne 'directTenant') {
            Write-LogMessage -tenant $Item.defaultDomainName -tenantId $Item.customerId -message 'A New tenant has been added, or a new CIPP-SAM Application is in use' -Sev 'Warning' -API 'NewTenant'
            Write-Information 'Adding CPV permissions'
            Set-CIPPCPVConsent -Tenantfilter $Item.customerId
            $DomainRefreshRequired = $true
        }
        Write-Information 'Updating permissions'
        $AppResults = Add-CIPPApplicationPermission -RequiredResourceAccess 'CIPPDefaults' -ApplicationId $env:ApplicationID -tenantfilter $Item.customerId
        $DelegatedResults = Add-CIPPDelegatedPermission -RequiredResourceAccess 'CIPPDefaults' -ApplicationId $env:ApplicationID -tenantfilter $Item.customerId

        # Check for permission failures (excluding service principal creation failures)
        $AllResults = @($AppResults) + @($DelegatedResults)
        $PermissionFailures = $AllResults | Where-Object {
            $_ -like '*Failed*' -and
            $_ -notlike '*Failed to create service principal*'
        }

        if ($PermissionFailures) {
            $Status = 'Failed'
            $FailureMessage = ($PermissionFailures -join '; ')
            Write-LogMessage -tenant $Item.defaultDomainName -tenantId $Item.customerId -message "Permission update completed with failures for $($Item.displayName): $FailureMessage" -Sev 'Warning' -API 'UpdatePermissionsQueue'
        } else {
            $Status = 'Success'
            Write-LogMessage -tenant $Item.defaultDomainName -tenantId $Item.customerId -message "Updated permissions for $($Item.displayName)" -Sev 'Info' -API 'UpdatePermissionsQueue'
        }

        if ($Item.defaultDomainName -ne 'PartnerTenant') {
            Write-Information 'Pushing CIPP-SAM admin roles'
            Set-CIPPSAMAdminRoles -TenantFilter $Item.customerId
        }

        $Table = Get-CIPPTable -TableName cpvtenants
        $unixtime = [int64](([datetime]::UtcNow) - (Get-Date '1/1/1970')).TotalSeconds
        $GraphRequest = @{
            LastApply     = "$unixtime"
            LastStatus    = "$Status"
            applicationId = "$($env:ApplicationID)"
            Tenant        = "$($Item.customerId)"
            PartitionKey  = 'Tenant'
            RowKey        = "$($Item.customerId)"
        }
        if ($PermissionFailures) {
            $GraphRequest.LastError = $FailureMessage
        }
        Add-CIPPAzDataTableEntity @Table -Entity $GraphRequest -Force

        if ($DomainRefreshRequired) {
            $UpdatedTenant = Get-Tenants -TenantFilter $Item.customerId -TriggerRefresh
            if ($UpdatedTenant.defaultDomainName) {
                Write-Information "Updated tenant domains $($UpdatedTenant.defaultDomainName)"
            }
        }
    } catch {
        Write-Information "Error updating permissions for $($Item.displayName): $($_.Exception.Message)"
        Write-Information $_.InvocationInfo.PositionMessage
        Write-LogMessage -tenant $Item.defaultDomainName -tenantId $Item.customerId -message "Error updating permissions for $($Item.displayName) - $($_.Exception.Message)" -Sev 'Error' -API 'UpdatePermissionsQueue' -LogData (Get-CippException -Exception $_)
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-UpdatePermissionsQueue.ps1' 79
#Region './Public/Entrypoints/Activity Triggers/Push-UpdateTenants.ps1' -1

function Push-UpdateTenants {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    Param($Item)
    $QueueReference = 'UpdateTenants'
    $RunningQueue = Get-CIPPQueueData -Reference $QueueReference | Where-Object { $_.Status -ne 'Completed' -and $_.Status -ne 'Failed' }

    $Queue = New-CippQueueEntry -Name 'Update Tenants' -Reference $QueueReference -TotalTasks 1
    try {
        $QueueTask = @{
            QueueId = $Queue.RowKey
            Name    = 'Get tenant list'
            Status  = 'Running'
        }
        $TaskStatus = Set-CippQueueTask @QueueTask
        $QueueTask.TaskId = $TaskStatus.RowKey
        Update-CippQueueEntry -RowKey $Queue.RowKey -Status 'Running'
        Get-Tenants -IncludeAll -TriggerRefresh | Out-Null
        Update-CippQueueEntry -RowKey $Queue.RowKey -Status 'Completed'
        $QueueTask.Status = 'Completed'
        Set-CippQueueTask @QueueTask
    } catch {
        Write-Host "Queue Error: $($_.Exception.Message)"
        Update-CippQueueEntry -RowKey $Queue.RowKey -Status 'Failed'
        $QueueTask.Status = 'Failed'
        Set-CippQueueTask @QueueTask
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-UpdateTenants.ps1' 31
#Region './Public/Entrypoints/Activity Triggers/Push-Z_CIPPQueueTrigger.ps1' -1

function Push-Z_CIPPQueueTrigger {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    Param($QueueItem, $TriggerMetadata)
    $APIName = $QueueItem.FunctionName

    $FunctionName = 'Push-{0}' -f $APIName
    if (Get-Command -Name $FunctionName -ErrorAction SilentlyContinue) {
        & $FunctionName -QueueItem $QueueItem -TriggerMetadata $TriggerMetadata
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Push-Z_CIPPQueueTrigger.ps1' 14
#Region './Public/Entrypoints/Activity Triggers/Standards/Push-CIPPDriftManagement.ps1' -1

function Push-CippDriftManagement {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param (
        $Item
    )

    Write-Information "Received drift standard item for $($Item.Tenant)"

    try {
        $Drift = Get-CIPPDrift -TenantFilter $Item.Tenant
        if ($Drift.newDeviationsCount -gt 0) {
            $Settings = $Drift.driftSettings
            $email = $Settings.driftAlertEmail
            $webhook = $Settings.driftAlertWebhook
            $CippConfigTable = Get-CippTable -tablename Config
            $CippConfig = Get-CIPPAzDataTableEntity @CippConfigTable -Filter "PartitionKey eq 'InstanceProperties' and RowKey eq 'CIPPURL'"
            $CIPPURL = 'https://{0}' -f $CippConfig.Value

            # Process deviations more efficiently with foreach instead of ForEach-Object
            $Data = foreach ($deviation in $Drift.currentDeviations) {
                $currentValue = if ($deviation.receivedValue -and $deviation.receivedValue.Length -gt 200) {
                    $deviation.receivedValue.Substring(0, 200) + '...'
                } else {
                    $deviation.receivedValue
                }
                [PSCustomObject]@{
                    Standard         = $deviation.standardDisplayName ? $deviation.standardDisplayName : $deviation.standardName
                    'Expected Value' = $deviation.expectedValue
                    'Current Value'  = $currentValue
                    Status           = $deviation.status
                }
            }

            $GenerateEmail = New-CIPPAlertTemplate -format 'html' -data $Data -CIPPURL $CIPPURL -Tenant $Item.Tenant -InputObject 'driftStandard' -AuditLogLink $drift.standardId

            # Check if notifications are disabled (default to false if not set)
            if (-not $Settings.driftAlertDisableEmail) {
                # Send email alert if configured
                $CIPPAlert = @{
                    Type         = 'email'
                    Title        = $GenerateEmail.title
                    HTMLContent  = $GenerateEmail.htmlcontent
                    TenantFilter = $Item.Tenant
                }
                Write-Information "Sending email alert for tenant $($Item.Tenant)"
                Send-CIPPAlert @CIPPAlert -altEmail $email
                
                # Send webhook alert if configured
                $WebhookData = @{
                    Title      = $GenerateEmail.title
                    ActionUrl  = $GenerateEmail.ButtonUrl
                    ActionText = $GenerateEmail.ButtonText
                    AlertData  = $Data
                    Tenant     = $Item.Tenant
                } | ConvertTo-Json -Depth 5 -Compress
                $CippAlert = @{
                    Type         = 'webhook'
                    Title        = $GenerateEmail.title
                    JSONContent  = $WebhookData
                    TenantFilter = $Item.Tenant
                }
                Write-Information "Sending webhook alert for tenant $($Item.Tenant)"
                Send-CIPPAlert @CippAlert -altWebhook $webhook
                
                # Send PSA alert
                $CIPPAlert = @{
                    Type         = 'psa'
                    Title        = $GenerateEmail.title
                    HTMLContent  = $GenerateEmail.htmlcontent
                    TenantFilter = $Item.Tenant
                }
                Send-CIPPAlert @CIPPAlert
            } else {
                Write-Information "All notifications disabled for tenant $($Item.Tenant)"
            }
            return $true
        } else {
            Write-LogMessage -API 'DriftStandards' -tenant $Item.Tenant -message "No new drift deviations found for tenant $($Item.Tenant)" -sev Info
            return $true
        }
        Write-Information "Drift management completed for tenant $($Item.Tenant)"
    } catch {
        Write-LogMessage -API 'DriftStandards' -tenant $Item.Tenant -message "Error running Drift Check for tenant $($Item.Tenant) - $($_.Exception.Message)" -sev Error -LogData (Get-CippException -Exception $_)
        Write-Warning "Error running drift standards for tenant $($Item.Tenant) - $($_.Exception.Message)"
        Write-Information $_.InvocationInfo.PositionMessage
        throw $_.Exception.Message
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Standards/Push-CIPPDriftManagement.ps1' 92
#Region './Public/Entrypoints/Activity Triggers/Standards/Push-CIPPStandard.ps1' -1

function Push-CIPPStandard {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param (
        $Item
    )

    Write-Information "Received queue item for $($Item.Tenant) and standard $($Item.Standard)."

    $Tenant = $Item.Tenant
    $Standard = $Item.Standard
    $FunctionName = 'Invoke-CIPPStandard{0}' -f $Standard

    Write-Information "We'll be running $FunctionName"

    if ($Standard -in @('IntuneTemplate', 'ConditionalAccessTemplate')) {
        $API = "$($Standard)_$($Item.TemplateId)_$($Item.Settings.TemplateList.value)"
    } else {
        $API = "$($Standard)_$($Item.TemplateId)"
    }

    $Rerun = Test-CIPPRerun -Type Standard -Tenant $Tenant -API $API
    if ($Rerun) {
        Write-Information 'Detected rerun. Exiting cleanly'
        return
    } else {
        Write-Information "Rerun is set to false. We'll be running $FunctionName"
    }

    $StandardInfo = @{
        Standard           = $Standard
        StandardTemplateId = $Item.TemplateId
    }
    if ($Standard -eq 'IntuneTemplate') {
        $StandardInfo.IntuneTemplateId = $Item.Settings.TemplateList.value
    }
    if ($Standard -eq 'ConditionalAccessTemplate') {
        $StandardInfo.ConditionalAccessTemplateId = $Item.Settings.TemplateList.value
    }

    # Initialize AsyncLocal storage for thread-safe per-invocation context
    # Uses $global: so Write-LogMessage (CIPPCore module) can read it across module boundaries
    if (-not $global:CippStandardInfoStorage) {
        $global:CippStandardInfoStorage = [System.Threading.AsyncLocal[object]]::new()
    }
    $global:CippStandardInfoStorage.Value = $StandardInfo

    # ---- Standard execution telemetry ----
    $runId = [guid]::NewGuid().ToString()
    $invocationId = if ($ExecutionContext -and $ExecutionContext.InvocationId) {
        "$($ExecutionContext.InvocationId)"
    } else {
        $null
    }

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $result = 'Unknown'
    $err = $null

    Write-Information -Tag 'CIPPStandardStart' -MessageData (@{
            Kind         = 'CIPPStandardStart'
            RunId        = $runId
            InvocationId = $invocationId
            Tenant       = $Tenant
            Standard     = $Standard
            TemplateId   = $Item.TemplateId
            API          = $API
            FunctionName = $FunctionName
        } | ConvertTo-Json -Compress)
    # -------------------------------------

    try {
        # Convert settings to JSON, replace %variables%, then convert back to object
        $SettingsJSON = $Item.Settings | ConvertTo-Json -Depth 10 -Compress
        if ($SettingsJSON -match '%') {
            $Settings = Get-CIPPTextReplacement -TenantFilter $Item.Tenant -Text $SettingsJSON | ConvertFrom-Json
        } else {
            $Settings = $Item.Settings
        }

        # Prepare telemetry metadata for standard execution
        $metadata = @{
            Standard     = $Standard
            Tenant       = $Tenant
            TemplateId   = $Item.TemplateId
            FunctionName = $FunctionName
            TriggerType  = 'Standard'
        }

        if ($Standard -eq 'IntuneTemplate' -and $Item.Settings.TemplateList.value) {
            $metadata['IntuneTemplateId'] = $Item.Settings.TemplateList.value
        }
        if ($Standard -eq 'ConditionalAccessTemplate' -and $Item.Settings.TemplateList.value) {
            $metadata['CATemplateId'] = $Item.Settings.TemplateList.value
        }

        & $FunctionName -Tenant $Item.Tenant -Settings $Settings -ErrorAction Stop

        $result = 'Success'
        Write-Information "Standard $($Standard) completed for tenant $($Tenant)"
    } catch {
        $result = 'Failed'
        $err = $_.Exception.Message

        Write-LogMessage -API 'Standards' -tenant $Tenant -message "Error running standard $($Standard) for tenant $($Tenant) - $($_.Exception.Message)" -sev Error -LogData (Get-CippException -Exception $_)
        Write-Warning "Error running standard $($Standard) for tenant $($Tenant) - $($_.Exception.Message)"
        Write-Information $_.InvocationInfo.PositionMessage
        throw $_.Exception.Message
    } finally {
        $sw.Stop()

        Write-Information -Tag 'CIPPStandardEnd' -MessageData (@{
                Kind         = 'CIPPStandardEnd'
                RunId        = $runId
                InvocationId = $invocationId
                Tenant       = $Tenant
                Standard     = $Standard
                TemplateId   = $Item.TemplateId
                API          = $API
                FunctionName = $FunctionName
                Result       = $result
                ElapsedMs    = $sw.ElapsedMilliseconds
                Error        = $err
            } | ConvertTo-Json -Compress)

        if ($global:CippStandardInfoStorage) {
            $global:CippStandardInfoStorage.Value = $null
        }
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Standards/Push-CIPPStandard.ps1' 133
#Region './Public/Entrypoints/Activity Triggers/Standards/Push-CIPPStandardsApplyBatch.ps1' -1

function Push-CIPPStandardsApplyBatch {
    <#
    .FUNCTIONALITY
    Entrypoint
    #>
    param($Item)

    try {
        # Aggregate all standards from all tenants
        $AllStandards = $Item.Results | ForEach-Object {
            foreach ($Standard in $_) {
                if ($Standard -and $Standard.FunctionName -eq 'CIPPStandard') {
                    $Standard
                }
            }
        }

        if ($AllStandards.Count -eq 0) {
            Write-Information 'No standards to apply across all tenants'
            return
        }

        Write-Information "Aggregated $($AllStandards.Count) standards from all tenants: $($AllStandards | ConvertTo-Json -Depth 5 -Compress)"

        # Start orchestrator to apply standards
        $InputObject = [PSCustomObject]@{
            OrchestratorName = 'StandardsApply'
            Batch            = @($AllStandards)
            SkipLog          = $true
        }
        Write-Host "Standards InputObject: $($InputObject | ConvertTo-Json -Depth 25 -Compress)"
        $InstanceId = Start-CIPPOrchestrator -InputObject $InputObject
        Write-Information "Started standards apply orchestrator with ID = '$InstanceId'"
    } catch {
        Write-Warning "Error in standards apply batch aggregation: $($_.Exception.Message)"
    }
    return @{
        Success = $true
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Standards/Push-CIPPStandardsApplyBatch.ps1' 41
#Region './Public/Entrypoints/Activity Triggers/Standards/Push-CIPPStandardsList.ps1' -1

function Push-CIPPStandardsList {
    <#
    .FUNCTIONALITY
    Entrypoint
    #>
    param($Item)

    $TenantFilter = $Item.TenantFilter
    $runManually = $Item.runManually
    $TemplateId = $Item.TemplateId

    try {
        # Get standards for this tenant
        $GetStandardParams = @{
            TenantFilter = $TenantFilter
            runManually  = $runManually
        }
        if ($TemplateId) {
            $GetStandardParams['TemplateId'] = $TemplateId
        }

        $AllStandards = Get-CIPPStandards @GetStandardParams

        if ($AllStandards.Count -eq 0) {
            Write-Information "No standards found for tenant $TenantFilter"
            return @()
        }
        Write-Host "Retrieved $($AllStandards.Count) standards for tenant $TenantFilter before filtering."
        # Build hashtable for efficient lookup
        $ComputedStandards = @{}
        foreach ($Standard in $AllStandards) {
            $Key = "$($Standard.Standard)|$($Standard.Settings.TemplateList.value)"
            $ComputedStandards[$Key] = $Standard
        }

        # Check if IntuneTemplate standards are present
        $IntuneTemplateFound = ($ComputedStandards.Keys.Where({ $_ -like '*IntuneTemplate*' }, 'First').Count -gt 0)

        if ($IntuneTemplateFound) {
            # Perform license check
            $TestResult = Test-CIPPStandardLicense -StandardName 'IntuneTemplate_general' -TenantFilter $TenantFilter -RequiredCapabilities @('INTUNE_A', 'MDM_Services', 'EMS', 'SCCM', 'MICROSOFTINTUNEPLAN1')

            if (-not $TestResult) {
                # Remove IntuneTemplate standards and set compare fields
                $IntuneKeys = @($ComputedStandards.Keys | Where-Object { $_ -like '*IntuneTemplate*' })
                $BulkFields = [System.Collections.Generic.List[object]]::new()

                foreach ($Key in $IntuneKeys) {
                    $TemplateKey = ($Key -split '\|', 2)[1]
                    if ($TemplateKey) {
                        $BulkFields.Add([PSCustomObject]@{
                                FieldName  = "standards.IntuneTemplate.$TemplateKey"
                                FieldValue = 'This tenant does not have the required license for this standard.'
                            })
                    }
                    [void]$ComputedStandards.Remove($Key)
                }

                if ($BulkFields.Count -gt 0) {
                    Set-CIPPStandardsCompareField -TenantFilter $TenantFilter -BulkFields $BulkFields
                }

                Write-Information "Removed IntuneTemplate standards for $TenantFilter - missing required license"
            } else {
                # License valid - check policy timestamps to filter unchanged templates
                $TypeMap = @{
                    Device                       = 'deviceManagement/deviceConfigurations'
                    Catalog                      = 'deviceManagement/configurationPolicies'
                    Admin                        = 'deviceManagement/groupPolicyConfigurations'
                    deviceCompliancePolicies     = 'deviceManagement/deviceCompliancePolicies'
                    AppProtection_Android        = 'deviceAppManagement/androidManagedAppProtections'
                    AppProtection_iOS            = 'deviceAppManagement/iosManagedAppProtections'
                    windowsDriverUpdateProfiles  = 'deviceManagement/windowsDriverUpdateProfiles'
                    windowsFeatureUpdateProfiles = 'deviceManagement/windowsFeatureUpdateProfiles'
                    windowsQualityUpdatePolicies = 'deviceManagement/windowsQualityUpdatePolicies'
                    windowsQualityUpdateProfiles = 'deviceManagement/windowsQualityUpdateProfiles'
                }

                $BulkRequests = $TypeMap.GetEnumerator() | ForEach-Object {
                    @{
                        id     = $_.Key
                        url    = "$($_.Value)?`$orderby=lastModifiedDateTime desc&`$select=id,lastModifiedDateTime,displayName,name&`$top=999"
                        method = 'GET'
                    }
                }

                try {
                    $TrackingTable = Get-CippTable -tablename 'IntunePolicyTypeTracking'
                    $BulkResults = New-GraphBulkRequest -Requests $BulkRequests -tenantid $TenantFilter -NoPaginateIds @($BulkRequests.id)
                    $PolicyTimestamps = @{}
                    $PolicyNamesByType = @{}

                    foreach ($Result in $BulkResults) {
                        $FirstPolicy = if ($Result.body.value) { $Result.body.value[0] } else { $null }
                        $GraphTime = $FirstPolicy.lastModifiedDateTime
                        $GraphId = $FirstPolicy.id
                        $GraphCount = ($Result.body.value | Measure-Object).Count
                        $Cached = Get-CIPPAzDataTableEntity @TrackingTable -Filter "PartitionKey eq '$TenantFilter' and RowKey eq '$($Result.id)'"

                        $CountChanged = $false
                        if ($Cached -and $Cached.PolicyCount -ne $null) {
                            $CountChanged = ($GraphCount -ne $Cached.PolicyCount)
                        }

                        $IdChanged = $false
                        if ($GraphId -and $Cached -and $Cached.LatestPolicyId) {
                            $IdChanged = ($GraphId -ne $Cached.LatestPolicyId)
                        }

                        if ($GraphTime) {
                            $GraphTimeUtc = ([DateTime]$GraphTime).ToUniversalTime()
                            if ($Cached -and $Cached.LatestPolicyModified -and -not $IdChanged -and -not $CountChanged) {
                                $CachedTimeUtc = ([DateTimeOffset]$Cached.LatestPolicyModified).UtcDateTime
                                $TimeDiff = [Math]::Abs(($GraphTimeUtc - $CachedTimeUtc).TotalSeconds)
                                $Changed = ($TimeDiff -gt 60)
                            } else {
                                $Changed = $true
                            }
                            Add-CIPPAzDataTableEntity @TrackingTable -Entity @{
                                PartitionKey         = $TenantFilter
                                RowKey               = $Result.id
                                LatestPolicyModified = $GraphTime
                                LatestPolicyId       = $GraphId
                                PolicyCount          = $GraphCount
                            } -Force | Out-Null
                        } elseif ($Cached -and $Cached.PolicyCount -ne $null) {
                            # No timestamp available - fall back to count-based detection
                            $Changed = $CountChanged -or $IdChanged
                            Add-CIPPAzDataTableEntity @TrackingTable -Entity @{
                                PartitionKey   = $TenantFilter
                                RowKey         = $Result.id
                                LatestPolicyId = $GraphId
                                PolicyCount    = $GraphCount
                            } -Force | Out-Null
                        } else {
                            # No timestamp and no prior cache entry - treat as changed and seed the cache
                            $Changed = $true
                            Add-CIPPAzDataTableEntity @TrackingTable -Entity @{
                                PartitionKey   = $TenantFilter
                                RowKey         = $Result.id
                                LatestPolicyId = $GraphId
                                PolicyCount    = $GraphCount
                            } -Force | Out-Null
                        }

                        $PolicyTimestamps[$Result.id] = $Changed
                        $PolicyNamesByType[$Result.id] = @($Result.body.value | ForEach-Object { $_.displayName; $_.name } | Where-Object { $_ })
                        Write-Host "POLICY TYPE CHANGE CHECK: $($Result.id) -> Changed=$Changed (GraphCount=$GraphCount, CachedCount=$($Cached.PolicyCount), IdChanged=$IdChanged)"
                    }

                    # Filter unchanged templates
                    $TemplateTable = Get-CippTable -tablename 'templates'
                    $IntuneKeys = @($ComputedStandards.Keys | Where-Object { $_ -like '*IntuneTemplate*' })
                    Write-Host "INTUNE FILTER: Processing $($IntuneKeys.Count) IntuneTemplate standards for $TenantFilter"

                    # Build compliance lookup - keyed by "standards.IntuneTemplate.<templateValue>"
                    $IntuneComplianceLookup = @{}
                    try {
                        $AlignmentResults = Get-CIPPTenantAlignment -TenantFilter $TenantFilter
                        foreach ($AlignmentResult in $AlignmentResults) {
                            foreach ($Detail in $AlignmentResult.ComparisonDetails) {
                                if ($Detail.StandardName -like 'standards.IntuneTemplate.*') {
                                    $IntuneComplianceLookup[$Detail.StandardName] = $Detail.Compliant
                                }
                            }
                        }
                    } catch {
                        Write-Warning "Failed to get tenant alignment data for $TenantFilter : $($_.Exception.Message)"
                    }
                    Write-Host "COMPLIANCE LOOKUP: Found $($IntuneComplianceLookup.Count) IntuneTemplate entries in alignment data"

                    foreach ($Key in $IntuneKeys) {
                        $Template = $ComputedStandards[$Key]
                        $TemplateEntity = Get-CIPPAzDataTableEntity @TemplateTable -Filter "PartitionKey eq 'IntuneTemplate' and RowKey eq '$($Template.Settings.TemplateList.value)'"

                        if (-not $TemplateEntity) {
                            Write-Host "SKIP: $Key - no IntuneTemplate entity found for RowKey '$($Template.Settings.TemplateList.value)'"
                            continue
                        }

                        $ParsedTemplate = $TemplateEntity.JSON | ConvertFrom-Json
                        if (-not $ParsedTemplate.Type) {
                            Write-Host "SKIP: $Key - template has no Type property"
                            continue
                        }

                        $PolicyType = $ParsedTemplate.Type
                        $PolicyChanged = if ($PolicyType -eq 'AppProtection') {
                            [bool]($PolicyTimestamps['AppProtection_Android'] -or $PolicyTimestamps['AppProtection_iOS'])
                        } else {
                            [bool]$PolicyTimestamps[$PolicyType]
                        }
                        Write-Host "TEMPLATE CHECK: $Key | PolicyType=$PolicyType | PolicyChanged=$PolicyChanged"

                        # Check StandardTemplate changes
                        $StandardTemplate = Get-CIPPAzDataTableEntity @TemplateTable -Filter "PartitionKey eq 'StandardsTemplateV2' and RowKey eq '$($Template.TemplateId)'"
                        $StandardTemplateChanged = $false

                        if ($StandardTemplate) {
                            $StandardTimeUtc = ([DateTimeOffset]$StandardTemplate.Timestamp).UtcDateTime
                            $CachedStandardTemplate = Get-CIPPAzDataTableEntity @TrackingTable -Filter "PartitionKey eq '$TenantFilter' and RowKey eq 'StandardTemplate_$($Template.TemplateId)'"

                            if ($CachedStandardTemplate -and $CachedStandardTemplate.CachedTimestamp) {
                                $CachedStandardTimeUtc = ([DateTimeOffset]$CachedStandardTemplate.CachedTimestamp).UtcDateTime
                                $TimeDiff = [Math]::Abs(($StandardTimeUtc - $CachedStandardTimeUtc).TotalSeconds)
                                $StandardTemplateChanged = ($TimeDiff -gt 60)
                                Write-Host "STDTEMPLATE CHECK: TemplateId=$($Template.TemplateId) | TimeDiff=${TimeDiff}s | Changed=$StandardTemplateChanged"
                            } else {
                                $StandardTemplateChanged = $true
                                Write-Host "STDTEMPLATE CHECK: TemplateId=$($Template.TemplateId) | No cached timestamp - treating as changed"
                            }

                            Add-CIPPAzDataTableEntity @TrackingTable -Entity @{
                                PartitionKey    = $TenantFilter
                                RowKey          = "StandardTemplate_$($Template.TemplateId)"
                                CachedTimestamp = $StandardTemplate.Timestamp
                            } -Force | Out-Null
                        }

                        if (-not $PolicyChanged -and -not $StandardTemplateChanged) {
                            $AlignmentKey = "standards.IntuneTemplate.$($Template.Settings.TemplateList.value)"
                            $IsDeployed = $IntuneComplianceLookup.ContainsKey($AlignmentKey)
                            $IsCompliant = $IsDeployed -and ($IntuneComplianceLookup[$AlignmentKey] -eq $true)
                            Write-Host "COMPLIANCE CHECK: $AlignmentKey | InLookup=$IsDeployed | Compliant=$IsCompliant | LookupValue=$($IntuneComplianceLookup[$AlignmentKey])"

                            if ($IsCompliant) {
                                # Verify the policy still exists in Graph before trusting compliance
                                $TemplateDisplayName = $ParsedTemplate.Displayname
                                $TypeNames = if ($PolicyType -eq 'AppProtection') {
                                    @($PolicyNamesByType['AppProtection_Android']) + @($PolicyNamesByType['AppProtection_iOS'])
                                } else {
                                    @($PolicyNamesByType[$PolicyType])
                                }
                                if ($TypeNames -contains $TemplateDisplayName) {
                                    # Policy unchanged, exists in Graph, and compliant - safe to skip
                                    Write-Host "NO INTUNE CHANGE: Filtering out $Key for $TenantFilter (compliant)"
                                    [void]$ComputedStandards.Remove($Key)
                                } else {
                                    Write-Host "KEEPING: $Key - policy '$TemplateDisplayName' not found in Graph for type $PolicyType (deleted?)"
                                }
                            } else {
                                Write-Host "KEEPING: $Key - not compliant or not in lookup (InLookup=$IsDeployed, Compliant=$IsCompliant)"
                            }
                        } else {
                            Write-Host "KEEPING: $Key - changed (PolicyChanged=$PolicyChanged, StdTemplateChanged=$StandardTemplateChanged)"
                        }
                    }
                } catch {
                    Write-Warning "Timestamp check failed for $TenantFilter : $($_.Exception.Message)"
                }
            }
        }

        $CAStandardFound = ($ComputedStandards.Keys.Where({ $_ -like '*ConditionalAccessTemplate*' }, 'First').Count -gt 0)
        if ($CAStandardFound) {
            $TestResult = Test-CIPPStandardLicense -StandardName 'ConditionalAccessTemplate_general' -TenantFilter $TenantFilter -RequiredCapabilities @('AAD_PREMIUM', 'AAD_PREMIUM_P2')
            if (-not $TestResult) {
                $CAKeys = @($ComputedStandards.Keys | Where-Object { $_ -like '*ConditionalAccessTemplate*' })
                $BulkFields = [System.Collections.Generic.List[object]]::new()
                foreach ($Key in $CAKeys) {
                    $TemplateKey = ($Key -split '\|', 2)[1]
                    if ($TemplateKey) {
                        $BulkFields.Add([PSCustomObject]@{
                                FieldName  = "standards.ConditionalAccessTemplate.$TemplateKey"
                                FieldValue = 'This tenant does not have the required license for this standard.'
                            })
                    }
                    [void]$ComputedStandards.Remove($Key)
                }
                if ($BulkFields.Count -gt 0) {
                    Set-CIPPStandardsCompareField -TenantFilter $TenantFilter -BulkFields $BulkFields
                }

                Write-Information "Removed ConditionalAccessTemplate standards for $TenantFilter - missing required license"
            } else {
                # License valid - update CIPPDB cache with latest CA information before we run so that standards have the most up to date info
                try {
                    Write-Information "Updating CIPPDB cache for Conditional Access policies for $TenantFilter"
                    Set-CIPPDBCacheConditionalAccessPolicies -TenantFilter $TenantFilter
                } catch {
                    Write-Warning "Failed to update CA cache for $TenantFilter : $($_.Exception.Message)"
                }
            }
        }

        Write-Host "Returning $($ComputedStandards.Count) standards for tenant $TenantFilter after filtering."
        # Return filtered standards
        $FilteredStandards = $ComputedStandards.Values | ForEach-Object {
            [PSCustomObject]@{
                Tenant       = $_.Tenant
                Standard     = $_.Standard
                Settings     = $_.Settings
                TemplateId   = $_.TemplateId
                FunctionName = 'CIPPStandard'
            }
        }
        Write-Host "Sending back $($FilteredStandards.Count) standards"
        return @($FilteredStandards)
    } catch {
        Write-Warning "Error listing standards for $TenantFilter : $($_.Exception.Message)"
        return @()
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Standards/Push-CIPPStandardsList.ps1' 304
#Region './Public/Entrypoints/Activity Triggers/Standards/Push-GetStandards.ps1' -1

function Push-GetStandards {
    <#
    .FUNCTIONALITY
    Entrypoint
    #>
    Param($Item)

    $Params = $Item.StandardParams | ConvertTo-Json | ConvertFrom-Json -AsHashtable
    Write-Host "My params are $($Params | ConvertTo-Json -Depth 5 -Compress)"
    try {
        $AllTasks = Get-CIPPStandards @Params
        Write-Host "AllTasks: $($AllTasks | ConvertTo-Json -Depth 5 -Compress)"
        foreach ($task in $AllTasks) {
            [PSCustomObject]@{
                Tenant       = $task.Tenant
                Standard     = $task.Standard
                Settings     = $task.Settings
                QueueId      = $Item.QueueId
                templateId   = $task.templateId
                QueueName    = '{0} - {1}' -f $task.Standard, $Task.Tenant
                FunctionName = 'CIPPStandard'
            }
        }
    } catch {
        Write-Host "GetStandards Exception $($_.Exception.Message)"
    }

}
#EndRegion './Public/Entrypoints/Activity Triggers/Standards/Push-GetStandards.ps1' 29
#Region './Public/Entrypoints/Activity Triggers/Tenant Groups/Push-UpdateDynamicTenantGroup.ps1' -1

function Push-UpdateDynamicTenantGroup {
    <#
    .SYNOPSIS
    Push an update to a Dynamic Tenant Group
    .FUNCTIONALITY
    Entrypoint
    #>

    [CmdletBinding()]
    param ($Item)

    Write-Information "Pushing update to Dynamic Tenant Group: $($Item.Name) (ID: $($Item.Id))"
    Update-CIPPDynamicTenantGroups -GroupId $Item.Id
}
#EndRegion './Public/Entrypoints/Activity Triggers/Tenant Groups/Push-UpdateDynamicTenantGroup.ps1' 15
#Region './Public/Entrypoints/Activity Triggers/Tests/Invoke-CIPPDBTestsRun.ps1' -1

function Invoke-CIPPDBTestsRun {
    <#
    .FUNCTIONALITY
        Entrypoint
    .ROLE
        Tenant.Tests.Read
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$TenantFilter = 'allTenants',

        [Parameter(Mandatory = $false)]
        [switch]$Force
    )

    return Start-CIPPDBTestsRun -TenantFilter $TenantFilter -Force:$Force
}
#EndRegion './Public/Entrypoints/Activity Triggers/Tests/Invoke-CIPPDBTestsRun.ps1' 19
#Region './Public/Entrypoints/Activity Triggers/Tests/Push-CIPPDBTestsRun.ps1' -1

function Push-CIPPDBTestsRun {
    <#
    .SYNOPSIS
        PostExecution function to run tests after data collection completes
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    try {
        $TenantFilter = $Item.Parameters.TenantFilter
        Write-Information "PostExecution: Starting tests for tenant: $TenantFilter after data collection completed"
        Write-LogMessage -API 'Tests' -tenant $TenantFilter -message 'Starting test run after data collection' -sev Info

        # Call the test run function — Force clears rerun protection since this is a manual trigger
        $Result = Invoke-CIPPDBTestsRun -TenantFilter $TenantFilter -Force

        Write-LogMessage -API 'Tests' -tenant $TenantFilter -message "Test run started. Instance ID: $($Result.InstanceId)" -sev Info
        Write-Information "PostExecution: Tests started with Instance ID: $($Result.InstanceId)"

        return @{
            Success    = $true
            InstanceId = $Result.InstanceId
            Message    = $Result.Message
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $TenantFilter -message "Failed to start test run: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Write-Warning "PostExecution: Error starting tests - $($ErrorMessage.NormalizedError)"

        return @{
            Success = $false
            Error   = $ErrorMessage.NormalizedError
        }
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Tests/Push-CIPPDBTestsRun.ps1' 37
#Region './Public/Entrypoints/Activity Triggers/Tests/Push-CIPPTest.ps1' -1

function Push-CIPPTest {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param(
        $Item
    )

    $TenantFilter = $Item.TenantFilter
    $TestId = $Item.TestId

    Write-Information "Running test $TestId for tenant $TenantFilter"

    try {
        if ($TestId -like 'CustomScript-*') {
            $ScriptGuid = $TestId -replace '^CustomScript-', ''
            Write-Information "Executing Invoke-CippTestCustomScripts for $TenantFilter (ScriptGuid: $ScriptGuid)"
            Invoke-CippTestCustomScripts -Tenant $TenantFilter -ScriptGuid $ScriptGuid
            Write-Host "Returning true, test has run for $tenantFilter"
            return @{ testRun = $true }
        }

        $FunctionName = "Invoke-CippTest$TestId"

        if (-not (Get-Command $FunctionName -Module CIPPTests -ErrorAction SilentlyContinue)) {
            Write-LogMessage -API 'Tests' -tenant $TenantFilter -message "Test function not found: $FunctionName" -sev Error
            return @{ testRun = $false }
        }

        Write-Information "Executing $FunctionName for $TenantFilter"
        & $FunctionName -Tenant $TenantFilter
        Write-Host "Returning true, test has run for $tenantFilter"
        return @{ testRun = $true }

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $TenantFilter -message "Failed to run test $TestId $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        return @{ testRun = $false }
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Tests/Push-CIPPTest.ps1' 42
#Region './Public/Entrypoints/Activity Triggers/Tests/Push-CIPPTestCollection.ps1' -1

function Push-CIPPTestCollection {
    <#
    .SYNOPSIS
        Activity trigger: run all tests for a named suite against a tenant

    .DESCRIPTION
        Grouped test execution activity — the test-suite equivalent of the grouped
        CollectionType mode in Push-ExecCIPPDBCache. Delegates to Invoke-CIPPTestCollection
        which discovers and runs all matching Invoke-CippTest* functions via Get-Command
        (path-independent, ModuleBuilder compatible).

    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param($Item)

    $TenantFilter = $Item.TenantFilter
    $SuiteName = $Item.SuiteName

    try {
        Write-Information "Running $SuiteName suite for tenant $TenantFilter"

        $Result = Invoke-CIPPTestCollection -SuiteName $SuiteName -TenantFilter $TenantFilter

        Write-Information "Completed $SuiteName suite for $TenantFilter - $($Result.Success)/$($Result.Total) tests ran in $($Result.TotalSeconds)s"
        return "Successfully executed $SuiteName suite for $TenantFilter ($($Result.Success)/$($Result.Total) ran, $($Result.Failed) errored)"

    } catch {
        $ErrorMsg = "Failed to execute $SuiteName suite for tenant $TenantFilter : $($_.Exception.Message)"
        Write-LogMessage -API 'Tests' -tenant $TenantFilter -message $ErrorMsg -sev Error
        throw $ErrorMsg
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Tests/Push-CIPPTestCollection.ps1' 35
#Region './Public/Entrypoints/Activity Triggers/Tests/Push-CIPPTestsApplyBatch.ps1' -1

function Push-CIPPTestsApplyBatch {
    <#
    .SYNOPSIS
        Aggregate test tasks from all tenants and start a flat execution orchestrator (Phase 2)

    .DESCRIPTION
        PostExecution function for the Tests pipeline. Receives aggregated results from the
        per-tenant CIPPTestsList activities, flattens them into a single batch, and starts
        one orchestrator to execute all test tasks across all tenants in parallel.

    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    try {
        # Aggregate all test tasks from all tenant list activities
        $AllTasks = [System.Collections.Generic.List[object]]::new()

        foreach ($TenantResult in $Item.Results) {
            foreach ($Batch in $TenantResult) {
                foreach ($Task in $Batch) {
                    if ($Task -and $Task.FunctionName) {
                        $AllTasks.Add($Task)
                    }
                }
            }
        }

        if ($AllTasks.Count -eq 0) {
            Write-Information 'No test tasks to execute across all tenants'
            return @{ Success = $true; TaskCount = 0 }
        }

        Write-Information "Aggregated $($AllTasks.Count) test tasks from all tenants"

        # Start a single flat orchestrator to execute all test tasks
        $InputObject = [PSCustomObject]@{
            OrchestratorName = 'CIPPTestsExecute'
            Batch            = @($AllTasks)
            SkipLog          = $true
        }

        $InstanceId = Start-CIPPOrchestrator -InputObject $InputObject
        Write-Information "Started flat tests execution orchestrator with ID = '$InstanceId' for $($AllTasks.Count) tasks"

        return @{
            Success    = $true
            TaskCount  = $AllTasks.Count
            InstanceId = $InstanceId
        }

    } catch {
        Write-Warning "Error in Tests apply batch aggregation: $($_.Exception.Message)"
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Tests/Push-CIPPTestsApplyBatch.ps1' 58
#Region './Public/Entrypoints/Activity Triggers/Tests/Push-CIPPTestsList.ps1' -1

function Push-CIPPTestsList {
    <#
    .SYNOPSIS
        Build the list of test suite activities for a single tenant (Phase 1)

    .DESCRIPTION
        Checks whether the tenant has cached data and returns one task per test suite.
        Suite tasks are executed by Push-CIPPTestCollection, which discovers individual
        test functions at runtime via Get-Command — no filesystem paths are used, so this
        works correctly with ModuleBuilder compiled modules.

        Reduces activity count from ~262 per tenant (one per test) to 6 per tenant
        (one per suite), dramatically cutting orchestrator replay overhead.

    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $TenantFilter = $Item.TenantFilter

    try {
        Write-Information "Building test suite list for tenant: $TenantFilter"

        # Check if tenant has data before emitting any work
        $DbCounts = Get-CIPPDbItem -TenantFilter $TenantFilter -CountsOnly
        if (($DbCounts | Measure-Object -Property DataCount -Sum).Sum -eq 0) {
            Write-Information "Tenant $TenantFilter has no data in database. Skipping tests."
            return @()
        }

        # Emit one task per suite — suite names must match the ValidateSet in Invoke-CIPPTestCollection.
        # Function discovery happens inside Invoke-CIPPTestCollection via Get-Command (path-independent).
        $Suites = @('ZTNA', 'ORCA', 'EIDSCA', 'CISA', 'CopilotReadiness', 'GenericTests', 'Custom')

        $Tasks = foreach ($Suite in $Suites) {
            [PSCustomObject]@{
                FunctionName = 'CIPPTestCollection'
                TenantFilter = $TenantFilter
                SuiteName    = $Suite
            }
        }

        Write-Information "Built $($Tasks.Count) suite tasks for tenant $TenantFilter"
        return @($Tasks)

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $TenantFilter -message "Failed to build test suite list: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        return @()
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Tests/Push-CIPPTestsList.ps1' 53
#Region './Public/Entrypoints/Activity Triggers/Webhooks/Push-AuditLogProcessingBatch.ps1' -1

function Push-AuditLogProcessingBatch {
    <#
    .SYNOPSIS
        Builds the batch of audit log processing tasks from the webhook cache table.
    .DESCRIPTION
        Called as a QueueFunction activity by the AuditLogProcessingOrchestrator.
        Loads CacheWebhooks in pages, groups by tenant, and returns batch items
        for AuditLogTenantProcess activities. Running in an activity isolates
        the memory usage from the timer function.

        Rows are stamped with CippProcessing = true and CippProcessingStarted timestamp
        before being included in the batch, so that subsequent 15-minute timer runs skip
        them instead of spawning duplicate activities. Rows stuck in processing state for
        more than 4 hours (e.g. from a worker crash) are automatically recovered and
        re-queued on the next run.
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $WebhookCacheTable = Get-CippTable -TableName 'CacheWebhooks'
    $AllBatchItems = [System.Collections.Generic.List[object]]::new()
    $TotalRows = 0
    $PageSize = 20000
    $Skip = 0
    $NowUtc = (Get-Date).ToUniversalTime()
    $StaleThreshold = $NowUtc.AddHours(-4)

    do {
        # Fetch only the properties needed to determine claim status and build the batch
        $WebhookCache = Get-CIPPAzDataTableEntity @WebhookCacheTable -First $PageSize -Skip $Skip -Property @('PartitionKey', 'RowKey', 'ETag', 'Timestamp', 'CippProcessing')
        $PageCount = $WebhookCache.Count

        # Filter client-side: skip rows actively claimed unless the claim is stale (> 4 hours old)
        $TenantGroups = $WebhookCache | Where-Object {
            -not $_.CippProcessing -or
            ($_.Timestamp -and $_.Timestamp.UtcDateTime -lt $StaleThreshold)
        } | Group-Object -Property PartitionKey
        $WebhookCache = $null

        if ($TenantGroups) {
            foreach ($TenantGroup in $TenantGroups) {
                $TenantFilter = $TenantGroup.Name
                $Rows = @($TenantGroup.Group)
                $RowIds = @($Rows.RowKey)

                # Claim these rows so subsequent timer runs skip them (UpsertMerge preserves JSON and other fields)
                # The entity Timestamp is updated automatically on write and used for stale detection.
                foreach ($Row in $Rows) {
                    $ClaimEntity = [PSCustomObject]@{
                        PartitionKey   = $Row.PartitionKey
                        RowKey         = $Row.RowKey
                        CippProcessing = $true
                    }
                    Add-CIPPAzDataTableEntity @WebhookCacheTable -Entity $ClaimEntity -OperationType UpsertMerge
                }

                $TotalRows += $RowIds.Count
                for ($i = 0; $i -lt $RowIds.Count; $i += 500) {
                    $BatchRowIds = $RowIds[$i..([Math]::Min($i + 499, $RowIds.Count - 1))]
                    $AllBatchItems.Add([PSCustomObject]@{
                            TenantFilter = $TenantFilter
                            RowIds       = $BatchRowIds
                            FunctionName = 'AuditLogTenantProcess'
                        })
                }
            }
            $TenantGroups = $null
        }

        if ($PageCount -lt $PageSize) { break }
        $Skip += $PageSize
    } while ($PageCount -eq $PageSize)

    if ($AllBatchItems.Count -gt 0) {
        $ProcessQueue = New-CippQueueEntry -Name 'Audit Logs Process' -Reference 'AuditLogsProcess' -TotalTasks $TotalRows
        foreach ($BatchItem in $AllBatchItems) {
            $BatchItem | Add-Member -MemberType NoteProperty -Name QueueId -Value $ProcessQueue.RowKey -Force
        }
        Write-Information "AuditLogProcessingBatch: $($AllBatchItems.Count) batch items across $TotalRows rows"
    } else {
        Write-Information 'AuditLogProcessingBatch: no webhook cache entries found'
    }

    return $AllBatchItems.ToArray()
}
#EndRegion './Public/Entrypoints/Activity Triggers/Webhooks/Push-AuditLogProcessingBatch.ps1' 87
#Region './Public/Entrypoints/Activity Triggers/Webhooks/Push-AuditLogSearchCreation.ps1' -1

function Push-AuditLogSearchCreation {
    <#
    .FUNCTIONALITY
    Entrypoint
    #>
    [CmdletBinding(SupportsShouldProcess = $true)]
    param($Item)

    # Get params from batch item
    $Tenant = $Item.Tenant
    $StartTime = $Item.StartTime
    $EndTime = $Item.EndTime
    try {
        $LogSearch = @{
            StartTime         = $StartTime
            EndTime           = $EndTime
            TenantFilter      = $Tenant.defaultDomainName
            ProcessLogs       = $true
            RecordTypeFilters = @(
                'exchangeAdmin',
                'azureActiveDirectory',
                'azureActiveDirectoryAccountLogon',
                'azureActiveDirectoryStsLogon'
            )
        }
        if ($PSCmdlet.ShouldProcess('Push-AuditLogSearchCreation', 'Creating Audit Log Search')) {
            $NewSearch = New-CippAuditLogSearch @LogSearch
            if ($NewSearch.id) {
                Write-Information "Created audit log search $($Tenant.defaultDomainName) - $($NewSearch.displayName)"
            } elseif ($NewSearch.cippStatus -eq 'TransientError') {
                Write-Information "Audit log search creation hit transient error for tenant $($Tenant.defaultDomainName) ($($NewSearch.status))"
            } elseif ($NewSearch.status -eq 'AuditingDisabledTenant') {
                Write-Information "Skipping audit log search $($Tenant.defaultDomainName) because unified auditing is disabled for this tenant"
                Write-LogMessage -API 'Audit Logs' -Message "Skipped audit log search creation for tenant $($Tenant.defaultDomainName) because unified auditing is disabled" -Sev Warning -tenant $Tenant.defaultDomainName
            } else {
                Write-Information "Audit log search creation returned no query id for tenant $($Tenant.defaultDomainName)"
                Write-LogMessage -API 'Audit Logs' -Message "Audit log search creation returned no query id for tenant $($Tenant.defaultDomainName)" -Sev Warning -tenant $Tenant.defaultDomainName
            }
        }
    } catch {
        Write-Information "Error creating audit log search $($Tenant.defaultDomainName) - $($_.Exception.Message)"
        Write-Information $_.InvocationInfo.PositionMessage
        #Write-LogMessage -API 'Audit Logs' -tenant $Tenant.defaultDomainName -Message "Error creating audit log search for tenant $($Tenant.defaultDomainName): $($_.Exception.Message)" -Sev Error -LogData (Get-CippException -Exception $_)
    }
    return $true
}
#EndRegion './Public/Entrypoints/Activity Triggers/Webhooks/Push-AuditLogSearchCreation.ps1' 47
#Region './Public/Entrypoints/Activity Triggers/Webhooks/Push-AuditLogTenantDownload.ps1' -1

function Push-AuditLogTenantDownload {
    param($Item)
    $TenantFilter = $Item.TenantFilter

    try {
        Write-Information "Audit Logs: Downloading $($TenantFilter)"
        # Get CIPP Url, cleanup legacy tasks
        $SchedulerConfig = Get-CippTable -TableName 'SchedulerConfig'
        $LegacyWebhookTasks = Get-CIPPAzDataTableEntity @SchedulerConfig -Filter "PartitionKey eq 'webhookcreation'"
        $LegacyUrl = $LegacyWebhookTasks | Select-Object -First 1 -ExpandProperty CIPPURL
        $CippConfigTable = Get-CippTable -tablename Config
        $CippConfig = Get-CIPPAzDataTableEntity @CippConfigTable -Filter "PartitionKey eq 'InstanceProperties' and RowKey eq 'CIPPURL'"
        if ($LegacyUrl) {
            if (!$CippConfig) {
                $Entity = @{
                    PartitionKey = 'InstanceProperties'
                    RowKey       = 'CIPPURL'
                    Value        = [string]([System.Uri]$LegacyUrl).Host
                }
                Add-CIPPAzDataTableEntity @CippConfigTable -Entity $Entity -Force
            }
            # remove legacy webhooks
            foreach ($Task in $LegacyWebhookTasks) {
                Remove-AzDataTableEntity -Force @SchedulerConfig -Entity $Task
            }
            $CIPPURL = $LegacyUrl
        } else {
            if (!$CippConfig) {
                $CippConfig = @{
                    PartitionKey = 'InstanceProperties'
                    RowKey       = 'CIPPURL'
                    Value        = [string]([System.Uri]$Request.Headers.'x-ms-original-url').Host
                }
                Add-AzDataTableEntity @CippConfigTable -Entity $CippConfig -Force
                $CIPPURL = 'https://{0}' -f $CippConfig.Value
            } else { $CIPPURL = 'https://{0}' -f $CippConfig.Value }
        }

        $LogSearchesTable = Get-CippTable -TableName 'AuditLogSearches'

        try {
            $LogSearches = Get-CippAuditLogSearches -TenantFilter $TenantFilter -ReadyToProcess | Sort-Object -Property filterStartDateTime | Select-Object -First 10
            if ($LogSearches.Count -eq 0) {
                Write-Information "Audit Logs: No searches ready to process for $TenantFilter"
                return $true
            }
            Write-Information ('Audit Logs: Found {0} searches for {1}, begin downloading' -f $LogSearches.Count, $TenantFilter)
            foreach ($Search in $LogSearches) {
                $SearchEntity = Get-CIPPAzDataTableEntity @LogSearchesTable -Filter "Tenant eq '$($TenantFilter)' and RowKey eq '$($Search.id)'"
                $SearchEntity.CippStatus = 'Processing'
                Add-CIPPAzDataTableEntity @LogSearchesTable -Entity $SearchEntity -Force
                try {
                    Write-Information "Audit Log search: Processing search ID: $($Search.id) for tenant: $TenantFilter"
                    $null = New-CIPPAuditLogSearchResultsCache -TenantFilter $TenantFilter -searchId $Search.id
                    $SearchEntity.CippStatus = 'Downloaded'
                } catch {
                    if ($_.Exception.Message -match 'Request rate is large. More Request Units may be needed, so no changes were made. Please retry this request later.') {
                        $SearchEntity.CippStatus = 'Pending'
                        Write-Information "Audit Log search: Rate limit hit for $($SearchEntity.RowKey)."
                        if ($SearchEntity.PSObject.Properties.Name -contains 'RetryCount') {
                            $SearchEntity.RetryCount++
                        } else {
                            $SearchEntity | Add-Member -MemberType NoteProperty -Name RetryCount -Value 1
                        }
                    } else {
                        $Exception = [string](ConvertTo-Json -Compress -InputObject (Get-CippException -Exception $_))
                        $SearchEntity | Add-Member -MemberType NoteProperty -Name Error -Value $Exception
                        $SearchEntity.CippStatus = 'Failed'
                        Write-Information "Error processing audit log rules: $($_.Exception.Message)"
                    }

                }
                Add-CIPPAzDataTableEntity @LogSearchesTable -Entity $SearchEntity -Force
            }
            return $true
        } catch {
            Write-Information ('Audit Log search: Error {0} line {1} - {2}' -f $_.InvocationInfo.ScriptName, $_.InvocationInfo.ScriptLineNumber, $_.Exception.Message)
            return $false
        }

    } catch {
        Write-Information ('Push-AuditLogTenant: Error {0} line {1} - {2}' -f $_.InvocationInfo.ScriptName, $_.InvocationInfo.ScriptLineNumber, $_.Exception.Message)
        return $false
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Webhooks/Push-AuditLogTenantDownload.ps1' 86
#Region './Public/Entrypoints/Activity Triggers/Webhooks/Push-AuditLogTenantProcess.ps1' -1

function Push-AuditLogTenantProcess {
    param($Item)
    $TenantFilter = $Item.TenantFilter
    $RowIds = $Item.RowIds

    try {
        Write-Information "Audit Logs: Processing $($TenantFilter) with $($RowIds.Count) row IDs. We're processing id $($RowIds[0]) to $($RowIds[-1])"

        # Get the CacheWebhooks table
        $CacheWebhooksTable = Get-CippTable -TableName 'CacheWebhooks'
        # we do it this way because the rows can grow extremely large, if we get them all it might just hang for minutes at a time.
        $Rows = foreach ($RowId in $RowIds) {
            $CacheEntity = Get-CIPPAzDataTableEntity @CacheWebhooksTable -Filter "PartitionKey eq '$TenantFilter' and RowKey eq '$RowId'"
            if ($CacheEntity) {
                $AuditData = $CacheEntity.JSON | ConvertFrom-Json -ErrorAction SilentlyContinue
                $AuditData
            }
        }

        if ($Rows.Count -gt 0) {
            Write-Information "Retrieved $($Rows.Count) rows from cache for processing"
            Test-CIPPAuditLogRules -TenantFilter $TenantFilter -Rows $Rows
            return $true
        } else {
            Write-Information 'No rows found in cache for the provided row IDs'
            return $false
        }
    } catch {
        Write-Information ('Push-AuditLogTenant: Error {0} line {1} - {2}' -f $_.InvocationInfo.ScriptName, $_.InvocationInfo.ScriptLineNumber, $_.Exception.Message)
        return $false
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Webhooks/Push-AuditLogTenantProcess.ps1' 33
#Region './Public/Entrypoints/Activity Triggers/Webhooks/Push-PublicWebhookProcess.ps1' -1

function Push-PublicWebhookProcess {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param($Item)

    $Table = Get-CIPPTable -TableName WebhookIncoming
    $Webhook = Get-CIPPAzDataTableEntity @Table -Filter "RowKey eq '$($Item.RowKey)'"
    try {
        if ($Webhook.Type -eq 'GraphSubscription') {
            Invoke-CippGraphWebhookProcessing -Data ($Webhook.Data | ConvertFrom-Json) -CIPPID $Webhook.CIPPID -WebhookInfo ($Webhook.Webhookinfo | ConvertFrom-Json)
        } elseif ($Webhook.Type -eq 'AuditLog') {
            Invoke-CippWebhookProcessing -TenantFilter $Webhook.TenantFilter -Data ($Webhook.Data | ConvertFrom-Json) -CIPPURL $Webhook.CIPPURL
        } elseif ($Webhook.Type -eq 'PartnerCenter') {
            Invoke-CippPartnerWebhookProcessing -Data ($Webhook.Data | ConvertFrom-Json)
        }
    } catch {
        Write-Host "Webhook Exception: $($_.Exception.Message)"
    } finally {
        $Entity = $Webhook | Select-Object -Property RowKey, PartitionKey
        Remove-AzDataTableEntity -Force @Table -Entity $Entity
    }
}
#EndRegion './Public/Entrypoints/Activity Triggers/Webhooks/Push-PublicWebhookProcess.ps1' 25
#Region './Public/Entrypoints/Activity Triggers/Webhooks/Push-Schedulerwebhookcreation.ps1' -1

function Push-Schedulerwebhookcreation {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    param (
        $item
    )
    <#$Table = Get-CIPPTable -TableName 'SchedulerConfig'
    $WebhookTable = Get-CIPPTable -TableName 'webhookTable'
    $Tenant = $Item.Tenant
    $Row = Get-CIPPAzDataTableEntity @Table -Filter "RowKey eq '$($item.SchedulerRow)'"
    if (!$Row) {
        Write-Information "No row found for $($item.SchedulerRow). Full received item was $($item | ConvertTo-Json)"
        return
    } else {
        Write-Information "Working on $Tenant - $($Item.Tenantid)"
        #use the queueitem to see if we already have a webhook for this tenant + webhooktype. If we do, delete this row from SchedulerConfig.
        $Webhook = Get-CIPPAzDataTableEntity @WebhookTable -Filter "PartitionKey eq '$Tenant' and Version eq '3' and Resource eq '$($Row.webhookType)'"
        if ($Webhook) {
            Write-Information "Found existing webhook for $Tenant - $($Row.webhookType)"
            if ($Row.tenantid -ne 'AllTenants') {
                Remove-AzDataTableEntity -Force @Table -Entity $Row
            }
            if (($Webhook | Measure-Object).Count -gt 1) {
                $Webhook = $Webhook | Select-Object -First 1
                $WebhooksToRemove = $ExistingWebhooks | Where-Object { $_.RowKey -ne $Webhook.RowKey }
                foreach ($RemoveWebhook in $WebhooksToRemove) {
                    Remove-AzDataTableEntity -Force @WebhookTable -Entity $RemoveWebhook
                }
            }
        } else {
            Write-Information "No existing webhook for $Tenant - $($Row.webhookType) - Time to create."
            try {
                $NewSub = New-CIPPGraphSubscription -TenantFilter $Tenant -EventType $Row.webhookType -auditLogAPI $true
                if ($NewSub.Success -and $Row.tenantid -ne 'AllTenants') {
                    Remove-AzDataTableEntity -Force @Table -Entity $Row
                } else {
                    Write-Information "Failed to create webhook for $Tenant - $($Row.webhookType) - $($_.Exception.Message)"
                }
            } catch {
                Write-Information "Failed to create webhook for $Tenant - $($Row.webhookType): $($_.Exception.Message)"
            }
        }
    }#>

}
#EndRegion './Public/Entrypoints/Activity Triggers/Webhooks/Push-Schedulerwebhookcreation.ps1' 48
