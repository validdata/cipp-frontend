@{
    # Script module or binary module file associated with this manifest.
    RootModule         = '.\CIPPActivityTriggers.psm1'

    # Version number of this module.
    ModuleVersion      = '1.0'

    # Supported PSEditions
    # CompatiblePSEditions = @()

    # ID used to uniquely identify this module
    GUID               = '3d72e22c-16a3-4e0d-8f9f-f4436b911f14'

    # Author of this module
    Author             = 'Kelvin Tegelaar - Kelvin@cyberdrain.com'

    # Company or vendor of this module
    CompanyName        = 'CyberDrain.com'

    # Copyright statement for this module
    Copyright          = '(c) 2020 Kelvin Tegelaar - Kelvin@CyberDrain.com All rights reserved.'

    # Description of the functionality provided by this module
    Description        = ''

    # Minimum version of the Windows PowerShell engine required by this module
    PowerShellVersion  = '7.0'

    # Name of the Windows PowerShell host required by this module
    # PowerShellHostName = ''

    # Minimum version of the Windows PowerShell host required by this module
    # PowerShellHostVersion = ''

    # Minimum version of Microsoft .NET Framework required by this module. This prerequisite is valid for the PowerShell Desktop edition only.
    # DotNetFrameworkVersion = ''

    # Minimum version of the common language runtime (CLR) required by this module. This prerequisite is valid for the PowerShell Desktop edition only.
    # CLRVersion = ''

    # Processor architecture (None, X86, Amd64) required by this module
    # ProcessorArchitecture = ''

    # Modules that must be imported into the global environment prior to importing this module
    # RequiredModules = @()

    # Assemblies that must be loaded prior to importing this module
    # RequiredAssemblies = @()

    # Script files (.ps1) that are run in the caller's environment prior to importing this module.
    # ScriptsToProcess = @()

    # Type files (.ps1xml) to be loaded when importing this module
    # TypesToProcess = @()

    # Format files (.ps1xml) to be loaded when importing this module
    # FormatsToProcess = @()

    # Modules to import as nested modules of the module specified in RootModule/ModuleToProcess
    # NestedModules = @()

    # Functions to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no functions to export.
    FunctionsToExport  = @('Push-GetApplicationQueue','Push-UploadApplication','Push-BECRun','Push-BPACollectData','Push-ExecCIPPDBCache','Push-DomainAnalyserDomain','Push-DomainAnalyserTenant','Push-GetDomainAnalyserResults','Push-GetTenantDomains','Push-ListGraphRequestQueue','Push-GetCalendarPermissionsBatch','Push-GetMailboxPermissionsBatch','Push-StoreMailboxPermissions','Push-TableCleanupTask','Push-CIPPDriftManagement','Push-CIPPStandard','Push-CIPPStandardsApplyBatch','Push-CIPPStandardsList','Push-GetStandards','Push-UpdateDynamicTenantGroup','Invoke-CIPPDBTestsRun','Push-CIPPDBTestsRun','Push-CIPPTest','Push-CIPPTestCollection','Push-CIPPTestsApplyBatch','Push-CIPPTestsList','Push-AuditLogProcessingBatch','Push-AuditLogSearchCreation','Push-AuditLogTenantDownload','Push-AuditLogTenantProcess','Push-PublicWebhookProcess','Push-Schedulerwebhookcreation','Push-CIPPAccessTenantTest','Push-CIPPDBCacheApplyBatch','Push-CIPPDBCacheData','Push-CIPPOffboardingComplete','Push-CIPPOffboardingTask','Push-ExecAddMultiTenantApp','Push-ExecAlertsListAllTenants','Push-ExecAppApprovalTemplate','Push-ExecApplicationCopy','Push-ExecGDAPInviteQueue','Push-ExecIncidentsListAllTenants','Push-ExecJITAdminListAllTenants','Push-ExecMdoAlertsListAllTenants','Push-ExecOffboardingMailboxPermissions','Push-ExecOnboardTenantQueue','Push-ExecScheduledCommand','Push-GetMailboxRulesBatch','Push-GetPendingWebhooks','Push-GetTenants','Push-ListBasicAuthAllTenants','Push-ListConditionalAccessPoliciesAllTenants','Push-ListLicensesQueue','Push-ListMailboxRulesQueue','Push-ListMailQuarantineAllTenants','Push-ListMFAUsersQueue','Push-ListTenantAllowBlockListAllTenants','Push-ListTransportRulesAllTenants','Push-OrchestratorBatchItems','Push-ScheduledTaskPostExecution','Push-SchedulerCIPPNotifications','Push-StoreMailboxRules','Push-UpdatePermissionsQueue','Push-UpdateTenants','Push-Z_CIPPQueueTrigger')

    # Cmdlets to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no cmdlets to export.
    CmdletsToExport    = @()

    # Variables to export from this module
    VariablesToExport  = @()

    # Aliases to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no aliases to export.
    AliasesToExport    = @()

    # DSC resources to export from this module
    # DscResourcesToExport = @()

    # List of all modules packaged with this module
    # ModuleList = @()

    # List of all files packaged with this module
    # FileList = @()

    # Private data to pass to the module specified in RootModule/ModuleToProcess. This may also contain a PSData hashtable with additional module metadata used by PowerShell.
    PrivateData        = @{

        PSData = @{

            # Tags applied to this module. These help with module discovery in online galleries.
            Tags         = @()

            # A URL to the license for this module.
            LicenseUri   = 'https://github.com/KelvinTegelaar/CIPP-API/blob/master/LICENSE'

            # A URL to the main website for this project.
            ProjectUri   = 'https://github.com/KelvinTegelaar/CIPP-API'

            # A URL to an icon representing this module.
            # IconUri = ''

            # ReleaseNotes of this module
            ReleaseNotes = ''

        } # End of PSData hashtable

    } # End of PrivateData hashtable

    # HelpInfo URI of this module
    HelpInfoURI        = 'https://github.com/KelvinTegelaar/CIPP-API'

    # Default prefix for commands exported from this module. Override the default prefix using Import-Module -Prefix.
    # DefaultCommandPrefix = ''

}
