@{
    # Script module or binary module file associated with this manifest.
    RootModule         = '.\CIPPHTTP.psm1'

    # Version number of this module.
    ModuleVersion      = '1.0'

    # Supported PSEditions
    # CompatiblePSEditions = @()

    # ID used to uniquely identify this module
    GUID               = 'b2c2c4ef-67a0-4a0a-8f73-ef0045636b42'

    # Author of this module
    Author             = 'Kelvin Tegelaar - Kelvin@cyberdrain.com'

    # Company or vendor of this module
    CompanyName        = 'CyberDrain.com'

    # Copyright statement for this module
    Copyright          = '(c) 2020 Kelvin Tegelaar - Kelvin@CyberDrain.com All rights reserved.'

    # Description of the functionality provided by this module
    Description        = ''

    # Minimum version of the Windows PowerShell engine required by this module
    PowerShellVersion  = '7.0'

    # Name of the Windows PowerShell host required by this module
    # PowerShellHostName = ''

    # Minimum version of the Windows PowerShell host required by this module
    # PowerShellHostVersion = ''

    # Minimum version of Microsoft .NET Framework required by this module. This prerequisite is valid for the PowerShell Desktop edition only.
    # DotNetFrameworkVersion = ''

    # Minimum version of the common language runtime (CLR) required by this module. This prerequisite is valid for the PowerShell Desktop edition only.
    # CLRVersion = ''

    # Processor architecture (None, X86, Amd64) required by this module
    # ProcessorArchitecture = ''

    # Modules that must be imported into the global environment prior to importing this module
    # RequiredModules = @()

    # Assemblies that must be loaded prior to importing this module
    # RequiredAssemblies = @()

    # Script files (.ps1) that are run in the caller's environment prior to importing this module.
    # ScriptsToProcess = @()

    # Type files (.ps1xml) to be loaded when importing this module
    # TypesToProcess = @()

    # Format files (.ps1xml) to be loaded when importing this module
    # FormatsToProcess = @()

    # Modules to import as nested modules of the module specified in RootModule/ModuleToProcess
    # NestedModules = @()

    # Functions to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no functions to export.
    FunctionsToExport  = @('Invoke-ExecAddAlert','Invoke-ExecAppInsightsQuery','Invoke-ExecAzBobbyTables','Invoke-ExecCIPPDBCache','Invoke-ExecCippFunction','Invoke-ExecCippLogsSas','Invoke-ExecCloneTemplate','Invoke-ExecCPVRefresh','Invoke-ExecDiagnosticsPresets','Invoke-ExecDurableFunctions','Invoke-ExecEditTemplate','Invoke-ExecFeatureFlag','Invoke-ExecGeoIPLookup','Invoke-ExecGraphRequestProfile','Invoke-ExecListBackup','Invoke-ExecPartnerWebhook','Invoke-ExecRemoveSnooze','Invoke-ExecServicePrincipals','Invoke-ExecSetCIPPAutoBackup','Invoke-ExecSetPackageTag','Invoke-ExecSnoozeAlert','Invoke-GetCippAlerts','Invoke-GetVersion','Invoke-ListAdminPortalLicenses','Invoke-ListApiTest','Invoke-ListCustomDataMappings','Invoke-ListDiagnosticsPresets','Invoke-ListDirectoryObjects','invoke-ListEmptyResults','Invoke-ListExtensionCacheData','Invoke-ListFeatureFlags','Invoke-ListGraphBulkRequest','Invoke-ListGraphRequest','Invoke-ListSnoozedAlerts','Invoke-PublicPing','Invoke-ExecExtensionClearHIBPKey','Invoke-ExecExtensionMapping','Invoke-ExecExtensionsConfig','Invoke-ExecExtensionSync','Invoke-ExecExtensionTest','Invoke-ListExtensionSync','Invoke-AddScheduledItem','Invoke-ListScheduledItemDetails','Invoke-ListScheduledItems','Invoke-RemoveScheduledItem','Invoke-ExecAccessChecks','Invoke-ExecAddTrustedIP','Invoke-ExecApiClient','Invoke-ExecAPIPermissionList','Invoke-ExecBackendURLs','Invoke-ExecBackupRetentionConfig','Invoke-ExecBrandingSettings','Invoke-ExecCippReplacemap','Invoke-ExecCPVPermissions','Invoke-ExecCreateDefaultGroups','Invoke-ExecCustomData','Invoke-ExecCustomRole','Invoke-ExecDnsConfig','Invoke-ExecExchangeRoleRepair','Invoke-ExecExcludeLicenses','Invoke-ExecExcludeTenant','Invoke-ExecGDAPTrace','Invoke-ExecJITAdminSettings','Invoke-ExecLogRetentionConfig','Invoke-ExecMaintenanceScripts','Invoke-ExecNotificationConfig','Invoke-ExecOffloadFunctions','Invoke-ExecPartnerMode','Invoke-ExecPasswordConfig','Invoke-ExecPermissionRepair','Invoke-ExecRemoveTenant','Invoke-ExecRestoreBackup','Invoke-ExecRunBackup','Invoke-ExecRunTenantGroupRule','Invoke-ExecSAMAppPermissions','Invoke-ExecSAMRoles','Invoke-ExecTenantGroup','Invoke-ExecTimeSettings','Invoke-ExecWebhookSubscriptions','Invoke-ListCustomRole','Invoke-ListCustomVariables','Invoke-ListExcludedLicenses','Invoke-ListTenantGroups','Invoke-ExecAddTenant','Invoke-ExecCombinedSetup','Invoke-ExecCreateSAMApp','Invoke-ExecDeviceCodeLogon','Invoke-ExecSAMSetup','Invoke-ExecTokenExchange','Invoke-ExecUpdateRefreshToken','Invoke-AddContact','Invoke-AddContactTemplates','Invoke-DeployContactTemplates','Invoke-EditContact','Invoke-EditContactTemplates','Invoke-ListContacts','Invoke-ListContactTemplates','Invoke-RemoveContact','Invoke-RemoveContactTemplates','Invoke-ExecManageRetentionPolicies','Invoke-ExecManageRetentionTags','Invoke-ExecSetMailboxRetentionPolicies','Invoke-AddSharedMailbox','Invoke-ExecConvertMailbox','Invoke-ExecCopyForSent','Invoke-ExecEditCalendarPermissions','Invoke-ExecEditMailboxPermissions','Invoke-ExecEmailForward','Invoke-ExecEnableArchive','Invoke-ExecEnableAutoExpandingArchive','Invoke-ExecGroupsDelete','Invoke-ExecGroupsDeliveryManagement','Invoke-ExecGroupsHideFromGAL','Invoke-ExecHideFromGAL','Invoke-ExecHVEUser','Invoke-ExecMailboxMobileDevices','Invoke-ExecModifyCalPerms','Invoke-ExecModifyContactPerms','Invoke-ExecModifyMBPerms','Invoke-ExecRemoveMailboxRule','Invoke-ExecRemoveRestrictedUser','Invoke-ExecScheduleForwardingVacation','Invoke-ExecScheduleMailboxVacation','Invoke-ExecScheduleOOOVacation','Invoke-ExecSetCalendarProcessing','Invoke-ExecSetLitigationHold','Invoke-ExecSetMailboxEmailSize','Invoke-ExecSetMailboxLocale','Invoke-ExecSetMailboxQuota','Invoke-ExecSetMailboxRule','Invoke-ExecSetOoO','Invoke-ExecSetRecipientLimits','Invoke-ExecSetRetentionHold','Invoke-ExecStartManagedFolderAssistant','Invoke-ListCalendarPermissions','Invoke-ListContactPermissions','Invoke-ListMailboxes','Invoke-ListMailboxMobileDevices','Invoke-ListmailboxPermissions','Invoke-ListMailboxRules','Invoke-ListOoO','Invoke-ListRestrictedUsers','Invoke-ListSharedMailboxStatistics','Invoke-ListActiveSyncDevices','Invoke-ListAntiPhishingFilters','Invoke-ListGlobalAddressList','Invoke-ListMailboxCAS','Invoke-ListMailboxForwarding','Invoke-ListMalwareFilters','Invoke-ListSafeAttachmentsFilters','Invoke-ListSharedMailboxAccountEnabled','Invoke-AddEquipmentMailbox','Invoke-AddRoomList','Invoke-AddRoomMailbox','Invoke-EditEquipmentMailbox','Invoke-EditRoomList','Invoke-EditRoomMailbox','Invoke-ListEquipment','Invoke-ListRoomLists','Invoke-ListRooms','Invoke-AddQuarantinePolicy','Invoke-AddSpamFilter','Invoke-AddSpamFilterTemplate','Invoke-AddTenantAllowBlockList','Invoke-AddTenantAllowBlockListTemplate','Invoke-EditAntiPhishingFilter','Invoke-EditMalwareFilter','Invoke-EditQuarantinePolicy','Invoke-EditSafeAttachmentsFilter','Invoke-EditSpamFilter','Invoke-ExecQuarantineManagement','Invoke-ListConnectionFilter','Invoke-ListConnectionFilterTemplates','Invoke-ListMailQuarantine','Invoke-ListMailQuarantineMessage','Invoke-ListQuarantinePolicy','Invoke-ListSpamfilter','Invoke-ListSpamFilterTemplates','Invoke-ListTenantAllowBlockListTemplates','Invoke-RemoveConnectionfilterTemplate','Invoke-RemoveQuarantinePolicy','Invoke-RemoveSpamfilter','Invoke-RemoveSpamfilterTemplate','Invoke-RemoveTenantAllowBlockListTemplate','Invoke-ExecMailboxRestore','Invoke-ExecMailTest','Invoke-ListExoRequest','Invoke-ListMailboxRestores','Invoke-ListMessageTrace','Invoke-AddConnectionFilter','Invoke-AddConnectionFilterTemplate','Invoke-AddEditTransportRule','Invoke-AddExConnector','Invoke-AddExConnectorTemplate','Invoke-AddTransportRule','Invoke-AddTransportTemplate','Invoke-EditExConnector','Invoke-EditTransportRule','Invoke-ListExchangeConnectors','Invoke-ListExConnectorTemplates','Invoke-ListTransportRules','Invoke-ListTransportRulesTemplates','Invoke-RemoveExConnector','Invoke-RemoveExConnectorTemplate','Invoke-RemoveTransportRule','Invoke-RemoveTransportRuleTemplate','Invoke-AddAppTemplate','Invoke-AddChocoApp','Invoke-AddMSPApp','Invoke-AddOfficeApp','Invoke-AddStoreApp','Invoke-AddWin32ScriptApp','Invoke-ExecAppUpload','Invoke-ExecAssignApp','Invoke-ExecDeployAppTemplate','Invoke-ExecSyncVPP','Invoke-ListApplicationQueue','Invoke-ListApps','Invoke-ListAppsRepository','Invoke-ListAppTemplates','Invoke-RemoveApp','Invoke-RemoveAppTemplate','Invoke-RemoveQueuedApp','Invoke-AddAPDevice','Invoke-AddAutopilotConfig','Invoke-AddEnrollment','Invoke-ExecAssignAPDevice','Invoke-ExecRenameAPDevice','Invoke-ExecSetAPDeviceGroupTag','Invoke-ExecSyncAPDevices','Invoke-ListAPDevices','Invoke-ListAutopilotconfig','Invoke-RemoveAPDevice','Invoke-RemoveAutopilotConfig','Invoke-AddAssignmentFilter','Invoke-AddAssignmentFilterTemplate','Invoke-AddDefenderDeployment','Invoke-AddDefenderTemplate','Invoke-AddIntuneReusableSetting','Invoke-AddIntuneReusableSettingTemplate','Invoke-AddIntuneTemplate','Invoke-AddPolicy','Invoke-EditAssignmentFilter','Invoke-EditIntunePolicy','Invoke-EditIntuneScript','Invoke-EditPolicy','Invoke-ExecAssignmentFilter','Invoke-ExecAssignPolicy','Invoke-ExecCompareIntunePolicy','Invoke-ExecDeviceAction','Invoke-ExecDevicePasscodeAction','Invoke-ExecGetLocalAdminPassword','Invoke-ExecGetRecoveryKey','Invoke-ExecSyncDEP','Invoke-ListAppProtectionPolicies','Invoke-ListAssignmentFilters','Invoke-ListAssignmentFilterTemplates','Invoke-ListCompliancePolicies','Invoke-ListDefenderState','Invoke-ListDefenderTVM','Invoke-ListIntunePolicy','Invoke-ListIntuneReusableSettings','Invoke-ListIntuneReusableSettingTemplates','Invoke-ListIntuneScript','Invoke-ListIntuneTemplates','Invoke-RemoveAssignmentFilterTemplate','Invoke-RemoveIntuneReusableSetting','Invoke-RemoveIntuneReusableSettingTemplate','Invoke-RemoveIntuneScript','Invoke-RemoveIntuneTemplate','Invoke-RemovePolicy','Invoke-ListDevices','Invoke-ExecDeviceDelete','Invoke-AddGroup','Invoke-AddGroupTeam','Invoke-AddGroupTemplate','Invoke-EditGroup','Invoke-ListGroups','Invoke-ListGroupSenderAuthentication','Invoke-ListGroupTemplates','Invoke-RemoveGroupTemplate','Invoke-AddGuest','Invoke-AddJITAdminTemplate','Invoke-AddUser','Invoke-AddUserBulk','Invoke-AddUserDefaults','Invoke-EditJITAdminTemplate','Invoke-EditUser','Invoke-EditUserAliases','Invoke-ExecBECCheck','Invoke-ExecBECRemediate','Invoke-ExecBulkLicense','Invoke-ExecClrImmId','Invoke-ExecCreateTAP','Invoke-ExecDisableUser','Invoke-ExecDismissRiskyUser','Invoke-ExecJITAdmin','Invoke-ExecOffboardUser','Invoke-ExecOnedriveProvision','Invoke-ExecOneDriveShortCut','Invoke-ExecPasswordNeverExpires','Invoke-ExecPerUserMFA','Invoke-ExecReprocessUserLicenses','Invoke-ExecResetMFA','Invoke-ExecResetPass','Invoke-ExecRestoreDeleted','Invoke-ExecRevokeSessions','Invoke-ExecSendPush','Invoke-ExecSetUserPhoto','Invoke-ListDeletedItems','Invoke-ListJITAdmin','Invoke-ListJITAdminTemplates','Invoke-ListNewUserDefaults','Invoke-ListPerUserMFA','Invoke-ListUserConditionalAccessPolicies','Invoke-ListUserCounts','Invoke-ListUserDevices','Invoke-ListUserGroups','Invoke-ListUserMailboxDetails','Invoke-ListUserMailboxRules','Invoke-ListUserPhoto','Invoke-ListUsers','Invoke-ListUserSettings','Invoke-ListUserSigninLogs','Invoke-ListUserTrustedBlockedSenders','Invoke-PatchUser','Invoke-RemoveDeletedObject','Invoke-RemoveJITAdminTemplate','Invoke-RemoveTrustedBlockedSender','Invoke-RemoveUser','Invoke-RemoveUserDefaultTemplate','Invoke-ListAzureADConnectStatus','Invoke-ListBasicAuth','Invoke-ListInactiveAccounts','Invoke-ListMFAUsers','Invoke-ListSignIns','Invoke-ExecSetCloudManaged','Invoke-AddSafeLinksPolicyFromTemplate','Invoke-AddSafeLinksPolicyTemplate','Invoke-CreateSafeLinksPolicyTemplate','Invoke-EditSafeLinksPolicy','Invoke-EditSafeLinksPolicyTemplate','Invoke-ExecDeleteSafeLinksPolicy','Invoke-ExecNewSafeLinksPolicy','Invoke-ListSafeLinksPolicy','Invoke-ListSafeLinksPolicyDetails','Invoke-ListSafeLinksPolicyTemplateDetails','Invoke-ListSafeLinksPolicyTemplates','Invoke-RemoveSafeLinksPolicyTemplate','Invoke-ExecAlertsList','Invoke-ExecIncidentsList','Invoke-ExecMdoAlertsList','Invoke-ExecSetMdoAlert','Invoke-ExecSetSecurityAlert','Invoke-ExecSetSecurityIncident','Invoke-ListMDEOnboarding','Invoke-AddSite','Invoke-AddSiteBulk','Invoke-AddTeam','Invoke-DeleteSharepointSite','Invoke-ExecRemoveTeamsVoicePhoneNumberAssignment','Invoke-ExecSetSharePointMember','Invoke-ExecSharePointPerms','Invoke-ExecTeamsVoicePhoneNumberAssignment','Invoke-ListSharepointAdminUrl','Invoke-ListSharepointQuota','Invoke-ListSharepointSettings','Invoke-ListSiteMembers','Invoke-ListSites','Invoke-ListTeams','Invoke-ListTeamsActivity','Invoke-ListTeamsLisLocation','Invoke-ListTeamsVoice','Invoke-AddAlert','Invoke-AddScriptedAlert','Invoke-ExecAuditLogSearch','Invoke-ListAlertsQueue','Invoke-ListAuditLogs','Invoke-ListAuditLogSearches','Invoke-ListAuditLogTest','Invoke-ListWebhookAlert','Invoke-PublicWebhooks','Invoke-RemoveQueuedAlert','Invoke-ExecAddMultiTenantApp','Invoke-ExecAppApproval','Invoke-ExecAppApprovalTemplate','Invoke-ExecApplication','Invoke-ExecAppPermissionTemplate','Invoke-ExecCreateAppTemplate','Invoke-ExecManageAppCredentials','Invoke-ListAppApprovalTemplates','Invoke-AddDomain','Invoke-ExecDomainAction','Invoke-AddTenant','Invoke-EditTenant','Invoke-EditTenantOffboardingDefaults','Invoke-ListTenantDetails','Invoke-ListTenants','Invoke-RemoveTenantCapabilitiesCache','Invoke-ExecAddSPN','Invoke-ExecOffboardTenant','Invoke-ExecOnboardTenant','Invoke-ExecUpdateSecureScore','Invoke-ListAppConsentRequests','Invoke-ListDomains','Invoke-ListOffboardTenants','Invoke-ListTenantOnboarding','Invoke-SetAuthMethod','Invoke-AddCAPolicy','Invoke-AddCATemplate','Invoke-AddNamedLocation','Invoke-EditCAPolicy','Invoke-ExecCACheck','Invoke-ExecCAExclusion','Invoke-ExecCAServiceExclusion','Invoke-ExecNamedLocation','Invoke-ListCAtemplates','Invoke-ListConditionalAccessPolicies','Invoke-ListConditionalAccessPolicyChanges','Invoke-RemoveCAPolicy','Invoke-RemoveCATemplate','Invoke-ExecAddGDAPRole','Invoke-ExecAutoExtendGDAP','Invoke-ExecDeleteGDAPRelationship','Invoke-ExecDeleteGDAPRoleMapping','Invoke-ExecGDAPAccessAssignment','Invoke-ExecGDAPInvite','Invoke-ExecGDAPInviteApproved','Invoke-ExecGDAPRemoveGArole','Invoke-ExecGDAPRoleTemplate','Invoke-ListGDAPAccessAssignments','Invoke-ListGDAPContracts','Invoke-ListGDAPInvite','Invoke-ListGDAPRelationships','Invoke-ListGDAPRoles','Invoke-ListGDAPServicePrincipals','Invoke-ListGraphReports','Invoke-ListLicenses','Invoke-ListOAuthApps','Invoke-ListServiceHealth','Invoke-AddStandardsDeploy','Invoke-AddStandardsTemplate','Invoke-BestPracticeAnalyser_List','invoke-DomainAnalyser_List','Invoke-ExecBPA','Invoke-ExecDomainAnalyser','Invoke-ExecDriftClone','Invoke-ExecStandardConvert','Invoke-ExecStandardsRun','Invoke-ExecUpdateDriftDeviation','Invoke-ListBPA','Invoke-ListBPATemplates','Invoke-ListDomainAnalyser','Invoke-ListDomainHealth','Invoke-ListStandards','Invoke-ListStandardsCompare','Invoke-ListStandardsCurrentState','Invoke-listStandardTemplates','Invoke-ListTenantAlignment','Invoke-ListTenantDrift','Invoke-RemoveBPATemplate','Invoke-RemoveStandard','Invoke-RemoveStandardTemplate','Invoke-AddBPATemplate','Invoke-ExecGraphExplorerPreset','Invoke-AddCustomScript','Invoke-ExecCustomScript','Invoke-ListCustomScripts','Invoke-RemoveCustomScript','Invoke-ExecCommunityRepo','Invoke-ExecGitHubAction','Invoke-ListCommunityRepos','Invoke-ListGitHubReleaseNotes','Invoke-ExecGenerateReportBuilderReport','Invoke-ExecReportBuilderTemplate','Invoke-ListGeneratedReports','Invoke-ListReportBuilderTemplates','Invoke-AddTestReport','Invoke-DeleteTestReport','Invoke-ExecBitlockerSearch','Invoke-ExecBreachSearch','Invoke-ExecCSPLicense','Invoke-ExecExtensionNinjaOneQueue','Invoke-ExecLicenseSearch','Invoke-ExecListAppId','Invoke-ExecSchedulerBillingRun','Invoke-ExecSendOrgMessage','Invoke-ExecTestRefresh','Invoke-ExecTestRun','Invoke-ExecUniversalSearch','Invoke-ExecUniversalSearchV2','Invoke-ExecUserBookmarks','Invoke-ExecUserSettings','Invoke-ListAllTenantDeviceCompliance','Invoke-ListAppStatus','Invoke-ListAvailableTests','Invoke-ListBreachesAccount','Invoke-ListBreachesTenant','Invoke-ListCheckExtAlerts','Invoke-ListCippQueue','Invoke-ListCSPLicenses','Invoke-ListCSPsku','Invoke-ListDBCache','Invoke-ListDetectedAppDevices','Invoke-ListDetectedApps','Invoke-ListDeviceDetails','Invoke-ListExtensionsConfig','Invoke-ListExternalTenantInfo','Invoke-ListFunctionParameters','Invoke-ListFunctionStats','Invoke-ListGenericTestFunction','Invoke-ListGraphExplorerPresets','Invoke-ListHaloClients','Invoke-ListIntuneIntents','Invoke-ListIPWhitelist','Invoke-ListKnownIPDb','Invoke-ListLogs','Invoke-ListNamedLocations','Invoke-ListNotificationConfig','Invoke-ListOrg','Invoke-ListPartnerRelationships','Invoke-ListPendingWebhooks','Invoke-ListPotentialApps','Invoke-ListRoles','Invoke-ListTenantAllowBlockList','Invoke-ListTestReports','Invoke-ListTests','Invoke-ListUsersAndGroups','Invoke-PublicPhishingCheck','Invoke-RemoveCippQueue','Invoke-RemoveTenantAllowBlockList','Invoke-RemoveWebhookAlert','New-CippCoreRequest')

    # Cmdlets to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no cmdlets to export.
    CmdletsToExport    = @()

    # Variables to export from this module
    VariablesToExport  = @()

    # Aliases to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no aliases to export.
    AliasesToExport    = @()

    # DSC resources to export from this module
    # DscResourcesToExport = @()

    # List of all modules packaged with this module
    # ModuleList = @()

    # List of all files packaged with this module
    # FileList = @()

    # Private data to pass to the module specified in RootModule/ModuleToProcess. This may also contain a PSData hashtable with additional module metadata used by PowerShell.
    PrivateData        = @{

        PSData = @{

            # Tags applied to this module. These help with module discovery in online galleries.
            Tags         = @()

            # A URL to the license for this module.
            LicenseUri   = 'https://github.com/KelvinTegelaar/CIPP-API/blob/master/LICENSE'

            # A URL to the main website for this project.
            ProjectUri   = 'https://github.com/KelvinTegelaar/CIPP-API'

            # A URL to an icon representing this module.
            # IconUri = ''

            # ReleaseNotes of this module
            ReleaseNotes = ''

        } # End of PSData hashtable

    } # End of PrivateData hashtable

    # HelpInfo URI of this module
    HelpInfoURI        = 'https://github.com/KelvinTegelaar/CIPP-API'

    # Default prefix for commands exported from this module. Override the default prefix using Import-Module -Prefix.
    # DefaultCommandPrefix = ''

}
