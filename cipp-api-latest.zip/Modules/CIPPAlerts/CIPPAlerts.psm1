#Region './Public/Alerts/Get-CIPPAlertAdminPassword.ps1' -1


function Get-CIPPAlertAdminPassword {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        $TenantId = (Get-Tenants | Where-Object -Property defaultDomainName -EQ $TenantFilter).customerId

        # Get role assignments without expanding principal to avoid rate limiting
        $RoleAssignments = New-GraphGETRequest -uri "https://graph.microsoft.com/beta/roleManagement/directory/roleAssignments?`$filter=roleDefinitionId eq '62e90394-69f5-4237-9190-012177145e10'" -tenantid $($TenantFilter) | Where-Object { $_.principalOrganizationId -EQ $TenantId }

        # Build bulk requests for each principalId
        $UserRequests = $RoleAssignments | ForEach-Object {
            [PSCustomObject]@{
                id     = $_.principalId
                method = 'GET'
                url    = "users/$($_.principalId)?`$select=id,UserPrincipalName,lastPasswordChangeDateTime"
            }
        }

        # Make bulk call to get user information
        if ($UserRequests) {
            $BulkResults = New-GraphBulkRequest -Requests @($UserRequests) -tenantid $TenantFilter

            # Filter users with recent password changes and sort to prevent duplicate alerts
            $AlertData = $BulkResults | Where-Object { $_.status -eq 200 -and $_.body.lastPasswordChangeDateTime -gt (Get-Date).AddDays(-1) } | ForEach-Object {
                $_.body | Select-Object -Property UserPrincipalName, lastPasswordChangeDateTime
            } | Sort-Object UserPrincipalName
        } else {
            $AlertData = @()
        }

        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not get admin password changes for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertAdminPassword.ps1' 49
#Region './Public/Alerts/Get-CIPPAlertApnCertExpiry.ps1' -1

function Get-CIPPAlertApnCertExpiry {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        $Apn = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/deviceManagement/applePushNotificationCertificate' -tenantid $TenantFilter
        $AlertData = if ($Apn.expirationDateTime -lt (Get-Date).AddDays(30) -and $Apn.expirationDateTime -gt (Get-Date).AddDays(-7)) {
            $Apn | Select-Object -Property appleIdentifier, expirationDateTime
        }
        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        #no error because if a tenant does not have an APN, it'll error anyway.
        #$ErrorMessage = Get-CippException -Exception $_
        #Write-AlertMessage -tenant $($TenantFilter) -message "Failed to check APN certificate expiry for $($TenantFilter): $($ErrorMessage.NormalizedError)"
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertApnCertExpiry.ps1' 29
#Region './Public/Alerts/Get-CIPPAlertAppCertificateExpiry.ps1' -1

function Get-CIPPAlertAppCertificateExpiry {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    $Now = Get-Date
    $AlertData = @()

    try {
        $appList = New-CIPPDbRequest -TenantFilter $TenantFilter -Type 'Apps'
    } catch {
        $appList = @()
    }

    $AppAlertData = foreach ($App in $appList) {
        if ($App.keyCredentials) {
            foreach ($Credential in $App.keyCredentials) {
                if ($Credential.endDateTime -lt $Now.AddDays(30) -and $Credential.endDateTime -gt $Now.AddDays(-7)) {
                    @{
                        DisplayName = $App.displayName
                        Expires     = $Credential.endDateTime
                        AppId       = $App.appId
                        Type        = 'Application'
                    }
                }
            }
        }
    }

    try {
        $servicePrincipals = New-CIPPDbRequest -TenantFilter $TenantFilter -Type 'ServicePrincipals'
    } catch {
        $servicePrincipals = @()
    }

    $SamlAlertData = foreach ($ServicePrincipal in $servicePrincipals) {
        $ExpiryDate = $null
        if ($ServicePrincipal.preferredTokenSigningKeyEndDateTime) {
            $ExpiryDate = [datetime]$ServicePrincipal.preferredTokenSigningKeyEndDateTime
        }
        if ($ExpiryDate -and $ExpiryDate -lt $Now.AddDays(30) -and $ExpiryDate -gt $Now.AddDays(-7)) {
            @{
                DisplayName        = $ServicePrincipal.displayName
                Expires            = $ExpiryDate
                AppId              = $ServicePrincipal.appId
                ServicePrincipalId = $ServicePrincipal.id
                Type               = 'SamlServicePrincipal'
            }
        }
    }

    $AlertData = @(
        @($AppAlertData)
        @($SamlAlertData)
    ) | Where-Object { $null -ne $_ }
    if ($AlertData) {
        Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertAppCertificateExpiry.ps1' 68
#Region './Public/Alerts/Get-CIPPAlertAppleTerms.ps1' -1

function Get-CIPPAlertAppleTerms {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    # 0 = Expired
    # 1 = expired?
    # 2 = unknown
    # 3 = Terms & Conditions
    # 4 = Warning

    try {
        Write-Host "Checking Apple Terms for $($TenantFilter)"
        $AppleTerms = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/deviceManagement/depOnboardingSettings' -tenantid $TenantFilter
    } catch {
        return
    }

    if ($AppleTerms.lastSyncErrorCode -eq 3) {
        $AlertData = [PSCustomObject]@{
            Message                    = 'New Apple Business Manager terms are ready to accept.'
            AppleIdentifier            = $AppleTerms.appleIdentifier
            TokenName                  = $AppleTerms.tokenName
            TokenExpirationDateTime    = $AppleTerms.tokenExpirationDateTime
            LastSyncErrorCode          = $AppleTerms.lastSyncErrorCode
            LastSuccessfulSyncDateTime = $AppleTerms.lastSuccessfulSyncDateTime
            LastSyncTriggeredDateTime  = $AppleTerms.lastSyncTriggeredDateTime
            Tenant                     = $TenantFilter
        }
        Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertAppleTerms.ps1' 41
#Region './Public/Alerts/Get-CIPPAlertAppSecretExpiry.ps1' -1

function Get-CIPPAlertAppSecretExpiry {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        Write-Host "Checking app expire for $($TenantFilter)"
        $appList = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/applications?`$select=appId,displayName,passwordCredentials" -tenantid $TenantFilter
    } catch {
        return
    }

    $AlertData = [System.Collections.Generic.List[PSCustomObject]]::new()

    foreach ($App in $applist) {
        Write-Host "checking $($App.displayName)"
        if ($App.passwordCredentials) {
            foreach ($Credential in $App.passwordCredentials) {
                if ($Credential.endDateTime -lt (Get-Date).AddDays(30) -and $Credential.endDateTime -gt (Get-Date).AddDays(-7)) {
                    Write-Host ("Application '{0}' has secrets expiring on {1}" -f $App.displayName, $Credential.endDateTime)

                    $Message = [PSCustomObject]@{
                        AppName    = $App.displayName
                        AppId      = $App.appId
                        Expires    = $Credential.endDateTime
                        SecretName = $Credential.displayName
                        SecretID   = $Credential.keyId
                        Tenant     = $TenantFilter
                    }
                    $AlertData.Add($Message)
                }
            }
        }
    }
    if ($AlertData) {
        Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertAppSecretExpiry.ps1' 47
#Region './Public/Alerts/Get-CippAlertBreachAlert.ps1' -1


function Get-CippAlertBreachAlert {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $TenantFilter
    )
    try {
        $Search = New-BreachTenantSearch -TenantFilter $TenantFilter
        if ($Search) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $Search -PartitionKey BreachAlert
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-AlertMessage -tenant $($TenantFilter) -message "Could not get New Breaches for $($TenantFilter): $($ErrorMessage.NormalizedError)"
    }
}
#EndRegion './Public/Alerts/Get-CippAlertBreachAlert.ps1' 23
#Region './Public/Alerts/Get-CIPPAlertCheckExtension.ps1' -1

function Get-CIPPAlertCheckExtension {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        $TenantFilter,
        [Alias('input')]
        $InputValue
    )

    try {
        $CheckTable = Get-CippTable -tablename 'CheckExtensionAlerts'
        $LastRunTable = Get-CippTable -tablename 'AlertLastRun'
        $LastRunKey = "$TenantFilter-Get-CIPPAlertCheckExtension"

        # Get the last run timestamp for this tenant to only fetch new alerts
        $LastRun = Get-CIPPAzDataTableEntity @LastRunTable -Filter "PartitionKey eq 'AlertLastRun' and RowKey eq '$LastRunKey'" | Select-Object -First 1
        $Since = if ($LastRun.Timestamp) {
            $LastRun.Timestamp.UtcDateTime
        } else {
            (Get-Date).AddDays(-1).ToUniversalTime()
        }
        $SinceString = $Since.ToString('yyyy-MM-ddTHH:mm:ssZ')

        $CheckAlerts = Get-CIPPAzDataTableEntity @CheckTable -Filter "PartitionKey eq 'CheckAlert' and tenantFilter eq '$TenantFilter' and Timestamp ge datetime'$SinceString'"

        $AlertData = foreach ($Alert in $CheckAlerts) {
            [PSCustomObject]@{
                Message                  = "Phishing alert: $($Alert.type) detected for user $($Alert.potentialUserName) at URL $($Alert.url) - $($Alert.reason)"
                Type                     = $Alert.type
                URL                      = $Alert.url
                Reason                   = $Alert.reason
                Score                    = $Alert.score
                Threshold                = $Alert.threshold
                PotentialUserName        = $Alert.potentialUserName
                PotentialUserDisplayName = $Alert.potentialUserDisplayName
                ReportedByIP             = $Alert.reportedByIP
                Tenant                   = $TenantFilter
            }
        }

        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-AlertMessage -message "Check Extension alert failed: $($ErrorMessage.NormalizedError)" -tenant $TenantFilter -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertCheckExtension.ps1' 53
#Region './Public/Alerts/Get-CIPPAlertDefenderAlerts.ps1' -1


function Get-CIPPAlertDefenderAlerts {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    $AlertSeverities = $InputValue.AlertSeverities.value -as [System.Collections.Generic.List[string]]
    try {
        $DefenderAlerts = New-GraphGetRequest -uri "https://graph.microsoft.com/v1.0/security/alerts_v2?`$top=50&`$filter=status eq 'new'" -tenantid $TenantFilter
        $AlertData = foreach ($Alert in $DefenderAlerts) {
            # Skip if severity doesn't match filter (unless "All" is selected or no filter)
            if ($AlertSeverities.Count -gt 0 -and 'All' -notin $AlertSeverities) {
                if ($Alert.severity -notin $AlertSeverities) {
                    continue
                }
            }

            [PSCustomObject]@{
                Title                 = $Alert.title
                Description           = $Alert.description
                Severity              = $Alert.severity
                Category              = $Alert.category
                ServiceSource         = $Alert.serviceSource
                ProductName           = $Alert.productName
                DetectionSource       = $Alert.detectionSource
                Classification        = $Alert.classification
                Determination         = $Alert.determination
                ThreatDisplayName     = $Alert.threatDisplayName
                ThreatFamilyName      = $Alert.threatFamilyName
                ActorDisplayName      = $Alert.actorDisplayName
                MitreTechniques       = ($Alert.mitreTechniques -join ', ')
                AssignedTo            = $Alert.assignedTo
                FirstActivityDateTime = $Alert.firstActivityDateTime
                LastActivityDateTime  = $Alert.lastActivityDateTime
                CreatedAt             = $Alert.createdDateTime
                RecommendedActions    = $Alert.recommendedActions
                AlertID               = $Alert.id
                IncidentID            = $Alert.incidentId
                AlertUrl              = $Alert.alertWebUrl
                IncidentUrl           = $Alert.incidentWebUrl
                Tenant                = $TenantFilter
            }
        }
        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        # Commented out due to potential licensing spam
        # $ErrorMessage = Get-CippException -Exception $_
        # Write-AlertMessage -tenant $($TenantFilter) -message "Could not get Defender alerts for $($TenantFilter): $($ErrorMessage.NormalizedError)"
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertDefenderAlerts.ps1' 62
#Region './Public/Alerts/Get-CIPPAlertDefenderIncidents.ps1' -1


function Get-CIPPAlertDefenderIncidents {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    $IncidentSeverities = $InputValue.IncidentSeverities.value -as [System.Collections.Generic.List[string]]
    try {
        $Incidents = New-GraphGetRequest -uri "https://graph.microsoft.com/v1.0/security/incidents?`$top=50&`$filter=status eq 'active'" -tenantid $TenantFilter
        $AlertData = foreach ($Incident in $Incidents) {
            # Skip if severity doesn't match filter (unless "All" is selected or no filter)
            if ($IncidentSeverities.Count -gt 0 -and 'All' -notin $IncidentSeverities) {
                if ($Incident.severity -notin $IncidentSeverities) {
                    continue
                }
            }

            [PSCustomObject]@{
                IncidentName   = $Incident.displayName
                Severity       = $Incident.severity
                Classification = $Incident.classification
                Determination  = $Incident.determination
                Summary        = $Incident.summary
                AssignedTo     = $Incident.assignedTo
                CreatedAt      = $Incident.createdDateTime
                IncidentID     = $Incident.id
                IncidentUrl    = $Incident.incidentWebUrl
                Tenant         = $TenantFilter
            }
        }
        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        # Pretty sure this one is gonna be spammy cause of licensing issues, so it's commented out -Bobby
        # $ErrorMessage = Get-CippException -Exception $_
        # Write-AlertMessage -tenant $($TenantFilter) -message "Could not get Defender incident data for $($TenantFilter): $($ErrorMessage.NormalizedError)"
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertDefenderIncidents.ps1' 49
#Region './Public/Alerts/Get-CIPPAlertDefenderMalware.ps1' -1


function Get-CIPPAlertDefenderMalware {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        $TenantId = (Get-Tenants | Where-Object -Property defaultDomainName -EQ $TenantFilter).customerId
        $AlertData = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/tenantRelationships/managedTenants/windowsDeviceMalwareStates?`$top=999&`$filter=tenantId eq '$($TenantId)'" | Where-Object { $_.malwareThreatState -eq 'Active' } | ForEach-Object {
            [PSCustomObject]@{
                DeviceName               = $_.managedDeviceName
                MalwareName              = $_.malwareDisplayName
                MalwareSeverity          = $_.malwareSeverity
                ThreatState              = $_.malwareThreatState
                AdditionalInformationUrl = $_.additionalInformationUrl
                InitialDetectionDateTime = $_.initialDetectionDateTime
                LastStateChangeDateTime  = $_.lastStateChangeDateTime
                DetectionCount           = $_.detectionCount
                Tenant                   = $TenantFilter
                TenantId                 = $_.tenantId
            }
        }
        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not get malware data for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertDefenderMalware.ps1' 39
#Region './Public/Alerts/Get-CIPPAlertDefenderStatus.ps1' -1

function Get-CIPPAlertDefenderStatus {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        $TenantId = (Get-Tenants | Where-Object -Property defaultDomainName -EQ $TenantFilter).customerId
        $AlertData = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/tenantRelationships/managedTenants/windowsProtectionStates?`$top=999&`$filter=tenantId eq '$($TenantId)'" | Where-Object { $_.realTimeProtectionEnabled -eq $false -or $_.MalwareprotectionEnabled -eq $false } | ForEach-Object {
            [PSCustomObject]@{
                ManagedDeviceName              = $_.managedDeviceName
                RealTimeProtectionEnabled      = $_.realTimeProtectionEnabled
                MalwareProtectionEnabled       = $_.malwareProtectionEnabled
                NetworkInspectionSystemEnabled = $_.networkInspectionSystemEnabled
                ManagedDeviceHealthState       = $_.managedDeviceHealthState
                AttentionRequired              = $_.attentionRequired
                LastSyncDateTime               = $_.lastSyncDateTime
                OsVersion                      = $_.osVersion
                Tenant                         = $TenantFilter
                TenantId                       = $_.tenantId
            }
        }
        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not get defender status for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertDefenderStatus.ps1' 38
#Region './Public/Alerts/Get-CIPPAlertDepTokenExpiry.ps1' -1

function Get-CIPPAlertDepTokenExpiry {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        try {
            $DepTokens = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/deviceManagement/depOnboardingSettings' -tenantid $TenantFilter
            $AlertData = foreach ($Dep in $DepTokens) {
                if ($Dep.tokenExpirationDateTime -lt (Get-Date).AddDays(30) -and $Dep.tokenExpirationDateTime -gt (Get-Date).AddDays(-7)) {
                    $Message = 'Apple Device Enrollment Program token expiring on {0}' -f $Dep.tokenExpirationDateTime
                    $Dep | Select-Object -Property tokenName, @{Name = 'Message'; Expression = { $Message } }
                }
            }
            if ($AlertData) {
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }

        } catch {}


    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Failed to check Apple Device Enrollment Program token expiry for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertDepTokenExpiry.ps1' 35
#Region './Public/Alerts/Get-CIPPAlertDeviceCompliance.ps1' -1


function Get-CIPPAlertDeviceCompliance {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        $AlertData = New-GraphGETRequest -uri "https://graph.microsoft.com/v1.0/deviceManagement/managedDevices?`$filter=complianceState eq 'noncompliant'&`$select=id,deviceName,managedDeviceOwnerType,complianceState,lastSyncDateTime&`$top=999" -tenantid $TenantFilter
        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not get compliance state for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertDeviceCompliance.ps1' 24
#Region './Public/Alerts/Get-CIPPAlertEntraConnectSyncStatus.ps1' -1


function Get-CIPPAlertEntraConnectSyncStatus {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        # Set Hours with fallback to 72 hours
        $Hours = if ($InputValue) { [int]$InputValue } else { 72 }
        $ConnectSyncStatus = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/organization?$select=onPremisesLastPasswordSyncDateTime,onPremisesLastSyncDateTime,onPremisesSyncEnabled' -tenantid $TenantFilter

        if ($ConnectSyncStatus.onPremisesSyncEnabled -eq $true) {
            $LastPasswordSync = $ConnectSyncStatus.onPremisesLastPasswordSyncDateTime
            $SyncDateTime = $ConnectSyncStatus.onPremisesLastSyncDateTime
            # Get the older of the two sync times
            $LastSync = if ($SyncDateTime -lt $LastPasswordSync) { $SyncDateTime; $Cause = 'DirectorySync' } else { $LastPasswordSync; $Cause = 'PasswordSync' }

            if ($LastSync -lt (Get-Date).AddHours(-$Hours).ToUniversalTime()) {

                $AlertData = @{
                    Message           = "Entra Connect $Cause for $($TenantFilter) has not run for over $Hours hours. Last sync was at $($LastSync.ToString('o'))"
                    LastSync          = $LastSync
                    Cause             = $Cause
                    LastPasswordSync  = $LastPasswordSync
                    LastDirectorySync = $SyncDateTime
                    Tenant            = $TenantFilter
                }
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not get Entra Connect Sync Status for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertEntraConnectSyncStatus.ps1' 43
#Region './Public/Alerts/Get-CIPPAlertEntraLicenseUtilization.ps1' -1

function Get-CIPPAlertEntraLicenseUtilization {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        # Set threshold with fallback to 110%
        $Threshold = if ($InputValue) { [int]$InputValue } else { 110 }

        $LicenseData = New-GraphGETRequest -uri 'https://graph.microsoft.com/beta/reports/azureADPremiumLicenseInsight' -tenantid $($TenantFilter)

        $AlertData = @(
            # Check P1 License utilization
            if ($LicenseData.entitledP1LicenseCount -gt 0 -or $LicenseData.entitledP2LicenseCount -gt 0) {
                $P1Used = $LicenseData.p1FeatureUtilizations.conditionalAccess.userCount
                $P1Entitled = $LicenseData.entitledP1LicenseCount + $LicenseData.entitledP2LicenseCount
                $P1Usage = [math]::Round(($P1Used / $P1Entitled) * 100, 2)
                $P1Overage = $P1Used - $P1Entitled

                if ($P1Usage -gt $Threshold -and $P1Overage -ge 5) {
                    [PSCustomObject]@{
                        Message          = "Entra ID P1 license utilization is at $P1Usage% (using $P1Used of $P1Entitled licenses, over by $P1Overage)"
                        LicenseType      = 'Entra ID P1'
                        UsedLicenses     = $P1Used
                        EntitledLicenses = $P1Entitled
                        UsagePercent     = $P1Usage
                        Overage          = $P1Overage
                        Threshold        = $Threshold
                        Tenant           = $TenantFilter
                    }
                }
            }

            # Check P2 License utilization
            if ($LicenseData.entitledP2LicenseCount -gt 0) {
                $P2Used = $LicenseData.p2FeatureUtilizations.riskBasedConditionalAccess.userCount
                $P2Entitled = $LicenseData.entitledP2LicenseCount
                $P2Usage = [math]::Round(($P2Used / $P2Entitled) * 100, 2)
                $P2Overage = $P2Used - $P2Entitled

                if ($P2Usage -gt $Threshold -and $P2Overage -ge 5) {
                    [PSCustomObject]@{
                        Message          = "Entra ID P2 license utilization is at $P2Usage% (using $P2Used of $P2Entitled licenses, over by $P2Overage)"
                        LicenseType      = 'Entra ID P2'
                        UsedLicenses     = $P2Used
                        EntitledLicenses = $P2Entitled
                        UsagePercent     = $P2Usage
                        Overage          = $P2Overage
                        Threshold        = $Threshold
                        Tenant           = $TenantFilter
                    }
                }
            }
        )

        if ($AlertData.Count -gt 0) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -message "Failed to check license utilization: $($ErrorMessage.NormalizedError)" -API 'License Utilization Alert' -tenant $TenantFilter -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertEntraLicenseUtilization.ps1' 72
#Region './Public/Alerts/Get-CIPPAlertExpiringLicenses.ps1' -1

function Get-CIPPAlertExpiringLicenses {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        # Parse input parameters - default to 30 days if not specified
        # Support both old format (direct value) and new format (object with properties)
        if ($InputValue -is [hashtable] -or $InputValue -is [PSCustomObject]) {
            $DaysThreshold = if ($InputValue.ExpiringLicensesDays) { [int]$InputValue.ExpiringLicensesDays } else { 30 }
            $UnassignedOnly = if ($null -ne $InputValue.ExpiringLicensesUnassignedOnly) { [bool]$InputValue.ExpiringLicensesUnassignedOnly } else { $false }
        } else {
            # Backward compatibility: if InputValue is a simple value, treat it as days threshold
            $DaysThreshold = if ($InputValue) { [int]$InputValue } else { 30 }
            $UnassignedOnly = $false
        }

        $AlertData = @(
            Get-CIPPLicenseOverview -TenantFilter $TenantFilter | ForEach-Object {

                $UnassignedCount = [int]$_.CountAvailable

                # If unassigned only filter is enabled, skip licenses with no unassigned units
                if ($UnassignedOnly -and $UnassignedCount -le 0) {
                    return
                }

                # FIX: term rows are in TermInfo on the overview object
                $TermData = @($_.TermInfo)

                foreach ($Term in $TermData) {
                    $DaysUntilRenew = [int]$Term.DaysUntilRenew

                    if ($DaysUntilRenew -lt $DaysThreshold -and $DaysUntilRenew -gt 0) {

                        $Message = if ($UnassignedOnly) {
                            "$($_.License) has $UnassignedCount unassigned license(s) expiring in $DaysUntilRenew days. The estimated term is $($Term.Term)"
                        } else {
                            "$($_.License) will expire in $DaysUntilRenew days. The estimated term is $($Term.Term)"
                        }

                        [PSCustomObject]@{
                            Message        = $Message
                            License        = $_.License
                            SkuId          = $_.skuId
                            DaysUntilRenew = $DaysUntilRenew
                            Term           = $Term.Term
                            Status         = $Term.Status
                            TotalLicenses  = $Term.TotalLicenses
                            CountUsed      = $_.CountUsed
                            CountAvailable = $UnassignedCount
                            NextLifecycle  = $Term.NextLifecycle
                            Tenant         = $_.Tenant
                        }
                    }
                }
            }
        )

        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -error $_
        throw
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertExpiringLicenses.ps1' 77
#Region './Public/Alerts/Get-CIPPAlertGlobalAdminAllowList.ps1' -1

function Get-CIPPAlertGlobalAdminAllowList {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        $AllowedAdmins = @()
        $AlertEachAdmin = $false
        if ($InputValue -is [hashtable] -or $InputValue -is [pscustomobject]) {
            $AlertEachAdmin = [bool]($InputValue['AlertEachAdmin'])
            $ApprovedValue = if ($InputValue.ContainsKey('ApprovedGlobalAdmins') -or ($InputValue.PSObject.Properties.Name -contains 'ApprovedGlobalAdmins')) {
                $InputValue['ApprovedGlobalAdmins']
            } else {
                $null
            }
            $InputValue = $ApprovedValue
        }
        if ($null -ne $InputValue) {
            if ($InputValue -is [string]) {
                $AllowedAdmins = $InputValue -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
            } elseif ($InputValue -is [System.Collections.IEnumerable]) {
                $AllowedAdmins = $InputValue | ForEach-Object { $_.ToString().Trim() } | Where-Object { $_ }
            } else {
                $AllowedAdmins = @("$InputValue")
            }
        }
        $AllowedLookup = $AllowedAdmins | ForEach-Object { $_.ToLowerInvariant() } | Select-Object -Unique

        if (-not $AllowedLookup -or $AllowedLookup.Count -eq 0) {
            return
        }

        $GlobalAdmins = New-GraphGetRequest -uri "https://graph.microsoft.com/v1.0/directoryRoles/roleTemplateId=62e90394-69f5-4237-9190-012177145e10/members?`$select=id,displayName,userPrincipalName" -tenantid $TenantFilter -AsApp $true -ErrorAction Stop | Where-Object {
            $_.'@odata.type' -eq '#microsoft.graph.user' -and $_.displayName -ne 'On-Premises Directory Synchronization Service Account'
        }

        $UnapprovedAdmins = foreach ($admin in $GlobalAdmins) {
            if ([string]::IsNullOrWhiteSpace($admin.userPrincipalName)) { continue }
            $UpnPrefix = ($admin.userPrincipalName -split '@')[0].ToLowerInvariant()
            if ($AllowedLookup -notcontains $UpnPrefix) {
                [PSCustomObject]@{
                    Admin     = $admin
                    UpnPrefix = $UpnPrefix
                }
            }
        }

        if ($UnapprovedAdmins) {
            if ($AlertEachAdmin) {
                $AlertData = foreach ($item in $UnapprovedAdmins) {
                    $admin = $item.Admin
                    $UpnPrefix = $item.UpnPrefix
                    [PSCustomObject]@{
                        Message           = "$($admin.userPrincipalName) has Global Administrator role but is not in the approved allow list (prefix '$UpnPrefix')."
                        DisplayName       = $admin.displayName
                        UserPrincipalName = $admin.userPrincipalName
                        Id                = $admin.id
                        AllowedList       = if ($AllowedAdmins) { $AllowedAdmins -join ', ' } else { 'Not provided' }
                        Tenant            = $TenantFilter
                    }
                }
            } else {
                $NonCompliantUpns = @($UnapprovedAdmins.Admin.userPrincipalName)
                $AlertData = @([PSCustomObject]@{
                        Message           = "Found $($NonCompliantUpns.Count) Global Administrator account(s) not in the approved allow list."
                        NonCompliantUsers = $NonCompliantUpns -join ', '
                        ApprovedPrefixes  = if ($AllowedAdmins) { $AllowedAdmins -join ', ' } else { 'Not provided' }
                        Tenant            = $TenantFilter
                    })
            }

            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Failed to check approved Global Admins: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertGlobalAdminAllowList.ps1' 86
#Region './Public/Alerts/Get-CIPPAlertGlobalAdminNoAltEmail.ps1' -1

function Get-CIPPAlertGlobalAdminNoAltEmail {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        # Get all Global Admin accounts using the role template ID
        $globalAdmins = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/directoryRoles/roleTemplateId=62e90394-69f5-4237-9190-012177145e10/members?`$select=id,displayName,userPrincipalName,otherMails" -tenantid $($TenantFilter) -AsApp $true | Where-Object {
            $_.userDisplayName -ne 'On-Premises Directory Synchronization Service Account' -and $_.'@odata.type' -eq '#microsoft.graph.user'
        }

        # Filter for Global Admins without alternate email addresses
        $adminsWithoutAltEmail = $globalAdmins | Where-Object {
            $null -eq $_.otherMails -or $_.otherMails.Count -eq 0
        }

        if ($adminsWithoutAltEmail.Count -gt 0) {
            $AlertData = foreach ($admin in $adminsWithoutAltEmail) {
                [PSCustomObject]@{
                    DisplayName       = $admin.displayName
                    UserPrincipalName = $admin.userPrincipalName
                    Id                = $admin.id
                    Tenant            = $TenantFilter
                }
            }
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        Write-LogMessage -message "Failed to check alternate email status for Global Admins: $($_.exception.message)" -API 'Global Admin Alt Email Alerts' -tenant $TenantFilter -sev Error
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertGlobalAdminNoAltEmail.ps1' 39
#Region './Public/Alerts/Get-CIPPAlertGroupMembershipChange.ps1' -1

function Get-CIPPAlertGroupMembershipChange {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        $MonitoredGroups = $InputValue -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        if (!$MonitoredGroups) { return $true }

        $OneHourAgo = (Get-Date).AddHours(-3).ToString('yyyy-MM-ddTHH:mm:ssZ')
        $AuditLogs = New-GraphGetRequest -uri "https://graph.microsoft.com/v1.0/auditLogs/directoryAudits?`$filter=activityDateTime ge $OneHourAgo and (activityDisplayName eq 'Add member to group' or activityDisplayName eq 'Remove member from group')" -tenantid $TenantFilter

        $AlertData = foreach ($Log in $AuditLogs) {
            $Member = ($Log.targetResources | Where-Object { $_.type -in @('User', 'ServicePrincipal', 'Group') })[0]
            $GroupProp = ($Member.modifiedProperties | Where-Object { $_.displayName -eq 'Group.DisplayName' })
            $GroupDisplayName = (($GroupProp.newValue ?? $GroupProp.oldValue) -replace '"', '')
            if (!$GroupDisplayName -or !($MonitoredGroups | Where-Object { $GroupDisplayName -like $_ })) { continue }

            $InitiatedBy = if ($Log.initiatedBy.user) { $Log.initiatedBy.user.userPrincipalName } else { $Log.initiatedBy.app.displayName }
            $Action = if ($Log.activityDisplayName -eq 'Add member to group') { 'added to' } else { 'removed from' }

            [PSCustomObject]@{
                Message      = "$($Member.userPrincipalName ?? $Member.displayName) was $Action group '$GroupDisplayName' by $InitiatedBy"
                GroupName    = $GroupDisplayName
                MemberName   = $Member.userPrincipalName ?? $Member.displayName
                Action       = $Log.activityDisplayName
                InitiatedBy  = $InitiatedBy
                ActivityTime = $Log.activityDateTime
                Tenant       = $TenantFilter
            }
        }

        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not check group membership changes for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertGroupMembershipChange.ps1' 49
#Region './Public/Alerts/Get-CIPPAlertHuntressRogueApps.ps1' -1

function Get-CIPPAlertHuntressRogueApps {
    <#
    .SYNOPSIS
        Check for rogue apps in a Tenant
    .DESCRIPTION
        This function checks for rogue apps in the tenant by comparing the service principals in the tenant with a list of known rogue apps provided by Huntress.
    .FUNCTIONALITY
        Entrypoint
    .LINK
        https://huntresslabs.github.io/rogueapps/
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        $RogueApps = Invoke-RestMethod -Uri 'https://huntresslabs.github.io/rogueapps/rogueapps.json'
        $RogueAppFilter = $RogueApps.appId -join "','"
        $ServicePrincipals = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/servicePrincipals?`$filter=appId in ('$RogueAppFilter')" -tenantid $TenantFilter
        # If IgnoreDisabledApps is true, filter out disabled service principals
        if ($InputValue -eq $true) {
            $ServicePrincipals = $ServicePrincipals | Where-Object { $_.accountEnabled -eq $true }
        }

        if (($ServicePrincipals | Measure-Object).Count -gt 0) {
            $AlertData = foreach ($ServicePrincipal in $ServicePrincipals) {
                $RogueApp = $RogueApps | Where-Object { $_.appId -eq $ServicePrincipal.appId }
                [pscustomobject]@{
                    'App Name'       = $RogueApp.appDisplayName
                    'App Id'         = $RogueApp.appId
                    'Description'    = $RogueApp.description
                    'Enabled'        = $ServicePrincipal.accountEnabled
                    'Created'        = $ServicePrincipal.createdDateTime
                    'Tags'           = $RogueApp.tags -join ', '
                    'References'     = $RogueApp.references -join ', '
                    'Huntress Added' = $RogueApp.dateAdded
                }
            }
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        #$ErrorMessage = Get-CippException -Exception $_
        #Write-AlertMessage -tenant $($TenantFilter) -message "Failed to check for rogue apps for $($TenantFilter): $($ErrorMessage.NormalizedError)"
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertHuntressRogueApps.ps1' 50
#Region './Public/Alerts/Get-CIPPAlertInactiveGuestUsers.ps1' -1

function Get-CIPPAlertInactiveGuestUsers {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        [Parameter(Mandatory = $false)]
        [switch]$IncludeNeverSignedIn, # Include users who have never signed in (default is to skip them), future use would allow this to be set in an alert configuration
        $TenantFilter
    )

    try {
        try {
            $inactiveDays = 90
            $excludeDisabled = $false

            $excludeDisabled = [bool]$InputValue.ExcludeDisabled
            if ($null -ne $InputValue.DaysSinceLastLogin -and $InputValue.DaysSinceLastLogin -ne '') {
                $parsedDays = 0
                if ([int]::TryParse($InputValue.DaysSinceLastLogin.ToString(), [ref]$parsedDays) -and $parsedDays -gt 0) {
                    $inactiveDays = $parsedDays
                }
            }



            $Lookup = (Get-Date).AddDays(-$inactiveDays).ToUniversalTime()
            Write-Host "Checking for guest users inactive since $Lookup (excluding disabled: $excludeDisabled)"
            # Build base filter - cannot filter assignedLicenses server-side
            $BaseFilter = if ($excludeDisabled) { 'accountEnabled eq true' } else { '' }

            $Uri = if ($BaseFilter) {
                "https://graph.microsoft.com/beta/users?`$filter=$BaseFilter&`$select=id,UserPrincipalName,signInActivity,mail,userType,accountEnabled,assignedLicenses"
            } else {
                "https://graph.microsoft.com/beta/users?`$select=id,UserPrincipalName,signInActivity,mail,userType,accountEnabled,assignedLicenses"
            }

            $GraphRequest = New-GraphGetRequest -uri $Uri -tenantid $TenantFilter | Where-Object { $_.userType -eq 'Guest' }

            $AlertData = foreach ($user in $GraphRequest) {
                $lastInteractive = $user.signInActivity.lastSignInDateTime
                $lastNonInteractive = $user.signInActivity.lastNonInteractiveSignInDateTime

                # Find most recent sign-in
                $lastSignIn = $null
                if ($lastInteractive -and $lastNonInteractive) {
                    $lastSignIn = if ([DateTime]$lastInteractive -gt [DateTime]$lastNonInteractive) { $lastInteractive } else { $lastNonInteractive }
                } elseif ($lastInteractive) {
                    $lastSignIn = $lastInteractive
                } elseif ($lastNonInteractive) {
                    $lastSignIn = $lastNonInteractive
                }

                # Check if inactive
                $isInactive = (-not $lastSignIn) -or ([DateTime]$lastSignIn -le $Lookup)
                # Skip users who have never signed in by default (unless IncludeNeverSignedIn is specified)
                if (-not $IncludeNeverSignedIn -and -not $lastSignIn) { continue }
                # Only process inactive users
                if ($isInactive) {

                    if (-not $lastSignIn) {
                        $Message = 'Guest user {0} has never signed in.' -f $user.UserPrincipalName
                    } else {
                        $daysSinceSignIn = [Math]::Round(((Get-Date) - [DateTime]$lastSignIn).TotalDays)
                        $Message = 'Guest user {0} has been inactive for {1} days. Last sign-in: {2}' -f $user.UserPrincipalName, $daysSinceSignIn, $lastSignIn
                    }


                    [PSCustomObject]@{
                        UserPrincipalName   = $user.UserPrincipalName
                        Id                  = $user.id
                        lastSignIn          = $lastSignIn
                        DaysSinceLastSignIn = if ($daysSinceSignIn) { $daysSinceSignIn } else { 'N/A' }
                        Message             = $Message
                        Tenant              = $TenantFilter
                    }
                }
            }

            if ($AlertData) {
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        } catch {}
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Failed to check inactive guest users for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertInactiveGuestUsers.ps1' 93
#Region './Public/Alerts/Get-CIPPAlertInactiveLicensedUsers.ps1' -1

function Get-CIPPAlertInactiveLicensedUsers {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        [Parameter(Mandatory = $false)]
        [switch]$IncludeNeverSignedIn, # Include users who have never signed in (default is to skip them), future use would allow this to be set in an alert configuration
        $TenantFilter
    )

    try {
        try {
            $inactiveDays = 90
            $excludeDisabled = $false

            if ($InputValue -is [hashtable] -or $InputValue -is [pscustomobject]) {
                $excludeDisabled = [bool]$InputValue.ExcludeDisabled
                if ($null -ne $InputValue.DaysSinceLastLogin -and $InputValue.DaysSinceLastLogin -ne '') {
                    $parsedDays = 0
                    if ([int]::TryParse($InputValue.DaysSinceLastLogin.ToString(), [ref]$parsedDays) -and $parsedDays -gt 0) {
                        $inactiveDays = $parsedDays
                    }
                }
            } elseif ($InputValue -eq $true) {
                # Backwards compatibility: legacy single-input boolean means exclude disabled users
                $excludeDisabled = $true
            }

            $Lookup = (Get-Date).AddDays(-$inactiveDays).ToUniversalTime()
            Write-Host "Checking for users inactive since $Lookup (excluding disabled: $excludeDisabled)"
            # Build base filter - cannot filter assignedLicenses server-side
            $BaseFilter = if ($excludeDisabled) { 'accountEnabled eq true' } else { '' }

            $Uri = if ($BaseFilter) {
                "https://graph.microsoft.com/beta/users?`$filter=$BaseFilter&`$select=id,UserPrincipalName,signInActivity,mail,userType,accountEnabled,assignedLicenses"
            } else {
                "https://graph.microsoft.com/beta/users?`$select=id,UserPrincipalName,signInActivity,mail,userType,accountEnabled,assignedLicenses"
            }

            $GraphRequest = New-GraphGetRequest -uri $Uri -scope 'https://graph.microsoft.com/.default' -tenantid $TenantFilter |
                Where-Object { $null -ne $_.assignedLicenses -and $_.assignedLicenses.Count -gt 0 }

            $AlertData = foreach ($user in $GraphRequest) {
                $lastInteractive = $user.signInActivity.lastSignInDateTime
                $lastNonInteractive = $user.signInActivity.lastNonInteractiveSignInDateTime

                # Find most recent sign-in
                $lastSignIn = $null
                if ($lastInteractive -and $lastNonInteractive) {
                    $lastSignIn = if ([DateTime]$lastInteractive -gt [DateTime]$lastNonInteractive) { $lastInteractive } else { $lastNonInteractive }
                } elseif ($lastInteractive) {
                    $lastSignIn = $lastInteractive
                } elseif ($lastNonInteractive) {
                    $lastSignIn = $lastNonInteractive
                }

                # Check if inactive
                $isInactive = (-not $lastSignIn) -or ([DateTime]$lastSignIn -le $Lookup)
                # Skip users who have never signed in by default (unless IncludeNeverSignedIn is specified)
                if (-not $IncludeNeverSignedIn -and -not $lastSignIn) { continue }
                # Only process inactive users
                if ($isInactive) {
                    if (-not $lastSignIn) {
                        $Message = 'User {0} has never signed in but still has a license assigned.' -f $user.UserPrincipalName
                    } else {
                        $daysSinceSignIn = [Math]::Round(((Get-Date) - [DateTime]$lastSignIn).TotalDays)
                        $Message = 'User {0} has been inactive for {1} days but still has a license assigned. Last sign-in: {2}' -f $user.UserPrincipalName, $daysSinceSignIn, $lastSignIn
                    }

                    [PSCustomObject]@{
                        UserPrincipalName = $user.UserPrincipalName
                        Id                = $user.id
                        lastSignIn        = $lastSignIn
                        Message           = $Message
                        Tenant            = $TenantFilter
                    }
                }
            }

            if ($AlertData) {
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        } catch {}
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Failed to check inactive users with licenses for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertInactiveLicensedUsers.ps1' 94
#Region './Public/Alerts/Get-CIPPAlertInactiveUsers.ps1' -1

function Get-CIPPAlertInactiveUsers {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        [Parameter(Mandatory = $false)]
        [switch]$IncludeNeverSignedIn, # Include users who have never signed in (default is to skip them), future use would allow this to be set in an alert configuration
        $TenantFilter
    )

    try {
        try {
            $inactiveDays = 90
            $excludeDisabled = $false

            $excludeDisabled = [bool]$InputValue.ExcludeDisabled
            if ($null -ne $InputValue.DaysSinceLastLogin -and $InputValue.DaysSinceLastLogin -ne '') {
                $parsedDays = 0
                if ([int]::TryParse($InputValue.DaysSinceLastLogin.ToString(), [ref]$parsedDays) -and $parsedDays -gt 0) {
                    $inactiveDays = $parsedDays
                }
            }

            $Lookup = (Get-Date).AddDays(-$inactiveDays).ToUniversalTime()
            Write-Host "Checking for users inactive since $Lookup (excluding disabled: $excludeDisabled)"
            # Build base filter - cannot filter accountEnabled server-side
            $BaseFilter = if ($excludeDisabled) { 'accountEnabled eq true' } else { '' }

            $Uri = if ($BaseFilter) {
                "https://graph.microsoft.com/beta/users?`$filter=$BaseFilter&`$select=id,UserPrincipalName,signInActivity,mail,userType,accountEnabled,assignedLicenses"
            } else {
                "https://graph.microsoft.com/beta/users?`$select=id,UserPrincipalName,signInActivity,mail,userType,accountEnabled,assignedLicenses"
            }

            $GraphRequest = New-GraphGetRequest -uri $Uri -tenantid $TenantFilter | Where-Object { $_.userType -eq 'Member' }

            $AlertData = foreach ($user in $GraphRequest) {
                $lastInteractive = $user.signInActivity.lastSignInDateTime
                $lastNonInteractive = $user.signInActivity.lastNonInteractiveSignInDateTime

                # Find most recent sign-in
                $lastSignIn = $null
                if ($lastInteractive -and $lastNonInteractive) {
                    $lastSignIn = if ([DateTime]$lastInteractive -gt [DateTime]$lastNonInteractive) { $lastInteractive } else { $lastNonInteractive }
                } elseif ($lastInteractive) {
                    $lastSignIn = $lastInteractive
                } elseif ($lastNonInteractive) {
                    $lastSignIn = $lastNonInteractive
                }

                # Check if inactive
                $isInactive = (-not $lastSignIn) -or ([DateTime]$lastSignIn -le $Lookup)
                # Skip users who have never signed in by default (unless IncludeNeverSignedIn is specified)
                if (-not $IncludeNeverSignedIn -and -not $lastSignIn) { continue }
                # Only process inactive users
                if ($isInactive) {
                    if (-not $lastSignIn) {
                        $Message = 'User {0} has never signed in.' -f $user.UserPrincipalName
                    } else {
                        $daysSinceSignIn = [Math]::Round(((Get-Date) - [DateTime]$lastSignIn).TotalDays)
                        $Message = 'User {0} has been inactive for {1} days. Last sign-in: {2}' -f $user.UserPrincipalName, $daysSinceSignIn, $lastSignIn
                    }

                    [PSCustomObject]@{
                        UserPrincipalName   = $user.UserPrincipalName
                        Id                  = $user.id
                        lastSignIn          = $lastSignIn
                        DaysSinceLastSignIn = if ($daysSinceSignIn) { $daysSinceSignIn } else { 'N/A' }
                        Message             = $Message
                        Tenant              = $TenantFilter
                    }
                }
            }

            if ($AlertData) {
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        } catch {}
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Failed to check inactive users with licenses for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertInactiveUsers.ps1' 89
#Region './Public/Alerts/Get-CIPPAlertIntunePolicyConflicts.ps1' -1

function Get-CIPPAlertIntunePolicyConflicts {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    # Normalize JSON/string input to object when possible
    if ($InputValue -is [string]) {
        try {
            if ($InputValue.Trim().StartsWith('{')) {
                $InputValue = $InputValue | ConvertFrom-Json -ErrorAction Stop
            }
        } catch {
            # Leave as-is if parsing fails
        }
    }

    $Config = [ordered]@{
        AlertEachIssue      = $false   # align with AlertEachAdmin convention (false = aggregated)
        IncludePolicies     = $true
        IncludeApplications = $true
        AlertConflicts      = $true
        AlertErrors         = $true
    }

    if ($InputValue -is [hashtable] -or $InputValue -is [pscustomobject]) {
        # Primary key follows AlertEach* convention; legacy Aggregate supported (true == aggregated)
        if ($null -ne $InputValue.AlertEachIssue) { $Config.AlertEachIssue = [bool]$InputValue.AlertEachIssue }
        if ($null -ne $InputValue.Aggregate) { $Config.AlertEachIssue = -not [bool]$InputValue.Aggregate }

        $Config.IncludePolicies = if ($null -ne $InputValue.IncludePolicies) { [bool]$InputValue.IncludePolicies } else { $Config.IncludePolicies }
        $Config.IncludeApplications = if ($null -ne $InputValue.IncludeApplications) { [bool]$InputValue.IncludeApplications } else { $Config.IncludeApplications }
        $Config.AlertConflicts = if ($null -ne $InputValue.AlertConflicts) { [bool]$InputValue.AlertConflicts } else { $Config.AlertConflicts }
        $Config.AlertErrors = if ($null -ne $InputValue.AlertErrors) { [bool]$InputValue.AlertErrors } else { $Config.AlertErrors }
    } elseif ($InputValue -is [bool]) {
        # Back-compat for boolean toggle used as Aggregate previously
        $Config.AlertEachIssue = -not [bool]$InputValue
    }

    if (-not $Config.IncludePolicies -and -not $Config.IncludeApplications) {
        return
    }

    $AlertableStatuses = @()
    if ($Config.AlertErrors) { $AlertableStatuses += 'error', 'failed' }
    if ($Config.AlertConflicts) { $AlertableStatuses += 'conflict' }

    if (-not $AlertableStatuses) {
        return
    }

    $HasLicense = Test-CIPPStandardLicense -StandardName 'IntunePolicyStatus' -TenantFilter $TenantFilter -RequiredCapabilities @(
        'INTUNE_A',
        'MDM_Services',
        'EMS',
        'SCCM',
        'MICROSOFTINTUNEPLAN1'
    )

    if (-not $HasLicense) {
        return
    }

    $Issues = @()

    if ($Config.IncludePolicies) {
        try {
            $ManagedDevices = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/deviceManagement/managedDevices?`$select=id,deviceName,userPrincipalName&`$expand=deviceConfigurationStates(`$select=displayName,state,settingStates)" -tenantid $TenantFilter

            foreach ($Device in $ManagedDevices) {
                $PolicyStates = $Device.deviceConfigurationStates | Where-Object { $_.state -and ($AlertableStatuses -contains $_.state) }
                foreach ($State in $PolicyStates) {
                    $Issues += [PSCustomObject]@{
                        Message           = "Policy '$($State.displayName)' is $($State.state) on device '$($Device.deviceName)' for $($Device.userPrincipalName)."
                        Tenant            = $TenantFilter
                        Type              = 'Policy'
                        PolicyName        = $State.displayName
                        IssueStatus       = $State.state
                        DeviceName        = $Device.deviceName
                        UserPrincipalName = $Device.userPrincipalName
                        DeviceId          = $Device.id
                    }
                }
            }
        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Failed to query Intune policy states: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        }
    }

    if ($Config.IncludeApplications) {
        try {
            $Applications = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps?`$select=id,displayName&`$expand=deviceStatuses(`$select=installState,deviceName,userPrincipalName,deviceId)" -tenantid $TenantFilter

            foreach ($App in $Applications) {
                $BadStatuses = $App.deviceStatuses | Where-Object {
                    $_.installState -and ($AlertableStatuses -contains $_.installState.ToLowerInvariant())
                }

                foreach ($Status in $BadStatuses) {
                    $Issues += [PSCustomObject]@{
                        Message           = "App '$($App.displayName)' install is $($Status.installState) on device '$($Status.deviceName)' for $($Status.userPrincipalName)."
                        Tenant            = $TenantFilter
                        Type              = 'Application'
                        AppName           = $App.displayName
                        IssueStatus       = $Status.installState
                        DeviceName        = $Status.deviceName
                        UserPrincipalName = $Status.userPrincipalName
                        DeviceId          = $Status.deviceId
                    }
                }
            }
        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Failed to query Intune application states: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        }
    }

    if (-not $Issues) {
        return
    }

    if (-not $Config.AlertEachIssue) {
        $PolicyCount = ($Issues | Where-Object { $_.Type -eq 'Policy' }).Count
        $AppCount = ($Issues | Where-Object { $_.Type -eq 'Application' }).Count

        $AlertData = @([PSCustomObject]@{
                Message        = "Found $PolicyCount policy issues and $AppCount application issues in Intune."
                Tenant         = $TenantFilter
                PolicyIssues   = $PolicyCount
                AppIssues      = $AppCount
                Issues         = $Issues
            })
    } else {
        $AlertData = $Issues
    }

    if ($AlertData) {
        Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertIntunePolicyConflicts.ps1' 149
#Region './Public/Alerts/Get-CIPPAlertLicenseAssignmentErrors.ps1' -1

function Get-CIPPAlertLicenseAssignmentErrors {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        $TenantFilter,
        [Alias('input')]
        $InputValue
    )

    # Define error code translations for human-readable messages
    $ErrorTranslations = @(
        @{
            ErrorCode   = 'CountViolation'
            Description = 'Not enough licenses available - the organization has exceeded the number of available licenses for this SKU'
        },
        @{
            ErrorCode   = 'MutuallyExclusiveViolation'
            Description = 'Conflicting licenses assigned - this license cannot be assigned alongside another license the user already has'
        },
        @{
            ErrorCode   = 'ProhibitedInUsageLocationViolation'
            Description = "License not available in user's location - this license cannot be assigned to users in the user's current usage location"
        },
        @{
            ErrorCode   = 'UniquenessViolation'
            Description = 'Duplicate license assignment - this license can only be assigned once per user'
        },
        @{
            ErrorCode   = 'Unknown'
            Description = 'Unknown license assignment error - an unspecified error occurred during license assignment'
        }
    )

    try {
        # Get all users with license assignment states from Graph API
        $Users = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/users?`$select=id,userPrincipalName,displayName,licenseAssignmentStates&`$top=999" -tenantid $TenantFilter

        # Filter users who have license assignment violations
        $UsersWithViolations = $Users | Where-Object {
            $_.licenseAssignmentStates -and
            ($_.licenseAssignmentStates | Where-Object {
                $_.error -and (
                    $_.error -like '*CountViolation*' -or
                    $_.error -like '*MutuallyExclusiveViolation*' -or
                    $_.error -like '*ProhibitedInUsageLocationViolation*' -or
                    $_.error -like '*UniquenessViolation*' -or
                    $_.error -like '*Unknown*'
                )
            })
        }

        # Build alert messages for users with violations
        $LicenseAssignmentErrors = foreach ($User in $UsersWithViolations) {
            $ViolationErrors = $User.licenseAssignmentStates | Where-Object {
                $_.error -and (
                    $_.error -like '*CountViolation*' -or
                    $_.error -like '*MutuallyExclusiveViolation*' -or
                    $_.error -like '*ProhibitedInUsageLocationViolation*' -or
                    $_.error -like '*UniquenessViolation*' -or
                    $_.error -like '*Unknown*'
                )
            }

            foreach ($Violation in $ViolationErrors) {
                # Find matching error translation
                $ErrorTranslation = $ErrorTranslations | Where-Object { $Violation.error -like "*$($_.ErrorCode)*" } | Select-Object -First 1
                $HumanReadableError = if ($ErrorTranslation) {
                    $ErrorTranslation.Description
                } else {
                    "Unknown license assignment error: $($Violation.error)"
                }

                $PrettyName = Convert-SKUname -SkuID $Violation.skuId

                $Message = "$($User.userPrincipalName): $HumanReadableError (License: $PrettyName)"
                [PSCustomObject]@{
                    Message           = $Message
                    UserPrincipalName = $User.userPrincipalName
                    Error             = $HumanReadableError
                    LicenseName       = $PrettyName
                    SkuId             = $Violation.skuId
                    DisplayName       = $User.displayName
                    Id                = $User.id
                    Tenant            = $TenantFilter
                }
            }
        }

        # If errors are found, write alert
        if ($LicenseAssignmentErrors) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $LicenseAssignmentErrors
        }

    } catch {
        Write-LogMessage -message "Failed to check license assignment errors: $($_.exception.message)" -API 'License Assignment Alerts' -tenant $TenantFilter -sev Error
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertLicenseAssignmentErrors.ps1' 102
#Region './Public/Alerts/Get-CIPPAlertLicensedUsersWithRoles.ps1' -1

function Get-CIPPAlertLicensedUsersWithRoles {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    # Get all users with assigned licenses
    $LicensedUsers = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/users?`$top=999&`$select=userPrincipalName,assignedLicenses,displayName" -tenantid $TenantFilter | Where-Object { $_.assignedLicenses -and $_.assignedLicenses.Count -gt 0 }
    if (-not $LicensedUsers -or $LicensedUsers.Count -eq 0) {
        Write-Information "No licensed users found for tenant $TenantFilter"
        return $true
    }
    # Get all directory roles with their members
    $DirectoryRoles = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/directoryRoles?`$expand=members" -tenantid $TenantFilter
    if (-not $DirectoryRoles -or $DirectoryRoles.Count -eq 0) {
        Write-Information "No directory roles found for tenant $TenantFilter"
        return
    }
    $UsersToAlertOn = $LicensedUsers | Where-Object { $_.userPrincipalName -in $DirectoryRoles.members.userPrincipalName }


    if ($UsersToAlertOn.Count -gt 0) {
        Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $UsersToAlertOn
    } else {
        Write-Information "No licensed users with roles found for tenant $TenantFilter"
    }


}
#EndRegion './Public/Alerts/Get-CIPPAlertLicensedUsersWithRoles.ps1' 37
#Region './Public/Alerts/Get-CIPPAlertLongLivedAppCredentials.ps1' -1

function Get-CIPPAlertLongLivedAppCredentials {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    Param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    $MaxMonths = $InputValue

    try {
        $Apps = @(New-GraphGetRequest -uri "https://graph.microsoft.com/beta/applications?`$select=id,appId,displayName,passwordCredentials,keyCredentials&`$top=999" -tenantid $TenantFilter -AsApp $true)

        $NowUtc = [datetime]::UtcNow
        $DatePartition = (Get-Date -UFormat '%Y%m%d').ToString()
        $CredTypeMap = @(
            @{ Property = 'passwordCredentials'; TypeLabel = 'Secret' }
            @{ Property = 'keyCredentials'; TypeLabel = 'Certificate' }
        )

        foreach ($App in @($Apps)) {
            foreach ($ct in $CredTypeMap) {
                $credList = $App.($ct.Property)
                if (-not $credList) { continue }
                foreach ($Cred in @($credList)) {
                    $startUtc = ([datetime]$Cred.startDateTime).ToUniversalTime()
                    $endUtc = ([datetime]$Cred.endDateTime).ToUniversalTime()
                    if ($endUtc -le $startUtc -or $endUtc -le $NowUtc) { continue }
                    $months = (New-TimeSpan -Start $startUtc -End $endUtc).TotalDays / 30.4375
                    if ($months -gt $MaxMonths) {
                        $keyId = if ($Cred.keyId) { "$($Cred.keyId)" } else { 'unknown' }
                        $tracePartition = "$DatePartition-$($App.id)-$keyId" -replace '[/\\#?]', '_'
                        $oneFinding = [PSCustomObject]@{
                            AppDisplayName   = $App.displayName
                            AppId            = $App.appId
                            CredentialType   = $ct.TypeLabel
                            CredentialName   = $Cred.displayName
                            KeyId            = $Cred.keyId
                            StartDateTime    = $Cred.startDateTime
                            EndDateTime      = $Cred.endDateTime
                            ValidityMonths   = [math]::Round([double]$months, 2)
                            MaxMonthsAllowed = $MaxMonths
                        }
                        Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $oneFinding -PartitionKey $tracePartition
                    }
                }
            }
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Excessive secret validity alert failed: $($ErrorMessage.NormalizedError)" -sev 'Error' -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertLongLivedAppCredentials.ps1' 59
#Region './Public/Alerts/Get-CIPPAlertLowDomainScore.ps1' -1

function Get-CIPPAlertLowDomainScore {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        $TenantFilter,
        [Alias('input')]
        [ValidateRange(0, 100)]
        [int]$InputValue = 70
    )

    $DomainData = Get-CIPPDomainAnalyser -TenantFilter $TenantFilter
    $LowScoreDomains = $DomainData | Where-Object { $_.ScorePercentage -lt $InputValue -and $_.ScorePercentage -ne '' -and $_.Domain -notlike '*.onmicrosoft.com' -and $_.Domain -notlike '*.mail.onmicrosoft.com' } | ForEach-Object {
        [PSCustomObject]@{
            Message          = "$($_.Domain): Domain security score is $($_.ScorePercentage)%, which is below the threshold of $InputValue%. Issues: $($_.ScoreExplanation)"
            Domain           = $_.Domain
            ScorePercentage  = $_.ScorePercentage
            ScoreExplanation = $_.ScoreExplanation
            Tenant           = $TenantFilter
        }
    }

    if ($LowScoreDomains) {
        Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $LowScoreDomains
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertLowDomainScore.ps1' 30
#Region './Public/Alerts/Get-CIPPAlertLowTenantAlignment.ps1' -1

function Get-CIPPAlertLowTenantAlignment {
    <#
    .SYNOPSIS
        Alert for low tenant alignment percentage
    .DESCRIPTION
        This alert checks tenant alignment scores against standards templates and alerts when the alignment percentage falls below the specified threshold.
    .PARAMETER TenantFilter
        The tenant to check alignment for
    .PARAMETER InputValue
        The minimum alignment percentage threshold (0-100). Default is 80.
    .FUNCTIONALITY
        Entrypoint
    .EXAMPLE
        Get-CIPPAlertLowTenantAlignment -TenantFilter "contoso.onmicrosoft.com" -InputValue 75
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        $TenantFilter,
        [Alias('input')]
        [ValidateRange(0, 100)]
        [int]$InputValue = 99
    )

    try {
        # Get tenant alignment data using the new function
        $AlignmentData = Get-CIPPTenantAlignment -TenantFilter $TenantFilter

        if (-not $AlignmentData) {
            Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "No alignment data found for tenant $TenantFilter. This may indicate no standards templates are configured or applied to this tenant." -sev Warning
            return
        }

        $LowAlignmentAlerts = $AlignmentData | Where-Object { $_.AlignmentScore -lt $InputValue } | ForEach-Object {
            [PSCustomObject]@{
                TenantFilter             = $_.TenantFilter
                StandardName             = $_.StandardName
                StandardId               = $_.StandardId
                AlignmentScore           = $_.AlignmentScore
                LicenseMissingPercentage = $_.LicenseMissingPercentage
                LatestDataCollection     = $_.LatestDataCollection
            }
        }

        if ($LowAlignmentAlerts.Count -gt 0) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $LowAlignmentAlerts
        }

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not get tenant alignment data for $TenantFilter`: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertLowTenantAlignment.ps1' 54
#Region './Public/Alerts/Get-CIPPAlertMFAAdmins.ps1' -1

function Get-CIPPAlertMFAAdmins {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        $CAPolicies = (New-GraphGetRequest -Uri 'https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies?$top=999' -tenantid $TenantFilter -ErrorAction Stop)
        foreach ($Policy in $CAPolicies) {
            if ($policy.grantControls.customAuthenticationFactors -eq 'RequireDuoMfa') {
                $DuoActive = $true
            }
        }
        if (!$DuoActive) {
            $MFAReport = try { Get-CIPPMFAStateReport -TenantFilter $TenantFilter | Where-Object { $_.DisplayName -ne 'On-Premises Directory Synchronization Service Account' } } catch { $null }
            $IncludeDisabled = [System.Convert]::ToBoolean($InputValue)

            # Check 1: Admins with no MFA registered — prefer cache, fall back to live Graph
            $Users = if ($MFAReport) {
                $MFAReport | Where-Object { $_.IsAdmin -eq $true -and $_.MFARegistration -eq $false -and $_.UserType -ne 'Guest' -and ($IncludeDisabled -or $_.AccountEnabled -eq $true) }
            } else {
                New-GraphGETRequest -uri "https://graph.microsoft.com/beta/reports/authenticationMethods/userRegistrationDetails?`$top=999&filter=IsAdmin eq true and isMfaRegistered eq false and userType eq 'member'&`$select=id,userDisplayName,userPrincipalName,lastUpdatedDateTime,isMfaRegistered,IsAdmin" -tenantid $($TenantFilter) -AsApp $true |
                    Where-Object { $_.userDisplayName -ne 'On-Premises Directory Synchronization Service Account' } |
                    Select-Object @{n = 'ID'; e = { $_.id } }, @{n = 'UPN'; e = { $_.userPrincipalName } }, @{n = 'DisplayName'; e = { $_.userDisplayName } }
            }

            # Check 2: Admins with MFA registered but no enforcement.
            # I hate how this ended up looking, but I couldn't think of a better way to do it ¯\_(ツ)_/¯
            $UnenforcedAdmins = $MFAReport | Where-Object {
                $_.IsAdmin -eq $true -and
                $_.MFARegistration -eq $true -and
                $_.UserType -ne 'Guest' -and
                ($IncludeDisabled -or $_.AccountEnabled -eq $true) -and
                $_.PerUser -notin @('Enforced', 'Enabled') -and
                $null -ne $_.CoveredBySD -and
                $_.CoveredBySD -ne $true -and
                $_.CoveredByCA -notlike 'Enforced*'
            }

            # Filter out JIT admins
            if ($Users -or $UnenforcedAdmins) {
                $Schema = Get-CIPPSchemaExtensions | Where-Object { $_.id -match '_cippUser' } | Select-Object -First 1
                $JITAdmins = New-GraphGETRequest -uri "https://graph.microsoft.com/beta/users?`$select=id,$($Schema.id)&`$filter=$($Schema.id)/jitAdminEnabled eq true" -tenantid $TenantFilter -ComplexFilter
                $JITAdminIds = $JITAdmins.id
                $Users = $Users | Where-Object { $_.ID -notin $JITAdminIds }
                $UnenforcedAdmins = $UnenforcedAdmins | Where-Object { $_.ID -notin $JITAdminIds }
            }


            $AlertData = [System.Collections.Generic.List[PSCustomObject]]::new()

            foreach ($user in $Users) {
                $AlertData.Add([PSCustomObject]@{
                        Message           = "Admin user $($user.DisplayName) ($($user.UPN)) does not have MFA registered."
                        UserPrincipalName = $user.UPN
                        DisplayName       = $user.DisplayName
                        Id                = $user.ID
                        Tenant            = $TenantFilter
                    })
            }

            foreach ($user in $UnenforcedAdmins) {
                $AlertData.Add([PSCustomObject]@{
                        Message           = "Admin user $($user.DisplayName) ($($user.UPN)) has MFA registered but no enforcement method (Per-User MFA, Security Defaults, or Conditional Access) is active."
                        UserPrincipalName = $user.UPN
                        DisplayName       = $user.DisplayName
                        Id                = $user.ID
                        Tenant            = $TenantFilter
                    })
            }

            if ($AlertData.Count -gt 0) {
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        } else {
            Write-LogMessage -message 'Potentially using Duo for MFA, could not check MFA status for Admins with 100% accuracy' -API 'MFA Alerts - Informational' -tenant $TenantFilter -sev Info
        }
    } catch {
        Write-LogMessage -message "Failed to check MFA status for Admins: $($_.exception.message)" -API 'MFA Alerts - Informational' -tenant $TenantFilter -sev Error
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertMFAAdmins.ps1' 88
#Region './Public/Alerts/Get-CIPPAlertMFAAlertUsers.ps1' -1

function Get-CIPPAlertMFAAlertUsers {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        Write-Host "Checking MFA status for users in tenant '$TenantFilter'..."
        $MFAReport = try { Get-CIPPMFAStateReport -TenantFilter $TenantFilter | Where-Object { $_.DisplayName -ne 'On-Premises Directory Synchronization Service Account' } } catch { Write-Host "Could not get cached report for tenant '$TenantFilter' $_" }

        $Users = if ($MFAReport) {
            $MFAReport | Where-Object { $_.IsAdmin -ne $true -and $_.MFARegistration -eq $false -and $_.UserType -ne 'Guest' -and $_.UPN -notmatch '^package_[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}@' }
        } else {
            New-GraphGETRequest -uri "https://graph.microsoft.com/beta/reports/authenticationMethods/userRegistrationDetails?`$top=999&filter=IsAdmin eq false and isMfaRegistered eq false and userType eq 'member'&`$select=userDisplayName,userPrincipalName,lastUpdatedDateTime,isMfaRegistered,IsAdmin" -tenantid $($TenantFilter) -AsApp $true |
            Where-Object { $_.userDisplayName -ne 'On-Premises Directory Synchronization Service Account' -and $_.userPrincipalName -notmatch '^package_[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}@' } |
            Select-Object @{n = 'UPN'; e = { $_.userPrincipalName } }, @{n = 'DisplayName'; e = { $_.userDisplayName } }
        }
        Write-Host "Completed MFA status check for tenant '$TenantFilter'. Found $($Users.Count) users without MFA registered."

        if ($Users) {
            $AlertData = foreach ($user in $Users) {
                [PSCustomObject]@{
                    UserPrincipalName = $user.UPN
                    DisplayName       = $user.DisplayName
                }
            }
            Write-Host 'Writing alert trace'
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        Write-LogMessage -message "Failed to check MFA status for all users: $($_.exception.message)" -API 'MFA Alerts - Informational' -tenant $TenantFilter -sev Error
    }

}
#EndRegion './Public/Alerts/Get-CIPPAlertMFAAlertUsers.ps1' 42
#Region './Public/Alerts/Get-CIPPAlertMXRecordChanged.ps1' -1

function Get-CIPPAlertMXRecordChanged {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        $TenantFilter,
        [Alias('input')]
        $InputValue
    )

    try {
        $DomainData = Get-CIPPDomainAnalyser -TenantFilter $TenantFilter
        $CacheTable = Get-CippTable -tablename 'CacheMxRecords'
        $PreviousResults = Get-CIPPAzDataTableEntity @CacheTable -Filter "PartitionKey eq '$TenantFilter'"

        if (!$DomainData) {
            return
        }

        $ChangedDomains = foreach ($Domain in $DomainData) {
            try {
                $PreviousDomain = $PreviousResults | Where-Object { $_.Domain -eq $Domain.Domain }
                $PreviousRecords = if ($PreviousDomain.ActualMXRecords) { @($PreviousDomain.ActualMXRecords -split ',' | Sort-Object) } else { @() }
                $CurrentRecords = if ($Domain.ActualMXRecords.Hostname) { @($Domain.ActualMXRecords.Hostname | Sort-Object) } else { @() }

                # Only compare if both have records
                $Differences = $null
                if ($PreviousRecords.Count -gt 0 -and $CurrentRecords.Count -gt 0) {
                    $Differences = Compare-Object -ReferenceObject $PreviousRecords -DifferenceObject $CurrentRecords
                }

                if ($PreviousRecords.Count -eq 0 -and $CurrentRecords.Count -gt 0) {
                    Write-Information "New MX records detected for domain $($Domain.Domain): $($CurrentRecords -join ', ')"
                    $Differences = 'NewRecords'
                } elseif ($PreviousRecords.Count -gt 0 -and $CurrentRecords.Count -eq 0) {
                    Write-Information "All MX records removed for domain $($Domain.Domain). Previous records were: $($PreviousRecords -join ', ')"
                    $Differences = 'RemovedRecords'
                }

                if ($Differences) {
                    [PSCustomObject]@{
                        Message         = "$($Domain.Domain): MX records changed from [$($PreviousRecords -join ', ')] to [$($CurrentRecords -join ', ')]"
                        Domain          = $Domain.Domain
                        PreviousRecords = $PreviousRecords -join ', '
                        CurrentRecords  = $CurrentRecords -join ', '
                        Tenant          = $TenantFilter
                    }
                }
            } catch {
                Write-Information "Error checking domain $($Domain.Domain): $($_.Exception.Message)"
            }
        }
        # Update cache with current data
        foreach ($Domain in $DomainData) {
            $CurrentRecords = @($Domain.ActualMXRecords.Hostname | Sort-Object)
            $CacheEntity = @{
                PartitionKey    = [string]$TenantFilter
                RowKey          = [string]$Domain.Domain
                Domain          = [string]$Domain.Domain
                ActualMXRecords = [string]($CurrentRecords -join ',')
                LastRefresh     = [string]$Domain.LastRefresh
                MailProvider    = [string]$Domain.MailProvider
            }
            Add-CIPPAzDataTableEntity @CacheTable -Entity $CacheEntity -Force
        }

        if ($ChangedDomains) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $ChangedDomains
        }
    } catch {
        Write-LogMessage -message "Failed to check MX record changes: $($_.Exception.Message)" -API 'MX Record Alert' -tenant $TenantFilter -sev Error
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertMXRecordChanged.ps1' 77
#Region './Public/Alerts/Get-CIPPAlertNewAppApproval.ps1' -1


function Get-CIPPAlertNewAppApproval {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter,
        $Headers
    )

    try {
        $Approvals = New-GraphGetRequest -Uri "https://graph.microsoft.com/beta/identityGovernance/appConsent/appConsentRequests?`$top=100&`$filter=userConsentRequests/any (u:u/status eq 'InProgress')" -tenantid $TenantFilter

        if ($Approvals.count -gt 0) {
            $TenantGUID = (Get-Tenants -TenantFilter $TenantFilter -SkipDomains).customerId
            $AlertData = [System.Collections.Generic.List[PSCustomObject]]::new()

            foreach ($App in $Approvals) {
                $userConsentRequests = New-GraphGetRequest -Uri "https://graph.microsoft.com/v1.0/identityGovernance/appConsent/appConsentRequests/$($App.id)/userConsentRequests" -tenantid $TenantFilter

                $userConsentRequests | ForEach-Object {
                    $consentUrl = if ($App.consentType -eq 'Static') {
                        # if something is going wrong here you've probably stumbled on a fourth variation - rvdwegen
                        "https://login.microsoftonline.com/$($TenantFilter)/adminConsent?client_id=$($App.appId)&bf_id=$($App.id)&redirect_uri=https://entra.microsoft.com/TokenAuthorize"
                    } elseif ($App.pendingScopes.displayName) {
                        "https://login.microsoftonline.com/$($TenantFilter)/v2.0/adminConsent?client_id=$($App.appId)&scope=$($App.pendingScopes.displayName -Join(' '))&bf_id=$($App.id)&redirect_uri=https://entra.microsoft.com/TokenAuthorize"
                    } else {
                        "https://login.microsoftonline.com/$($TenantFilter)/adminConsent?client_id=$($App.appId)&bf_id=$($App.id)&redirect_uri=https://entra.microsoft.com/TokenAuthorize"
                    }

                    $Message = [PSCustomObject]@{
                        RequestId   = $_.id
                        AppName     = $App.appDisplayName
                        RequestUser = $_.createdBy.user.userPrincipalName
                        Reason      = $_.reason
                        RequestDate = $_.createdDateTime
                        Status      = $_.status # Will always be InProgress as we filter to only get these but this will reduce confusion when an alert is generated
                        AppId       = $App.appId
                        Scopes      = ($App.pendingScopes.displayName -join ', ')
                        ConsentURL  = $consentUrl
                        Tenant      = $TenantFilter
                        TenantId    = $TenantGUID
                    }
                    $AlertData.Add($Message)
                }
            }

            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertNewAppApproval.ps1' 58
#Region './Public/Alerts/Get-CIPPAlertNewMFADevice.ps1' -1

function Get-CIPPAlertNewMFADevice {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        $OneHourAgo = (Get-Date).AddHours(-1).ToString('yyyy-MM-ddTHH:mm:ssZ')

        $AuditLogs = New-GraphGetRequest -uri "https://graph.microsoft.com/v1.0/auditLogs/directoryAudits?`$filter=activityDateTime ge $OneHourAgo and (activityDisplayName eq 'User registered security info' or activityDisplayName eq 'User deleted security info')" -tenantid $TenantFilter
        $AlertData = foreach ($Log in $AuditLogs) {
            if ($Log.activityDisplayName -eq 'User registered security info') {
                $User = $Log.targetResources[0].userPrincipalName
                if (-not $User) { $User = $Log.initiatedBy.user.userPrincipalName }

                $IPAddress = $Log.initiatedBy.user.ipAddress
                $LocationData = $null
                if (-not [string]::IsNullOrEmpty($IPAddress) -and $IPAddress -notmatch '[X]+') {
                    try {
                        $LocationData = Get-CIPPGeoIPLocation -IP $IPAddress
                    } catch {
                        Write-Information "Could not enrich MFA audit IP ${$IPAddress}: $($_.Exception.Message)"
                    }
                }

                [PSCustomObject]@{
                    Message           = "New MFA method registered: $User"
                    User              = $User
                    DisplayName       = $Log.targetResources[0].displayName
                    Activity          = $Log.activityDisplayName
                    ActivityTime      = $Log.activityDateTime
                    Tenant            = $TenantFilter
                    IpAddress         = $IPAddress
                    CountryOrRegion   = if ($LocationData) { $LocationData.countryCode } else { $null }
                    City              = if ($LocationData) { $LocationData.city } else { $null }
                    Proxy             = if ($LocationData) { $LocationData.proxy } else { $null }
                    Hosting           = if ($LocationData) { $LocationData.hosting } else { $null }
                    ASN               = if ($LocationData) { $LocationData.asname } else { $null }
                    GeoLocationInfo   = if ($LocationData) { ($LocationData | ConvertTo-Json -Depth 10 -Compress) } else { $null }
                }
            }
        }

        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not check for new MFA devices for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertNewMFADevice.ps1' 60
#Region './Public/Alerts/Get-CIPPAlertNewRiskyUsers.ps1' -1

function Get-CIPPAlertNewRiskyUsers {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $TenantFilter
    )
    $Deltatable = Get-CIPPTable -Table DeltaCompare
    try {
        # Check if tenant has P2 capabilities
        $Capabilities = Get-CIPPTenantCapabilities -TenantFilter $TenantFilter
        if (-not ($Capabilities.AAD_PREMIUM_P2 -eq $true)) {
            Write-LogMessage -API 'Alerts' -tenant $($TenantFilter) -message 'Tenant does not have Azure AD Premium P2 licensing required for risky users detection' -sev Warning
            return
        }

        $Filter = "PartitionKey eq 'RiskyUsersDelta' and RowKey eq '{0}'" -f $TenantFilter
        $RiskyUsersDelta = (Get-CIPPAzDataTableEntity @Deltatable -Filter $Filter).delta | ConvertFrom-Json -ErrorAction SilentlyContinue

        # Get current risky users with more detailed information
        $NewDelta = (New-GraphGetRequest -uri 'https://graph.microsoft.com/v1.0/identityProtection/riskyUsers' -tenantid $TenantFilter) | Select-Object userPrincipalName, riskLevel, riskState, riskDetail, riskLastUpdatedDateTime, isProcessing, history

        $NewDeltatoSave = $NewDelta | ConvertTo-Json -Depth 10 -Compress -ErrorAction SilentlyContinue | Out-String
        $DeltaEntity = @{
            PartitionKey = 'RiskyUsersDelta'
            RowKey       = [string]$TenantFilter
            delta        = "$NewDeltatoSave"
        }
        Add-CIPPAzDataTableEntity @DeltaTable -Entity $DeltaEntity -Force

        if ($RiskyUsersDelta) {
            $AlertData = $NewDelta | Where-Object { $_.userPrincipalName -notin $RiskyUsersDelta.userPrincipalName } | ForEach-Object {
                $RiskHistory = if ($_.history) {
                    $latestHistory = $_.history | Sort-Object -Property riskLastUpdatedDateTime -Descending | Select-Object -First 1
                    "Previous Risk Level: $($latestHistory.riskLevel), Last Updated: $($latestHistory.riskLastUpdatedDateTime)"
                } else {
                    'No previous risk history'
                }

                # Map risk level to severity
                $Severity = switch ($_.riskLevel) {
                    'high' { 'Critical' }
                    'medium' { 'Warning' }
                    'low' { 'Info' }
                    default { 'Info' }
                }

                [PSCustomObject]@{
                    Message = "New risky user detected: $($_.userPrincipalName)"
                    Details = @{
                        RiskLevel    = $_.riskLevel
                        RiskState    = $_.riskState
                        RiskDetail   = $_.riskDetail
                        LastUpdated  = $_.riskLastUpdatedDateTime
                        IsProcessing = $_.isProcessing
                        RiskHistory  = $RiskHistory
                        Severity     = $Severity
                    }
                    Tenant  = $TenantFilter
                }
            }

            if ($AlertData) {
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not get risky users for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertNewRiskyUsers.ps1' 76
#Region './Public/Alerts/Get-CIPPAlertNewRole.ps1' -1

function Get-CIPPAlertNewRole {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    $Deltatable = Get-CIPPTable -Table DeltaCompare
    try {
        $Filter = "PartitionKey eq 'AdminDelta' and RowKey eq '{0}'" -f $TenantFilter
        $AdminDelta = (Get-CIPPAzDataTableEntity @Deltatable -Filter $Filter).delta | ConvertFrom-Json -ErrorAction SilentlyContinue
        $NewDelta = (New-GraphGetRequest -uri "https://graph.microsoft.com/v1.0/directoryRoles?`$expand=members" -tenantid $TenantFilter) | Select-Object displayName, Members | ForEach-Object {
            @{
                GroupName = $_.displayName
                Members   = $_.Members.UserPrincipalName
            }
        }
        $NewDeltatoSave = $NewDelta | ConvertTo-Json -Depth 10 -Compress -ErrorAction SilentlyContinue | Out-String
        $DeltaEntity = @{
            PartitionKey = 'AdminDelta'
            RowKey       = [string]$TenantFilter
            delta        = "$NewDeltatoSave"
        }
        Add-CIPPAzDataTableEntity @DeltaTable -Entity $DeltaEntity -Force

        if ($AdminDelta) {
            $AlertData = foreach ($Group in $NewDelta) {
                $OldDelta = $AdminDelta | Where-Object { $_.GroupName -eq $Group.GroupName }
                $Group.members | Where-Object { $_ -notin $OldDelta.members } | ForEach-Object {
                    [PSCustomObject]@{
                        Message = "$_ has been added to the $($Group.GroupName) Role"
                        User    = $_
                        Role    = $Group.GroupName
                        Tenant  = $TenantFilter
                    }
                }
            }
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not get role changes for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertNewRole.ps1' 50
#Region './Public/Alerts/Get-CIPPAlertNoCAConfig.ps1' -1

function Get-CIPPAlertNoCAConfig {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        # Only consider CA available when a SKU that grants it has enabled seats (> 0)
        $SubscribedSkus = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/subscribedSkus?`$select=prepaidUnits,servicePlans" -tenantid $TenantFilter -ErrorAction Stop
        $CAAvailable = foreach ($sku in $SubscribedSkus) {
            if ([int]$sku.prepaidUnits.enabled -gt 0) { $sku.servicePlans }
        }

        if (('AAD_PREMIUM' -in $CAAvailable.servicePlanName) -or ('AAD_PREMIUM_P2' -in $CAAvailable.servicePlanName)) {
            $CAPolicies = (New-GraphGetRequest -uri 'https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies' -tenantid $TenantFilter)
            if (!$CAPolicies.id) {
                $AlertData = [PSCustomObject]@{
                    Message = 'Conditional Access is available, but no policies could be found.'
                    Tenant  = $TenantFilter
                }

                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Conditional Access Config Alert: Error occurred: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }

}
#EndRegion './Public/Alerts/Get-CIPPAlertNoCAConfig.ps1' 38
#Region './Public/Alerts/Get-CIPPAlertOnedriveQuota.ps1' -1

function Get-CIPPAlertOneDriveQuota {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        $TenantFilter,
        [Alias('input')]
        [ValidateRange(0, 100)]
        [int]$InputValue = 90
    )

    try {
        $Usage = New-GraphGetRequest -tenantid $TenantFilter -uri "https://graph.microsoft.com/beta/reports/getOneDriveUsageAccountDetail(period='D7')?`$format=application/json&`$top=999" -AsApp $true
        if (!$Usage) {
            return
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "OneDrive quota Alert: Unable to get OneDrive usage: Error occurred: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        return
    }

    #Check if the OneDrive quota is over the threshold
    $OverQuota = $Usage | ForEach-Object {
        if ($_.StorageUsedInBytes -eq 0 -or $_.storageAllocatedInBytes -eq 0) { return }
        try {
            $UsagePercent = [math]::Round(($_.storageUsedInBytes / $_.storageAllocatedInBytes) * 100)
        } catch { $UsagePercent = 100 }

        if ($UsagePercent -gt $InputValue) {
            $GBLeft = [math]::Round(($_.storageAllocatedInBytes - $_.storageUsedInBytes) / 1GB)
            [PSCustomObject]@{
                Message                 = "$($_.ownerPrincipalName): OneDrive is $UsagePercent% full. OneDrive has $($GBLeft)GB storage left"
                Owner                   = $_.ownerPrincipalName
                UsagePercent            = $UsagePercent
                GBLeft                  = $GBLeft
                StorageUsedInBytes      = $_.storageUsedInBytes
                StorageAllocatedInBytes = $_.storageAllocatedInBytes
                Tenant                  = $TenantFilter
            }
        }

    }

    #If the quota is over the threshold, send an alert
    if ($OverQuota) {
        Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $OverQuota
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertOnedriveQuota.ps1' 53
#Region './Public/Alerts/Get-CIPPAlertOverusedLicenses.ps1' -1

function Get-CIPPAlertOverusedLicenses {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )


    try {
        $LicenseTable = Get-CIPPTable -TableName ExcludedLicenses
        $ExcludedSkuList = Get-CIPPAzDataTableEntity @LicenseTable
        $AlertData = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/subscribedSkus' -tenantid $TenantFilter | ForEach-Object {
            $skuid = $_
            foreach ($sku in $skuid) {
                if ($sku.skuId -in $ExcludedSkuList.GUID) { continue }
                $PrettyName = Convert-SKUname -SkuID $sku.skuId
                if (!$PrettyName) { $PrettyName = $sku.skuPartNumber }
                if ($sku.prepaidUnits.enabled - $sku.consumedUnits -lt 0) {
                    [PSCustomObject]@{
                        Message       = "$PrettyName has Overused licenses. Using $($sku.consumedUnits) of $($sku.prepaidUnits.enabled)."
                        LicenseName   = $PrettyName
                        SkuId         = $sku.skuId
                        SkuPartNumber = $sku.skuPartNumber
                        ConsumedUnits = $sku.consumedUnits
                        EnabledUnits  = $sku.prepaidUnits.enabled
                        Tenant        = $TenantFilter
                    }
                }
            }
        }
        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Overused Licenses Alert Error occurred: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertOverusedLicenses.ps1' 46
#Region './Public/Alerts/Get-CIPPAlertQuarantineReleaseRequests.ps1' -1

function Get-CIPPAlertQuarantineReleaseRequests {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    #Add rerun protection: This Monitor can only run once every hour.
    $Rerun = Test-CIPPRerun -TenantFilter $TenantFilter -Type 'ExchangeMonitor' -API 'Get-CIPPAlertQuarantineReleaseRequests'
    if ($Rerun) {
        return
    }
    $HasLicense = Test-CIPPStandardLicense -StandardName 'QuarantineReleaseRequests' -TenantFilter $TenantFilter -RequiredCapabilities @(
        'EXCHANGE_S_STANDARD',
        'EXCHANGE_S_ENTERPRISE',
        'EXCHANGE_S_STANDARD_GOV',
        'EXCHANGE_S_ENTERPRISE_GOV',
        'EXCHANGE_LITE'
    )

    if (-not $HasLicense) {
        return
    }

    try {
        $cmdParams = @{
            PageSize          = 1000
            ReleaseStatus     = 'Requested'
            StartReceivedDate = (Get-Date).AddHours(-6)
            EndReceivedDate   = (Get-Date).AddHours(0)
        }
        $RequestedReleases = New-ExoRequest -tenantid $TenantFilter -cmdlet 'Get-QuarantineMessage' -cmdParams $cmdParams -ErrorAction Stop | Select-Object -ExcludeProperty *data.type* | Sort-Object -Property ReceivedTime

        if ($RequestedReleases) {
            # Get the CIPP URL for the Quarantine link
            $CippConfigTable = Get-CippTable -tablename Config
            $CippConfig = Get-CIPPAzDataTableEntity @CippConfigTable -Filter "PartitionKey eq 'InstanceProperties' and RowKey eq 'CIPPURL'"
            $CIPPUrl = 'https://{0}' -f $CippConfig.Value

            $AlertData = foreach ($Message in $RequestedReleases) {
                [PSCustomObject]@{
                    Identity          = $Message.Identity
                    MessageId         = $Message.MessageId
                    Subject           = $Message.Subject
                    SenderAddress     = $Message.SenderAddress
                    RecipientAddress  = $Message.RecipientAddress -join '; '
                    Type              = $Message.Type
                    PolicyName        = $Message.PolicyName
                    ReleaseStatus     = $Message.ReleaseStatus
                    ReceivedTime      = $Message.ReceivedTime
                    QuarantineViewUrl = "$CIPPUrl/email/administration/quarantine?tenantFilter=$TenantFilter"
                    Tenant            = $TenantFilter
                }
            }

            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "QuarantineReleaseRequests: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertQuarantineReleaseRequests.ps1' 69
#Region './Public/Alerts/Get-CIPPAlertQuotaUsed.ps1' -1

function Get-CIPPAlertQuotaUsed {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        $AlertData = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/reports/getMailboxUsageDetail(period='D7')?`$format=application/json" -tenantid $TenantFilter
    } catch {
        return
    }
    $OverQuota = $AlertData | ForEach-Object {
        if ([string]::IsNullOrEmpty($_.StorageUsedInBytes) -or [string]::IsNullOrEmpty($_.prohibitSendReceiveQuotaInBytes) -or $_.StorageUsedInBytes -eq 0 -or $_.prohibitSendReceiveQuotaInBytes -eq 0) { return }
        try {
            $PercentLeft = [math]::round(($_.storageUsedInBytes / $_.prohibitSendReceiveQuotaInBytes) * 100)
        } catch { $PercentLeft = 100 }
        try {
            if ([int]$InputValue -gt 0) {
                $Value = [int]$InputValue
            } else {
                $Value = 90
            }
        } catch {
            $Value = 90
        }
        if ($PercentLeft -gt $Value) {
            [PSCustomObject]@{
                Message                         = "$($_.userPrincipalName): Mailbox is more than $($value)% full. Mailbox is $PercentLeft% full"
                Owner                           = $_.userPrincipalName
                RecipientType                   = $_.recipientType
                UsagePercent                    = $PercentLeft
                StorageUsedInBytes              = $_.storageUsedInBytes
                ProhibitSendReceiveQuotaInBytes = $_.prohibitSendReceiveQuotaInBytes
                Tenant                          = $TenantFilter
            }
        }
    }
    if ($OverQuota) {
        Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $OverQuota
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertQuotaUsed.ps1' 49
#Region './Public/Alerts/Get-CIPPAlertReportOnlyCA.ps1' -1

function Get-CIPPAlertReportOnlyCA {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        # Only consider CA available when a SKU that grants it has enabled seats (> 0)
        $SubscribedSkus = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/subscribedSkus?`$select=prepaidUnits,servicePlans" -tenantid $TenantFilter -ErrorAction Stop
        $CAAvailable = foreach ($sku in $SubscribedSkus) {
            if ([int]$sku.prepaidUnits.enabled -gt 0) { $sku.servicePlans }
        }

        if (('AAD_PREMIUM' -in $CAAvailable.servicePlanName) -or ('AAD_PREMIUM_P2' -in $CAAvailable.servicePlanName)) {
            $CAPolicies = (New-GraphGetRequest -uri 'https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies?$top=999' -tenantid $TenantFilter -ErrorAction Stop)

            # Filter for policies in report-only mode
            $ReportOnlyPolicies = $CAPolicies | Where-Object { $_.state -eq 'enabledForReportingButNotEnforced' }

            if ($ReportOnlyPolicies) {
                $AlertData = foreach ($Policy in $ReportOnlyPolicies) {
                    [PSCustomObject]@{
                        PolicyNames = $Policy.displayName
                        State       = $Policy.state
                        Tenant      = $TenantFilter
                    }
                }
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Report-Only CA Alert: Error occurred: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }

}
#EndRegion './Public/Alerts/Get-CIPPAlertReportOnlyCA.ps1' 44
#Region './Public/Alerts/Get-CIPPAlertRestrictedUsers.ps1' -1

function Get-CIPPAlertRestrictedUsers {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        $BlockedUsers = New-ExoRequest -tenantid $TenantFilter -cmdlet 'Get-BlockedSenderAddress'

        if ($BlockedUsers) {
            $AlertData = foreach ($User in $BlockedUsers) {
                # Parse the reason to make it more readable
                $ReasonParts = $User.Reason -split ';'
                $LimitType = ($ReasonParts | Where-Object { $_ -like 'ExceedingLimitType=*' }) -replace 'ExceedingLimitType=', ''
                $InternalCount = ($ReasonParts | Where-Object { $_ -like 'InternalRecipientCountToday=*' }) -replace 'InternalRecipientCountToday=', ''
                $ExternalCount = ($ReasonParts | Where-Object { $_ -like 'ExternalRecipientCountToday=*' }) -replace 'ExternalRecipientCountToday=', ''

                [PSCustomObject]@{
                    SenderAddress   = $User.SenderAddress
                    Message         = "User $($User.SenderAddress) is restricted from sending email. Block type: $($LimitType ?? 'Unknown'). Created: $($User.CreatedDatetime)"
                    BlockType       = if ($LimitType) { "$LimitType recipient limit exceeded" } else { 'Email sending limit exceeded' }
                    TemporaryBlock  = $User.TemporaryBlock
                    InternalCount   = $InternalCount
                    ExternalCount   = $ExternalCount
                    CreatedDatetime = $User.CreatedDatetime
                    Reason          = $User.Reason
                    Tenant          = $TenantFilter
                }
            }
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
       # $ErrorMessage = Get-CippException -Exception $_
       # Write-LogMessage -tenant $($TenantFilter) -message "Could not get restricted users for $($TenantFilter): $($ErrorMessage.NormalizedError)" -severity 'Error' -API 'Get-CIPPAlertRestrictedUsers' -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertRestrictedUsers.ps1' 44
#Region './Public/Alerts/Get-CIPPAlertRoleEscalableGroups.ps1' -1

function Get-CIPPAlertRoleEscalableGroups {
    <#
    .SYNOPSIS
        Flags non-role-assignable groups in Entra directory role paths.

    .DESCRIPTION
        Scans Entra directory role assignments where the role principal is a group. Flags:
        1) direct role-assigned groups that are not marked isAssignableToRole, and
        2) non-role-assignable nested groups found via transitive group membership under a role-assigned group.
        Findings include path type, role-assigned group details, impacted group details, and human-readable role name.

    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        $groups = @(New-GraphGetRequest -uri "https://graph.microsoft.com/beta/groups?`$select=id,displayName,isAssignableToRole&`$top=999" -tenantid $TenantFilter)
        if (-not $groups -or $groups.Count -eq 0) {
            Write-Information "Get-CIPPAlertRoleEscalableGroups: no groups returned for $TenantFilter"
            return
        }
        $groupById = @{}
        foreach ($g in $groups) {
            if (-not $g.id) { continue }
            $groupById["$($g.id)"] = $g
        }

        $roleDefinitions = @(New-GraphGetRequest -uri "https://graph.microsoft.com/beta/roleManagement/directory/roleDefinitions?`$select=id,displayName&`$top=999" -tenantid $TenantFilter)
        $roleDefById = @{}
        foreach ($rd in $roleDefinitions) {
            if (-not $rd.id) { continue }
            $roleDefById["$($rd.id)"] = $rd
        }

        $roleAssignments = @(New-GraphGetRequest -uri "https://graph.microsoft.com/beta/roleManagement/directory/roleAssignments?`$select=id,principalId,roleDefinitionId,directoryScopeId,appScopeId&`$top=999" -tenantid $TenantFilter)
        if (-not $roleAssignments -or $roleAssignments.Count -eq 0) {
            Write-Information "Get-CIPPAlertRoleEscalableGroups: no role assignments returned for $TenantFilter"
            return
        }

        $findings = [System.Collections.Generic.List[object]]::new()
        $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        $transitiveNestedGroupIdsByRoot = @{}

        foreach ($assignment in $roleAssignments) {
            $principalId = "$($assignment.principalId)"
            if (-not $principalId) { continue }

            if (-not $groupById.ContainsKey($principalId)) { continue }
            $rootGroup = $groupById[$principalId]
            if (-not $rootGroup) { continue }

            $roleDefId = "$($assignment.roleDefinitionId)"
            $roleDef = if ($roleDefId) { $roleDefById[$roleDefId] } else { $null }
            $roleName = if ($roleDef -and $roleDef.displayName) { $roleDef.displayName } else { 'Unknown role' }
            $scope = if ($assignment.directoryScopeId) { "$($assignment.directoryScopeId)" } elseif ($assignment.appScopeId) { "$($assignment.appScopeId)" } else { '/' }

            if ($rootGroup.isAssignableToRole -ne $true) {
                $dedupeKey = "D|$principalId|$roleDefId|$scope"
                if (-not $seen.Add($dedupeKey)) { continue }

                $findings.Add([PSCustomObject]@{
                        PathType                      = 'Direct'
                        RoleAssignedGroupId           = $rootGroup.id
                        RoleAssignedGroupDisplayName  = $rootGroup.displayName
                        GroupDisplayName              = $rootGroup.displayName
                        GroupId                       = $rootGroup.id
                        IsAssignableToRole            = $rootGroup.isAssignableToRole
                        RoleName                      = $roleName
                        Risk                          = 'High'
                        Reason                        = 'Group has directory role assignment while not marked role-assignable; group owners/admins have an indirect role-escalation path.'
                    })
            }

            if (-not $transitiveNestedGroupIdsByRoot.ContainsKey($principalId)) {
                $nestedIds = [System.Collections.Generic.List[string]]::new()
                try {
                    $transitive = @(New-GraphGetRequest -uri "https://graph.microsoft.com/beta/groups/$principalId/transitiveMembers/microsoft.graph.group?`$select=id" -tenantid $TenantFilter)
                    foreach ($m in $transitive) {
                        $mid = "$($m.id)"
                        if (-not $mid -or $mid -eq $principalId) { continue }
                        $nestedIds.Add($mid)
                    }
                } catch {
                    Write-Information "Get-CIPPAlertRoleEscalableGroups: transitiveMembers failed for group $principalId — $($_.Exception.Message)"
                }
                $transitiveNestedGroupIdsByRoot[$principalId] = $nestedIds
            }

            foreach ($nestedId in @($transitiveNestedGroupIdsByRoot[$principalId])) {
                if (-not $groupById.ContainsKey($nestedId)) { continue }
                $nestedGroup = $groupById[$nestedId]
                if (-not $nestedGroup) { continue }
                if ($nestedGroup.isAssignableToRole -eq $true) { continue }

                $dedupeKey = "N|$nestedId|$roleDefId|$scope|$principalId"
                if (-not $seen.Add($dedupeKey)) { continue }

                $findings.Add([PSCustomObject]@{
                        PathType                      = 'Nested'
                        RoleAssignedGroupId           = $rootGroup.id
                        RoleAssignedGroupDisplayName  = $rootGroup.displayName
                        GroupDisplayName              = $nestedGroup.displayName
                        GroupId                       = $nestedGroup.id
                        IsAssignableToRole            = $nestedGroup.isAssignableToRole
                        RoleName                      = $roleName
                        Risk                          = 'High'
                        Reason                        = 'Non-role-assignable group is nested (transitive member) under a group that has a directory role; group owners/admins can add members who inherit high privileged membership.'
                    })
            }
        }

        if ($findings.Count -gt 0) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data @($findings)
        } else {
            Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Role-escalable groups alert: no role-escalation group paths found" -sev 'Information'
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Role-escalable groups alert failed: $($ErrorMessage.NormalizedError)" -sev 'Error' -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertRoleEscalableGroups.ps1' 130
#Region './Public/Alerts/Get-CIPPAlertSecDefaultsDisabled.ps1' -1

function Get-CIPPAlertSecDefaultsDisabled {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        # Check if Security Defaults is disabled
        $SecDefaults = (New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/policies/identitySecurityDefaultsEnforcementPolicy' -tenantid $TenantFilter)

        if ($SecDefaults.isEnabled -eq $false) {
            # Security Defaults is disabled, now check if there are any CA policies
            $CAPolicies = (New-GraphGetRequest -uri 'https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies' -tenantid $TenantFilter)

            if (!$CAPolicies -or $CAPolicies.Count -eq 0) {
                # Security Defaults is off AND no CA policies exist
                $AlertData = [PSCustomObject]@{
                    Message = 'Security Defaults is disabled and no Conditional Access policies are configured. This tenant has no baseline security protection.'
                    Tenant  = $TenantFilter
                }

                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Security Defaults Disabled Alert: Error occurred: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertSecDefaultsDisabled.ps1' 37
#Region './Public/Alerts/Get-CIPPAlertSecDefaultsUpsell.ps1' -1

function Get-CIPPAlertSecDefaultsUpsell {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        try {
            $SecDefaults = (New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/policies/identitySecurityDefaultsEnforcementPolicy' -tenantid $TenantFilter)
            if ($SecDefaults.isEnabled -eq $false -and $SecDefaults.securityDefaultsUpsell.action -in @('autoEnable', 'autoEnabledNotify')) {
                $AlertData = [PSCustomObject]@{
                    Message        = ('Security Defaults will be automatically enabled on {0}' -f $SecDefaults.securityDefaultsUpsell.dueDateTime)
                    EnablementDate = $SecDefaults.securityDefaultsUpsell.dueDateTime
                    Action         = $SecDefaults.securityDefaultsUpsell.action
                    Tenant         = $TenantFilter
                }
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData

            }
        } catch {}

    } catch {
        # Error handling
    }
}

#EndRegion './Public/Alerts/Get-CIPPAlertSecDefaultsUpsell.ps1' 34
#Region './Public/Alerts/Get-CIPPAlertSecureScore.ps1' -1


function Get-CippAlertSecureScore {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        $TopCount = if ($InputValue.ThresholdType.value -eq 'drop') { 2 } else { 1 }
        $SecureScores = @(New-GraphGetRequest -uri "https://graph.microsoft.com/v1.0/security/secureScores?`$top=$TopCount" -tenantid $TenantFilter -noPagination $true)
        $SecureScore = $SecureScores[0]

        if ($InputValue.ThresholdType.value -eq 'absolute') {
            if ($SecureScore.currentScore -lt $InputValue.InputValue) {
                $SecureScoreResult = [PSCustomObject]@{
                    Message        = "Secure Score is below acceptable threshold"
                    Tenant         = $TenantFilter
                    CurrentScore   = $SecureScore.currentScore
                    MaxSecureScore = $SecureScore.maxScore
                }
            } else {
                $SecureScoreResult = @()
            }
        } elseif ($InputValue.ThresholdType.value -eq 'percent') {
            $PercentageScore = [math]::Round((($SecureScore.currentScore / $SecureScore.maxScore) * 100), 2)
            if ($PercentageScore -lt $InputValue.InputValue) {
                $SecureScoreResult = [PSCustomObject]@{
                    Message                  = "Secure Score is below acceptable threshold"
                    Tenant                   = $TenantFilter
                    CurrentScore             = $SecureScore.currentScore
                    MaxScore                 = $SecureScore.maxScore
                    CurrentScorePercentage   = [math]::Round($PercentageScore, 2)
                    ScoreThresholdPercentage = $InputValue.InputValue
                }
            } else {
                $SecureScoreResult = @()
            }
        } elseif ($InputValue.ThresholdType.value -eq 'drop') {
            if ($SecureScores.Count -ge 2) {
                $PreviousScore = $SecureScores[1]
                if ($PreviousScore.currentScore -gt 0) {
                    $DropPercentage = [math]::Round((($PreviousScore.currentScore - $SecureScore.currentScore) / $PreviousScore.currentScore) * 100, 2)
                    if ($DropPercentage -ge $InputValue.InputValue) {
                        $SecureScoreResult = [PSCustomObject]@{
                            Message        = "Secure Score dropped by $DropPercentage% (from $($PreviousScore.currentScore) to $($SecureScore.currentScore))"
                            Tenant         = $TenantFilter
                            CurrentScore   = $SecureScore.currentScore
                            PreviousScore  = $PreviousScore.currentScore
                            MaxScore       = $SecureScore.maxScore
                            DropPercentage = $DropPercentage
                            DropThreshold  = $InputValue.InputValue
                        }
                    } else {
                        $SecureScoreResult = @()
                    }
                } else {
                    $SecureScoreResult = @()
                }
            } else {
                $SecureScoreResult = @()
            }
        }

        if ($SecureScoreResult) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $SecureScoreResult -PartitionKey SecureScore
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Could not get Secure Score for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertSecureScore.ps1' 78
#Region './Public/Alerts/Get-CIPPAlertSharepointQuota.ps1' -1

function Get-CIPPAlertSharepointQuota {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        $SharePointInfo = Get-SharePointAdminLink -Public $false -tenantFilter $TenantFilter
        $extraHeaders = @{
            'Accept' = 'application/json'
        }
        $sharepointQuota = (New-GraphGetRequest -extraHeaders $extraHeaders -scope "$($SharePointInfo.AdminUrl)/.default" -tenantid $TenantFilter -uri "$($SharePointInfo.AdminUrl)/_api/StorageQuotas()?api-version=1.3.2")
    } catch {
        return
    }
    if ($sharepointQuota) {
        try {
            if ([int]$InputValue -gt 0) { $Value = [int]$InputValue } else { $Value = 90 }
        } catch {
            $Value = 90
        }
        $UsedStoragePercentage = [int](($sharepointQuota.GeoUsedStorageMB / $sharepointQuota.TenantStorageMB) * 100)
        if ($UsedStoragePercentage -gt $Value) {
            $AlertData = [PSCustomObject]@{
                UsedStoragePercentage = $UsedStoragePercentage
                StorageUsed           = ([math]::Round($sharepointQuota.GeoUsedStorageMB / 1024, 2))
                StorageQuota          = ([math]::Round($sharepointQuota.TenantStorageMB / 1024, 2))
                AlertQuotaThreshold   = $Value
                Tenant                = $TenantFilter
            }
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertSharepointQuota.ps1' 41
#Region './Public/Alerts/Get-CIPPAlertSmtpAuthSuccess.ps1' -1

function Get-CIPPAlertSmtpAuthSuccess {
    <#
    .FUNCTIONALITY
        Entrypoint – Check sign-in logs for SMTP AUTH with success status
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        $lookupDays = if ($InputValue.SmtpAuthSuccessDays) { [int]$InputValue.SmtpAuthSuccessDays } else { 7 }
        $lookupDays = [Math]::Min($lookupDays, 30)

        $endDateTime = (Get-Date).ToUniversalTime()
        $startDateTime = $endDateTime.AddDays(-$lookupDays)
        $startDateTimeString = $startDateTime.ToString('yyyy-MM-ddTHH:mm:ssZ')
        $endDateTimeString = $endDateTime.ToString('yyyy-MM-ddTHH:mm:ssZ')

        # Graph API endpoint for sign-ins
        $uri = "https://graph.microsoft.com/v1.0/auditLogs/signIns?`$filter=createdDateTime ge $startDateTimeString and createdDateTime le $endDateTimeString and (clientAppUsed eq 'Authenticated SMTP' or clientAppUsed eq 'SMTP') and status/errorCode eq 0"

        # Call Graph API for the given tenant
        $SignIns = New-GraphGetRequest -uri $uri -tenantid $TenantFilter

        # Select only the properties you care about
        $AlertData = $SignIns | Select-Object userPrincipalName, createdDateTime, clientAppUsed, ipAddress, status, @{Name = 'Tenant'; Expression = { $TenantFilter } }

        # Write results into the alert pipeline
        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        # Suppress errors if no data returned
        # Uncomment if you want explicit error logging
        # $ErrorMessage = Get-CippException -Exception $_
        # Write-AlertMessage -tenant $($TenantFilter) -message "Failed to query SMTP AUTH sign-ins for $($TenantFilter): $($ErrorMessage.NormalizedError)"
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertSmtpAuthSuccess.ps1' 44
#Region './Public/Alerts/Get-CIPPAlertSoftDeletedMailboxes.ps1' -1

function Get-CIPPAlertSoftDeletedMailboxes {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    $Select = 'ExchangeGuid,ArchiveGuid,WhenSoftDeleted,UserPrincipalName,IsInactiveMailbox'

    try {
        $SoftDeletedMailBoxes = New-ExoRequest -tenantid $TenantFilter -cmdlet 'get-mailbox' -cmdParams @{SoftDeletedMailbox = $true } -Select $Select |
            Select-Object ExchangeGuid, ArchiveGuid, WhenSoftDeleted, @{ Name = 'UPN'; Expression = { $_.'UserPrincipalName' } }, IsInactiveMailbox, @{ Name = 'Tenant'; Expression = { $TenantFilter } }

        # Filter out the mailboxes where IsInactiveMailbox is $true
        $AlertData = $SoftDeletedMailBoxes | Where-Object { $_.IsInactiveMailbox -ne $true }

        # Write the alert trace with the filtered data
        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Failed to check for soft deleted mailboxes in $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertSoftDeletedMailboxes.ps1' 33
#Region './Public/Alerts/Get-CIPPAlertStaleEntraDevices.ps1' -1

function Get-CIPPAlertStaleEntraDevices {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        try {
            $inactiveDays = 90

            $excludeDisabled = [bool]$InputValue.ExcludeDisabled
            if ($null -ne $InputValue.DaysSinceLastActivity -and $InputValue.DaysSinceLastActivity -ne '') {
                $parsedDays = 0
                if ([int]::TryParse($InputValue.DaysSinceLastActivity.ToString(), [ref]$parsedDays) -and $parsedDays -gt 0) {
                    $inactiveDays = $parsedDays
                }
            }

            $Lookup = (Get-Date).AddDays(-$inactiveDays).ToUniversalTime()
            Write-Host "Checking for inactive Entra devices since $Lookup (excluding disabled: $excludeDisabled)"
            # Build base filter - cannot filter accountEnabled server-side
            $BaseFilter = if ($excludeDisabled) { 'accountEnabled eq true' } else { '' }

            $Uri = if ($BaseFilter) {
                "https://graph.microsoft.com/beta/devices?`$filter=$BaseFilter"
            } else {
                'https://graph.microsoft.com/beta/devices'
            }

            $GraphRequest = New-GraphGetRequest -uri $Uri -tenantid $TenantFilter

            $AlertData = foreach ($device in $GraphRequest) {

                $lastActivity = $device.approximateLastSignInDateTime

                $isInactive = (-not $lastActivity) -or ([DateTime]$lastActivity -le $Lookup)
                # Only process stale Entra devices
                if ($isInactive) {

                    if (-not $lastActivity) {

                        $Message = 'Device {0} has never been active' -f $device.displayName
                    } else {
                        $daysSinceLastActivity = [Math]::Round(((Get-Date) - [DateTime]$lastActivity).TotalDays)
                        $Message = 'Device {0} has been inactive for {1} days. Last activity: {2}' -f $device.displayName, $daysSinceLastActivity, $lastActivity
                    }

                    if ($device.TrustType -eq 'Workplace') { $TrustType = 'Entra registered' }
                    elseif ($device.TrustType -eq 'AzureAd') { $TrustType = 'Entra joined' }
                    elseif ($device.TrustType -eq 'ServerAd') { $TrustType = 'Entra hybrid joined' }

                    [PSCustomObject]@{
                        DeviceName            = if ($device.displayName) { $device.displayName } else { 'N/A' }
                        Id                    = if ($device.id) { $device.id } else { 'N/A' }
                        deviceOwnership       = if ($device.deviceOwnership) { $device.deviceOwnership } else { 'N/A' }
                        operatingSystem       = if ($device.operatingSystem) { $device.operatingSystem } else { 'N/A' }
                        enrollmentType        = if ($device.enrollmentType) { $device.enrollmentType } else { 'N/A' }
                        Enabled               = if ($device.accountEnabled) { $device.accountEnabled } else { 'N/A' }
                        Managed               = if ($device.isManaged) { $device.isManaged } else { 'N/A' }
                        Compliant             = if ($device.isCompliant) { $device.isCompliant } else { 'N/A' }
                        JoinType              = $TrustType
                        lastActivity          = if ($lastActivity) { $lastActivity } else { 'N/A' }
                        DaysSinceLastActivity = if ($daysSinceLastActivity) { $daysSinceLastActivity } else { 'N/A' }
                        RegisteredDateTime    = if ($device.createdDateTime) { $device.createdDateTime } else { 'N/A' }
                        Message               = $Message
                        Tenant                = $TenantFilter
                    }
                }
            }

            if ($AlertData) {
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        } catch {}
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Failed to check stale Entra devices for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertStaleEntraDevices.ps1' 87
#Region './Public/Alerts/Get-CIPPAlertTenantAccess.ps1' -1

function Get-CIPPAlertTenantAccess {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    $ExpectedRoles = @(
        @{ Name = 'Application Administrator'; Id = '9b895d92-2cd3-44c7-9d02-a6ac2d5ea5c3' },
        @{ Name = 'User Administrator'; Id = 'fe930be7-5e62-47db-91af-98c3a49a38b1' },
        @{ Name = 'Intune Administrator'; Id = '3a2c62db-5318-420d-8d74-23affee5d9d5' },
        @{ Name = 'Exchange Administrator'; Id = '29232cdf-9323-42fd-ade2-1d097af3e4de' },
        @{ Name = 'Security Administrator'; Id = '194ae4cb-b126-40b2-bd5b-6091b380977d' },
        @{ Name = 'Cloud App Security Administrator'; Id = '892c5842-a9a6-463a-8041-72aa08ca3cf6' },
        @{ Name = 'Cloud Device Administrator'; Id = '7698a772-787b-4ac8-901f-60d6b08affd2' },
        @{ Name = 'Teams Administrator'; Id = '69091246-20e8-4a56-aa4d-066075b2a7a8' },
        @{ Name = 'SharePoint Administrator'; Id = 'f28a1f50-f6e7-4571-818b-6a12f2af6b6c' },
        @{ Name = 'Authentication Policy Administrator'; Id = '0526716b-113d-4c15-b2c8-68e3c22b9f80' },
        @{ Name = 'Privileged Role Administrator'; Id = 'e8611ab8-c189-46e8-94e1-60213ab1f814' },
        @{ Name = 'Privileged Authentication Administrator'; Id = '7be44c8a-adaf-4e2a-84d6-ab2649e08a13' },
        @{ Name = 'Billing Administrator'; Id = 'b0f54661-2d74-4c50-afa3-1ec803f12efe'; Optional = $true },
        @{ Name = 'Global Reader'; Id = 'f2ef992c-3afb-46b9-b7cf-a126ee74c451'; Optional = $true },
        @{ Name = 'Domain Name Administrator'; Id = '8329153b-31d0-4727-b945-745eb3bc5f31'; Optional = $true }
    )

    try {
        $Tenant = Get-Tenants -TenantFilter $TenantFilter -IncludeErrors
        if (-not $Tenant) {
            return
        }
        $TenantId = $Tenant.customerId
        $Issues = [System.Collections.Generic.List[object]]::new()

        # Test Graph API connectivity and GDAP role assignments
        $GraphStatus = $false
        $GraphMessage = ''
        try {
            $BulkRequests = $ExpectedRoles | ForEach-Object {
                @{
                    id     = "roleManagement_$($_.Id)"
                    method = 'GET'
                    url    = "roleManagement/directory/roleAssignments?`$filter=roleDefinitionId eq '$($_.Id)'&`$expand=principal"
                }
            }
            $GDAPRolesGraph = New-GraphBulkRequest -tenantid $TenantId -Requests $BulkRequests
            $MissingRoles = [System.Collections.Generic.List[string]]::new()

            foreach ($RoleId in $ExpectedRoles) {
                $GraphRole = $GDAPRolesGraph.body.value | Where-Object -Property roleDefinitionId -EQ $RoleId.Id
                $Role = $GraphRole.principal | Where-Object -Property organizationId -EQ $env:TenantID
                if (-not $Role -and $RoleId.Optional -ne $true) {
                    $MissingRoles.Add($RoleId.Name)
                }
            }

            $GraphStatus = $true
            if ($MissingRoles.Count -gt 0) {
                $GraphMessage = "Graph connected but missing required GDAP roles: $($MissingRoles -join ', ')"
                $Issues.Add([PSCustomObject]@{
                        Issue        = 'MissingGDAPRoles'
                        Message      = $GraphMessage
                        MissingRoles = ($MissingRoles -join ', ')
                        Tenant       = $TenantFilter
                    })
            }
        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            $GraphMessage = "Failed to connect to Graph API: $($ErrorMessage.NormalizedError)"
            $Issues.Add([PSCustomObject]@{
                    Issue   = 'GraphFailure'
                    Message = $GraphMessage
                    Tenant  = $TenantFilter
                })
        }

        # Test Exchange Online connectivity
        $ExchangeStatus = $false
        try {
            $null = New-ExoRequest -tenantid $TenantId -cmdlet 'Get-OrganizationConfig' -ErrorAction Stop
            $ExchangeStatus = $true
        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            $Issues.Add([PSCustomObject]@{
                    Issue   = 'ExchangeFailure'
                    Message = "Failed to connect to Exchange Online: $($ErrorMessage.NormalizedError)"
                    Tenant  = $TenantFilter
                })
        }

        # Build alert data only if there are issues
        $AlertData = @()
        if (-not $GraphStatus -and -not $ExchangeStatus) {
            $AlertData = @([PSCustomObject]@{
                    Message        = "Tenant $TenantFilter is inaccessible. Graph API and Exchange Online connectivity both failed. This tenant may have removed GDAP permissions or requires consent refresh."
                    GraphStatus    = $false
                    ExchangeStatus = $false
                    Issues         = ($Issues | ForEach-Object { $_.Message }) -join '; '
                    Tenant         = $TenantFilter
                })
        } elseif (-not $GraphStatus) {
            $AlertData = @([PSCustomObject]@{
                    Message        = "Tenant $TenantFilter has lost Graph API access. $GraphMessage"
                    GraphStatus    = $false
                    ExchangeStatus = $ExchangeStatus
                    Issues         = ($Issues | ForEach-Object { $_.Message }) -join '; '
                    Tenant         = $TenantFilter
                })
        } elseif (-not $ExchangeStatus) {
            $AlertData = @([PSCustomObject]@{
                    Message        = "Tenant $TenantFilter has lost Exchange Online access. This may indicate missing Exchange Administrator GDAP role or removed consent."
                    GraphStatus    = $GraphStatus
                    ExchangeStatus = $false
                    Issues         = ($Issues | ForEach-Object { $_.Message }) -join '; '
                    Tenant         = $TenantFilter
                })
        } elseif ($MissingRoles.Count -gt 0) {
            $AlertData = @([PSCustomObject]@{
                    Message        = "Tenant $TenantFilter is accessible but missing required GDAP roles: $($MissingRoles -join ', '). This may indicate a CIPP-SAM permission update is needed."
                    GraphStatus    = $GraphStatus
                    ExchangeStatus = $ExchangeStatus
                    MissingRoles   = ($MissingRoles -join ', ')
                    Tenant         = $TenantFilter
                })
        }

        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Tenant access alert error for $($TenantFilter): $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertTenantAccess.ps1' 140
#Region './Public/Alerts/Get-CIPPAlertTERRL.ps1' -1

function Get-CIPPAlertTERRL {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        # Set threshold with fallback to 80%
        $Threshold = if ([string]::IsNullOrWhiteSpace($InputValue)) { 80 } else { [int]$InputValue }

        # Get TERRL status
        $TerrlStatus = New-ExoRequest -tenantid $TenantFilter -cmdlet 'Get-LimitsEnforcementStatus'

        if ($TerrlStatus) {
            $UsagePercentage = [math]::Round(($TerrlStatus.ObservedValue / $TerrlStatus.Threshold) * 100, 2)

            if ($UsagePercentage -gt $Threshold) {
                $AlertData = [PSCustomObject]@{
                    UsagePercentage    = $UsagePercentage
                    CurrentVolume      = $TerrlStatus.ObservedValue
                    ThresholdLimit     = $TerrlStatus.Threshold
                    EnforcementEnabled = $TerrlStatus.EnforcementEnabled
                    Verdict            = $TerrlStatus.Verdict
                    Message            = 'Tenant is at {0}% of their TERRL limit (using {1} of {2} messages). Tenant Enforcement Status: {3}' -f $UsagePercentage, $TerrlStatus.ObservedValue, $TerrlStatus.Threshold, $TerrlStatus.Verdict
                    Tenant             = $TenantFilter
                }
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -tenant $TenantFilter -message "Could not get TERRL status for $($TenantFilter): $($ErrorMessage.NormalizedError)" -severity 'Error' -API 'CIPPAlertTERRL' -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertTERRL.ps1' 42
#Region './Public/Alerts/Get-CIPPAlertUnusedLicenses.ps1' -1

function Get-CIPPAlertUnusedLicenses {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    try {
        $LicenseTable = Get-CIPPTable -TableName ExcludedLicenses
        $ExcludedSkuList = Get-CIPPAzDataTableEntity @LicenseTable
        $AlertData = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/subscribedSkus' -tenantid $TenantFilter | ForEach-Object {
            $SkuId = $_
            foreach ($sku in $SkuId) {
                if ($sku.skuId -in $ExcludedSkuList.GUID) { continue }
                $PrettyName = Convert-SKUname -SkuID $sku.skuId
                if (!$PrettyName) { $PrettyName = $sku.skuPartNumber }
                if ($sku.prepaidUnits.enabled - $sku.consumedUnits -gt 0) {
                    [PSCustomObject]@{
                        Message       = "$PrettyName has unused licenses. Using $($sku.consumedUnits) of $($sku.prepaidUnits.enabled)."
                        LicenseName   = $PrettyName
                        SkuId         = $sku.skuId
                        SkuPartNumber = $sku.skuPartNumber
                        ConsumedUnits = $sku.consumedUnits
                        EnabledUnits  = $sku.prepaidUnits.enabled
                        Tenant        = $TenantFilter
                    }
                }
            }
        }

        if ($AlertData) {
            Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Alerts' -tenant $TenantFilter -message "Unused Licenses Alert Error occurred: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertUnusedLicenses.ps1' 45
#Region './Public/Alerts/Get-CIPPAlertVppTokenExpiry.ps1' -1

function Get-CIPPAlertVppTokenExpiry {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )
    try {
        try {
            $VppTokens = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/deviceAppManagement/vppTokens' -tenantid $TenantFilter
            $AlertData = foreach ($Vpp in $VppTokens) {
                if ($Vpp.state -ne 'valid') {
                    $Message = 'Apple Volume Purchase Program Token is not valid, new token required'
                    $Vpp | Select-Object -Property organizationName, appleId, vppTokenAccountType, @{Name = 'Message'; Expression = { $Message } }, @{Name = 'Tenant'; Expression = { $TenantFilter } }
                } elseif ($Vpp.expirationDateTime -lt (Get-Date).AddDays(30).ToUniversalTime() -and $Vpp.expirationDateTime -gt (Get-Date).AddDays(-7).ToUniversalTime()) {
                    $Message = 'Apple Volume Purchase Program token expiring on {0}' -f $Vpp.expirationDateTime
                    $Vpp | Select-Object -Property organizationName, appleId, vppTokenAccountType, @{Name = 'Message'; Expression = { $Message } }, @{Name = 'Tenant'; Expression = { $TenantFilter } }
                }
            }
            if ($AlertData) {
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }

        } catch {}

    } catch {
        # Error handling
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertVppTokenExpiry.ps1' 35
#Region './Public/Alerts/Get-CIPPAlertVulnerabilities.ps1' -1

function Get-CIPPAlertVulnerabilities {
    <#
    .FUNCTIONALITY
        Entrypoint
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [Alias('input')]
        $InputValue,
        $TenantFilter
    )

    # Extract filter parameters from InputValue
    $ExploitabilityLevels = [System.Collections.Generic.List[string]]::new()
    if ($InputValue -is [hashtable] -or $InputValue -is [PSCustomObject]) {
        # Number inputs are stored directly
        $AgeThresholdHours = if ($InputValue.VulnerabilityAgeHours) { [int]$InputValue.VulnerabilityAgeHours } else { 0 }
        # Autocomplete inputs store value in .value subproperty
        $CVSSSeverity = if ($InputValue.CVSSSeverity.value) { $InputValue.CVSSSeverity.value } else { 'low' }
        # Switch inputs are stored as boolean
        $NewerThanMode = [bool]($InputValue.NewerThanMode)
        # Multi-select autocomplete returns array of objects with .value
        if ($InputValue.ExploitabilityLevels) {
            foreach ($level in $InputValue.ExploitabilityLevels) {
                $ExploitabilityLevels.Add($(if ($level.value) { $level.value } else { $level }))
            }
        }
    } else {
        $NewerThanMode = $false
        # Backward compatibility: simple value = hours threshold
        $AgeThresholdHours = if ($InputValue) { [int]$InputValue } else { 0 }
        $CVSSSeverity = 'low'
    }

    # Convert CVSS severity to minimum score
    $CVSSMinScore = switch ($CVSSSeverity.ToLower()) {
        'critical' { 9.0 }
        'high' { 7.0 }
        'medium' { 4.0 }
        'low' { 0.0 }
        default { 0.0 }
    }

    try {
        $VulnerabilityRequest = New-GraphGetRequest -tenantid $TenantFilter -uri 'https://api.securitycenter.microsoft.com/api/machines/SoftwareVulnerabilitiesByMachine' -scope 'https://api.securitycenter.microsoft.com/.default'

        if ($VulnerabilityRequest) {
            $AlertData = [System.Collections.Generic.List[PSCustomObject]]::new()

            # Group by CVE ID and create objects for each vulnerability
            $VulnerabilityGroups = $VulnerabilityRequest | Where-Object { $_.cveId } | Group-Object cveId

            foreach ($Group in $VulnerabilityGroups) {
                $FirstVuln = $Group.Group | Sort-Object firstSeenTimestamp | Select-Object -First 1
                $HoursOld = [math]::Round(((Get-Date) - [datetime]$FirstVuln.firstSeenTimestamp).TotalHours)

                # Skip based on age threshold mode
                if ($NewerThanMode) {
                    # Newer-than mode: only alert on items newer than threshold
                    if ($HoursOld -gt $AgeThresholdHours) {
                        continue
                    }
                } else {
                    # Older-than mode (default): only alert on items older than threshold
                    if ($HoursOld -lt $AgeThresholdHours) {
                        continue
                    }
                }

                # Skip if CVSS score is below minimum threshold
                $VulnCVSS = if ($null -ne $FirstVuln.cvssScore) { [double]$FirstVuln.cvssScore } else { 0 }
                if ($VulnCVSS -lt $CVSSMinScore) {
                    continue
                }

                # Skip if exploitability level doesn't match filter (unless "All" is selected)
                if ($ExploitabilityLevels.Count -gt 0 -and 'All' -notin $ExploitabilityLevels) {
                    if ($FirstVuln.exploitabilityLevel -notin $ExploitabilityLevels) {
                        continue
                    }
                }

                $DaysOld = [math]::Round(((Get-Date) - [datetime]$FirstVuln.firstSeenTimestamp).TotalDays)
                $AffectedDevices = ($Group.Group | Select-Object -ExpandProperty deviceName -Unique) -join ', '

                $VulnerabilityAlert = [PSCustomObject]@{
                    CVE                  = $Group.Name
                    Severity             = $FirstVuln.vulnerabilitySeverityLevel
                    FirstSeenTimestamp   = $FirstVuln.firstSeenTimestamp
                    LastSeenTimestamp    = $FirstVuln.lastSeenTimestamp
                    DaysOld              = $DaysOld
                    HoursOld             = $HoursOld
                    AffectedDeviceCount  = $Group.Count
                    SoftwareName         = $FirstVuln.softwareName
                    SoftwareVendor       = $FirstVuln.softwareVendor
                    SoftwareVersion      = $FirstVuln.softwareVersion
                    CVSSScore            = $FirstVuln.cvssScore
                    ExploitabilityLevel  = $FirstVuln.exploitabilityLevel
                    RecommendedUpdate    = $FirstVuln.recommendedSecurityUpdate
                    RecommendedUpdateId  = $FirstVuln.recommendedSecurityUpdateId
                    RecommendedUpdateUrl = $FirstVuln.recommendedSecurityUpdateUrl
                    AffectedDevices      = $AffectedDevices
                    Tenant               = $TenantFilter
                }
                $AlertData.Add($VulnerabilityAlert)
            }

            # Only send alert if we have vulnerabilities that meet the criteria
            if ($AlertData.Count -gt 0) {
                Write-AlertTrace -cmdletName $MyInvocation.MyCommand -tenantFilter $TenantFilter -data $AlertData
            }
        }
    } catch {
        Write-LogMessage -message "Failed to check vulnerabilities: $($_.exception.message)" -API 'Vulnerability Alerts' -tenant $TenantFilter -sev Error
    }
}
#EndRegion './Public/Alerts/Get-CIPPAlertVulnerabilities.ps1' 118
