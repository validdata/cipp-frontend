#Region './Private/Get-AssignedMap.ps1' -1

function Get-AssignedMap {
    # Assigned Licenses Map
    $AssignedMap = [pscustomobject]@{
        'AADPremiumService'             = 'o-skypeforbusiness'
        'MultiFactorService'            = 'o-skypeforbusiness'
        'RMSOnline'                     = 'o-skypeforbusiness'
        'MicrosoftPrint'                = 'o-yammer'
        'WindowsDefenderATP'            = 'o-skypeforbusiness'
        'exchange'                      = 'o-exchange'
        'ProcessSimple'                 = 'o-onedrive'
        'OfficeForms'                   = 'o-yammer'
        'SCO'                           = 'o-skypeforbusiness'
        'MicrosoftKaizala'              = 'o-yammer'
        'Adallom'                       = 'o-skypeforbusiness'
        'ProjectWorkManagement'         = 'o-yammer'
        'TeamspaceAPI'                  = 'o-teams'
        'MicrosoftOffice'               = 'o-yammer'
        'PowerAppsService'              = 'o-onedrive'
        'SharePoint'                    = 'o-sharepoint'
        'MicrosoftCommunicationsOnline' = 'o-teams'
        'Deskless'                      = 'o-yammer'
        'MicrosoftStream'               = 'o-yammer'
        'Sway'                          = 'o-yammer'
        'To-Do'                         = 'o-yammer'
        'WhiteboardServices'            = 'o-yammer'
        'Windows'                       = 'o-skypeforbusiness'
        'YammerEnterprise'              = 'o-yammer'
    }

    return $AssignedMap

}
#EndRegion './Private/Get-AssignedMap.ps1' 33
#Region './Private/Get-AssignedNameMap.ps1' -1

function Get-AssignedNameMap {

    $AssignedNameMap = @{
        'AADPremiumService'             = 'Azure Active Directory Premium'
        'MultiFactorService'            = 'Azure Multi-Factor Authentication'
        'RMSOnline'                     = 'Azure Rights Management'
        'MicrosoftPrint'                = 'Cloud Print'
        'WindowsDefenderATP'            = 'Defender for Endpoint'
        'exchange'                      = 'Exchange Online'
        'ProcessSimple'                 = 'Flow'
        'OfficeForms'                   = 'Forms'
        'SCO'                           = 'Intune'
        'MicrosoftKaizala'              = 'Kaizala'
        'Adallom'                       = 'Microsoft Cloud App Security'
        'ProjectWorkManagement'         = 'Microsoft Planner'
        'TeamspaceAPI'                  = 'Microsoft Teams'
        'MicrosoftOffice'               = 'Office 365'
        'PowerAppsService'              = 'PowerApps'
        'SharePoint'                    = 'SharePoint Online'
        'MicrosoftCommunicationsOnline' = 'Skype for Business'
        'Deskless'                      = 'Staff Hub'
        'MicrosoftStream'               = 'Stream'
        'Sway'                          = 'Sway'
        'To-Do'                         = 'To-Do'
        'WhiteboardServices'            = 'Whiteboard'
        'Windows'                       = 'Windows'
        'YammerEnterprise'              = 'Yammer'
    }

    return $AssignedNameMap

}
#EndRegion './Private/Get-AssignedNameMap.ps1' 33
#Region './Private/Get-StringHash.ps1' -1

function Get-StringHash {
    Param($String)
    $StringBuilder = New-Object System.Text.StringBuilder
    [System.Security.Cryptography.HashAlgorithm]::Create('SHA1').ComputeHash([System.Text.Encoding]::UTF8.GetBytes($String)) | ForEach-Object {
        [Void]$StringBuilder.Append($_.ToString('x2'))
    }
    $StringBuilder.ToString()
}
#EndRegion './Private/Get-StringHash.ps1' 9
#Region './Private/Hudu/Get-HuduFormattedBlock.ps1' -1

function Get-HuduFormattedBlock ($Heading, $Body) {
    return @"
<div class="nasa__block" style="margin-bottom: 20px;">
    <header class='nasa__block-header' style="padding-top: 15px;">
            <h1>$Heading</h1>
        </header>
        <div style="padding-left: 15px; padding-right: 15px; padding-bottom: 15px;">
        $Body
    </div>
</div>
"@
}
#EndRegion './Private/Hudu/Get-HuduFormattedBlock.ps1' 13
#Region './Private/Hudu/Get-HuduFormattedField.ps1' -1

function Get-HuduFormattedField ($Title, $Value) {
    return @"
<div class="card__item">
    <div class="card__item-slot">
        $Title
    </div>
    <div class="card__item-slot">
        $Value
    </div>
</div>
"@
}

#EndRegion './Private/Hudu/Get-HuduFormattedField.ps1' 14
#Region './Private/Hudu/Get-HuduLinkBlock.ps1' -1

function Get-HuduLinkBlock($URL, $Icon, $Title) {
    return '<button class="button" style="background-color: var(--primary)" role="button"><a style="color: white;" role="button" href="{0}" target="_blank"><i class="{1} me-2"></i>{2}</a></button>' -f $URL, $Icon, $Title
}
#EndRegion './Private/Hudu/Get-HuduLinkBlock.ps1' 4
#Region './Public/Extension Functions/Add-HuduAssetLayoutField.ps1' -1

function Add-HuduAssetLayoutField {
    Param(
        $AssetLayoutId,
        $Label = 'Microsoft 365',
        $FieldType = 'RichText',
        $Position = 0,
        $ShowInList = $false
    )

    $M365Field = @{
        position     = $Position
        label        = $Label
        field_type   = $FieldType
        show_in_list = $ShowInList
        required     = $false
        expiration   = $false
    }

    $AssetLayout = Get-HuduAssetLayouts -LayoutId $AssetLayoutId

    if ($AssetLayout.fields.label -contains $Label) {
        return $AssetLayout
    }

    $AssetLayoutFields = [System.Collections.Generic.List[object]]::new()
    $AssetLayoutFields.Add($M365Field)
    foreach ($Field in $AssetLayout.fields) {
        $Field.position++
        $AssetLayoutFields.Add($Field)
    }
    Set-HuduAssetLayout -Id $AssetLayoutId -Fields $AssetLayoutFields
}
#EndRegion './Public/Extension Functions/Add-HuduAssetLayoutField.ps1' 33
#Region './Public/Extension Functions/Get-CippExtensionReportingData.ps1' -1

function Get-CippExtensionReportingData {
    <#
    .SYNOPSIS
        Retrieves cached data from CIPP Reporting DB for extension sync

    .DESCRIPTION
        This function replaces Get-ExtensionCacheData by retrieving data from the new CIPP Reporting DB
        instead of the legacy CacheExtensionSync table. It handles property mappings and data transformations
        to maintain compatibility with existing extension sync code.

    .PARAMETER TenantFilter
        The tenant to retrieve data for

    .PARAMETER IncludeMailboxes
        Include mailbox data (requires separate cache run with Type 'Mailboxes')

    .EXAMPLE
        $ExtensionCache = Get-CippExtensionReportingData -TenantFilter 'contoso.onmicrosoft.com'

    .EXAMPLE
        $ExtensionCache = Get-CippExtensionReportingData -TenantFilter 'contoso.onmicrosoft.com' -IncludeMailboxes

    .FUNCTIONALITY
        Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TenantFilter,

        [Parameter(Mandatory = $false)]
        [switch]$IncludeMailboxes
    )

    try {
        $Return = @{}

        # Direct mappings - loop through items and parse each .Data property (filter out count entries)
        $UsersItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'Users' | Where-Object { $_.RowKey -notlike '*-Count' }
        $Return.Users = if ($UsersItems) { $UsersItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

        $DomainsItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'Domains' | Where-Object { $_.RowKey -notlike '*-Count' }
        $Return.Domains = if ($DomainsItems) { $DomainsItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

        $ConditionalAccessItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'ConditionalAccessPolicies' | Where-Object { $_.RowKey -notlike '*-Count' }
        $Return.ConditionalAccess = if ($ConditionalAccessItems) { $ConditionalAccessItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

        $ManagedDevicesItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'ManagedDevices' | Where-Object { $_.RowKey -notlike '*-Count' }
        $Return.Devices = if ($ManagedDevicesItems) { $ManagedDevicesItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

        $OrganizationItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'Organization' | Where-Object { $_.RowKey -notlike '*-Count' }
        $Return.Organization = if ($OrganizationItems) { ($OrganizationItems | ForEach-Object { $_.Data | ConvertFrom-Json } | Select-Object -First 1) } else { $null }

        # Groups with inline members (members are now in each group object)
        $GroupsItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'Groups' | Where-Object { $_.RowKey -notlike '*-Count' }
        $Return.Groups = if ($GroupsItems) { $GroupsItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

        # Roles with inline members (members are now in each role object)
        $RolesItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'Roles' | Where-Object { $_.RowKey -notlike '*-Count' }
        $Return.AllRoles = if ($RolesItems) { $RolesItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

        # License mapping with property translation to maintain compatibility
        $LicenseItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'LicenseOverview' | Where-Object { $_.RowKey -notlike '*-Count' }
        if ($LicenseItems) {
            $ParsedLicenseData = $LicenseItems | ForEach-Object { $_.Data | ConvertFrom-Json }
            $Return.Licenses = $ParsedLicenseData | Select-Object @{N = 'skuId'; E = { $_.skuId } },
            @{N = 'skuPartNumber'; E = { $_.skuPartNumber } },
            @{N = 'consumedUnits'; E = { $_.CountUsed } },
            @{N = 'prepaidUnits'; E = { @{enabled = $_.TotalLicenses } } },
            @{N = 'TermInfo'; E = { @($_.TermInfo) } },
            @{N = 'servicePlans'; E = { $_.ServicePlans } }
        } else {
            $Return.Licenses = @()
        }

        # Intune policies (renamed from DeviceCompliancePolicies to IntuneDeviceCompliancePolicies)
        $IntunePoliciesItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'IntuneDeviceCompliancePolicies' | Where-Object { $_.RowKey -notlike '*-Count' }
        $Return.DeviceCompliancePolicies = if ($IntunePoliciesItems) { $IntunePoliciesItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

        # Secure Score
        $SecureScoreItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'SecureScore' | Where-Object { $_.RowKey -notlike '*-Count' }
        $Return.SecureScore = if ($SecureScoreItems) { $SecureScoreItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

        # Secure Score Control Profiles
        $SecureScoreControlProfilesItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'SecureScoreControlProfiles' | Where-Object { $_.RowKey -notlike '*-Count' }
        $Return.SecureScoreControlProfiles = if ($SecureScoreControlProfilesItems) { $SecureScoreControlProfilesItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

        # Mailboxes (optional - requires separate cache run)
        if ($IncludeMailboxes) {
            $MailboxesItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'Mailboxes' | Where-Object { $_.RowKey -notlike '*-Count' }
            $Return.Mailboxes = if ($MailboxesItems) { $MailboxesItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

            $CASMailboxItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'CASMailbox' | Where-Object { $_.RowKey -notlike '*-Count' }
            $Return.CASMailbox = if ($CASMailboxItems) { $CASMailboxItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

            $MailboxPermissionsItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'MailboxPermissions' | Where-Object { $_.RowKey -notlike '*-Count' }
            $Return.MailboxPermissions = if ($MailboxPermissionsItems) { $MailboxPermissionsItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

            $OneDriveUsageItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'OneDriveUsage' | Where-Object { $_.RowKey -notlike '*-Count' }
            $Return.OneDriveUsage = if ($OneDriveUsageItems) { $OneDriveUsageItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }

            $MailboxUsageItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type 'MailboxUsage' | Where-Object { $_.RowKey -notlike '*-Count' }
            $Return.MailboxUsage = if ($MailboxUsageItems) { $MailboxUsageItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }
        }

        return $Return

    } catch {
        Write-LogMessage -API 'ExtensionCache' -tenant $TenantFilter -message "Failed to retrieve extension reporting data: $($_.Exception.Message)" -sev Error
        throw
    }
}
#EndRegion './Public/Extension Functions/Get-CippExtensionReportingData.ps1' 113
#Region './Public/Extension Functions/Get-ExtensionAPIKey.ps1' -1

function Get-ExtensionAPIKey {
    <#
    .FUNCTIONALITY
        Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Extension,
        [switch]$Force
    )

    $Var = "Ext_$Extension"
    $APIKey = Get-Item -Path "env:$Var" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Value
    if ($APIKey -and -not $Force) {
        Write-Information "Using cached API Key for $Extension"
    } else {
        Write-Information "Retrieving API Key for $Extension"
        if ($env:AzureWebJobsStorage -eq 'UseDevelopmentStorage=true' -or $env:NonLocalHostAzurite -eq 'true') {
            $DevSecretsTable = Get-CIPPTable -tablename 'DevSecrets'
            $APIKey = (Get-CIPPAzDataTableEntity @DevSecretsTable -Filter "PartitionKey eq '$Extension' and RowKey eq '$Extension'").APIKey
        } else {
            $keyvaultname = ($env:WEBSITE_DEPLOYMENT_ID -split '-')[0]
            $APIKey = (Get-CippKeyVaultSecret -VaultName $keyvaultname -Name $Extension -AsPlainText)
        }
        Set-Item -Path "env:$Var" -Value $APIKey -Force -ErrorAction SilentlyContinue
    }
    return $APIKey
}
#EndRegion './Public/Extension Functions/Get-ExtensionAPIKey.ps1' 30
#Region './Public/Extension Functions/Get-ExtensionCacheData.ps1' -1

function Get-ExtensionCacheData {
    param(
        $TenantFilter
    )

    $Table = Get-CIPPTable -TableName CacheExtensionSync
    $CacheData = Get-CIPPAzDataTableEntity @Table -Filter "PartitionKey eq '$TenantFilter'"

    $Return = @{}
    foreach ($Data in $CacheData) {
        try {
            $Return[$Data.RowKey] = $Data.Data | ConvertFrom-Json -ErrorAction SilentlyContinue
        } catch {
            Write-Information "Failed to convert cache data for $($Data.RowKey) to JSON"
        }
    }
    return [PSCustomObject]$Return
}
#EndRegion './Public/Extension Functions/Get-ExtensionCacheData.ps1' 19
#Region './Public/Extension Functions/Get-ExtensionMapping.ps1' -1

function Get-ExtensionMapping {
    param(
        $Extension
    )

    $Table = Get-CIPPTable -TableName CippMapping
    return Get-CIPPAzDataTableEntity @Table -Filter "PartitionKey eq '$($Extension)Mapping'"
}
#EndRegion './Public/Extension Functions/Get-ExtensionMapping.ps1' 9
#Region './Public/Extension Functions/Push-CippExtensionData.ps1' -1

function Push-CippExtensionData {
    param(
        $TenantFilter,
        $Extension
    )

    $Table = Get-CIPPTable -TableName Extensionsconfig
    $Config = (Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json -ea stop

    switch ($Extension) {
        'Hudu' {
            if ($Config.Hudu.Enabled) {
                Write-Host 'Perfoming Hudu Extension Sync...'
                Invoke-HuduExtensionSync -Configuration $Config -TenantFilter $TenantFilter
            }
        }
        'CustomData' {
            Write-Host 'Perfoming Custom Data Extension Sync...'
            Invoke-CustomDataSync -TenantFilter $TenantFilter
        }
    }
}
#EndRegion './Public/Extension Functions/Push-CippExtensionData.ps1' 23
#Region './Public/Extension Functions/Register-CippExtensionScheduledTasks.ps1' -1

function Register-CIPPExtensionScheduledTasks {
    param(
        [switch]$Reschedule,
        [int64]$NextSync = (([datetime]::UtcNow.AddMinutes(30)) - (Get-Date '1/1/1970')).TotalSeconds,
        [string[]]$Extensions = @('Hudu', 'NinjaOne', 'CustomData')
    )

    # get extension configuration and mappings table
    $Table = Get-CIPPTable -TableName Extensionsconfig
    $Config = ((Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json -ea stop)
    $MappingsTable = Get-CIPPTable -TableName CippMapping

    # Get existing scheduled usertasks
    $ScheduledTasksTable = Get-CIPPTable -TableName ScheduledTasks
    $ScheduledTasks = Get-CIPPAzDataTableEntity @ScheduledTasksTable -Filter 'Hidden eq true' | Where-Object { $_.Command -match 'Sync-CippExtensionData' }
    $PushTasks = Get-CIPPAzDataTableEntity @ScheduledTasksTable -Filter 'Hidden eq true' | Where-Object { $_.Command -match 'Push-CippExtensionData' }
    $Tenants = Get-Tenants -IncludeErrors

    # Remove all legacy Sync-CippExtensionData tasks (now deprecated - extensions use CippReportingDB)
    Write-Information "Removing $($ScheduledTasks.Count) legacy Sync-CippExtensionData scheduled tasks"
    foreach ($Task in $ScheduledTasks) {
        Write-Information "Removing legacy task: $($Task.Name) for tenant $($Task.Tenant)"
        $Entity = $Task | Select-Object -Property PartitionKey, RowKey
        Remove-AzDataTableEntity -Force @ScheduledTasksTable -Entity $Entity
    }
    $ScheduledTasks = @() # Clear the list since we removed them all

    $MappedTenants = [System.Collections.Generic.List[string]]::new()
    foreach ($Extension in $Extensions) {
        $ExtensionConfig = $Config.$Extension
        if ($ExtensionConfig.Enabled -eq $true -or $Extension -eq 'CustomData') {
            if ($Extension -eq 'CustomData') {
                $CustomDataMappingTable = Get-CIPPTable -TableName CustomDataMappings
                $Mappings = Get-CIPPAzDataTableEntity @CustomDataMappingTable | ForEach-Object {
                    $Mapping = $_.JSON | ConvertFrom-Json
                    if ($Mapping.sourceType.value -eq 'reportingDb' -or $Mapping.sourceType.value -eq 'extensionSync') {
                        $TenantMappings = if ($Mapping.tenantFilter.value -contains 'AllTenants') {
                            $Tenants
                        } else {
                            foreach ($TenantMapping in $TenantMappings) {
                                $TenantMapping | Where-Object { $_.customerId -eq $Mapping.tenantFilter.value -or $_.defaultDomainName -eq $Mapping.tenantFilter.value }
                            }
                        }
                        foreach ($TenantMapping in $TenantMappings) {
                            [pscustomobject]@{
                                RowKey = $TenantMapping.customerId
                            }
                        }
                    }
                } | Sort-Object -Property RowKey -Unique

                if (($Mappings | Measure-Object).Count -eq 0) {
                    Write-Warning 'No tenants found for CustomData extension'
                    continue
                }
            } else {
                $Mappings = Get-CIPPAzDataTableEntity @MappingsTable -Filter "PartitionKey eq '$($Extension)Mapping'"
                $FieldMapping = Get-CIPPAzDataTableEntity @MappingsTable -Filter "PartitionKey eq '$($Extension)FieldMapping'"
            }
            $FieldSync = @{}
            $SyncTypes = [System.Collections.Generic.List[string]]::new()

            foreach ($Mapping in $FieldMapping) {
                $FieldSync[$Mapping.RowKey] = !([string]::IsNullOrEmpty($Mapping.IntegrationId))
            }

            $SyncTypes.Add('Overview')
            $SyncTypes.Add('Groups')
            $SyncTypes.Add('Users')
            $SyncTypes.Add('Mailboxes')
            $SyncTypes.Add('Devices')

            foreach ($Mapping in $Mappings) {
                $Tenant = $Tenants | Where-Object { $_.customerId -eq $Mapping.RowKey }
                if (!$Tenant) {
                    Write-Warning "Tenant $($Mapping.RowKey) not found"
                    continue
                }
                $MappedTenants.Add($Tenant.defaultDomainName)
                
                # Legacy Sync-CippExtensionData tasks are no longer needed - extensions now use CippReportingDB
                # All cache data is now collected by Push-CIPPDBCacheData scheduled tasks

                $ExistingPushTask = $PushTasks | Where-Object { $_.Tenant -eq $Tenant.defaultDomainName -and $_.SyncType -eq $Extension }
                if ((!$ExistingPushTask -or $Reschedule.IsPresent) -and $Extension -ne 'NinjaOne') {
                    # push cached data to extension

                    $Task = [pscustomobject]@{
                        Name          = "$Extension Extension Sync"
                        Command       = @{
                            value = 'Push-CippExtensionData'
                            label = 'Push-CippExtensionData'
                        }
                        Parameters    = [pscustomobject]@{
                            TenantFilter = $Tenant.defaultDomainName
                            Extension    = $Extension
                        }
                        Recurrence    = '1d'
                        ScheduledTime = $NextSync
                        TenantFilter  = $Tenant.defaultDomainName
                    }
                    if ($ExistingPushTask) {
                        $task | Add-Member -NotePropertyName 'RowKey' -NotePropertyValue $ExistingPushTask.RowKey -Force
                    }
                    $null = Add-CIPPScheduledTask -Task $Task -hidden $true -SyncType $Extension
                    Write-Information "Creating $Extension task for tenant $($Tenant.defaultDomainName)"
                }
            }
        } else {
            # remove existing scheduled tasks
            $PushTasks | Where-Object { $_.SyncType -eq $Extension } | ForEach-Object {
                Write-Information "Extension Disabled: Cleaning up scheduled task $($_.Name) for tenant $($_.Tenant)"
                $Entity = $_ | Select-Object -Property PartitionKey, RowKey
                Remove-AzDataTableEntity -Force @ScheduledTasksTable -Entity $Entity
            }
        }
    }
    $MappedTenants = $MappedTenants | Sort-Object -Unique

    foreach ($Task in $ScheduledTasks) {
        if ($Task.Tenant -notin $MappedTenants) {
            Write-Information "Tenant Removed: Cleaning up scheduled task $($Task.Name) for tenant $($Task.TenantFilter)"
            $Entity = $Task | Select-Object -Property PartitionKey, RowKey
            Remove-AzDataTableEntity -Force @ScheduledTasksTable -Entity $Entity
        }
    }
    foreach ($Task in $PushTasks) {
        if ($Task.Tenant -notin $MappedTenants) {
            Write-Information "Tenant Removed: Cleaning up scheduled task $($Task.Name) for tenant $($Task.TenantFilter)"
            $Entity = $Task | Select-Object -Property PartitionKey, RowKey
            Remove-AzDataTableEntity -Force @ScheduledTasksTable -Entity $Entity
        }
    }
}
#EndRegion './Public/Extension Functions/Register-CippExtensionScheduledTasks.ps1' 135
#Region './Public/Extension Functions/Remove-ExtensionAPIKey.ps1' -1

function Remove-ExtensionAPIKey {
    <#
    .FUNCTIONALITY
        Internal
    #>
    param(
        [Parameter(Mandatory = $true)]
        [string]$Extension
    )

    $Var = "Ext_$Extension"
    if ($env:AzureWebJobsStorage -eq 'UseDevelopmentStorage=true' -or $env:NonLocalHostAzurite -eq 'true') {
        $DevSecretsTable = Get-CIPPTable -tablename 'DevSecrets'
        $DevSecretRows = Get-AzDataTableEntity @DevSecretsTable -Filter "PartitionKey eq '$Extension'"
        if ($DevSecretRows) {
            Remove-AzDataTableEntity @DevSecretsTable -Entity @($DevSecretRows) -Force -ErrorAction Stop
            Write-Information "Deleted $(@($DevSecretRows).Count) DevSecrets row(s) for '$Extension'."
        } else {
            Write-Information "No existing DevSecrets row found for '$Extension' to delete."
        }
    } else {
        $keyvaultname = ($env:WEBSITE_DEPLOYMENT_ID -split '-')[0]
        try {
            $null = Remove-CippKeyVaultSecret -VaultName $keyvaultname -Name $Extension
        } catch {
            Write-Warning "Unable to delete secret '$Extension' from '$keyvaultname'"
        }
    }

    Remove-Item -Path "env:$Var" -Force -ErrorAction SilentlyContinue

    return $true
}
#EndRegion './Public/Extension Functions/Remove-ExtensionAPIKey.ps1' 34
#Region './Public/Extension Functions/Set-ExtensionAPIKey.ps1' -1

function Set-ExtensionAPIKey {
    <#
    .FUNCTIONALITY
        Internal
    #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingConvertToSecureStringWithPlainText', '', Scope = 'Function')]
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Extension,
        [Parameter(Mandatory = $true)]
        [string]$APIKey
    )

    if ($PSCmdlet.ShouldProcess('API Key', "Set API Key for $Extension")) {
        $Var = "Ext_$Extension"
        if ($env:AzureWebJobsStorage -eq 'UseDevelopmentStorage=true' -or $env:NonLocalHostAzurite -eq 'true') {
            $DevSecretsTable = Get-CIPPTable -tablename 'DevSecrets'
            $Secret = [PSCustomObject]@{
                'PartitionKey' = $Extension
                'RowKey'       = $Extension
                'APIKey'       = $APIKey
            }
            Add-CIPPAzDataTableEntity @DevSecretsTable -Entity $Secret -Force
        } else {
            $keyvaultname = ($env:WEBSITE_DEPLOYMENT_ID -split '-')[0]
            $null = Set-CippKeyVaultSecret -VaultName $keyvaultname -Name $Extension -SecretValue (ConvertTo-SecureString -AsPlainText -Force -String $APIKey)
        }
        Set-Item -Path "env:$Var" -Value $APIKey -Force -ErrorAction SilentlyContinue
    }
    return $true
}
#EndRegion './Public/Extension Functions/Set-ExtensionAPIKey.ps1' 33
#Region './Public/Extension Functions/Set-ExtensionFieldMapping.ps1' -1

function Set-ExtensionFieldMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping,
        $Extension,
        $APIName,
        $Request,
        $TriggerMetadata
    )

    foreach ($Mapping in ([pscustomobject]$Request.Body).psobject.properties) {
        $AddObject = @{
            PartitionKey    = "$($Extension)FieldMapping"
            RowKey          = "$($mapping.name)"
            IntegrationId   = "$($mapping.value.value)"
            IntegrationName = "$($mapping.value.label)"
        }
        Add-AzDataTableEntity @CIPPMapping -Entity $AddObject -Force
        Write-LogMessage -API $APINAME -headers $Request.Headers -message "Added mapping for $($mapping.name)." -Sev 'Info'
    }
    $Result = [pscustomobject]@{'Results' = 'Successfully edited mapping table.' }

    Return $Result
}
#EndRegion './Public/Extension Functions/Set-ExtensionFieldMapping.ps1' 25
#Region './Public/Extension Functions/Sync-CippExtensionData.ps1' -1

function Sync-CippExtensionData {
    <#
    .FUNCTIONALITY
        Internal
    #>
    [CmdletBinding()]
    param(
        $TenantFilter,
        $SyncType
    )

    # Legacy cache system is deprecated - all extensions now use CippReportingDB
    throw 'Sync-CippExtensionData is deprecated. This scheduled task should be removed. Extensions now use Push-CIPPDBCacheData and Get-CippExtensionReportingData.'

    $Table = Get-CIPPTable -TableName ExtensionSync
    $Extensions = Get-CIPPAzDataTableEntity @Table -Filter "PartitionKey eq '$($SyncType)'"
    $LastSync = $Extensions | Where-Object { $_.RowKey -eq $TenantFilter }
    $CacheTable = Get-CIPPTable -tablename 'CacheExtensionSync'

    if (!$LastSync) {
        $LastSync = @{
            PartitionKey = $SyncType
            RowKey       = $TenantFilter
            Status       = 'Not Synced'
            Error        = ''
            LastSync     = 'Never'
        }
        $null = Add-CIPPAzDataTableEntity @Table -Entity $LastSync
    }

    try {
        switch ($SyncType) {
            'Overview' {
                # Build bulk requests array.
                [System.Collections.Generic.List[PSCustomObject]]$TenantRequests = @(
                    @{
                        id     = 'TenantDetails'
                        method = 'GET'
                        url    = '/organization'
                    },
                    @{
                        id     = 'AllRoles'
                        method = 'GET'
                        url    = '/directoryRoles'
                    },
                    @{
                        id     = 'Domains'
                        method = 'GET'
                        url    = '/domains?$top=99'
                    },
                    @{
                        id     = 'Licenses'
                        method = 'GET'
                        url    = '/subscribedSkus'
                    },
                    @{
                        id     = 'ConditionalAccess'
                        method = 'GET'
                        url    = '/identity/conditionalAccess/policies'
                    },
                    @{
                        id     = 'SecureScoreControlProfiles'
                        method = 'GET'
                        url    = '/security/secureScoreControlProfiles?$top=999'
                    },
                    @{
                        id     = 'Subscriptions'
                        method = 'GET'
                        url    = '/directory/subscriptions?$top=999'
                    },
                    @{
                        id     = 'OneDriveUsage'
                        method = 'GET'
                        url    = "reports/getOneDriveUsageAccountDetail(period='D7')?`$format=application%2fjson"
                    },
                    @{
                        id     = 'MailboxUsage'
                        method = 'GET'
                        url    = "reports/getMailboxUsageDetail(period='D7')?`$format=application%2fjson"
                    }
                )

                $SingleGraphQueries = @(@{
                        id           = 'SecureScore'
                        graphRequest = @{
                            uri          = 'https://graph.microsoft.com/beta/security/secureScores?$top=1'
                            noPagination = $true
                        }
                    })
                $AdditionalRequests = @(
                    @{
                        ParentId     = 'AllRoles'
                        graphRequest = @{
                            url    = '/directoryRoles/{0}/members?$select=id,displayName,userPrincipalName'
                            method = 'GET'
                        }
                    }
                )
            }
            'Users' {
                [System.Collections.Generic.List[PSCustomObject]]$TenantRequests = @(
                    @{
                        id     = 'Users'
                        method = 'GET'
                        url    = '/users?$top=999&$select=id,accountEnabled,businessPhones,city,createdDateTime,companyName,country,department,displayName,faxNumber,givenName,isResourceAccount,jobTitle,mail,mailNickname,mobilePhone,onPremisesDistinguishedName,officeLocation,onPremisesLastSyncDateTime,otherMails,postalCode,preferredDataLocation,preferredLanguage,proxyAddresses,showInAddressList,state,streetAddress,surname,usageLocation,userPrincipalName,userType,assignedLicenses,onPremisesSyncEnabled'
                    }
                )
            }
            'Groups' {
                [System.Collections.Generic.List[PSCustomObject]]$TenantRequests = @(
                    @{
                        id     = 'Groups'
                        method = 'GET'
                        url    = '/groups?$top=999&$select=id,createdDateTime,displayName,description,mail,mailEnabled,mailNickname,resourceProvisioningOptions,securityEnabled,visibility,organizationId,onPremisesSamAccountName,membershipRule,grouptypes,onPremisesSyncEnabled,resourceProvisioningOptions,userPrincipalName'
                    }
                )
                $AdditionalRequests = @(
                    @{
                        ParentId     = 'Groups'
                        graphRequest = @{
                            url    = '/groups/{0}/members?$select=id,displayName,userPrincipalName'
                            method = 'GET'
                        }
                    }
                )
            }
            'Devices' {
                [System.Collections.Generic.List[PSCustomObject]]$TenantRequests = @(
                    @{
                        id     = 'Devices'
                        method = 'GET'
                        url    = '/deviceManagement/managedDevices?$top=999'
                    },
                    @{
                        id     = 'DeviceCompliancePolicies'
                        method = 'GET'
                        url    = '/deviceManagement/deviceCompliancePolicies?$top=999'
                    },
                    @{
                        id     = 'DeviceApps'
                        method = 'GET'
                        url    = '/deviceAppManagement/mobileApps?$select=id,displayName,description,publisher,isAssigned,createdDateTime,lastModifiedDateTime&$top=999'
                    }
                )

                $AdditionalRequests = @(
                    @{
                        ParentId     = 'DeviceCompliancePolicies'
                        graphRequest = @{
                            url    = '/deviceManagement/deviceCompliancePolicies/{0}/deviceStatuses?$top=999'
                            method = 'GET'
                        }
                    }
                )
            }
            'Mailboxes' {
                $Select = 'id,ExchangeGuid,ArchiveGuid,UserPrincipalName,DisplayName,PrimarySMTPAddress,RecipientType,RecipientTypeDetails,EmailAddresses,WhenSoftDeleted,IsInactiveMailbox,ForwardingSmtpAddress,DeliverToMailboxAndForward,ForwardingAddress,HiddenFromAddressListsEnabled,ExternalDirectoryObjectId,MessageCopyForSendOnBehalfEnabled,MessageCopyForSentAsEnabled'
                $ExoRequest = @{
                    tenantid  = $TenantFilter
                    cmdlet    = 'Get-Mailbox'
                    cmdParams = @{}
                    Select    = $Select
                }
                $Mailboxes = (New-ExoRequest @ExoRequest) | Select-Object id, ExchangeGuid, ArchiveGuid, WhenSoftDeleted, @{ Name = 'UPN'; Expression = { $_.'UserPrincipalName' } },
                @{ Name = 'displayName'; Expression = { $_.'DisplayName' } },
                @{ Name = 'primarySmtpAddress'; Expression = { $_.'PrimarySMTPAddress' } },
                @{ Name = 'recipientType'; Expression = { $_.'RecipientType' } },
                @{ Name = 'recipientTypeDetails'; Expression = { $_.'RecipientTypeDetails' } },
                @{ Name = 'AdditionalEmailAddresses'; Expression = { ($_.'EmailAddresses' | Where-Object { $_ -clike 'smtp:*' }).Replace('smtp:', '') -join ', ' } },
                @{Name = 'ForwardingSmtpAddress'; Expression = { $_.'ForwardingSmtpAddress' -replace 'smtp:', '' } },
                @{Name = 'InternalForwardingAddress'; Expression = { $_.'ForwardingAddress' } },
                DeliverToMailboxAndForward,
                HiddenFromAddressListsEnabled,
                ExternalDirectoryObjectId,
                MessageCopyForSendOnBehalfEnabled,
                MessageCopyForSentAsEnabled

                $Entity = @{
                    PartitionKey = $TenantFilter
                    SyncType     = 'Mailboxes'
                    RowKey       = 'Mailboxes'
                    Data         = [string]($Mailboxes | ConvertTo-Json -Depth 10 -Compress)
                }
                $null = Add-CIPPAzDataTableEntity @CacheTable -Entity $Entity -Force

                $SingleGraphQueries = @(
                    @{
                        id           = 'CASMailbox'
                        graphRequest = @{
                            uri          = "https://outlook.office365.com/adminapi/beta/$($tenantfilter)/CasMailbox"
                            Tenantid     = $tenantfilter
                            scope        = 'ExchangeOnline'
                            noPagination = $true
                        }
                    }
                )

                # Bulk request mailbox permissions using New-ExoBulkRequest for each mailbox - mailboxPermissions is not a valid graph query
                $ExoBulkRequests = foreach ($Mailbox in $Mailboxes) {
                    @{
                        CmdletInput = @{
                            CmdletName = 'Get-MailboxPermission'
                            Parameters = @{ Identity = $Mailbox.UPN }
                        }
                    }
                }
                $MailboxPermissions = New-ExoBulkRequest -cmdletArray @($ExoBulkRequests) -tenantid $TenantFilter
                $Entity = @{
                    PartitionKey = $TenantFilter
                    SyncType     = 'Mailboxes'
                    RowKey       = 'MailboxPermissions'
                    Data         = [string]($MailboxPermissions | ConvertTo-Json -Depth 10 -Compress)
                }
                $null = Add-CIPPAzDataTableEntity @CacheTable -Entity $Entity -Force
            }
        }

        if ($TenantRequests) {
            Write-Information "Requesting tenant information for $TenantFilter $SyncType"
            try {
                $TenantResults = New-GraphBulkRequest -Requests @($TenantRequests) -tenantid $TenantFilter
            } catch {
                throw "Failed to fetch bulk company data: $_"
            }

            $TenantResults | Select-Object id, body | ForEach-Object {
                $Data = $_.body.value ?? $_.body
                if ($Data -match '^eyJ') {
                    # base64 decode
                    $Data = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($Data)) | ConvertFrom-Json
                    $Data = $Data.Value
                }

                # Filter out excluded licenses to respect the ExcludedLicenses table
                if ($_.id -eq 'Licenses') {
                    $LicenseTable = Get-CIPPTable -TableName ExcludedLicenses
                    $ExcludedSkuList = Get-CIPPAzDataTableEntity @LicenseTable
                    if ($ExcludedSkuList) {
                        $Data = $Data | Where-Object { $_.skuId -notin $ExcludedSkuList.GUID }
                    }
                }

                $Entity = @{
                    PartitionKey = $TenantFilter
                    RowKey       = $_.id
                    SyncType     = $SyncType
                    Data         = [string]($Data | ConvertTo-Json -Depth 10 -Compress)
                }
                $null = Add-CIPPAzDataTableEntity @CacheTable -Entity $Entity -Force
            }

            if ($AdditionalRequests) {
                foreach ($AdditionalRequest in $AdditionalRequests) {
                    if ($AdditionalRequest.Filter) {
                        $Filter = [scriptblock]::Create($AdditionalRequest.Filter)
                    } else {
                        $Filter = { $true }
                    }
                    $ParentId = $AdditionalRequest.ParentId
                    $GraphRequest = $AdditionalRequest.graphRequest.PSObject.Copy()
                    $AdditionalRequestQueries = ($TenantResults | Where-Object { $_.id -eq $ParentId }).body.value | Where-Object $Filter | ForEach-Object {
                        if ($_.id) {
                            [PSCustomObject]@{
                                id     = $_.id
                                method = $GraphRequest.method
                                url    = $GraphRequest.url -f $_.id
                            }
                        }
                    }
                    if (($AdditionalRequestQueries | Measure-Object).Count -gt 0) {
                        try {
                            $AdditionalResults = New-GraphBulkRequest -Requests @($AdditionalRequestQueries) -tenantid $TenantFilter
                        } catch {
                            throw $_
                        }
                        if ($AdditionalResults) {
                            $AdditionalResults | ForEach-Object {
                                $Data = $_.body.value ?? $_.body
                                if ($Data -match '^eyJ') {
                                    # base64 decode
                                    $Data = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($Data)) | ConvertFrom-Json
                                    $Data = $Data.Value
                                }
                                $Entity = @{
                                    PartitionKey = $TenantFilter
                                    SyncType     = $SyncType
                                    RowKey       = '{0}_{1}' -f $ParentId, $_.id
                                    Data         = [string]($Data | ConvertTo-Json -Depth 10 -Compress)
                                }
                                try {
                                    $null = Add-CIPPAzDataTableEntity @CacheTable -Entity $Entity -Force
                                } catch {
                                    throw $_
                                }
                            }
                        }

                    }
                }
            }
        }

        if ($SingleGraphQueries) {
            foreach ($SingleGraphQuery in $SingleGraphQueries) {
                $Request = $SingleGraphQuery.graphRequest
                $Data = New-GraphGetRequest @Request -tenantid $TenantFilter
                $Entity = @{
                    PartitionKey = $TenantFilter
                    SyncType     = $SyncType
                    RowKey       = $SingleGraphQuery.id
                    Data         = [string]($Data | ConvertTo-Json -Depth 10 -Compress)
                }
                $null = Add-CIPPAzDataTableEntity @CacheTable -Entity $Entity -Force
            }
        }

        $LastSync.LastSync = [datetime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')
        $LastSync.Status = 'Completed'
        $LastSync.Error = ''
    } catch {
        $LastSync.Status = 'Failed'
        $LastSync.Error = [string](Get-CippException -Exception $_ | ConvertTo-Json -Compress)
        throw "Failed to sync data: $(Get-NormalizedError -message $_.Exception.Message)"
    } finally {
        Add-CIPPAzDataTableEntity @Table -Entity $LastSync -Force
    }
    return $LastSync
}
#EndRegion './Public/Extension Functions/Sync-CippExtensionData.ps1' 329
#Region './Public/Get-ExtensionRateLimit.ps1' -1

function Get-ExtensionRateLimit($ExtensionName, $ExtensionPartitionKey, $RateLimit, $WaitTime) {
    
    $MappingTable = Get-CIPPTable -TableName CippMapping
    $CurrentMap = (Get-CIPPAzDataTableEntity @MappingTable -Filter "PartitionKey eq '$ExtensionPartitionKey'")
    $CurrentMap | ForEach-Object {
        if ($Null -ne $_.lastEndTime -and $_.lastEndTime -ne '') {
            $_.lastEndTime = (Get-Date($_.lastEndTime))
        } else {
            $_ | Add-Member -NotePropertyName lastEndTime -NotePropertyValue $Null -Force
        }

        if ($Null -ne $_.lastStartTime -and $_.lastStartTime -ne '') {
            $_.lastStartTime = (Get-Date($_.lastStartTime))
        } else {
            $_ | Add-Member -NotePropertyName lastStartTime -NotePropertyValue $Null -Force
        }
    }

    # Check Global Rate Limiting
    try {
        $ActiveJobs = $CurrentMap | Where-Object { ($Null -ne $_.lastStartTime) -and ($_.lastStartTime -gt (Get-Date).AddMinutes(-10)) -and ($Null -eq $_.lastEndTime -or $_.lastStartTime -gt $_.lastEndTime) }
    } catch {
        $ActiveJobs = 'FirstRun'
    }
    if (($ActiveJobs | Measure-Object).count -ge $RateLimit) {
        Write-Host "Rate Limiting. Currently $($ActiveJobs.count) Active Jobs"
        $CurrentMap = Get-ExtensionRateLimit -ExtensionName $ExtensionName -ExtensionPartitionKey $ExtensionPartitionKey -RateLimit $RateLimit -WaitTime $WaitTime
    }

    Return $CurrentMap

}
#EndRegion './Public/Get-ExtensionRateLimit.ps1' 33
#Region './Public/GitHub/Get-GitHubBranch.ps1' -1

function Get-GitHubBranch {
    <#
    .SYNOPSIS
        Get GitHub Branch
    .DESCRIPTION
        Get GitHub Branch
    .
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$FullName
    )

    Invoke-GitHubApiRequest -Path "repos/$FullName/branches" -Method GET
}
#EndRegion './Public/GitHub/Get-GitHubBranch.ps1' 17
#Region './Public/GitHub/Get-GitHubFileContents.ps1' -1

function Get-GitHubFileContents {
    [CmdletBinding()]
    param (
        [Parameter(ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        $FullName,

        [Parameter(ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        $Path,

        [Parameter(ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        $Branch
    )

    process {
        $Path = "repos/$($FullName)/contents/$($Path)?ref=$($Branch)"
        #Write-Information $Path
        $File = Invoke-GitHubApiRequest -Path $Path -Method GET
        $content = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($File.content))
        #If the first character is a BOM, remove it
        if ($content[0] -eq [char]65279) { $content = $content.Substring(1) }
        return [PSCustomObject]@{
            name    = $File.name
            path    = $File.path
            content = $content
            sha     = $File.sha
            size    = $File.size
        }
    }
}
#EndRegion './Public/GitHub/Get-GitHubFileContents.ps1' 30
#Region './Public/GitHub/Get-GitHubFileTree.ps1' -1

function Get-GitHubFileTree {
    <#
    .SYNOPSIS
        Get GitHub File Tree
    .DESCRIPTION
        Get GitHub File Tree
    .
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$FullName,
        [Parameter(Mandatory = $true)]
        [string]$Branch
    )

    Invoke-GitHubApiRequest -Path "repos/$FullName/git/trees/$($Branch)?recursive=1" -Method GET
}
#EndRegion './Public/GitHub/Get-GitHubFileTree.ps1' 19
#Region './Public/GitHub/Invoke-GitHubApiRequest.ps1' -1

function Invoke-GitHubApiRequest {
    [CmdletBinding()]
    param(
        [string]$Method = 'GET',
        [Parameter(Mandatory = $true)]
        [string]
        $Path,
        [Parameter()]
        $Body,
        [string]$Accept = 'application/vnd.github+json',
        [switch]$ReturnHeaders
    )

    $Table = Get-CIPPTable -TableName Extensionsconfig
    $ExtensionConfig = (Get-CIPPAzDataTableEntity @Table).config
    if ($ExtensionConfig -and (Test-Json -Json $ExtensionConfig)) {
        $Configuration = ($ExtensionConfig | ConvertFrom-Json).GitHub
    } else {
        $Configuration = @{ Enabled = $false }
    }

    if ($Configuration.Enabled) {
        $APIKey = Get-ExtensionAPIKey -Extension 'GitHub'
        $Headers = @{
            Authorization          = "Bearer $($APIKey)"
            'User-Agent'           = 'CIPP'
            Accept                 = $Accept
            'X-GitHub-API-Version' = '2022-11-28'
        }

        $FullUri = "https://api.github.com/$Path"
        Write-Verbose "[$Method] $FullUri"

        $RestMethod = @{
            Method  = $Method
            Uri     = $FullUri
            Headers = $Headers
        }
        if ($ReturnHeaders.IsPresent) {
            $RestMethod.ResponseHeadersVariable = 'ResponseHeaders'
        }

        if ($Body) {
            $RestMethod.Body = $Body | ConvertTo-Json -Depth 10
            $RestMethod.ContentType = 'application/json'
        }

        try {
            $Response = Invoke-RestMethod @RestMethod
            if ($ReturnHeaders.IsPresent) {
                $Response | Add-Member -MemberType NoteProperty -Name Headers -Value $ResponseHeaders
                return $Response
            } else {
                return $Response
            }
        } catch {
            throw $_.Exception.Message
        }
    } else {
        $Action = @{
            Action = 'ApiCall'
            Path   = $Path
            Method = $Method
            Body   = $Body
            Accept = $Accept
        }
        $Body = $Action | ConvertTo-Json -Depth 10

        (Invoke-RestMethod -Uri 'https://cippy.azurewebsites.net/api/ExecGitHubAction' -Method POST -Body $Body -ContentType 'application/json').Results
    }
}
#EndRegion './Public/GitHub/Invoke-GitHubApiRequest.ps1' 72
#Region './Public/GitHub/New-GitHubRepo.ps1' -1

function New-GitHubRepo {
    <#
    .SYNOPSIS
    Create a new GitHub repository

    .DESCRIPTION
    This function creates a new GitHub repository

    .PARAMETER Name
    The name of the repository

    .PARAMETER Description
    The description of the repository

    .PARAMETER Private
    Whether the repository is private

    .PARAMETER Type

    #>
    [CmdletBinding(SupportsShouldProcess = $true)]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [string]$Description,
        [switch]$Private,
        [ValidateSet('User', 'Org')]
        [string]$Type = 'User',
        [string]$Org,
        [string]$License = 'agpl-3.0'
    )

    $Body = @{
        name             = $Name
        description      = $Description
        private          = $Private.IsPresent
        license_template = $License
    }

    if ($Type -eq 'Org') {
        $Path = "orgs/$Org/repos"
        $Owner = $Org
    } else {
        $Path = 'user/repos'
        $Owner = (Invoke-GitHubApiRequest -Path 'user').login
    }

    # Check if repo exists
    try {
        $Existing = Invoke-GitHubApiRequest -Path "repos/$Owner/$Name"
        if ($Existing.id) {
            return $Existing
        }
    } catch { }
    if ($PSCmdlet.ShouldProcess("Create repository '$Name'")) {
        Invoke-GitHubApiRequest -Path $Path -Method POST -Body $Body
    }
}
#EndRegion './Public/GitHub/New-GitHubRepo.ps1' 59
#Region './Public/GitHub/Push-GitHubContent.ps1' -1

function Push-GitHubContent {
    <#
    .SYNOPSIS
        Update file content in GitHub repository
    .DESCRIPTION
        Update file content in GitHub repository
    .PARAMETER FullName
        The full name of the repository (e.g. 'octocat/Hello-World')
    .PARAMETER Path
        The path to the file in the repository
    .PARAMETER Branch
        The branch to update the file in (default: 'main')
    .PARAMETER Content
        The new content of the file
    .PARAMETER Message
        The commit message
    .EXAMPLE
        Push-GitHubContent -FullName 'octocat/Hello-World' -Path 'README.md' -Content 'Hello, World!' -Message 'Update README.md'
    #>
    [CmdletBinding()]
    param (
        [string]$FullName,
        [string]$Path,
        [string]$Branch = 'main',
        [string]$Content,
        [string]$Message
    )

    $ContentBase64 = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($Content))
    try {
        $ContentSha = (Invoke-GitHubApiRequest -Path "repos/$($FullName)/contents/$($Path)?ref=$($Branch)").sha
    } catch {
        $ContentSha = $null
    }
    $Filename = Split-Path $Path -Leaf

    $Body = @{
        message = $Message ?? "Update $($Filename)"
        content = $ContentBase64
        branch  = $Branch
    }
    if ($ContentSha) {
        $Body.sha = $ContentSha
    }

    Invoke-GitHubApiRequest -Path "repos/$($FullName)/contents/$($Path)" -Method PUT -Body $Body
}
#EndRegion './Public/GitHub/Push-GitHubContent.ps1' 48
#Region './Public/GitHub/Search-GitHub.ps1' -1

function Search-GitHub {
    [CmdletBinding()]
    param (
        [string[]]$Repository,
        [string]$User,
        [string]$Org,
        [string]$Path,
        [switch]$IncludeForks,
        [string[]]$SearchTerm,
        [string]$Language,
        [ValidateSet('code', 'commits', 'issues', 'users', 'repositories', 'topics', 'labels')]
        [string]$Type = 'code'
    )

    $QueryParts = [System.Collections.Generic.List[string]]::new()
    if ($SearchTerm) {
        $SearchTermParts = [System.Collections.Generic.List[string]]::new()
        foreach ($Term in $SearchTerm) {
            $SearchTermParts.Add("`"$Term`"")
        }
        if (($SearchTermParts | Measure-Object).Count -gt 1) {
            $QueryParts.Add(($SearchTermParts -join ' OR '))
        } else {
            $QueryParts.Add($SearchTermParts[0])
        }
    }
    if ($Repository) {
        $RepoParts = [System.Collections.Generic.List[string]]::new()
        foreach ($Repo in $Repository) {
            $RepoParts.Add("repo:$Repo")
        }
        if (($RepoParts | Measure-Object).Count -gt 1) {
            $QueryParts.Add('(' + ($RepoParts -join ' OR ') + ')')
        } else {
            $QueryParts.Add($RepoParts[0])
        }
    }
    if ($User) {
        $QueryParts.Add("user:$User")
    }
    if ($Org) {
        $QueryParts.Add("org:$Org")
    }
    if ($Path) {
        $QueryParts.Add("path:$Path")
    }
    if ($Language) {
        $QueryParts.Add("language:$Language")
    }
    if ($IncludeForks.IsPresent) {
        $QueryParts.Add('fork:true')
    }

    $Query = $QueryParts -join ' '
    Write-Information "Query: $Query"
    Invoke-GitHubApiRequest -Path "search/$($Type)?q=$($Query)" -Method GET
}
#EndRegion './Public/GitHub/Search-GitHub.ps1' 58
#Region './Public/Gradient/Get-GradientToken.ps1' -1

function Get-GradientToken {
    param(
        $Configuration
    )
    if ($Configuration.vendorKey) {
        $keyvaultname = ($env:WEBSITE_DEPLOYMENT_ID -split '-')[0]
        $partnerApiKey = (Get-CippKeyVaultSecret -VaultName $keyvaultname -Name 'Gradient' -AsPlainText)
        $authorizationToken = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$($configuration.vendorKey):$($partnerApiKey)"))

        $headers = [hashtable]@{
            'Accept'         = 'application/json'
            'GRADIENT-TOKEN' = $authorizationToken
        }

        try {
            return [hashtable]$headers
        } catch {
            return $false
        }
    } else {
        return $false
    }
}
#EndRegion './Public/Gradient/Get-GradientToken.ps1' 24
#Region './Public/Gradient/New-GradientAlert.ps1' -1

function New-GradientAlert {
    [CmdletBinding()]
    param (
        $title,
        $description,
        $client
    )

    $APINAME = 'GradientAlert'
    $Table = Get-CIPPTable -TableName Extensionsconfig
    $Configuration = ((Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json).Gradient
    #creating accounts in Gradient
    try {
        $GradientToken = Get-GradientToken -Configuration $Configuration
        $ExistingAccounts = (Invoke-RestMethod -Uri 'https://app.usegradient.com/api/vendor-api/organization/accounts' -Method GET -Headers $GradientToken) | Where-Object id -EQ $client
        $NewAccounts = ConvertTo-Json -Depth 10 -InputObject @([PSCustomObject]@{
                name        = $_.displayName
                description = $_.defaultDomainName
                id          = $_.defaultDomainName
            })
        if ($ExistingAccounts -eq $null) {
            Invoke-RestMethod -Uri 'https://app.usegradient.com/api/vendor-api/organization/accounts' -Method POST -Headers $GradientToken -Body $NewAccounts -ContentType 'application/json'
        }
        #Send the alert
        $body = @"
        {"priority":1,"status":1,"title":"$title","description":"$description","alertId":"$(New-Guid)"}
"@
        $AlertId = Invoke-RestMethod -Uri "https://app.usegradient.com/api/vendor-api/alerting/$($client)" -Method POST -Headers $GradientToken -Body $body -ContentType 'application/json'
        #check if the message is actually sent, if not, abort and log. check url: https://app.usegradient.com/api/vendor-api/alerting/debug/{messageId}
        $AlertStatus = Invoke-RestMethod -Uri "https://app.usegradient.com/api/vendor-api/alerting/debug/$($AlertId.messageId)" -Method GET -Headers $GradientToken
        if ($AlertStatus.status -eq 'failed') {
            Write-LogMessage -API $APINAME -message "Failed to create ticket in Gradient API. Error: $($AlertStatus.errors)" -Sev 'Error' -tenant $client
        }

    } catch {
        Write-LogMessage -API $APINAME -message "Failed to create ticket in Gradient API. Error: $($_.Exception.Message)" -Sev 'Error' -tenant 'GradientAPI'
    }


}
#EndRegion './Public/Gradient/New-GradientAlert.ps1' 41
#Region './Public/Gradient/New-GradientServiceSyncRun.ps1' -1

function New-GradientServiceSyncRun {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param ()

    $Table = Get-CIPPTable -TableName Extensionsconfig
    $Configuration = ((Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json).Gradient
    $Tenants = Get-Tenants
    #creating accounts in Gradient
    try {
        $GradientToken = Get-GradientToken -Configuration $Configuration
        $ExistingAccounts = (Invoke-RestMethod -Uri 'https://app.usegradient.com/api/vendor-api/organization/accounts' -Method GET -Headers $GradientToken)
        $NewAccounts = $Tenants | Where-Object defaultDomainName -NotIn $ExistingAccounts.id | ForEach-Object {
            [PSCustomObject]@{
                name        = $_.displayName
                description = $_.defaultDomainName
                id          = $_.defaultDomainName
            }
        } | ConvertTo-Json -Depth 10
        if ($NewAccounts) { Invoke-RestMethod -Uri 'https://app.usegradient.com/api/vendor-api/organization/accounts' -Method POST -Headers $GradientToken -Body $NewAccounts -ContentType 'application/json' }
        #setting the integration to active
        $ExistingIntegrations = (Invoke-RestMethod -Uri 'https://app.usegradient.com/api/vendor-api/organization' -Method GET -Headers $GradientToken)
        if ($ExistingIntegrations.Status -ne 'active') {
            $ActivateRequest = Invoke-RestMethod -Uri 'https://app.usegradient.com/api/vendor-api/organization/status/active' -Method PATCH -Headers $GradientToken
        }
    } catch {
        Write-LogMessage -API $APINAME -message "Failed to create tenants in Gradient API. Error: $($_.Exception.Message)" -Sev 'Error' -tenant 'GradientAPI'
    }

    $ConvertTable = [System.IO.File]::ReadAllText((Join-Path $env:CIPPRootPath 'Config\ConversionTable.csv')) | ConvertFrom-Csv
    $Table = Get-CIPPTable -TableName cachelicenses
    $LicenseTable = Get-CIPPTable -TableName ExcludedLicenses
    $ExcludedSkuList = Get-CIPPAzDataTableEntity @LicenseTable

    $RawGraphRequest = $Tenants | ForEach-Object -Parallel {
        $domainName = $_.defaultDomainName
        Import-Module (Join-Path $env:CIPPRootPath 'Modules\AzBobbyTables')
        Import-Module (Join-Path $env:CIPPRootPath 'Modules\CIPPCore')
        Write-Host "Doing $domainName"
        try {
            $Licrequest = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/subscribedSkus' -tenantid $_.defaultDomainName -ErrorAction Stop | Where-Object -Property skuId -NotIn $ExcludedSkuList.RowKey
            [PSCustomObject]@{
                Tenant   = $domainName
                Licenses = $Licrequest
            }
        } catch {
            [PSCustomObject]@{
                Tenant   = $domainName
                Licenses = @{
                    skuid         = "Could not connect to client: $($_.Exception.Message)"
                    skuPartNumber = 'Could not connect to client'
                    consumedUnits = 0
                    prepaidUnits  = { Enabled = 0 }
                }
            }
        }
    }
    $LicenseTable = foreach ($singlereq in $RawGraphRequest) {
        $skuid = $singlereq.Licenses
        foreach ($sku in $skuid) {
            try {
                if ($sku.skuId -eq 'Could not connect to client') { continue }
                $PrettyName = ($ConvertTable | Where-Object { $_.guid -eq $sku.skuid }).'Product_Display_Name' | Select-Object -Last 1
                if (!$PrettyName) { $PrettyName = $sku.skuPartNumber }
                #Check if serviceID exists by SKUID in gradient
                $ExistingService = (Invoke-RestMethod -Uri 'https://app.usegradient.com/api/vendor-api' -Method GET -Headers $GradientToken).data.skus | Where-Object name -EQ $PrettyName
                Write-Host "New service: $($ExistingService.name) ID: $($ExistingService.id)"
                if (!$ExistingService) {
                    #Create service
                    $ServiceBody = [PSCustomObject]@{
                        name        = $PrettyName
                        description = $PrettyName
                        category    = 'infrastructure'
                        subcategory = 'hosted email'
                    } | ConvertTo-Json -Depth 10
                    $ExistingService = (Invoke-RestMethod -Uri 'https://app.usegradient.com/api/vendor-api/service' -Method POST -Headers $GradientToken -Body $ServiceBody -ContentType 'application/json').skus | Where-Object name -EQ $PrettyName
                }
                #Post the CountAvailable to the service
                $ServiceBody = [PSCustomObject]@{
                    accountId = $singlereq.Tenant
                    unitCount = $sku.prepaidUnits.enabled
                } | ConvertTo-Json -Depth 10
                $Results = Invoke-RestMethod -Uri "https://app.usegradient.com/api/vendor-api/service/$($ExistingService.id)/count" -Method POST -Headers $GradientToken -Body $ServiceBody -ContentType 'application/json'
            } catch {
                Write-LogMessage -API $APINAME -message "Failed to create license in Gradient API. Error: $($_). $results" -Sev 'Error' -tenant $singlereq.tenant

            }
        }
    }

}
#EndRegion './Public/Gradient/New-GradientServiceSyncRun.ps1' 91
#Region './Public/Halo/Get-HaloMapping.ps1' -1

function Get-HaloMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping
    )
    #Get available mappings
    $Mappings = [pscustomobject]@{}

    # Migrate legacy mappings
    $Filter = "PartitionKey eq 'Mapping'"
    $MigrateRows = Get-CIPPAzDataTableEntity @CIPPMapping -Filter $Filter | ForEach-Object {
        [PSCustomObject]@{
            PartitionKey    = 'HaloMapping'
            RowKey          = $_.RowKey
            IntegrationId   = $_.HaloPSA
            IntegrationName = $_.HaloPSAName
        }
        Remove-AzDataTableEntity -Force @CIPPMapping -Entity $_ | Out-Null
    }
    if (($MigrateRows | Measure-Object).Count -gt 0) {
        Add-CIPPAzDataTableEntity @CIPPMapping -Entity $MigrateRows -Force
    }

    $ExtensionMappings = Get-ExtensionMapping -Extension 'Halo'

    $Tenants = Get-Tenants -IncludeErrors

    $Mappings = foreach ($Mapping in $ExtensionMappings) {
        $Tenant = $Tenants | Where-Object { $_.RowKey -eq $Mapping.RowKey }
        if ($Tenant) {
            [PSCustomObject]@{
                TenantId        = $Tenant.customerId
                Tenant          = $Tenant.displayName
                TenantDomain    = $Tenant.defaultDomainName
                IntegrationId   = $Mapping.IntegrationId
                IntegrationName = $Mapping.IntegrationName
            }
        }
    }
    $Table = Get-CIPPTable -TableName Extensionsconfig
    try {
        $Configuration = ((Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json -ea stop).HaloPSA

        $Token = Get-HaloToken -configuration $Configuration
        $i = 1
        $RawHaloClients = do {
            $Result = Invoke-RestMethod -Uri "$($Configuration.ResourceURL)/Client?page_no=$i&page_size=999&pageinate=true" -ContentType 'application/json' -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" }
            $Result.clients | Select-Object * -ExcludeProperty logo
            $i++
            $pagecount = [Math]::Ceiling($Result.record_count / 999)
        } while ($i -le $pagecount)
    } catch {
        $Message = if ($_.ErrorDetails.Message) {
            Get-NormalizedError -Message $_.ErrorDetails.Message
        } else {
            $_.Exception.message
        }

        Write-LogMessage -Message "Could not get HaloPSA Clients, error: $Message " -Level Error -tenant 'CIPP' -API 'HaloMapping'
        $RawHaloClients = @(@{name = "Could not get HaloPSA Clients, error: $Message"; id = '-1' })
    }
    $HaloClients = $RawHaloClients | ForEach-Object {
        [PSCustomObject]@{
            name  = $_.name
            value = "$($_.id)"
        }
    }
    $MappingObj = [PSCustomObject]@{
        Companies = @($HaloClients)
        Mappings  = @($Mappings)
    }

    return $MappingObj

}
#EndRegion './Public/Halo/Get-HaloMapping.ps1' 76
#Region './Public/Halo/Get-HaloTicketOutcome.ps1' -1

function Get-HaloTicketOutcome {
  <#
    .SYNOPSIS
        Get Halo Ticket Outcome
    .DESCRIPTION
        Get Halo Ticket Outcome
    .EXAMPLE
        Get-HaloTicketOutcome

    #>
  [CmdletBinding()]
  param ()
  $Table = Get-CIPPTable -TableName Extensionsconfig
  try {
    $Configuration = ((Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json -ea stop).HaloPSA
    $Token = Get-HaloToken -configuration $Configuration
    $TicketType = $Configuration.TicketType.value ?? $Configuration.TicketType
    if ($TicketType) {
      $WorkflowId = (Invoke-RestMethod -Uri "$($Configuration.ResourceURL)/tickettype/$TicketType" -ContentType 'application/json' -Method GET -Headers @{Authorization = "Bearer $($Token.access_token)" }).workflow_id
      $Workflow = Invoke-RestMethod -Uri "$($Configuration.ResourceURL)/workflow/$WorkflowId" -ContentType 'application/json' -Method GET -Headers @{Authorization = "Bearer $($Token.access_token)" }
      $Outcomes = Invoke-RestMethod -Uri "$($Configuration.ResourceURL)/outcome" -ContentType 'application/json' -Method GET -Headers @{Authorization = "Bearer $($Token.access_token)" }
      $Outcomes | Where-Object { $_.id -in $Workflow.steps.actions.action_id } | Sort-Object -Property buttonname
    }
    else {
      # Invoke-RestMethod -Uri "$($Configuration.ResourceURL)/outcome" -ContentType 'application/json' -Method GET -Headers @{Authorization = "Bearer $($Token.access_token)" }
      @(
        @{
          buttonname = 'Select and save a Ticket Type first to see available outcomes'
          value      = -1
        }
      )
    }
  }
  catch {
    $Message = if ($_.ErrorDetails.Message) {
      Get-NormalizedError -Message $_.ErrorDetails.Message
    }
    else {
      $_.Exception.message
    }
    @(@{name = "Could not get HaloPSA Outcomes, error: $Message"; id = '' })
  }
}

#EndRegion './Public/Halo/Get-HaloTicketOutcome.ps1' 45
#Region './Public/Halo/Get-HaloTicketType.ps1' -1

function Get-HaloTicketType {
    <#
    .SYNOPSIS
        Get Halo Ticket Type
    .DESCRIPTION
        Get Halo Ticket Type
    .EXAMPLE
        Get-HaloTicketType

    #>
    [CmdletBinding()]
    param ()
    $Table = Get-CIPPTable -TableName Extensionsconfig
    try {
        $Configuration = ((Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json -ea stop).HaloPSA
        $Token = Get-HaloToken -configuration $Configuration

        Invoke-RestMethod -Uri "$($Configuration.ResourceURL)/TicketType?showall=true" -ContentType 'application/json' -Method GET -Headers @{Authorization = "Bearer $($Token.access_token)" }
    } catch {
        $Message = if ($_.ErrorDetails.Message) {
            Get-NormalizedError -Message $_.ErrorDetails.Message
        } else {
            $_.Exception.message
        }
        @(@{name = "Could not get HaloPSA Ticket Types, error: $Message"; id = '' })
    }
}

#EndRegion './Public/Halo/Get-HaloTicketType.ps1' 29
#Region './Public/Halo/Get-HaloToken.ps1' -1

function Get-HaloToken {
    [CmdletBinding()]
    param (
        $Configuration
    )
    if (![string]::IsNullOrEmpty($Configuration.ClientID)) {
        $Secret = Get-ExtensionAPIKey -Extension 'HaloPSA'

        $body = @{
            grant_type    = 'client_credentials'
            client_id     = $Configuration.ClientID
            client_secret = $Secret
            scope         = 'all'
        }
        if ($Configuration.Tenant -ne 'None') { $Tenant = "?tenant=$($Configuration.Tenant)" }
        $token = Invoke-RestMethod -Uri "$($Configuration.AuthURL)/token$Tenant" -Method Post -Body $body -ContentType 'application/x-www-form-urlencoded'
        return $token
    } else {
        throw 'No Halo configuration'
    }
}
#EndRegion './Public/Halo/Get-HaloToken.ps1' 22
#Region './Public/Halo/New-HaloPSATicket.ps1' -1

function New-HaloPSATicket {
  [CmdletBinding(SupportsShouldProcess)]
  param (
    $title,
    $description,
    $client
  )
  #Get HaloPSA Token based on the config we have.
  $Table = Get-CIPPTable -TableName Extensionsconfig
  $Configuration = ((Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json).HaloPSA
  $TicketTable = Get-CIPPTable -TableName 'PSATickets'
  $token = Get-HaloToken -configuration $Configuration
  # sha hash title
  $TitleHash = Get-StringHash -String $title

  if ($Configuration.ConsolidateTickets) {
    $ExistingTicket = Get-CIPPAzDataTableEntity @TicketTable -Filter "PartitionKey eq 'HaloPSA' and RowKey eq '$($client)-$($TitleHash)'"
    if ($ExistingTicket) {
      Write-Information "Ticket already exists in HaloPSA: $($ExistingTicket.TicketID)"

      $Ticket = Invoke-RestMethod -Uri "$($Configuration.ResourceURL)/Tickets/$($ExistingTicket.TicketID)?includedetails=true&includelastaction=false&nocache=undefined&includeusersassets=false&isdetailscreen=true" -ContentType 'application/json; charset=utf-8' -Method Get -Headers @{Authorization = "Bearer $($token.access_token)" } -SkipHttpErrorCheck
      if ($Ticket.id) {
        if (!$Ticket.hasbeenclosed) {
          Write-Information 'Ticket is still open, adding new note'
          $Object = [PSCustomObject]@{
            ticket_id      = $ExistingTicket.TicketID
            outcome_id     = 7
            hiddenfromuser = $true
            note_html      = $description
          }
  
          if ($Configuration.Outcome) {
            $Outcome = $Configuration.Outcome.value ?? $Configuration.Outcome
            $Object.outcome_id = $Outcome
          }
  
          $body = ConvertTo-Json -Compress -Depth 10 -InputObject @($Object)
          try {
            if ($PSCmdlet.ShouldProcess('Add note to HaloPSA ticket', 'Add note')) {
              $Action = Invoke-RestMethod -Uri "$($Configuration.ResourceURL)/actions" -ContentType 'application/json; charset=utf-8' -Method Post -Body $body -Headers @{Authorization = "Bearer $($token.access_token)" }
              Write-Information "Note added to ticket in HaloPSA: $($ExistingTicket.TicketID)"
            }
            return "Note added to ticket in HaloPSA: $($ExistingTicket.TicketID)"
          }
          catch {
            $Message = if ($_.ErrorDetails.Message) {
              Get-NormalizedError -Message $_.ErrorDetails.Message
            }
            else {
              $_.Exception.message
            }
            Write-LogMessage -message "Failed to add note to HaloPSA ticket: $Message" -API 'HaloPSATicket' -sev Error -LogData (Get-CippException -Exception $_)
            Write-Information "Failed to add note to HaloPSA ticket: $Message"
            Write-Information "Body we tried to ship: $body"
            return "Failed to add note to HaloPSA ticket: $Message"
          }
        }
      }
      else {
        Write-Information 'Existing ticket could not be found. Creating a new ticket instead.'
      }
    }
  }

  $Object = [PSCustomObject]@{
    files                      = $null
    usertype                   = 1
    userlookup                 = @{
      id            = -1
      lookupdisplay = 'Enter Details Manually'
    }
    client_id                  = ($client | Select-Object -Last 1)
    _forcereassign             = $true
    site_id                    = $null
    user_name                  = $null
    reportedby                 = $null
    summary                    = $title
    details_html               = $description
    donotapplytemplateintheapi = $true
    attachments                = @()
    _novalidate                = $true
  }

  if ($Configuration.TicketType) {
    $TicketType = $Configuration.TicketType.value ?? $Configuration.TicketType
    $object | Add-Member -MemberType NoteProperty -Name 'tickettype_id' -Value $TicketType -Force
  }
  #use the token to create a new ticket in HaloPSA
  $body = ConvertTo-Json -Compress -Depth 10 -InputObject @($Object)

  Write-Information 'Sending ticket to HaloPSA'
  Write-Information $body
  try {
    if ($PSCmdlet.ShouldProcess('Send ticket to HaloPSA', 'Create ticket')) {
      $Ticket = Invoke-RestMethod -Uri "$($Configuration.ResourceURL)/Tickets" -ContentType 'application/json; charset=utf-8' -Method Post -Body $body -Headers @{Authorization = "Bearer $($token.access_token)" }
      Write-Information "Ticket created in HaloPSA: $($Ticket.id)"

      if ($Configuration.ConsolidateTickets) {
        $TicketObject = [PSCustomObject]@{
          PartitionKey = 'HaloPSA'
          RowKey       = "$($client)-$($TitleHash)"
          Title        = $title
          ClientId     = $client
          TicketID     = $Ticket.id
        }
        Add-CIPPAzDataTableEntity @TicketTable -Entity $TicketObject -Force
        Write-Information 'Ticket added to consolidation table'
      }
      return "Ticket created in HaloPSA: $($Ticket.id)"
    }
  }
  catch {
    $Message = if ($_.ErrorDetails.Message) {
      Get-NormalizedError -Message $_.ErrorDetails.Message
    }
    else {
      $_.Exception.message
    }
    Write-LogMessage -message "Failed to send ticket to HaloPSA: $Message" -API 'HaloPSATicket' -sev Error -LogData (Get-CippException -Exception $_)
    Write-Information "Failed to send ticket to HaloPSA: $Message"
    Write-Information "Body we tried to ship: $body"
    return "Failed to send ticket to HaloPSA: $Message"
  }
}
#EndRegion './Public/Halo/New-HaloPSATicket.ps1' 125
#Region './Public/Halo/Set-HaloMapping.ps1' -1

function Set-HaloMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping,
        $APIName,
        $Request
    )
    Get-CIPPAzDataTableEntity @CIPPMapping -Filter "PartitionKey eq 'HaloMapping'" | ForEach-Object {
        Remove-AzDataTableEntity -Force @CIPPMapping -Entity $_
    }
    foreach ($Mapping in $Request.Body) {
        if ($Mapping.TenantId) {
            $AddObject = @{
                PartitionKey    = 'HaloMapping'
                RowKey          = "$($mapping.TenantId)"
                IntegrationId   = "$($mapping.IntegrationId)"
                IntegrationName = "$($mapping.IntegrationName)"
            }
        }

        Add-CIPPAzDataTableEntity @CIPPMapping -Entity $AddObject -Force
        Write-LogMessage -API $APINAME -headers $Request.Headers -message "Added mapping for $($mapping.name)." -Sev 'Info'
    }
    $Result = [pscustomobject]@{'Results' = 'Successfully edited mapping table.' }

    Return $Result
}
#EndRegion './Public/Halo/Set-HaloMapping.ps1' 28
#Region './Public/HIBP/Get-BreachInfo.ps1' -1

function Get-BreachInfo {
    [CmdletBinding()]
    param(
        [Parameter()]
        $TenantFilter,
        [Parameter()]$Domain

    )
    if ($TenantFilter) {
        $Data = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/domains' -tenantid $TenantFilter | ForEach-Object {
            Invoke-RestMethod -Uri "https://geoipdb.azurewebsites.net/api/Breach?func=domain&domain=$($_.id)"
        }
        return $Data
    } else {
       $data = Invoke-RestMethod -Uri "https://geoipdb.azurewebsites.net/api/Breach?func=domain&domain=$($domain)&format=breachlist"
       return $Data
    }

}
#EndRegion './Public/HIBP/Get-BreachInfo.ps1' 20
#Region './Public/HIBP/Get-HIBPAuth.ps1' -1

function Get-HIBPAuth {
    $Var = 'Ext_HIBP'
    $APIKey = Get-Item -Path "env:$Var" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Value
    if ($APIKey) {
        Write-Information 'Using cached API Key for HIBP'
        $Secret = $APIKey
    } else {
        if ($env:AzureWebJobsStorage -eq 'UseDevelopmentStorage=true' -or $env:NonLocalHostAzurite -eq 'true') {
            $DevSecretsTable = Get-CIPPTable -tablename 'DevSecrets'
            $Secret = (Get-CIPPAzDataTableEntity @DevSecretsTable -Filter "PartitionKey eq 'HIBP' and RowKey eq 'HIBP'").APIKey
        } else {
            $VaultName = ($env:WEBSITE_DEPLOYMENT_ID -split '-')[0]
            try {
                $Secret = Get-CippKeyVaultSecret -VaultName $VaultName -Name 'HIBP' -AsPlainText -ErrorAction Stop
            } catch {
                $Secret = $null
            }

            if ([string]::IsNullOrEmpty($Secret) -and $env:CIPP_HOSTED -eq 'true') {
                $VaultName = 'hibp-kv'
                $Secret = Get-CippKeyVaultSecret -VaultName $VaultName -Name 'HIBP' -AsPlainText
            }
        }
        Set-Item -Path "env:$Var" -Value $APIKey -Force -ErrorAction SilentlyContinue
    }

    return @{
        'User-Agent'   = "CIPP-$($env:TenantID)"
        'Accept'       = 'application/json'
        'api-version'  = '3'
        'hibp-api-key' = $Secret
    }
}
#EndRegion './Public/HIBP/Get-HIBPAuth.ps1' 34
#Region './Public/HIBP/Get-HIBPConnectionTest.ps1' -1

function Get-HIBPConnectionTest {
    $uri = 'https://haveibeenpwned.com/api/v3/subscription/status'
    try {
        Invoke-RestMethod -Uri $uri -Headers (Get-HIBPAuth)
    } catch {
        throw "Failed to connect to HIBP: $($_.Exception.Message)"
    }
}
#EndRegion './Public/HIBP/Get-HIBPConnectionTest.ps1' 9
#Region './Public/HIBP/Get-HIBPRequest.ps1' -1

function Get-HIBPRequest {
    [CmdletBinding()]
    param(
        [Parameter()]
        $endpoint
    )
    $uri = "https://haveibeenpwned.com/api/v3/$endpoint"
    try {
        return Invoke-RestMethod -Uri $uri -Headers (Get-HIBPAuth)
    } catch {
        if ($_.Exception.Response -and $_.Exception.Response.StatusCode -eq 404) {
            return @()
        } elseif ($_.Exception.Response -and $_.Exception.Response.StatusCode -eq 429) {
            Write-Host 'Rate limited hit for hibp.'
            return @{
                Wait         = ($_.Exception.Response.headers | Where-Object -Property key -EQ 'Retry-After').value
                'rate-limit' = $true
            }
        } else {
            throw "Failed to connect to HIBP: $($_.Exception.Message)"
        }
    }
    throw "Failed to connect to HIBP after $maxRetries retries."
}
#EndRegion './Public/HIBP/Get-HIBPRequest.ps1' 25
#Region './Public/HIBP/New-BreachTenantSearch.ps1' -1

function New-BreachTenantSearch {
    [CmdletBinding()]
    param (
        [Parameter()]$TenantFilter,
        [Parameter()][switch]$Force
    )

    $Table = Get-CIPPTable -TableName UserBreaches
    $LatestBreach = Get-BreachInfo -TenantFilter $TenantFilter | ForEach-Object {
        $_ | Where-Object { $_ -and $_.email }
    } | Group-Object -Property clientDomain

    $usersResults = foreach ($domain in $LatestBreach) {
        $ExistingBreaches = Get-CIPPAzDataTableEntity @Table -Filter "RowKey eq '$($domain.name)'"
        if ($null -eq $domain.Group) {
            Write-Host "No breaches found for domain $($domain.name)"
            continue
        }
        $SumOfBreaches = $domain.Count
        if ($ExistingBreaches.sum -eq $SumOfBreaches) {
            if ($Force.IsPresent -eq $true) {
                Write-Host "Forcing update for tenant $TenantFilter"
            } else {
                Write-Host "No new breaches found for tenant $TenantFilter"
                continue
            }
        }

        @{
            RowKey       = $domain.name
            PartitionKey = $TenantFilter
            breaches     = "$($domain.Group | ConvertTo-Json -Depth 10 -Compress)"
            sum          = $SumOfBreaches
        }
    }

    #Add user breaches to table
    if ($usersResults) {
        try {
            $null = Add-CIPPAzDataTableEntity @Table -Entity $usersResults -Force
            return $LatestBreach.Group
        } catch {
            Write-Error "Failed to add breaches to table: $($_.Exception.Message)"
            return $null
        }
    }
}
#EndRegion './Public/HIBP/New-BreachTenantSearch.ps1' 48
#Region './Public/Hudu/Connect-HuduAPI.ps1' -1

function Connect-HuduAPI {
    [CmdletBinding()]
    param (
        $Configuration
    )

    $APIKey = Get-ExtensionAPIKey -Extension 'Hudu'

    if ($Configuration.Hudu.CFEnabled -eq $true -and $Configuration.CFZTNA.Enabled -eq $true) {
        $CFAPIKey = Get-ExtensionAPIKey -Extension 'CFZTNA'
        New-HuduCustomHeaders -Headers @{'CF-Access-Client-Id' = $Configuration.CFZTNA.ClientId; 'CF-Access-Client-Secret' = "$CFAPIKey" }
        Write-Information 'CF-Access-Client-Id and CF-Access-Client-Secret headers added to Hudu API request'
    }
    New-HuduBaseURL -BaseURL $Configuration.Hudu.BaseURL
    New-HuduAPIKey -ApiKey $APIKey
}
#EndRegion './Public/Hudu/Connect-HuduAPI.ps1' 17
#Region './Public/Hudu/Get-HuduFieldMapping.ps1' -1

function Get-HuduFieldMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping
    )

    $Mappings = Get-ExtensionMapping -Extension 'HuduField'

    $CIPPFieldHeaders = @(
        [PSCustomObject]@{
            Title       = 'Hudu Asset Layouts'
            FieldType   = 'Layouts'
            Description = 'Use the table below to map your Hudu Asset Layouts to the correct CIPP Data Type. A new Rich Text asset layout field will be created if it does not exist.'
        }
    )
    $CIPPFields = @(
        [PSCustomObject]@{
            FieldName  = 'Users'
            FieldLabel = 'Asset Layout for M365 Users'
            FieldType  = 'Layouts'
        }
        [PSCustomObject]@{
            FieldName  = 'Devices'
            FieldLabel = 'Asset Layout for M365 Devices'
            FieldType  = 'Layouts'
        }
    )

    $Table = Get-CIPPTable -TableName Extensionsconfig
    try {
        $Configuration = (Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json -ea stop
        Connect-HuduAPI -configuration $Configuration

        try {
            $AssetLayouts = Get-HuduAssetLayouts -ErrorAction Stop | Select-Object @{Name = 'FieldType' ; Expression = { 'Layouts' } }, @{Name = 'value'; Expression = { $_.id } }, name, fields
        } catch {
            $Message = $_.Exception.Message -replace "'" | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($Message) {
                $Message = $Message.error
            } else {
                $Message = $_.Exception.Message
            }

            Write-Warning "Could not get Hudu Asset Layouts, error: $Message"
            Write-LogMessage -Message "Could not get Hudu Asset Layouts, error: $Message " -Level Error -tenant 'CIPP' -API 'HuduMapping'
            $AssetLayouts = @(@{FieldType = 'Layouts'; name = "Could not get Hudu Asset Layouts, $Message"; value = -1 })
        }
    } catch {
        $Message = $_.Exception.Message -replace "'" | ConvertFrom-Json -ErrorAction SilentlyContinue
        if ($Message) {
            $Message = $Message.error
        } else {
            $Message = $_.Exception.Message
        }

        Write-Warning "Could not get Hudu Asset Layouts, error: $Message"
        Write-LogMessage -Message "Could not get Hudu Asset Layouts, error: $Message " -Level Error -tenant 'CIPP' -API 'HuduMapping'
        $AssetLayouts = @(@{FieldType = 'Layouts'; name = "Could not get Hudu Asset Layouts, $Message"; value = -1 })
    }

    $Unset = [PSCustomObject]@{
        name  = '--- Do not synchronize ---'
        value = $null
        type  = 'unset'
    }

    $MappingObj = [PSCustomObject]@{
        CIPPFields        = $CIPPFields
        CIPPFieldHeaders  = $CIPPFieldHeaders
        IntegrationFields = @($Unset) + @($AssetLayouts)
        Mappings          = @($Mappings)
    }

    return $MappingObj

}
#EndRegion './Public/Hudu/Get-HuduFieldMapping.ps1' 77
#Region './Public/Hudu/Get-HuduMapping.ps1' -1

function Get-HuduMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping
    )

    $ExtensionMappings = Get-ExtensionMapping -Extension 'Hudu'

    $Tenants = Get-Tenants -IncludeErrors

    $Mappings = foreach ($Mapping in $ExtensionMappings) {
        $Tenant = $Tenants | Where-Object { $_.RowKey -eq $Mapping.RowKey }
        if ($Tenant) {
            [PSCustomObject]@{
                TenantId        = $Tenant.customerId
                Tenant          = $Tenant.displayName
                TenantDomain    = $Tenant.defaultDomainName
                IntegrationId   = $Mapping.IntegrationId
                IntegrationName = $Mapping.IntegrationName
            }
        }
    }
    $Tenants = Get-Tenants -IncludeErrors
    $Table = Get-CIPPTable -TableName Extensionsconfig
    try {
        $Configuration = (Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json -ea stop

        Connect-HuduAPI -configuration $Configuration
        $HuduCompanies = Get-HuduCompanies

    } catch {
        $Message = if ($_.ErrorDetails.Message) {
            Get-NormalizedError -Message $_.ErrorDetails.Message
        } else {
            $_.Exception.message
        }

        Write-LogMessage -Message "Could not get Hudu Companies, error: $Message " -Level Error -tenant 'CIPP' -API 'HuduMapping'
        $HuduCompanies = @(@{name = "Could not get Hudu Companies, error: $Message"; value = '-1' })
    }
    $HuduCompanies = $HuduCompanies | ForEach-Object {
        [PSCustomObject]@{
            name  = $_.name
            value = "$($_.id)"
        }
    }
    $MappingObj = [PSCustomObject]@{
        Companies = @($HuduCompanies)
        Mappings  = @($Mappings)
    }

    return $MappingObj

}
#EndRegion './Public/Hudu/Get-HuduMapping.ps1' 55
#Region './Public/Hudu/Invoke-HuduExtensionSync.ps1' -1

function Invoke-HuduExtensionSync {
    <#
        .FUNCTIONALITY
        Internal
    #>
    param(
        $Configuration,
        $TenantFilter
    )
    try {
        Connect-HuduAPI -configuration $Configuration
        $Configuration = $Configuration.Hudu
        $Tenant = Get-Tenants -TenantFilter $TenantFilter -IncludeErrors
        $CompanyResult = [PSCustomObject]@{
            Name    = $Tenant.displayName
            Users   = 0
            Devices = 0
            Errors  = [System.Collections.Generic.List[string]]@()
            Logs    = [System.Collections.Generic.List[string]]@()
        }

        $AssignedNameMap = Get-AssignedNameMap
        $AssignedMap = Get-AssignedMap

        # Get mapping configuration
        $MappingTable = Get-CIPPTable -TableName 'CippMapping'
        $Mappings = Get-CIPPAzDataTableEntity @MappingTable -Filter "PartitionKey eq 'HuduMapping' or PartitionKey eq 'HuduFieldMapping'"

        $defaultdomain = $TenantFilter
        $TenantMap = $Mappings | Where-Object { $_.RowKey -eq $Tenant.customerId }

        # Get Asset cache
        $HuduAssetCache = Get-CippTable -tablename 'CacheHuduAssets'

        # Import license mapping
        $LicTable = [System.IO.File]::ReadAllText((Join-Path $env:CIPPRootPath 'Config\ConversionTable.csv')) | ConvertFrom-Csv

        $CompanyResult.Logs.Add('Starting Hudu Extension Sync')

        # Get CIPP URL
        $ConfigTable = Get-Cipptable -tablename 'Config'
        $Config = Get-CippAzDataTableEntity @ConfigTable -Filter "PartitionKey eq 'InstanceProperties' and RowKey eq 'CIPPURL'"
        $CIPPURL = 'https://{0}' -f $Config.Value
        $EnableCIPP = $true

        # Get CIPP Extension Reporting Data (from new CippReportingDB)
        # Include mailboxes if needed for Hudu sync
        $ExtensionCache = Get-CippExtensionReportingData -TenantFilter $Tenant.defaultDomainName -IncludeMailboxes
        $company_id = $TenantMap.IntegrationId

        # If tenant not found in mapping table, return error
        if (!$TenantMap) {
            return 'Tenant not found in mapping table'
        }

        # Get Hudu Layout mappings
        $PeopleLayoutId = $Mappings | Where-Object { $_.RowKey -eq 'Users' } | Select-Object -ExpandProperty IntegrationId
        $DeviceLayoutId = $Mappings | Where-Object { $_.RowKey -eq 'Devices' } | Select-Object -ExpandProperty IntegrationId

        try {
            if (![string]::IsNullOrEmpty($PeopleLayoutId)) {
                # Add required fields to People Layout
                $null = Add-HuduAssetLayoutField -AssetLayoutId $PeopleLayoutId -Label 'Microsoft 365'
                $null = Add-HuduAssetLayoutField -AssetLayoutId $PeopleLayoutId -Label 'Email Address' -Position 1 -ShowInList $true -FieldType 'Text'
                $CreateUsers = $Configuration.CreateMissingUsers
                $PeopleLayout = Get-HuduAssetLayouts -Id $PeopleLayoutId
                if ($PeopleLayout.id) {
                    $PeopleArray = Get-HuduAssets -CompanyId $company_id -AssetLayoutId $PeopleLayout.id
                    $People = [System.Collections.Generic.List[object]]::new([object[]]@($PeopleArray))
                } else {
                    $CreateUsers = $false
                    $People = [System.Collections.Generic.List[object]]::new()
                }
            } else {
                $CreateUsers = $false
                $People = [System.Collections.Generic.List[object]]::new()
            }
        } catch {
            $CreateUsers = $false
            $People = [System.Collections.Generic.List[object]]::new()
            $CompanyResult.Errors.add("Company: Unable to fetch People $_")
            Write-Host "Hudu People - Error: $_"
        }

        Write-Host "Configuration: $($Configuration | ConvertTo-Json)"

        try {
            if (![string]::IsNullOrEmpty($DeviceLayoutId)) {
                $null = Add-HuduAssetLayoutField -AssetLayoutId $DeviceLayoutId
                $CreateDevices = $Configuration.CreateMissingDevices
                $DesktopsLayout = Get-HuduAssetLayouts -Id $DeviceLayoutId
                if ($DesktopsLayout.id) {
                    $HuduDesktopDevices = Get-HuduAssets -CompanyId $company_id -AssetLayoutId $DesktopsLayout.id
                    $HuduDevices = [System.Collections.Generic.List[object]]::new([object[]]@($HuduDesktopDevices))
                } else {
                    $CreateDevices = $false
                    $HuduDevices = [System.Collections.Generic.List[object]]::new()
                }
            } else {
                $CreateDevices = $false
                $HuduDevices = [System.Collections.Generic.List[object]]::new()
            }
        } catch {
            $CreateDevices = $false
            $HuduDevices = [System.Collections.Generic.List[object]]::new()
            $CompanyResult.Errors.add("Company: Unable to fetch Devices $_")
            Write-Host "Hudu Devices - Error: $_"
        }

        $importDomains = $Configuration.ImportDomains
        $monitordomains = $Configuration.MonitorDomains

        # Defaults
        $IntuneDesktopDeviceTypes = 'windowsRT,macMDM' -split ','
        $DefaultSerials = [System.Collections.Generic.List[string]]@('SystemSerialNumber', 'To Be Filled By O.E.M.', 'System Serial Number', '0123456789', '123456789', 'TobefilledbyO.E.M.')

        if ($Configuration.ExcludeSerials) {
            $ExcludeSerials = $DefaultSerials.AddRange($Configuration.ExcludeSerials -split ',')
        } else {
            $ExcludeSerials = $DefaultSerials
        }

        $HuduRelations = Get-HuduRelations
        $Links = @(
            @{
                Title = 'M365 Admin Portal'
                URL   = 'https://admin.cloud.microsoft?delegatedOrg={0}' -f $Tenant.initialDomainName
                Icon  = 'fas fa-cogs'
            }
            @{
                Title = 'Exchange Admin Portal'
                URL   = 'https://admin.cloud.microsoft/exchange?delegatedOrg={0}' -f $Tenant.initialDomainName
                Icon  = 'fas fa-mail-bulk'
            }
            @{
                Title = 'Entra Portal'
                URL   = 'https://entra.microsoft.com/{0}' -f $Tenant.defaultDomainName
                Icon  = 'fas fa-users-cog'
            }
            @{
                Title = 'Intune'
                URL   = 'https://intune.microsoft.com/{0}/' -f $Tenant.defaultDomainName
                Icon  = 'fas fa-laptop'
            }
            @{
                Title = 'Teams Portal'
                URL   = 'https://admin.teams.microsoft.com/?delegatedOrg={0}' -f $Tenant.defaultDomainName
                Icon  = 'fas fa-users'
            }
            @{
                Title = 'Azure Portal'
                URL   = 'https://portal.azure.com/{0}' -f $Tenant.defaultDomainName
                Icon  = 'fas fa-server'
            }
        )
        $FormattedLinks = foreach ($Link in $Links) {
            Get-HuduLinkBlock @Link
        }


        $CustomerLinks = $FormattedLinks -join "`n"

        $Users = $ExtensionCache.Users
        $licensedUsers = $Users | Where-Object { $null -ne $_.assignedLicenses.skuId } | Sort-Object userPrincipalName
        $CompanyResult.users = ($licensedUsers | Measure-Object).count
        $AllRoles = $ExtensionCache.AllRoles


        $Roles = foreach ($Role in $AllRoles) {
            # Members are now inline with each role object
            $Members = $Role.members
            [PSCustomObject]@{
                ID            = $Role.id
                DisplayName   = $Role.displayName
                Description   = $Role.description
                Members       = $Members
                ParsedMembers = $Members.displayName -join ', '
            }
        }

        $pre = "<div class=`"nasa__block`"><header class='nasa__block-header'>
			<h1><i class='fas fa-users icon'></i>Assigned Roles</h1>
			 </header>"

        $post = '</div>'
        $RolesHtml = $Roles | Select-Object DisplayName, Description, ParsedMembers | ConvertTo-Html -PreContent $pre -PostContent $post -Fragment | ForEach-Object { $tmp = $_ -replace '&lt;', '<'; $tmp -replace '&gt;', '>'; } | Out-String

        $AdminUsers = (($Roles | Where-Object { $_.displayName -match 'Administrator' }).Members | Where-Object { $null -ne $_.displayName } | Select-Object @{N = 'Name'; E = { "<a target='_blank' href='https://entra.microsoft.com/$($Tenant.defaultDomainName)/#blade/Microsoft_AAD_IAM/UserDetailsMenuBlade/Profile/userId/$($_.Id)'>$($_.displayName) - $($_.userPrincipalName)</a>" } } -Unique).name -join '<br/>'

        $Domains = $ExtensionCache.Domains

        $customerDomains = ($Domains | Where-Object { $_.isVerified -eq $True }).id -join ', ' | Out-String

        $detailstable = "<div class='nasa__block'>
							<header class='nasa__block-header'>
							<h1><i class='fas fa-info-circle icon'></i>Basic Info</h1>
							 </header>
								<main>
								<article>
								<div class='basic_info__section'>
								<h2>Tenant Name</h2>
								<p>
									$($Tenant.displayName)
								</p>
								</div>
								<div class='basic_info__section'>
								<h2>Tenant ID</h2>
								<p>
									$($Tenant.customerId)
								</p>
								</div>
								<div class='basic_info__section'>
								<h2>Default Domain</h2>
								<p>
									$defaultdomain
								</p>
								</div>
								<div class='basic_info__section'>
								<h2>Customer Domains</h2>
								<p>
									$customerDomains
								</p>
								</div>
								<div class='basic_info__section'>
								<h2>Admin Users</h2>
								<p>
									$AdminUsers
								</p>
								</div>
                                <div class='basic_info__section'>
								<h2>Last Updated</h2>
								<p>
									$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
								</p>
								</div>
						</article>
						</main>
						</div>
"
        $Licenses = $ExtensionCache.Licenses
        if ($Licenses) {
            $pre = "<div class=`"nasa__block`"><header class='nasa__block-header'>
			<h1><i class='fas fa-info-circle icon'></i>Current Licenses</h1>
			 </header>"

            $post = '</div>'

            $licenseOut = $Licenses | Where-Object { $_.PrepaidUnits.Enabled -gt 0 } | Select-Object @{N = 'License Name'; E = { $_.SkuPartNumber } }, @{N = 'Active'; E = { $_.PrepaidUnits.Enabled } }, @{N = 'Consumed'; E = { $_.ConsumedUnits } }, @{N = 'Unused'; E = { $_.PrepaidUnits.Enabled - $_.ConsumedUnits } }
            $licenseHTML = $licenseOut | ConvertTo-Html -PreContent $pre -PostContent $post -Fragment | Out-String
        }

        $devices = $ExtensionCache.Devices
        $CompanyResult.Devices = ($Devices | Measure-Object).count

        $DeviceCompliancePolicies = $ExtensionCache.DeviceCompliancePolicies

        $DeviceComplianceDetails = foreach ($Policy in $DeviceCompliancePolicies) {
            # Device statuses are cached per policy with new naming: IntuneDeviceCompliancePolicies_{policyId}
            $DeviceStatusItems = Get-CIPPDbItem -TenantFilter $TenantFilter -Type "IntuneDeviceCompliancePolicies_$($Policy.id)" | Where-Object { $_.RowKey -notlike '*-Count' }
            $DeviceStatuses = if ($DeviceStatusItems) { $DeviceStatusItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }
            [pscustomobject]@{
                ID             = $Policy.id
                DisplayName    = $Policy.displayName
                DeviceStatuses = @($DeviceStatuses)
            }
        }

        $AllGroups = $ExtensionCache.Groups

        $Groups = foreach ($Group in $AllGroups) {
            # Members are now inline with each group object
            $Members = $Group.members
            [pscustomobject]@{
                ID          = $Group.id
                DisplayName = $Group.displayName
                Members     = @($Members)
            }
        }

        $AllConditionalAccessPolicies = $ExtensionCache.ConditionalAccess

        $ConditionalAccessMembers = foreach ($CAPolicy in $AllConditionalAccessPolicies) {
            [System.Collections.Generic.List[PSCustomObject]]$CAMembers = @()

            if ($CAPolicy.conditions.users.includeUsers -contains 'All') {
                $Users | ForEach-Object { $null = $CAMembers.add($_.id) }
            } else {
                $CAPolicy.conditions.users.includeUsers | ForEach-Object { $null = $CAMembers.add($_) }
            }

            foreach ($CAIGroup in $CAPolicy.conditions.users.includeGroups) {
                foreach ($Member in ($Groups | Where-Object { $_.id -eq $CAIGroup }).Members) {
                    $null = $CAMembers.add($Member.id)
                }
            }

            foreach ($CAIRole in $CAPolicy.conditions.users.includeRoles) {
                foreach ($Member in ($Roles | Where-Object { $_.id -eq $CAIRole }).Members) {
                    $null = $CAMembers.add($Member.id)
                }
            }

            $CAMembers = $CAMembers | Select-Object -Unique

            if ($CAMembers) {
                $CAPolicy.conditions.users.excludeUsers | ForEach-Object { $null = $CAMembers.remove($_) }

                foreach ($CAEGroup in $CAPolicy.conditions.users.excludeGroups) {
                    foreach ($Member in ($Groups | Where-Object { $_.id -eq $CAEGroup }).Members) {
                        $null = $CAMembers.remove($Member.id)
                    }
                }

                foreach ($CAIRole in $CAPolicy.conditions.users.excludeRoles) {
                    foreach ($Member in ($Roles | Where-Object { $_.id -eq $CAERole }).Members) {
                        $null = $CAMembers.remove($Member.id)
                    }
                }
            }

            # Enhanced policy information extraction based on API structure
            [pscustomobject]@{
                ID                     = $CAPolicy.id
                DisplayName            = $CAPolicy.displayName
                State                  = $CAPolicy.state
                CreatedDateTime        = $CAPolicy.createdDateTime
                ModifiedDateTime       = $CAPolicy.modifiedDateTime
                Members                = @($CAMembers)

                # Applications conditions
                IncludeApplications    = if ($CAPolicy.conditions.applications.includeApplications) {
                    $CAPolicy.conditions.applications.includeApplications -join ', '
                } else { 'None' }
                ExcludeApplications    = if ($CAPolicy.conditions.applications.excludeApplications) {
                    $CAPolicy.conditions.applications.excludeApplications -join ', '
                } else { 'None' }

                # Location conditions
                IncludeLocations       = if ($CAPolicy.conditions.locations.includeLocations) {
                    $CAPolicy.conditions.locations.includeLocations -join ', '
                } else { 'None' }
                ExcludeLocations       = if ($CAPolicy.conditions.locations.excludeLocations) {
                    $CAPolicy.conditions.locations.excludeLocations -join ', '
                } else { 'None' }

                # Platform conditions
                Platforms              = if ($CAPolicy.conditions.platforms -and $CAPolicy.conditions.platforms.includePlatforms) {
                    $CAPolicy.conditions.platforms.includePlatforms -join ', '
                } else { 'All' }

                # Client app types
                ClientAppTypes         = if ($CAPolicy.conditions.clientAppTypes) {
                    $CAPolicy.conditions.clientAppTypes -join ', '
                } else { 'All' }

                # Grant controls
                GrantOperator          = $CAPolicy.grantControls.operator
                BuiltInControls        = if ($CAPolicy.grantControls.builtInControls) {
                    $CAPolicy.grantControls.builtInControls -join ', '
                } else { 'None' }
                AuthenticationStrength = if ($CAPolicy.grantControls.authenticationStrength) {
                    $CAPolicy.grantControls.authenticationStrength.displayName
                } else { 'None' }

                # Session controls
                SignInFrequency        = if ($CAPolicy.sessionControls -and $CAPolicy.sessionControls.signInFrequency -and $CAPolicy.sessionControls.signInFrequency.isEnabled) {
                    "$($CAPolicy.sessionControls.signInFrequency.value) $($CAPolicy.sessionControls.signInFrequency.type)"
                } else { 'Not configured' }

                PersistentBrowser      = if ($CAPolicy.sessionControls -and $CAPolicy.sessionControls.persistentBrowser) {
                    $CAPolicy.sessionControls.persistentBrowser.mode
                } else { 'Not configured' }

                # Risk levels
                UserRiskLevels         = if ($CAPolicy.conditions.userRiskLevels) {
                    $CAPolicy.conditions.userRiskLevels -join ', '
                } else { 'None' }
                SignInRiskLevels       = if ($CAPolicy.conditions.signInRiskLevels) {
                    $CAPolicy.conditions.signInRiskLevels -join ', '
                } else { 'None' }
            }
        }

        if ($ExtensionCache.OneDriveUsage) {
            $OneDriveDetails = $ExtensionCache.OneDriveUsage
        } else {
            $CompanyResult.Errors.add("Company: Unable to fetch One Drive Details $_")
            $OneDriveDetails = $null
        }



        if ($ExtensionCache.CASMailbox) {
            $CASFull = $ExtensionCache.CASMailbox
        } else {
            $CompanyResult.Errors.add('Company: Unable to fetch CAS Mailbox Details')
            $CASFull = $null

        }



        if ($ExtensionCache.Mailboxes) {
            $MailboxDetailedFull = $ExtensionCache.Mailboxes
        } else {
            $CompanyResult.Errors.add('Company: Unable to fetch Mailbox Details')
            $MailboxDetailedFull = $null
        }


        if ($ExtensionCache.MailboxUsage) {
            $MailboxStatsFull = $ExtensionCache.MailboxUsage
        } else {
            $MailboxStatsFull = $null
            $CompanyResult.Errors.add('Company: Unable to fetch Mailbox Statistic Details')
        }

        $Permissions = $ExtensionCache.MailboxPermissions
        if ($licensedUsers) {
            $pre = "<div class=`"nasa__block`"><header class='nasa__block-header'>
			<h1><i class='fas fa-users icon'></i>Licensed Users</h1>
			 </header>"

            $post = '</div>'
            $CompanyResult.Logs.Add('Starting User Processing')
            $OutputUsers = foreach ($user in $licensedUsers) {
                try {
                    $HuduUser = $null
                    $UserGroups = foreach ($Group in $Groups) {
                        if ($User.id -in $Group.Members.id) {
                            $FoundGroup = $AllGroups | Where-Object { $_.id -eq $Group.id }
                            [PSCustomObject]@{
                                'Display Name'   = $FoundGroup.displayName
                                'Mail Enabled'   = $FoundGroup.mailEnabled
                                'Mail'           = $FoundGroup.mail
                                'Security Group' = $FoundGroup.securityEnabled
                                'Group Types'    = $FoundGroup.groupTypes -join ','
                            }
                        }
                    }

                    $UserPolicies = foreach ($cap in $ConditionalAccessMembers) {
                        if ($User.id -in $Cap.Members) {
                            [PSCustomObject]@{
                                displayName            = $cap.displayName
                                state                  = $cap.State
                                authenticationStrength = $cap.AuthenticationStrength
                                clientAppTypes         = $cap.ClientAppTypes
                                includeApplications    = $cap.IncludeApplications
                                includeLocations       = $cap.IncludeLocations
                                signInFrequency        = $cap.SignInFrequency
                                userRiskLevels         = $cap.UserRiskLevels
                                signInRiskLevels       = $cap.SignInRiskLevels
                            }
                        }
                    }

                    $PermsRequest = ''
                    $StatsRequest = ''
                    $MailboxDetailedRequest = ''
                    $CASRequest = ''

                    $CASRequest = $CASFull | Where-Object { $_.ExternalDirectoryObjectId -eq $User.id }
                    $MailboxDetailedRequest = $MailboxDetailedFull | Where-Object { $_.Id -eq $User.id }
                    $StatsRequest = $MailboxStatsFull | Where-Object { $_.'userPrincipalName' -eq $User.userPrincipalName }

                    $PermsRequest = $Permissions | Where-Object { $_.Identity -eq $User.id }

                    $ParsedPerms = foreach ($Perm in $PermsRequest) {
                        if ($Perm.User -ne 'NT AUTHORITY\SELF') {
                            [pscustomobject]@{
                                User         = $Perm.User
                                AccessRights = $Perm.PermissionList.AccessRights -join ', '
                            }
                        }
                    }

                    try {
                        $TotalItemSize = [math]::Round($StatsRequest.storageUsedInBytes / 1Gb, 2)
                    } catch {
                        $TotalItemSize = 0
                    }

                    $UserMailSettings = [pscustomobject]@{
                        ForwardAndDeliver        = $MailboxDetailedRequest.DeliverToMailboxAndForward
                        ForwardingAddress        = $MailboxDetailedRequest.ForwardingAddress + ' ' + $MailboxDetailedRequest.ForwardingSmtpAddress
                        LitiationHold            = $MailboxDetailedRequest.LitigationHoldEnabled
                        HiddenFromAddressLists   = $MailboxDetailedRequest.HiddenFromAddressListsEnabled
                        EWSEnabled               = $CASRequest.EwsEnabled
                        MailboxMAPIEnabled       = $CASRequest.MAPIEnabled
                        MailboxOWAEnabled        = $CASRequest.OWAEnabled
                        MailboxImapEnabled       = $CASRequest.ImapEnabled
                        MailboxPopEnabled        = $CASRequest.PopEnabled
                        MailboxActiveSyncEnabled = $CASRequest.ActiveSyncEnabled
                        Permissions              = $ParsedPerms
                        ProhibitSendQuota        = $StatsRequest.prohibitSendQuotaInBytes
                        ProhibitSendReceiveQuota = $StatsRequest.prohibitSendReceiveQuotaInBytes
                        ItemCount                = [math]::Round($StatsRequest.'itemCount', 2)
                        TotalItemSize            = $StatsRequest.totalItemSize
                        StorageUsedInBytes       = $StatsRequest.storageUsedInBytes
                    }

                    $userDevices = ($devices | Where-Object { $_.userPrincipalName -eq $user.userPrincipalName } | Select-Object @{N = 'Name'; E = { "<a target='_blank' href=https://intune.microsoft.com/$($Tenant.defaultDomainName)/#blade/Microsoft_Intune_Devices/DeviceSettingsBlade/overview/mdmDeviceId/$($_.id)>$($_.deviceName) ($($_.operatingSystem))" } }).name -join '<br/>'

                    $UserDevicesDetailsRaw = $devices | Where-Object { $_.userPrincipalName -eq $user.userPrincipalName } | Select-Object @{N = 'Name'; E = { "<a target='_blank' href=https://intune.microsoft.com/$($Tenant.defaultDomainName)/#blade/Microsoft_Intune_Devices/DeviceSettingsBlade/overview/mdmDeviceId/$($_.id)>$($_.deviceName)</a>" } }, @{n = 'Owner'; e = { $_.managedDeviceOwnerType } }, `
                    @{n = 'Enrolled'; e = { $_.enrolledDateTime } }, `
                    @{n = 'Last Sync'; e = { $_.lastSyncDateTime } }, `
                    @{n = 'OS'; e = { $_.operatingSystem } }, `
                    @{n = 'OS Version'; e = { $_.osVersion } }, `
                    @{n = 'State'; e = { $_.complianceState } }, `
                    @{n = 'Model'; e = { $_.model } }, `
                    @{n = 'Manufacturer'; e = { $_.manufacturer } },
                    deviceName,
                    @{n = 'url'; e = { "https://intune.microsoft.com/$($Tenant.defaultDomainName)/#blade/Microsoft_Intune_Devices/DeviceSettingsBlade/overview/mdmDeviceId/$($_.id)" } }

                    $aliases = (($user.proxyAddresses | Where-Object { $_ -cnotmatch 'SMTP' -and $_ -notmatch '.onmicrosoft.com' }) -replace 'SMTP:', ' ') -join ', '

                    $userLicenses = ($user.AssignedLicenses.SkuID | ForEach-Object {
                            $UserLic = $_
                            $SkuPartNumber = ($Licenses | Where-Object { $_.SkuId -eq $UserLic }).SkuPartNumber
                            if (!$SkuPartNumber) {
                                $SkuPartNumber = 'Unknown License'
                            }
                            $SkuPartNumber
                        }) -join ', '

                    $UserOneDriveDetails = $OneDriveDetails | Where-Object { $_.ownerPrincipalName -eq $user.userPrincipalName }



                    [System.Collections.Generic.List[PSCustomObject]]$OneDriveFormatted = @()
                    if ($UserOneDriveDetails) {
                        try {
                            $OneDriveUsePercent = [math]::Round([float](($UserOneDriveDetails.storageUsedInBytes / $UserOneDriveDetails.storageAllocatedInBytes) * 100), 2)
                            $StorageUsed = [math]::Round($UserOneDriveDetails.storageUsedInBytes / 1024 / 1024 / 1024, 2)
                            $StorageAllocated = [math]::Round($UserOneDriveDetails.storageAllocatedInBytes / 1024 / 1024 / 1024, 2)
                        } catch {
                            $OneDriveUsePercent = 100
                            $StorageUsed = 0
                            $StorageAllocated = 0
                        }

                        $OneDriveFormatted.add($(Get-HuduFormattedField -Title 'Owner Principal Name' -Value "$($UserOneDriveDetails.ownerPrincipalName)"))
                        $OneDriveFormatted.add($(Get-HuduFormattedField -Title 'One Drive URL' -Value "<a href=$($UserOneDriveDetails.siteUrl)>$($UserOneDriveDetails.siteUrl)</a>"))
                        $OneDriveFormatted.add($(Get-HuduFormattedField -Title 'Is Deleted' -Value "$($UserOneDriveDetails.isDeleted)"))
                        $OneDriveFormatted.add($(Get-HuduFormattedField -Title 'Last Activity Date' -Value "$($UserOneDriveDetails.lastActivityDate)"))
                        $OneDriveFormatted.add($(Get-HuduFormattedField -Title 'File Count' -Value "$($UserOneDriveDetails.fileCount)"))
                        $OneDriveFormatted.add($(Get-HuduFormattedField -Title 'Active File Count' -Value "$($UserOneDriveDetails.activeFileCount)"))
                        $OneDriveFormatted.add($(Get-HuduFormattedField -Title 'Storage Used (Byte)' -Value "$($UserOneDriveDetails.storageUsedInBytes)"))
                        $OneDriveFormatted.add($(Get-HuduFormattedField -Title 'Storage Allocated (Byte)' -Value "$($UserOneDriveDetails.storageAllocatedInBytes)"))
                        $OneDriveUserUsage = @"
                        <div class="o365-usage">
                        <div class="o365-mailbox">
                            <div class="o365-used" style="width: $OneDriveUsePercent%;"></div>
                        </div>
                        <div><b>$($StorageUsed) GB</b> used, <b>$OneDriveUsePercent%</b> of <b>$($StorageAllocated) GB</b></div>
                    </div>
"@

                        $OneDriveFormatted.add($(Get-HuduFormattedField -Title 'One Drive Usage' -Value $OneDriveUserUsage))
                    }

                    [System.Collections.Generic.List[PSCustomObject]]$UserMailSettingsFormatted = @()
                    [System.Collections.Generic.List[PSCustomObject]]$UserMailboxDetailsFormatted = @()
                    if ($UserMailSettings) {
                        $UserMailSettingsFormatted.add($(Get-HuduFormattedField -Title 'Forward and Deliver' -Value "$($UserMailSettings.ForwardAndDeliver)"))
                        $UserMailSettingsFormatted.add($(Get-HuduFormattedField -Title 'Forwarding Address' -Value "$($UserMailSettings.ForwardingAddress)"))
                        $UserMailSettingsFormatted.add($(Get-HuduFormattedField -Title 'Litiation Hold' -Value "$($UserMailSettings.LitiationHold)"))
                        $UserMailSettingsFormatted.add($(Get-HuduFormattedField -Title 'Hidden From Address Lists' -Value "$($UserMailSettings.HiddenFromAddressLists)"))
                        $UserMailSettingsFormatted.add($(Get-HuduFormattedField -Title 'EWS Enabled' -Value "$($UserMailSettings.EWSEnabled)"))
                        $UserMailSettingsFormatted.add($(Get-HuduFormattedField -Title 'MAPI Enabled' -Value "$($UserMailSettings.MailboxMAPIEnabled)"))
                        $UserMailSettingsFormatted.add($(Get-HuduFormattedField -Title 'OWA Enabled' -Value "$($UserMailSettings.MailboxOWAEnabled)"))
                        $UserMailSettingsFormatted.add($(Get-HuduFormattedField -Title 'IMAP Enabled' -Value "$($UserMailSettings.MailboxImapEnabled)"))
                        $UserMailSettingsFormatted.add($(Get-HuduFormattedField -Title 'POP Enabled' -Value "$($UserMailSettings.MailboxPopEnabled)"))
                        $UserMailSettingsFormatted.add($(Get-HuduFormattedField -Title 'Active Sync Enabled' -Value "$($UserMailSettings.MailboxActiveSyncEnabled)"))


                        $UserMailboxDetailsFormatted.add($(Get-HuduFormattedField -Title 'Permissions' -Value "$($UserMailSettings.Permissions | ConvertTo-Html -Fragment | Out-String)"))

                        $UserMailboxDetailsFormatted.add($(Get-HuduFormattedField -Title 'Item Count' -Value "$($UserMailSettings.ItemCount)"))

                        try {
                            $UserMailboxUsePercent = [math]::Round([float](($UserMailSettings.StorageUsedInBytes / $UserMailSettings.prohibitSendReceiveQuota) * 100), 2)
                            $MailboxStorageUsed = [math]::Round($UserMailSettings.StorageUsedInBytes / 1024 / 1024 / 1024, 2)
                            $MailboxStorageAllocated = [math]::Round($UserMailSettings.prohibitSendReceiveQuota / 1024 / 1024 / 1024, 2)
                            $MailboxProhibitSendQuota = [math]::Round($UserMailSettings.ProhibitSendQuota / 1024 / 1024 / 1024, 2)
                        } catch {
                            $UserMailboxUsePercent = 100
                            $MailboxStorageUsed = 0
                            $MailboxStorageAllocated = 0
                        }

                        $UserMailboxDetailsFormatted.add($(Get-HuduFormattedField -Title 'Prohibit Send Quota' -Value "$($MailboxProhibitSendQuota) GB"))
                        $UserMailboxDetailsFormatted.add($(Get-HuduFormattedField -Title 'Prohibit Send Receive Quota' -Value "$($MailboxStorageAllocated) GB"))
                        $UserMailboxDetailsFormatted.add($(Get-HuduFormattedField -Title 'Total Mailbox Size' -Value "$($MailboxStorageUsed) GB"))

                        $UserMailboxUsage = @"
                            <div class="o365-usage">
                        <div class="o365-mailbox">
                            <div class="o365-used" style="width: $UserMailboxUsePercent%;"></div>
                        </div>
                        <div><b>$MailboxStorageUsed GB</b> used, <b>$UserMailboxUsePercent%</b> of <b>$MailboxStorageAllocated GB</b></div>
                    </div>
"@
                        $UserMailboxDetailsFormatted.add($(Get-HuduFormattedField -Title 'Mailbox Usage' -Value $UserMailboxUsage))

                    }

                    # Enhanced Conditional Access Policy formatting
                    if ($UserPolicies) {
                        $UserPoliciesFormatted = $UserPolicies | ConvertTo-Html -Fragment -Property @(
                            @{ Name = 'Policy Name'; Expression = { $_.displayName } },
                            @{ Name = 'State'; Expression = { $_.state } },
                            @{ Name = 'MFA Requirement'; Expression = { $_.authenticationStrength } },
                            @{ Name = 'Client Apps'; Expression = { $_.clientAppTypes } },
                            @{ Name = 'Sign-in Frequency'; Expression = { $_.signInFrequency } },
                            @{ Name = 'User Risk'; Expression = { $_.userRiskLevels } },
                            @{ Name = 'Sign-in Risk'; Expression = { $_.signInRiskLevels } }
                        ) | Out-String
                    } else {
                        $UserPoliciesFormatted = '<p>No Conditional Access policies assigned to this user.</p>'
                    }

                    [System.Collections.Generic.List[PSCustomObject]]$UserOverviewFormatted = @()
                    $UserOverviewFormatted.add($(Get-HuduFormattedField -Title 'User Name' -Value "$($User.displayName)"))
                    $UserOverviewFormatted.add($(Get-HuduFormattedField -Title 'User Principal Name' -Value "$($User.userPrincipalName)"))
                    $UserOverviewFormatted.add($(Get-HuduFormattedField -Title 'User ID' -Value "$($User.ID)"))
                    $UserOverviewFormatted.add($(Get-HuduFormattedField -Title 'User Enabled' -Value "$($User.accountEnabled)"))
                    $UserOverviewFormatted.add($(Get-HuduFormattedField -Title 'Job Title' -Value "$($User.jobTitle)"))
                    $UserOverviewFormatted.add($(Get-HuduFormattedField -Title 'Mobile Phone' -Value "$($User.mobilePhone)"))
                    $UserOverviewFormatted.add($(Get-HuduFormattedField -Title 'Business Phones' -Value "$($User.businessPhones -join ', ')"))
                    $UserOverviewFormatted.add($(Get-HuduFormattedField -Title 'Office Location' -Value "$($User.officeLocation)"))
                    $UserOverviewFormatted.add($(Get-HuduFormattedField -Title 'Aliases' -Value "$aliases"))
                    $UserOverviewFormatted.add($(Get-HuduFormattedField -Title 'Licenses' -Value "$($userLicenses)"))

                    $AssignedPlans = $User.assignedplans | Where-Object { $_.capabilityStatus -eq 'Enabled' } | Select-Object @{n = 'Assigned'; e = { $_.assignedDateTime } }, @{n = 'Service'; e = { $_.service } } -Unique
                    [System.Collections.Generic.List[PSCustomObject]]$AssignedPlansFormatted = @()
                    foreach ($AssignedPlan in $AssignedPlans) {
                        if ($AssignedPlan.service -in ($AssignedMap | Get-Member -MemberType NoteProperty).name) {
                            $CSSClass = $AssignedMap."$($AssignedPlan.service)"
                            $PlanDisplayName = $AssignedNameMap."$($AssignedPlan.service)"
                            $ParsedDate = Get-Date($AssignedPlan.Assigned) -Format 'yyyy-MM-dd HH:mm:ss'
                            $AssignedPlansFormatted.add("<div class='o365__app $CSSClass' style='text-align:center'><strong>$PlanDisplayName</strong><font style='font-size: .72rem;'>Assigned $($ParsedDate)</font></div>")
                        }
                    }
                    $AssignedPlansBlock = "<div class='o365'>$($AssignedPlansFormatted -join '')</div>"

                    if ($UserMailSettingsFormatted) {
                        $UserMailSettingsBlock = Get-HuduFormattedBlock -Heading 'Mailbox Settings' -Body ($UserMailSettingsFormatted -join '')
                    } else {
                        $UserMailSettingsBlock = $null
                    }

                    if ($UserMailboxDetailsFormatted) {
                        $UserMailDetailsBlock = Get-HuduFormattedBlock -Heading 'Mailbox Details' -Body ($UserMailboxDetailsFormatted -join '')
                    } else {
                        $UserMailDetailsBlock = $null
                    }

                    if ($UserGroups) {
                        $UserGroupsBlock = Get-HuduFormattedBlock -Heading 'User Groups' -Body $($UserGroups | ConvertTo-Html -Fragment -As Table | Out-String)
                    } else {
                        $UserGroupsBlock = $null
                    }

                    if ($UserPoliciesFormatted) {
                        $UserPoliciesBlock = Get-HuduFormattedBlock -Heading 'Assigned Conditional Access Policies' -Body $UserPoliciesFormatted
                    } else {
                        $UserPoliciesBlock = $null
                    }

                    if ($OneDriveFormatted) {
                        $OneDriveBlock = Get-HuduFormattedBlock -Heading 'One Drive Details' -Body ($OneDriveFormatted -join '')
                    } else {
                        $OneDriveBlock = $null
                    }

                    if ($UserOverviewFormatted) {
                        $UserOverviewBlock = Get-HuduFormattedBlock -Heading 'User Details' -Body $UserOverviewFormatted
                    } else {
                        $UserOverviewBlock = $null
                    }

                    if ($UserDevicesDetailsRaw) {
                        $UserDevicesDetailsBlock = Get-HuduFormattedBlock -Heading 'Intune Devices' -Body $($UserDevicesDetailsRaw | Select-Object -ExcludeProperty deviceName, url | ConvertTo-Html -Fragment | ForEach-Object { $tmp = $_ -replace '&lt;', '<'; $tmp -replace '&gt;', '>'; } | Out-String)
                    } else {
                        $UserDevicesDetailsBlock = $null
                    }

                    $HuduUser = $People | Where-Object { ($_.fields.label -eq 'Email Address' -and $_.fields.value -eq $user.userPrincipalName) -or $_.primary_mail -eq $user.userPrincipalName -or ($_.cards.integrator_name -eq 'cw_manage' -and $_.cards.data.communicationItems.communicationType -eq 'Email' -and $_.cards.data.communicationItems.value -eq $user.userPrincipalName) }

                    [System.Collections.Generic.List[PSCustomObject]]$CIPPLinksFormatted = @()
                    if ($EnableCIPP) {
                        $CIPPLinksFormatted.add((Get-HuduLinkBlock -URL "$($CIPPURL)/identity/administration/users/user?tenantFilter=$($Tenant.defaultDomainName)&userId=$($User.id)" -Icon 'far fa-eye' -Title 'CIPP - View User'))
                        $CIPPLinksFormatted.add((Get-HuduLinkBlock -URL "$($CIPPURL)/identity/administration/users/user/edit?tenantFilter=$($Tenant.defaultDomainName)&userId=$($User.id)" -Icon 'fas fa-user-cog' -Title 'CIPP - Edit User'))
                        $CIPPLinksFormatted.add((Get-HuduLinkBlock -URL "$($CIPPURL)/identity/administration/users/user/bec?tenantFilter=$($Tenant.defaultDomainName)&userId=$($User.id))" -Icon 'fas fa-user-secret' -Title 'CIPP - BEC Tool'))
                    }

                    [System.Collections.Generic.List[PSCustomObject]]$UserLinksFormatted = @()
                    $UserLinksFormatted.add((Get-HuduLinkBlock -URL "https://entra.microsoft.com/$($Tenant.defaultDomainName)/#blade/Microsoft_AAD_IAM/UserDetailsMenuBlade/Profile/userId/$($User.id)" -Icon 'fas fa-users-cog' -Title 'Entra ID'))
                    $UserLinksFormatted.add((Get-HuduLinkBlock -URL "https://entra.microsoft.com/$($Tenant.defaultDomainName)/#blade/Microsoft_AAD_IAM/UserDetailsMenuBlade/SignIns/userId/$($User.id)" -Icon 'fas fa-history' -Title 'Sign Ins'))
                    $UserLinksFormatted.add((Get-HuduLinkBlock -URL "https://admin.teams.microsoft.com/users/$($User.id)/account?delegatedOrg=$($Tenant.defaultDomainName)" -Icon 'fas fa-users' -Title 'Teams Admin'))
                    $UserLinksFormatted.add((Get-HuduLinkBlock -URL "https://intune.microsoft.com/$($Tenant.defaultDomainName)/#blade/Microsoft_AAD_IAM/UserDetailsMenuBlade/Profile/userId/$($User.ID)" -Icon 'fas fa-laptop' -Title 'Intune (User)'))
                    $UserLinksFormatted.add((Get-HuduLinkBlock -URL "https://intune.microsoft.com/$($Tenant.defaultDomainName)/#blade/Microsoft_AAD_IAM/UserDetailsMenuBlade/Devices/userId/$($User.ID)" -Icon 'fas fa-laptop' -Title 'Intune (Devices)'))

                    if ($HuduUser) {
                        $HaloCard = $HuduUser.cards | Where-Object { $_.integrator_name -eq 'halo' }
                        if ($HaloCard) {
                            $UserLinksFormatted.add((Get-HuduLinkBlock -URL "$($PSAUserUrl)$($HaloCard.sync_id)" -Icon 'far fa-id-card' -Title 'Halo PSA'))
                        }
                    }

                    $UserLinksBlock = "<div>Management Links</div><div class='o365'>$($UserLinksFormatted -join '')$($CIPPLinksFormatted -join '')</div>"

                    $UserBody = "<div>$AssignedPlansBlock<br />$UserLinksBlock<br /><div class=`"nasa__content`">$($UserOverviewBlock)$($UserMailDetailsBlock)$($OneDriveBlock)$($UserMailSettingsBlock)$($UserPoliciesBlock)</div><div class=`"nasa__content`">$($UserDevicesDetailsBlock)</div><div class=`"nasa__content`">$($UserGroupsBlock)</div></div>"

                    if (![string]::IsNullOrEmpty($PeopleLayoutId)) {
                        $UserAssetFields = @{
                            microsoft_365 = $UserBody
                            email_address = $user.userPrincipalName
                        }
                        $NewHash = Get-StringHash -String $UserBody
                        $HuduUserCount = ($HuduUser | Measure-Object).Count

                        if ($HuduUserCount -eq 1) {
                            $ExistingAsset = Get-CIPPAzDataTableEntity @HuduAssetCache -Filter "PartitionKey eq 'HuduUser' and CompanyId eq '$company_id' and RowKey eq '$($HuduUser.id)'"
                            $ExistingHash = $ExistingAsset.Hash

                            if (!$ExistingAsset -or $ExistingHash -ne $NewHash) {
                                $CompanyResult.Logs.Add("Updating $($HuduUser.name) in Hudu")
                                $null = Set-HuduAsset -asset_id $HuduUser.id -Name $HuduUser.name -company_id $company_id -asset_layout_id $PeopleLayout.id -Fields $UserAssetFields
                                $AssetCache = [PSCustomObject]@{
                                    PartitionKey = 'HuduUser'
                                    RowKey       = [string]$HuduUser.id
                                    CompanyId    = [string]$company_id
                                    Hash         = [string]$NewHash
                                }
                                Add-CIPPAzDataTableEntity @HuduAssetCache -Entity $AssetCache -Force
                            }

                        } elseif ($HuduUserCount -eq 0) {
                            if ($CreateUsers -eq $true) {
                                $CompanyResult.Logs.Add("Creating $($User.displayName) in Hudu")
                                $CreateHuduUser = (New-HuduAsset -Name $User.displayName -company_id $company_id -asset_layout_id $PeopleLayout.id -Fields $UserAssetFields).asset
                                if (!$CreateHuduUser) {
                                    $CompanyResult.Errors.add("User $($User.userPrincipalName): Unable to create user in Hudu. Check the User asset fields for 'Email Address'")
                                } else {
                                    $AssetCache = [PSCustomObject]@{
                                        PartitionKey = 'HuduUser'
                                        RowKey       = [string]$CreateHuduUser.id
                                        CompanyId    = [string]$company_id
                                        Hash         = [string]$NewHash
                                    }
                                    Add-CIPPAzDataTableEntity @HuduAssetCache -Entity $AssetCache -Force
                                    # Add newly created user to the People collection to prevent duplicates
                                    $People.Add($CreateHuduUser)
                                }
                            }
                        } else {
                            $CompanyResult.Errors.add("User $($User.userPrincipalName): Multiple Users Matched to email address in Hudu: ($($HuduUser.name -join ', ') - $($($HuduUser.id -join ', '))) $_")
                        }
                    }

                    $UserLink = "<a target=_blank href=$($HuduUser.url)>$($user.displayName)</a>"

                    [PSCustomObject]@{
                        'Display Name'      = $UserLink
                        'Addresses'         = "<strong>$($user.userPrincipalName)</strong><br/>$aliases"
                        'EPM Devices'       = $userDevices
                        'Assigned Licenses' = $userLicenses
                        'Options'           = "<a target=`"_blank`" href=https://entra.microsoft.com/$($Tenant.defaultDomainName)/#blade/Microsoft_AAD_IAM/UserDetailsMenuBlade/Profile/userId/$($user.id)>Azure AD</a> | <a <a target=`"_blank`" href=https://admin.microsoft.com/Partner/BeginClientSession.aspx?CTID=$($customer.CustomerContextId)&CSDEST=o365admincenter/Adminportal/Home#/users/:/UserDetails/$($user.id)>M365 Admin</a>"
                    }
                } catch {
                    $CompanyResult.Errors.add("User $($User.userPrincipalName): A fatal error occured while processing user $_")
                    Write-Warning "User $($User.userPrincipalName): A fatal error occured while processing user $_"
                    Write-Information $_.InvocationInfo.PositionMessage
                }
            }

            $licensedUserHTML = $OutputUsers | ConvertTo-Html -PreContent $pre -PostContent $post -Fragment | ForEach-Object { $tmp = $_ -replace '&lt;', '<'; $tmp -replace '&gt;', '>'; } | Out-String

        }

        if (![string]::IsNullOrEmpty($DeviceLayoutId)) {
            $CompanyResult.Logs.Add('Starting Device Processing')
            Write-Information "### Processing Devices for $($Tenant.defaultDomainName)"
            foreach ($Device in $Devices) {
                try {
                    [System.Collections.Generic.List[PSCustomObject]]$DeviceOverviewFormatted = @()
                    $DeviceOverviewFormatted.add($(Get-HuduFormattedField -Title 'Device Name' -Value "$($Device.deviceName)"))
                    $DeviceOverviewFormatted.add($(Get-HuduFormattedField -Title 'User' -Value "$($Device.userDisplayName)"))
                    $DeviceOverviewFormatted.add($(Get-HuduFormattedField -Title 'User Email' -Value "$($Device.userPrincipalName)"))
                    $DeviceOverviewFormatted.add($(Get-HuduFormattedField -Title 'Owner' -Value "$($Device.ownerType)"))
                    $DeviceOverviewFormatted.add($(Get-HuduFormattedField -Title 'Enrolled' -Value "$($Device.enrolledDateTime)"))
                    $DeviceOverviewFormatted.add($(Get-HuduFormattedField -Title 'Last Checkin' -Value "$($Device.lastSyncDateTime)"))
                    if ($Device.complianceState -eq 'compliant') {
                        $CompliantSymbol = '<font color=green><em class="fas fa-check-circle">&nbsp;&nbsp;&nbsp;</em></font>'
                    } else {
                        $CompliantSymbol = '<font color=red><em class="fas fa-times-circle">&nbsp;&nbsp;&nbsp;</em></font>'
                    }
                    $DeviceOverviewFormatted.add($(Get-HuduFormattedField -Title 'Compliant' -Value "$($CompliantSymbol)$($Device.complianceState)"))
                    $DeviceOverviewFormatted.add($(Get-HuduFormattedField -Title 'Management Type' -Value "$($Device.managementAgent)"))

                    [System.Collections.Generic.List[PSCustomObject]]$DeviceHardwareFormatted = @()
                    $DeviceHardwareFormatted.add($(Get-HuduFormattedField -Title 'Serial Number' -Value "$($Device.serialNumber)"))
                    $DeviceHardwareFormatted.add($(Get-HuduFormattedField -Title 'OS' -Value "$($Device.operatingSystem)"))
                    $DeviceHardwareFormatted.add($(Get-HuduFormattedField -Title 'OS Versions' -Value "$($Device.osVersion)"))
                    $DeviceHardwareFormatted.add($(Get-HuduFormattedField -Title 'Chassis' -Value "$($Device.chassisType)"))
                    $DeviceHardwareFormatted.add($(Get-HuduFormattedField -Title 'Model' -Value "$($Device.model)"))
                    $DeviceHardwareFormatted.add($(Get-HuduFormattedField -Title 'Manufacturer' -Value "$($Device.manufacturer)"))
                    $DeviceHardwareFormatted.add($(Get-HuduFormattedField -Title 'Total Storage' -Value "$([math]::Round($Device.totalStorageSpaceInBytes /1024 /1024 /1024, 2))"))
                    $DeviceHardwareFormatted.add($(Get-HuduFormattedField -Title 'Free Storage' -Value "$([math]::Round($Device.freeStorageSpaceInBytes /1024 /1024 /1024, 2))"))

                    [System.Collections.Generic.List[PSCustomObject]]$DeviceEnrollmentFormatted = @()
                    $DeviceEnrollmentFormatted.add($(Get-HuduFormattedField -Title 'Enrollment Type' -Value "$($Device.deviceEnrollmentType)"))
                    $DeviceEnrollmentFormatted.add($(Get-HuduFormattedField -Title 'Join Type' -Value "$($Device.joinType)"))
                    $DeviceEnrollmentFormatted.add($(Get-HuduFormattedField -Title 'Registration State' -Value "$($Device.deviceRegistrationState)"))
                    $DeviceEnrollmentFormatted.add($(Get-HuduFormattedField -Title 'Autopilot Enrolled' -Value "$($Device.autopilotEnrolled)"))
                    $DeviceEnrollmentFormatted.add($(Get-HuduFormattedField -Title 'Device Guard Requirements' -Value "$($Device.hardwareinformation.deviceGuardVirtualizationBasedSecurityHardwareRequirementState)"))
                    $DeviceEnrollmentFormatted.add($(Get-HuduFormattedField -Title 'Virtualistation Based Security' -Value "$($Device.hardwareinformation.deviceGuardVirtualizationBasedSecurityState)"))
                    $DeviceEnrollmentFormatted.add($(Get-HuduFormattedField -Title 'Credential Guard' -Value "$($Device.hardwareinformation.deviceGuardLocalSystemAuthorityCredentialGuardState)"))

                    $DevicePoliciesTable = foreach ($Policy in $DeviceComplianceDetails) {
                        # Handle DeviceStatuses as either array or single object
                        $DeviceStatuses = $Policy.DeviceStatuses

                        # Enhanced device matching with multiple strategies
                        $MatchingStatuses = $DeviceStatuses | Where-Object {
                            # Primary match: deviceDisplayName to deviceName (most reliable)
                            ($_.deviceDisplayName -eq $device.deviceName) -or
                            # Secondary match: deviceDisplayName to managedDeviceName
                            ($_.deviceDisplayName -eq $device.managedDeviceName) -or
                            # Tertiary match: extract device ID from composite compliance ID and match to device.id
                            ($_.id -and $device.id -and $_.id -match ".*_$([regex]::Escape($device.id))$") -or
                            # Quaternary match: extract device ID from composite compliance ID and match to azureADDeviceId
                            ($_.id -and $device.azureADDeviceId -and $_.id -match ".*_$([regex]::Escape($device.azureADDeviceId))$") -or
                            # Alternative match: check if azureADDeviceId appears anywhere in the compliance ID
                            ($_.id -and $device.azureADDeviceId -and $_.id -like "*$($device.azureADDeviceId)*")
                        }

                        if ($MatchingStatuses) {
                            foreach ($Status in $MatchingStatuses) {
                                Write-Information "Processing Status for Device $($device.deviceName), Policy $($Policy.displayName)"
                                # Filter out invalid statuses
                                if ($Status.status -and $Status.status -ne 'unknown' -and $Status.status -ne $null) {
                                    try {
                                        $LastReport = if ($Status.lastReportedDateTime) {
                                            (Get-Date $Status.lastReportedDateTime -Format 'yyyy-MM-dd HH:mm:ss')
                                        } else { 'N/A' }

                                        $GraceExpiry = if ($Status.complianceGracePeriodExpirationDateTime) {
                                            (Get-Date $Status.complianceGracePeriodExpirationDateTime -Format 'yyyy-MM-dd HH:mm:ss')
                                        } else { 'N/A' }

                                        [PSCustomObject]@{
                                            Name           = $Policy.displayName
                                            Status         = $Status.status
                                            'Last Report'  = $LastReport
                                            'Grace Expiry' = $GraceExpiry
                                            'Match Method' = if ($Status.deviceDisplayName -eq $device.deviceName) { 'Device Name' }
                                            elseif ($Status.deviceDisplayName -eq $device.managedDeviceName) { 'Managed Name' }
                                            else { 'Device ID' }
                                        }
                                    } catch {
                                        # Log but continue processing if date parsing fails
                                        Write-Warning "Failed to parse compliance policy dates for device $($device.deviceName), policy $($Policy.displayName): $_"
                                        [PSCustomObject]@{
                                            Name           = $Policy.displayName
                                            Status         = $Status.status
                                            'Last Report'  = 'Parse Error'
                                            'Grace Expiry' = 'Parse Error'
                                            'Match Method' = 'Error'
                                        }
                                    }
                                }
                            }
                        }
                    }
                    $DevicePoliciesFormatted = $DevicePoliciesTable | ConvertTo-Html -Fragment | Out-String

                    $DeviceGroupsTable = foreach ($Group in $Groups) {
                        if ($device.azureADDeviceId -in $Group.members.deviceId) {
                            [PSCustomObject]@{
                                Name = $Group.displayName
                            }
                        }
                    }
                    $DeviceGroupsFormatted = $DeviceGroupsTable | ConvertTo-Html -Fragment | Out-String
                    <#
                $DeviceAppsTable = foreach ($App in $DeviceAppInstallDetails) {
                    if ($device.id -in $App.InstalledAppDetails.deviceId) {
                        $Status = $App.InstalledAppDetails | Where-Object { $_.deviceId -eq $device.id }
                        [PSCustomObject]@{
                            Name             = $App.displayName
                            'Install Status' = ($Status.installState | Select-Object -Unique ) -join ','
                        }
                    }
                }
                $DeviceAppsFormatted = $DeviceAppsTable | ConvertTo-Html -Fragment | Out-String
#>
                    $DeviceOverviewBlock = Get-HuduFormattedBlock -Heading 'Device Details' -Body ($DeviceOverviewFormatted -join '')
                    $DeviceHardwareBlock = Get-HuduFormattedBlock -Heading 'Hardware Details' -Body ($DeviceHardwareFormatted -join '')
                    $DeviceEnrollmentBlock = Get-HuduFormattedBlock -Heading 'Device Enrollment Details' -Body ($DeviceEnrollmentFormatted -join '')
                    $DevicePolicyBlock = Get-HuduFormattedBlock -Heading 'Compliance Policies' -Body ($DevicePoliciesFormatted -join '')
                    #$DeviceAppsBlock = Get-HuduFormattedBlock -Heading 'App Details' -Body ($DeviceAppsFormatted -join '')
                    $DeviceGroupsBlock = Get-HuduFormattedBlock -Heading 'Device Groups' -Body ($DeviceGroupsFormatted -join '')

                    if ("$($device.serialNumber)" -in $ExcludeSerials) {
                        $HuduDevice = $HuduDevices | Where-Object { $_.name -eq $device.deviceName -or ($_.cards.integrator_name -eq 'cw_manage' -and $_.cards.data.name -contains $device.deviceName) }
                    } else {
                        $HuduDevice = $HuduDevices | Where-Object { $_.primary_serial -eq $device.serialNumber -or ($_.cards.integrator_name -eq 'cw_manage' -and $_.cards.data.serialNumber -eq $device.serialNumber) }
                        if (!$HuduDevice) {
                            $HuduDevice = $HuduDevices | Where-Object { $_.name -eq $device.deviceName -or ($_.cards.integrator_name -eq 'cw_manage' -and $_.cards.data.name -contains $device.deviceName) }
                        }
                    }

                    [System.Collections.Generic.List[PSCustomObject]]$DeviceLinksFormatted = @()
                    $DeviceLinksFormatted.add((Get-HuduLinkBlock -URL "https://intune.microsoft.com/$($Tenant.defaultDomainName)/#blade/Microsoft_Intune_Devices/DeviceSettingsBlade/overview/mdmDeviceId/$($Device.id)" -Icon 'fas fa-laptop' -Title 'Endpoint Manager'))

                    if ($HuduDevice) {
                        $DRMMCard = $HuduDevice.cards | Where-Object { $_.integrator_name -eq 'dattormm' }
                        if ($DRMMCard) {
                            $DeviceLinksFormatted.add((Get-HuduLinkBlock -URL "$($RMMDeviceURL)$($DRMMCard.data.id)" -Icon 'fas fa-laptop-code' -Title 'Datto RMM'))
                            $DeviceLinksFormatted.add((Get-HuduLinkBlock -URL "$($RMMRemoteURL)$($DRMMCard.data.id)" -Icon 'fas fa-desktop' -Title 'Datto RMM Remote'))
                        }
                        $ManageCard = $HuduDevice.cards | Where-Object { $_.integrator_name -eq 'cw_manage' }
                        if ($ManageCard) {
                            $DeviceLinksFormatted.add((Get-HuduLinkBlock -URL $ManageCard.data.managementLink -Icon 'fas fa-laptop-code' -Title 'CW Automate'))
                            $DeviceLinksFormatted.add((Get-HuduLinkBlock -URL $ManageCard.data.remoteLink -Icon 'fas fa-desktop' -Title 'CW Control'))
                        }
                    }

                    $DeviceLinksBlock = "<div>Management Links</div><div class='o365'>$($DeviceLinksFormatted -join '')</div>"

                    $DeviceIntuneDetailshtml = "<div><div>$DeviceLinksBlock<br /><div class=`"nasa__content`">$($DeviceOverviewBlock)$($DeviceHardwareBlock)$($DeviceEnrollmentBlock)$($DevicePolicyBlock)$($DeviceAppsBlock)$($DeviceGroupsBlock)</div></div>"

                    $DeviceAssetFields = @{
                        microsoft_365 = $DeviceIntuneDetailshtml
                    }
                    $NewHash = Get-StringHash -String $DeviceIntuneDetailshtml

                    if (![string]::IsNullOrEmpty($DeviceLayoutId)) {
                        if ($HuduDevice) {
                            if (($HuduDevice | Measure-Object).count -eq 1) {
                                $ExistingAsset = Get-CIPPAzDataTableEntity @HuduAssetCache -Filter "PartitionKey eq 'HuduDevice' and CompanyId eq '$company_id' and RowKey eq '$($HuduDevice.id)'"
                                $ExistingHash = $ExistingAsset.Hash

                                if (!$ExistingAsset -or $ExistingAsset.Hash -ne $NewHash) {
                                    $CompanyResult.Logs.Add("Updating $($HuduDevice.name) in Hudu")
                                    $null = Set-HuduAsset -asset_id $HuduDevice.id -Name $HuduDevice.name -company_id $company_id -asset_layout_id $HuduDevice.asset_layout_id -Fields $DeviceAssetFields -PrimarySerial $Device.serialNumber
                                    $AssetCache = [PSCustomObject]@{
                                        PartitionKey = 'HuduDevice'
                                        RowKey       = [string]$HuduDevice.id
                                        CompanyId    = [string]$company_id
                                        Hash         = [string]$NewHash
                                    }
                                    Add-CIPPAzDataTableEntity @HuduAssetCache -Entity $AssetCache -Force
                                }

                                if (![string]::IsNullOrEmpty($Device.userPrincipalName)) {
                                    $RelHuduUser = $People | Where-Object { ($_.fields.label -eq 'Email Address' -and $_.fields.value -eq $Device.userPrincipalName) -or $_.primary_mail -eq $Device.userPrincipalName -or ($_.cards.integrator_name -eq 'cw_manage' -and $_.cards.data.communicationItems.communicationType -eq 'Email' -and $_.cards.data.communicationItems.value -eq $Device.userPrincipalName) }

                                    if ($RelHuduUser) {
                                        $Relation = $HuduRelations | Where-Object { $_.fromable_type -eq 'Asset' -and $_.fromable_id -eq $RelHuduUser.id -and $_.toable_type -eq 'Asset' -and $_.toable_id -eq $HuduDevice.id }
                                        if (-not $Relation) {
                                            try {
                                                Write-Information "Creating relation between $($RelHuduUser.name) and $($HuduDevice.name)"
                                                $null = New-HuduRelation -FromableType 'Asset' -FromableID $RelHuduUser.id -ToableType 'Asset' -ToableID $HuduDevice.id -ea stop
                                            } catch {
                                                Write-Warning "Failed to create relation between $($RelHuduUser.name) and $($HuduDevice.name): $_"
                                                $CompanyResult.Errors.add("Device $($device.deviceName): Failed to create relation between user and device: $_")
                                            }
                                        }
                                    }
                                }
                            } else {
                                $CompanyResult.Errors.add("Device $($HuduDevice.name): Multiple devices matched on name or serial ($($device.serialNumber -join ', '))")
                            }
                        } else {
                            if ($device.deviceType -in $IntuneDesktopDeviceTypes) {
                                $DeviceLayoutID = $DesktopsLayout.id
                                $DeviceCreation = $CreateDevices
                            } else {
                                $DeviceLayoutID = $MobilesLayout.id
                                $DeviceCreation = $CreateMobileDevices
                            }
                            if ($DeviceCreation -eq $true) {
                                $CompanyResult.Logs.Add("Creating $($device.deviceName) in Hudu")
                                $CreateHuduDevice = (New-HuduAsset -Name $device.deviceName -company_id $company_id -asset_layout_id $DeviceLayoutID -Fields $DeviceAssetFields -PrimarySerial $Device.serialNumber).asset

                                if (!$CreateHuduDevice) {
                                    $CompanyResult.Errors.add("Device $($device.deviceName): Failed to create device in Hudu, check your device asset fields for 'Primary Serial'.")
                                } else {
                                    $AssetCache = [PSCustomObject]@{
                                        PartitionKey = 'HuduDevice'
                                        RowKey       = [string]$CreateHuduDevice.id
                                        CompanyId    = [string]$company_id
                                        Hash         = [string]$NewHash
                                    }
                                    Add-CIPPAzDataTableEntity @HuduAssetCache -Entity $AssetCache -Force
                                    # Add newly created device to the HuduDevices collection to prevent duplicates
                                    $HuduDevices.Add($CreateHuduDevice)

                                    $RelHuduUser = $People | Where-Object { $_.primary_mail -eq $Device.userPrincipalName -or ($_.cards.integrator_name -eq 'cw_manage' -and $_.cards.data.communicationItems.communicationType -eq 'Email' -and $_.cards.data.communicationItems.value -eq $Device.userPrincipalName) }
                                    if ($RelHuduUser) {
                                        try {
                                            $null = New-HuduRelation -FromableType 'Asset' -FromableID $RelHuduUser.id -ToableType 'Asset' -ToableID $CreateHuduDevice.id -ea stop
                                        } catch {
                                            # No need to do anything here as its will be when relations already exist.
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch {
                    $CompanyResult.Errors.add("Device $($device.deviceName): A Fatal Error occured while processing the device $_")
                }
            }
        } else {
            $CompanyResult.Logs.Add('Skipping Device Processing - No Device Layout ID')
        }


        $body = "<div class='nasa__block'>
			<header class='nasa__block-header'>
			<h1><i class='fas fa-cogs icon'></i>Administrative Portals</h1>
	 		</header>
			<div class=`"o365 nasa__content`">$CustomerLinks</div>
			<br/>
			</div>
			<br/>
			<div class=`"nasa__content`">
			 $detailstable
			 $licenseHTML
			 </div>
             <br/>
			 <div class=`"nasa__content`">
			 $RolesHtml
			 </div>
			 <br/>
			 <div class=`"nasa__content`">
			 $licensedUserHTML
			 </div>"

        try {
            $null = Set-HuduMagicDash -Title "Microsoft 365 - $($Tenant.displayName)" -company_name $TenantMap.IntegrationName -Message "$($licensedUsers.count) Licensed Users" -Icon 'fab fa-microsoft' -Content $body -Shade 'success'
            $CompanyResult.Logs.Add("Updated Magic Dash for $($Tenant.displayName)")
        } catch {
            $CompanyResult.Errors.add("Company: Failed to add Magic Dash to Company: $_")
        }

        try {
            if ($importDomains) {
                $CompanyResult.Logs.Add('Starting Domain Processing')
                $domainstoimport = $ExtensionCache.Domains
                foreach ($imp in $domainstoimport) {
                    $impdomain = $imp.id
                    $huduimpdomain = Get-HuduWebsites -Name "https://$impdomain"
                    if ($($huduimpdomain.id.count) -eq 0) {
                        if ($monitorDomains) {
                            $null = New-HuduWebsite -Name "https://$impdomain" -Notes $HuduNotes -Paused 'false' -CompanyId $company_id -DisableDNS 'false' -DisableSSL 'false' -DisableWhois 'false'
                        } else {
                            $null = New-HuduWebsite -Name "https://$impdomain" -Notes $HuduNotes -Paused 'true' -CompanyId $company_id -DisableDNS 'true' -DisableSSL 'true' -DisableWhois 'true'
                        }

                    }
                }

            }
        } catch {
            $CompanyResult.Errors.add("Company: Failed to import domain: $_")
            Write-LogMessage -tenant $Tenant.defaultDomainName -tenantid $Tenant.customerId -API 'Hudu Sync' -message "Company: Failed to import domain: $_" -level 'Error'
        }
        Write-LogMessage -tenant $Tenant.defaultDomainName -tenantid $Tenant.customerId -API 'Hudu Sync' -message 'Company: Completed Sync' -level 'Information'
        $CompanyResult.Logs.Add('Hudu Sync Completed')
    } catch {
        Write-Warning "Company: A fatal error occured: $_"
        Write-Information $_.InvocationInfo.PositionMessage
        Write-LogMessage -tenant $Tenant.defaultDomainName -tenantid $Tenant.customerId -API 'Hudu Sync' -message "Company: A fatal error occured: $_" -level 'Error'
        $CompanyResult.Errors.add("Company: A fatal error occured: $_")
    }
    return $CompanyResult
}
#EndRegion './Public/Hudu/Invoke-HuduExtensionSync.ps1' 1085
#Region './Public/Hudu/Set-HuduMapping.ps1' -1

function Set-HuduMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping,
        $APIName,
        $Request
    )
    Get-CIPPAzDataTableEntity @CIPPMapping -Filter "PartitionKey eq 'HuduMapping'" | ForEach-Object {
        Remove-AzDataTableEntity -Force @CIPPMapping -Entity $_
    }
    foreach ($Mapping in $Request.Body) {
        $AddObject = @{
            PartitionKey    = 'HuduMapping'
            RowKey          = "$($mapping.TenantId)"
            IntegrationId   = "$($mapping.IntegrationId)"
            IntegrationName = "$($mapping.IntegrationName)"
        }

        Add-CIPPAzDataTableEntity @CIPPMapping -Entity $AddObject -Force
        Write-LogMessage -API $APINAME -headers $Request.Headers -message "Added mapping for $($mapping.name)." -Sev 'Info'
    }
    $Result = [pscustomobject]@{'Results' = 'Successfully edited mapping table.' }

    Return $Result
}
#EndRegion './Public/Hudu/Set-HuduMapping.ps1' 26
#Region './Public/New-CippExtAlert.ps1' -1

function New-CippExtAlert {
    [CmdletBinding()]
    param (
        [switch]$TestRun = $false,
        [pscustomobject]$Alert
    )
    #Get the current CIPP Alerts table and see what system is configured to receive alerts
    $Table = Get-CIPPTable -TableName Extensionsconfig
    $Configuration = (Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json -Depth 10 -ErrorAction SilentlyContinue
    $MappingTable = Get-CIPPTable -TableName CippMapping

    foreach ($ConfigItem in $Configuration.psobject.properties.name) {
        switch ($ConfigItem) {
            'HaloPSA' {
                if ($Configuration.HaloPSA.enabled) {
                    $MappingFile = Get-CIPPAzDataTableEntity @MappingTable -Filter "PartitionKey eq 'HaloMapping'"
                    $TenantId = (Get-Tenants | Where-Object defaultDomainName -EQ $Alert.TenantId).customerId
                    Write-Host "TenantId: $TenantId"
                    $MappedId = ($MappingFile | Where-Object { $_.RowKey -eq $TenantId }).IntegrationId
                    Write-Host "MappedId: $MappedId"
                    if (!$mappedId) { $MappedId = 1 }
                    Write-Host "MappedId: $MappedId"
                    New-HaloPSATicket -Title $Alert.AlertTitle -Description $Alert.AlertText -Client $mappedId
                }
            }
            'Gradient' {
                if ($Configuration.Gradient.enabled) {
                    New-GradientAlert -Title $Alert.AlertTitle -Description $Alert.AlertText -Client $Alert.TenantId
                }
            }
        }
    }

}
#EndRegion './Public/New-CippExtAlert.ps1' 35
#Region './Public/NinjaOne/Get-NinjaOneFieldMapping.ps1' -1

function Get-NinjaOneFieldMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping
    )
    try {
        #Get available mappings
        $Mappings = [pscustomobject]@{}

        [System.Collections.Generic.List[object]]$CIPPFieldHeaders = @(
            [PSCustomObject]@{
                Title       = 'NinjaOne Organization Global Custom Field Mapping'
                FieldType   = 'Organization'
                Description = 'Use the table below to map your Organization Field to the correct NinjaOne Field'
            }
            [PSCustomObject]@{
                Title       = 'NinjaOne Device Custom Field Mapping'
                FieldType   = 'Device'
                Description = 'Use the table below to map your Device Field to the correct NinjaOne Field'
            }
        )

        [System.Collections.Generic.List[object]]$CIPPFields = @(
            [PSCustomObject]@{
                FieldName  = 'TenantLinks'
                FieldLabel = 'Microsoft 365 Tenant Links - Field Used to Display Links to Microsoft 365 Portals and CIPP'
                FieldType  = 'Organization'
                Type       = 'WYSIWYG'
            },
            [PSCustomObject]@{
                FieldName  = 'TenantSummary'
                FieldLabel = 'Microsoft 365 Tenant Summary - Field Used to Display Tenant Summary Information'
                FieldType  = 'Organization'
                Type       = 'WYSIWYG'
            },
            [PSCustomObject]@{
                FieldName  = 'UsersSummary'
                FieldLabel = 'Microsoft 365 Users Summary - Field Used to Display User Summary Information'
                FieldType  = 'Organization'
                Type       = 'WYSIWYG'
            },
            [PSCustomObject]@{
                FieldName  = 'DeviceLinks'
                FieldLabel = 'Microsoft 365 Device Links - Field Used to Display Links to Microsoft 365 Portals and CIPP'
                FieldType  = 'Device'
                Type       = 'WYSIWYG'
            },
            [PSCustomObject]@{
                FieldName  = 'DeviceSummary'
                FieldLabel = 'Microsoft 365 Device Summary - Field Used to Display Device Summary Information'
                FieldType  = 'Device'
                Type       = 'WYSIWYG'
            },
            [PSCustomObject]@{
                FieldName  = 'DeviceCompliance'
                FieldLabel = 'Intune Device Compliance Status - Field Used to Monitor Device Compliance'
                FieldType  = 'Device'
                Type       = 'TEXT'
            }
        )

        $MappingFieldMigrate = Get-CIPPAzDataTableEntity @CIPPMapping -Filter "PartitionKey eq 'NinjaFieldMapping'" | ForEach-Object {
            [PSCustomObject]@{
                PartitionKey    = 'NinjaOneFieldMapping'
                RowKey          = $_.RowKey
                IntegrationId   = $_.NinjaOne
                IntegrationName = $_.NinjaOneName
            }
            Remove-AzDataTableEntity -Force @CIPPMapping -Entity $_
        }
        if (($MappingFieldMigrate | Measure-Object).count -gt 0) {
            Add-CIPPAzDataTableEntity @CIPPMapping -Entity $MappingFieldMigrate -Force
        }

        $Mappings = Get-ExtensionMapping -Extension 'NinjaOneField'

        $Table = Get-CIPPTable -TableName Extensionsconfig
        $Configuration = ((Get-AzDataTableEntity @Table).config | ConvertFrom-Json -ea stop).NinjaOne

        $Token = Get-NinjaOneToken -configuration $Configuration

        $NinjaCustomFieldsNodeRaw = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/device-custom-fields?scopes=node" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100

        [System.Collections.Generic.List[object]]$NinjaCustomFieldsNode = $NinjaCustomFieldsNodeRaw | Where-Object { $_.apiPermission -eq 'READ_WRITE' -and $_.type -in $CIPPFields.Type } | Select-Object @{n = 'name'; e = { $_.label } }, @{n = 'value'; e = { $_.name } }, type, @{n = 'FieldType'; e = { 'Device' } }

        $NinjaCustomFieldsOrgRaw = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/device-custom-fields?scopes=organization" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100

        [System.Collections.Generic.List[object]]$NinjaCustomFieldsOrg = $NinjaCustomFieldsOrgRaw | Where-Object { $_.apiPermission -eq 'READ_WRITE' -and $_.type -in $CIPPFields.Type } | Select-Object @{n = 'name'; e = { $_.label } }, @{n = 'value'; e = { $_.name } }, type, @{n = 'FieldType'; e = { 'Organization' } }

        if ($Null -eq $NinjaCustomFieldsNode) {
            [System.Collections.Generic.List[object]]$NinjaCustomFieldsNode = @()
        }

        if ($Null -eq $NinjaCustomFieldsOrg) {
            [System.Collections.Generic.List[object]]$NinjaCustomFieldsOrg = @()
        }
        $Unset = [PSCustomObject]@{
            name  = '--- Do not synchronize ---'
            value = $null
            type  = 'unset'
        }

    } catch {
        [System.Collections.Generic.List[object]]$NinjaCustomFieldsNode = @()
        [System.Collections.Generic.List[object]]$NinjaCustomFieldsOrg = @()
    }

    $MappingObj = [PSCustomObject]@{
        CIPPFields        = $CIPPFields
        CIPPFieldHeaders  = $CIPPFieldHeaders
        IntegrationFields = @($Unset) + @($NinjaCustomFieldsOrg) + @($NinjaCustomFieldsNode)
        Mappings          = @($Mappings)
    }

    return $MappingObj

}
#EndRegion './Public/NinjaOne/Get-NinjaOneFieldMapping.ps1' 118
#Region './Public/NinjaOne/Get-NinjaOneOrgMapping.ps1' -1

function Get-NinjaOneOrgMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping
    )
    try {
        $Tenants = Get-Tenants -IncludeErrors

        $ExtensionMappings = Get-ExtensionMapping -Extension 'NinjaOne'

        $Tenants = Get-Tenants -IncludeErrors

        $Mappings = foreach ($Mapping in $ExtensionMappings) {
            $Tenant = $Tenants | Where-Object { $_.RowKey -eq $Mapping.RowKey }
            if ($Tenant) {
                [PSCustomObject]@{
                    TenantId        = $Tenant.customerId
                    Tenant          = $Tenant.displayName
                    TenantDomain    = $Tenant.defaultDomainName
                    IntegrationId   = $Mapping.IntegrationId
                    IntegrationName = $Mapping.IntegrationName
                }
            }
        }
        #Get Available Tenants

        #Get available Ninja clients
        $Table = Get-CIPPTable -TableName Extensionsconfig
        $Configuration = ((Get-AzDataTableEntity @Table).config | ConvertFrom-Json -ea stop).NinjaOne


        $Token = Get-NinjaOneToken -configuration $Configuration

        $After = 0
        $PageSize = 1000
        $NinjaOrgs = do {
            $Result = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organizations?pageSize=$PageSize&after=$After" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100
            $Result | Select-Object name, @{n = 'value'; e = { $_.id } }
            $ResultCount = ($Result.id | Measure-Object -Maximum)
            $After = $ResultCount.maximum

        } while ($ResultCount.count -eq $PageSize)

    } catch {
        $Message = if ($_.ErrorDetails.Message) {
            Get-NormalizedError -Message $_.ErrorDetails.Message
        } else {
            $_.Exception.message
        }

        $NinjaOrgs = @(@{ name = 'Could not get NinjaOne Orgs, check your API credentials and try again.'; value = '-1' })
    }

    $MappingObj = [PSCustomObject]@{
        Companies = @($NinjaOrgs | Sort-Object name)
        Mappings  = @($Mappings)
    }

    return $MappingObj

}
#EndRegion './Public/NinjaOne/Get-NinjaOneOrgMapping.ps1' 62
#Region './Public/NinjaOne/Get-NinjaOneToken.ps1' -1

function Get-NinjaOneToken {
    [CmdletBinding()]
    param (
        $Configuration
    )

    $ClientSecret = Get-ExtensionAPIKey -Extension 'NinjaOne'

    $body = @{
        grant_type    = 'client_credentials'
        client_id     = $Configuration.ClientId
        client_secret = $ClientSecret
        scope         = 'monitoring management'
    }

    try {

        $token = Invoke-RestMethod -Uri "https://$($Configuration.Instance -replace '/ws','')/ws/oauth/token" -Method Post -Body $body -ContentType 'application/x-www-form-urlencoded'
    } catch {
        $Message = if ($_.ErrorDetails.Message) {
            Get-NormalizedError -Message $_.ErrorDetails.Message
        } else {
            $_.Exception.message
        }
        Write-LogMessage -Message $Message -sev error -API 'NinjaOne'
    }
    return $token

}
#EndRegion './Public/NinjaOne/Get-NinjaOneToken.ps1' 30
#Region './Public/NinjaOne/Invoke-NinjaOneDeviceWebhook.ps1' -1

function Invoke-NinjaOneDeviceWebhook {
    [CmdletBinding()]
    param (
        $Data,
        $Configuration
    )
    try {
        $MappedFields = [pscustomobject]@{}
        $CIPPMapping = Get-CIPPTable -TableName CippMapping
        $Filter = "PartitionKey eq 'NinjaOneFieldMapping'"
        Get-AzDataTableEntity @CIPPMapping -Filter $Filter | Where-Object { $Null -ne $_.IntegrationId -and $_.IntegrationId -ne '' } | ForEach-Object {
            $MappedFields | Add-Member -NotePropertyName $_.RowKey -NotePropertyValue $($_.IntegrationId)
        }

        if ($MappedFields.DeviceCompliance) {
            Write-LogMessage -Headers $Headers -API 'NinjaDeviceCompliance' -message "Webhook Received - Updating NinjaOne Device compliance for $($Data.resourceData.id) in $($Data.tenantId)" -Sev 'Info' -tenant $TenantFilter
            $tenantfilter = $Data.tenantId
            $M365DeviceID = $Data.resourceData.id

            $DeviceM365 = New-GraphGetRequest -uri "https://graph.microsoft.com/beta/devices/$($M365DeviceID)" -Tenantid $tenantfilter

            $DeviceFilter = "PartitionKey eq '$($tenantfilter)' and RowKey eq '$($DeviceM365.deviceID)'"
            $DeviceMapTable = Get-CippTable -tablename 'NinjaOneDeviceMap'
            $Device = Get-CIPPAzDataTableEntity @DeviceMapTable -Filter $DeviceFilter

            if (($Device | Measure-Object).count -eq 1) {
                try {
                    $Token = Get-NinjaOneToken -configuration $Configuration

                    if (!$Token.access_token) {
                        Write-LogMessage -API 'NinjaOneSync' -tenant $tenantfilter -message 'Failed to get NinjaOne Token for Device Compliance Update' -Sev 'Error'
                        return
                    }

                    if ($DeviceM365.isCompliant -eq $True) {
                        $Compliant = 'Compliant'
                    } else {
                        $Compliant = 'Non-Compliant'
                    }

                    $ComplianceBody = @{
                        "$($MappedFields.DeviceCompliance)" = $Compliant
                    } | ConvertTo-Json

                    $Null = Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/device/$($Device.NinjaOneID)/custom-fields" -Method PATCH -Body $ComplianceBody -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json'

                    Write-Host 'Updated NinjaOne Device Compliance'
                } catch {
                    $Message = if ($_.ErrorDetails.Message) {
                        Get-NormalizedError -Message $_.ErrorDetails.Message
                    } else {
                        $_.Exception.message
                    }
                    Write-Error "Failed NinjaOne Device Webhook for: $($Data | ConvertTo-Json -Depth 100) Linenumber: $($_.InvocationInfo.ScriptLineNumber) Error: $Message"
                    Write-LogMessage -API 'NinjaOneSync' -message "Failed NinjaOne Device Webhook Linenumber: $($_.InvocationInfo.ScriptLineNumber) Error: $Message" -Sev 'Error'
                }
            } else {
                Write-LogMessage -API 'NinjaOneSync' -message "$($DeviceM365.displayName) ($($M365DeviceID)) was not matched in Ninja for $($tenantfilter)" -Sev 'Info'
            }

        }

    } catch {
        $Message = if ($_.ErrorDetails.Message) {
            Get-NormalizedError -Message $_.ErrorDetails.Message
        } else {
            $_.Exception.message
        }
        Write-Error "Failed NinjaOne Device Webhook for: $($Data | ConvertTo-Json -Depth 100) Linenumber: $($_.InvocationInfo.ScriptLineNumber) Error: $Message"
        Write-LogMessage -API 'NinjaOneSync' -message "Failed NinjaOne Device Webhook Linenumber: $($_.InvocationInfo.ScriptLineNumber) Error: $Message" -Sev 'Error'
    }



}
#EndRegion './Public/NinjaOne/Invoke-NinjaOneDeviceWebhook.ps1' 76
#Region './Public/NinjaOne/Invoke-NinjaOneDocumentTemplate.ps1' -1

function Invoke-NinjaOneDocumentTemplate {
    [CmdletBinding()]
    param (
        $Template,
        $Token,
        $ID
    )

    if (!$Token) {
        $Table = Get-CIPPTable -TableName Extensionsconfig
        $Configuration = ((Get-AzDataTableEntity @Table).config | ConvertFrom-Json).NinjaOne
        $Token = Get-NinjaOneToken -configuration $Configuration
    }

    if (!$ID) {
        $DocumentTemplates = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/document-templates/" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100
        $DocumentTemplate = $DocumentTemplates | Where-Object { $_.name -eq $Template.name }
    } else {
        $DocumentTemplate = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/document-templates/$($ID)" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100
    }
    
    $MatchedCount = ($DocumentTemplate | Measure-Object).count
    if ($MatchedCount -eq 1) {
        # Matched a single document template
        $NinjaDocumentTemplate = $DocumentTemplate
    } elseif ($MatchedCount -eq 0) {
        # Create a new Document Template
        $Body = $Template | ConvertTo-Json -Depth 100
        Write-Host "Ninja Body: $body"
        $NinjaDocumentTemplate = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/document-templates/" -Method POST -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json' -Body $Body).content | ConvertFrom-Json -Depth 100
    } else {
        # Matched multiple templates. Should be impossible but lets check anyway :D
        Throw 'Multiple Documents Matched the Provided Criteria'
    }

    return $NinjaDocumentTemplate

}
#EndRegion './Public/NinjaOne/Invoke-NinjaOneDocumentTemplate.ps1' 39
#Region './Public/NinjaOne/Invoke-NinjaOneExtensionScheduler.ps1' -1

function Invoke-NinjaOneExtensionScheduler {
    $Table = Get-CIPPTable -TableName NinjaOneSettings
    $Settings = (Get-AzDataTableEntity @Table)
    $TimeSetting = ($Settings | Where-Object { $_.RowKey -eq 'NinjaSyncTime' }).SettingValue


    if (($TimeSetting | Measure-Object).count -ne 1) {
        [int]$TimeSetting = Get-Random -Minimum 1 -Maximum 95
        $AddObject = @{
            PartitionKey   = 'NinjaConfig'
            RowKey         = 'NinjaSyncTime'
            'SettingValue' = $TimeSetting
        }
        Add-AzDataTableEntity @Table -Entity $AddObject -Force
    }

    Write-Host "Ninja Time Setting: $TimeSetting"

    try {
        $LastRunTime = Get-Date(($Settings | Where-Object { $_.RowKey -eq 'NinjaLastRunTime' }).SettingValue)
    } catch {
        $LastRunTime = $Null
    }

    Write-Host "Last Run: $LastRunTime"

    $CurrentTime = Get-Date
    $CurrentInterval = ($CurrentTime.Hour * 4) + [math]::Floor($CurrentTime.Minute / 15)

    Write-Host "Current Interval: $CurrentInterval"

    $CIPPMapping = Get-CIPPTable -TableName CippMapping
    $Filter = "PartitionKey eq 'NinjaOneMapping'"
    $TenantsToProcess = Get-AzDataTableEntity @CIPPMapping -Filter $Filter | Where-Object { $Null -ne $_.IntegrationId -and $_.IntegrationId -ne '' }

    if ($Null -eq $LastRunTime -or $LastRunTime -le (Get-Date).addhours(-25) -or $TimeSetting -eq $CurrentInterval) {
        Write-Host 'Executing'
        $Batch = foreach ($Tenant in $TenantsToProcess | Sort-Object lastEndTime) {
            [PSCustomObject]@{
                'NinjaAction'  = 'SyncTenant'
                'MappedTenant' = $Tenant
                'FunctionName' = 'NinjaOneQueue'
            }
        }
        if (($Batch | Measure-Object).Count -gt 0) {
            $InputObject = [PSCustomObject]@{
                OrchestratorName = 'NinjaOneOrchestrator'
                Batch            = @($Batch)
            }
            #Write-Host ($InputObject | ConvertTo-Json)
            $InstanceId = Start-CIPPOrchestrator -InputObject $InputObject
            Write-Host "Started permissions orchestration with ID = '$InstanceId'"
        }

        $AddObject = @{
            PartitionKey   = 'NinjaConfig'
            RowKey         = 'NinjaLastRunTime'
            'SettingValue' = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffK')
        }
        Add-AzDataTableEntity @Table -Entity $AddObject -Force

        Write-LogMessage -API 'NinjaOneSync'  -message "NinjaOne Daily Synchronization Queued for $(($TenantsToProcess | Measure-Object).count) Tenants" -Sev 'Info'

    } else {
        if ($LastRunTime -lt (Get-Date).AddMinutes(-90)) {
            $TenantsToProcess | ForEach-Object {
                if ($Null -ne $_.lastEndTime -and $_.lastEndTime -ne '') {
                    $_.lastEndTime = (Get-Date($_.lastEndTime))
                } else {
                    $_ | Add-Member -NotePropertyName lastEndTime -NotePropertyValue $Null -Force
                }

                if ($Null -ne $_.lastStartTime -and $_.lastStartTime -ne '') {
                    $_.lastStartTime = (Get-Date($_.lastStartTime))
                } else {
                    $_ | Add-Member -NotePropertyName lastStartTime -NotePropertyValue $Null -Force
                }
            }
            $CatchupTenants = $TenantsToProcess | Where-Object { ((($_.lastEndTime -eq $Null) -or ($_.lastStartTime -gt $_.lastEndTime)) -and ($_.lastStartTime -lt (Get-Date).AddHours(-3))) -or (($_.lastStartTime -lt $LastRunTime) -and ($Null -eq $_.lastEndTime -or $_.lastEndTime -lt $LastRunTime)) }
            $Batch = foreach ($Tenant in $CatchupTenants) {
                [PSCustomObject]@{
                    NinjaAction  = 'SyncTenant'
                    MappedTenant = $Tenant
                    FunctionName = 'NinjaOneQueue'
                }
            }
            if (($Batch | Measure-Object).Count -gt 0) {
                $InputObject = [PSCustomObject]@{
                    OrchestratorName = 'NinjaOneOrchestrator'
                    Batch            = @($Batch)
                }
                #Write-Host ($InputObject | ConvertTo-Json)
                $InstanceId = Start-CIPPOrchestrator -InputObject $InputObject
                Write-Host "Started permissions orchestration with ID = '$InstanceId'"
            }

            if (($CatchupTenants | Measure-Object).count -gt 0) {
                Write-LogMessage -API 'NinjaOneSync'  -message "NinjaOne Synchronization Catchup Queued for $(($CatchupTenants | Measure-Object).count) Tenants" -Sev 'Info'
            }

        }

    }
}
#EndRegion './Public/NinjaOne/Invoke-NinjaOneExtensionScheduler.ps1' 105
#Region './Public/NinjaOne/Invoke-NinjaOneOrgMapping.ps1' -1

function Invoke-NinjaOneOrgMapping {

    [System.Collections.Generic.List[PSCustomObject]]$MatchedM365Tenants = @()
    [System.Collections.Generic.List[PSCustomObject]]$MatchedNinjaOrgs = @()

    $ExcludeSerials = @('0', 'SystemSerialNumber', 'To Be Filled By O.E.M.', 'System Serial Number', '0123456789', '123456789', '............')
    $CIPPMapping = Get-CIPPTable -TableName CippMapping


    #Get available mappings
    $Mappings = [pscustomobject]@{}
    $Filter = "PartitionKey eq 'NinjaOneMapping'"
    Get-AzDataTableEntity @CIPPMapping -Filter $Filter | ForEach-Object {
        $Mappings | Add-Member -NotePropertyName $_.RowKey -NotePropertyValue @{ label = "$($_.IntegrationName)"; value = "$($_.IntegrationId)" }
    }

    #Get Available Tenants
    $Tenants = Get-Tenants -IncludeErrors
    #Get available Ninja clients
    $Table = Get-CIPPTable -TableName Extensionsconfig
    $Configuration = ((Get-AzDataTableEntity @Table).config | ConvertFrom-Json).NinjaOne

    $Token = Get-NinjaOneToken -configuration $Configuration

    # Fetch Ninja Orgs
    $After = 0
    $PageSize = 1000
    $NinjaOrgs = do {
        $Result = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organizations?pageSize=$PageSize&after=$After" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100
        $Result
        $ResultCount = ($Result.id | Measure-Object -Maximum)
        $After = $ResultCount.maximum

    } while ($ResultCount.count -eq $PageSize)

    # Exclude tenants already mapped.
    Foreach ($ExistingMap in $mappings.psobject.properties) {
        $ExistingTenant = $Tenants | Where-Object { $_.customerId -eq $ExistingMap.name }
        $ExistingOrg = $NinjaOrgs | Where-Object { $_.id -eq $ExistingMap.value.value }

        if (($ExistingTenant | Measure-Object).count -eq 1) {
            $MatchedM365Tenants.add($ExistingTenant)
        }

        if (($ExistingOrg | Measure-Object).count -eq 1) {
            $MatchedM365Tenants.add($ExistingOrg)
        }
    }

    # Fetch Ninja Devices
    $After = 0
    $PageSize = 1000
    $NinjaDevicesRaw = do {
        $Result = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/devices-detailed?pageSize=$PageSize&after=$After" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100
        $Result
        $ResultCount = ($Result.id | Measure-Object -Maximum)
        $After = $ResultCount.maximum

    } while ($ResultCount.count -eq $PageSize)


    $NinjaDevices = $NinjaDevicesRaw | Where-Object { $null -ne $_.system.serialNumber -and $_.system.serialNumber -notin $ExcludeSerials } | ForEach-Object {
        [pscustomobject]@{
            ID               = $_.id
            SystemName       = $_.systemName
            DNSName          = $_.dnsName
            Serial           = $_.system.serialNumber
            BiosSerialNumber = $_.system.biosSerialNumber
            OrgID            = $_.organizationId
        }
    }

    # Remove any devices with duplicate serials
    $ParsedNinjaDevices = $NinjaDevices | Where-Object { $_.Serial -in (($NinjaDevices | Group-Object Serial | Where-Object { $_.count -eq 1 }).name) }


    # First lets match on Org names
    foreach ($Tenant in $Tenants | Where-Object { $_.customerId -notin $MatchedM365Tenants.customerId }) {
        $MatchedOrg = $NinjaOrgs | Where-Object { $_.name -eq $Tenant.displayName }
        if (($MatchedOrg | Measure-Object).count -eq 1) {
            $MatchedM365Tenants.add($Tenant)
            $MatchedNinjaOrgs.add($MatchedOrg)
            $AddObject = @{
                PartitionKey    = 'NinjaOneMapping'
                RowKey          = "$($Tenant.customerId)"
                IntegrationId   = "$($MatchedOrg.id)"
                IntegrationName = "$($MatchedOrg.name)"
            }
            Add-AzDataTableEntity @CIPPMapping -Entity $AddObject -Force
            Write-LogMessage -API 'NinjaOneAutoMap_Queue'  -message "Added mapping from Organization name match for $($Tenant.customerId). to $($($MatchedOrg.name))" -Sev 'Info'
        }
    }

    # Now Let match on remaining Tenants

    $Batch = Foreach ($Tenant in $Tenants | Where-Object { $_.customerId -notin $MatchedM365Tenants.customerId }) {
        [PSCustomObject]@{
            'NinjaAction'  = 'AutoMapTenant'
            'M365Tenant'   = $Tenant
            'NinjaOrgs'    = $NinjaOrgs | Where-Object { $_.id -notin $MatchedNinjaOrgs }
            'NinjaDevices' = $ParsedNinjaDevices
            'FunctionName' = 'NinjaOneQueue'
        }
    }
    if (($Batch | Measure-Object).Count -gt 0) {
        $InputObject = [PSCustomObject]@{
            OrchestratorName = 'NinjaOneOrchestrator'
            Batch            = @($Batch)
        }
        #Write-Host ($InputObject | ConvertTo-Json)
        $InstanceId = Start-CIPPOrchestrator -InputObject $InputObject
        Write-Host "Started permissions orchestration with ID = '$InstanceId'"
    }
}
#EndRegion './Public/NinjaOne/Invoke-NinjaOneOrgMapping.ps1' 115
#Region './Public/NinjaOne/Invoke-NinjaOneOrgMappingTenant.ps1' -1

function Invoke-NinjaOneOrgMappingTenant {
    [CmdletBinding()]
    param (
        $QueueItem
    )

    $Tenant = $QueueItem.M365Tenant
    $NinjaOrgs = $QueueItem.NinjaOrgs
    $NinjaDevices = $QueueItem.NinjaDevices

    Write-Host "Processing $($Tenant.displayName)"

    $CIPPMapping = Get-CIPPTable -TableName CippMapping

    $TenantFilter = $Tenant.customerId

    $M365DevicesRaw = New-GraphGetRequest -uri 'https://graph.microsoft.com/beta/deviceManagement/managedDevices' -Tenantid $tenantfilter

    $M365Devices = foreach ($Device in $M365DevicesRaw) {
        [pscustomobject]@{
            'DeviceID'     = $Device.id
            'DeviceName'   = $Device.deviceName
            'DeviceSerial' = $Device.serialNumber
        }
    }


    [System.Collections.Generic.List[PSCustomObject]]$MatchedDevices = @()

    # Match devices on serial
    $DevicesToMatchSerial = $M365Devices | Where-Object { $null -ne $_.DeviceSerial }
    foreach ($SerialMatchDevice in $DevicesToMatchSerial) {
        $MatchedDevice = $NinjaDevices | Where-Object { $_.Serial -eq $SerialMatchDevice.DeviceSerial -or $_.BiosSerialNumber -eq $SerialMatchDevice.DeviceSerial }
        if (($MatchedDevice | Measure-Object).count -eq 1) {
            $Match = [pscustomobject]@{
                M365  = $SerialMatchDevice
                Ninja = $MatchedDevice
            }
            $MatchedDevices.add($Match)
        }
    }

    # Try to match on Name
    $DevicesToMatchName = $M365Devices | Where-Object { $_ -notin $MatchedDevices.M365 }
    foreach ($NameMatchDevice in $DevicesToMatchName) {
        $MatchedDevice = $NinjaDevices | Where-Object { $_.SystemName -eq $NameMatchDevice.DeviceName -or $_.DNSName -eq $NameMatchDevice.DeviceName }
        if (($MatchedDevice | Measure-Object).count -eq 1) {
            $Match = [pscustomobject]@{
                M365  = $NameMatchDevice
                Ninja = $MatchedDevice
            }
            $MatchedDevices.add($Match)
        }
    }


    # Match on the Org with the most devices that match
    if (($MatchedDevices.Ninja.ID | Measure-Object).Count -eq 1) {
        $MatchedOrgID = ($MatchedDevices.Ninja | Group-Object OrgID | Sort-Object Count -desc)[0].name
        $MatchedOrg = $NinjaOrgs | Where-Object { $_.id -eq $MatchedOrgID }

        $AddObject = @{
            PartitionKey    = 'NinjaOneMapping'
            RowKey          = "$($Tenant.customerId)"
            IntegrationId   = "$($MatchedOrg.id)"
            IntegrationName = "$($MatchedOrg.name)"
        }
        Add-AzDataTableEntity @CIPPMapping -Entity $AddObject -Force
        Write-LogMessage -API 'NinjaOneAutoMap_Queue'  -message "Added mapping from Device match for $($Tenant.displayName) to $($($MatchedOrg.name))" -Sev 'Info'

    }

}
#EndRegion './Public/NinjaOne/Invoke-NinjaOneOrgMappingTenant.ps1' 74
#Region './Public/NinjaOne/Invoke-NinjaOneSync.ps1' -1

function Invoke-NinjaOneSync {
    try {
        $Table = Get-CIPPTable -TableName NinjaOneSettings

        $CIPPMapping = Get-CIPPTable -TableName CippMapping
        $Filter = "PartitionKey eq 'NinjaOneMapping'"
        $TenantsToProcess = Get-AzDataTableEntity @CIPPMapping -Filter $Filter | Where-Object { $Null -ne $_.IntegrationId -and $_.IntegrationId -ne '' }


        $Batch = foreach ($Tenant in $TenantsToProcess) {
            [PSCustomObject]@{
                'NinjaAction'  = 'SyncTenant'
                'MappedTenant' = $Tenant
                'FunctionName' = 'NinjaOneQueue'
            }
        }
        if (($Batch | Measure-Object).Count -gt 0) {
            $InputObject = [PSCustomObject]@{
                OrchestratorName = 'NinjaOneOrchestrator'
                Batch            = @($Batch)
            }
            #Write-Host ($InputObject | ConvertTo-Json)
            $InstanceId = Start-CIPPOrchestrator -InputObject $InputObject
            Write-Host "Started permissions orchestration with ID = '$InstanceId'"
        }

        $AddObject = @{
            PartitionKey   = 'NinjaConfig'
            RowKey         = 'NinjaLastRunTime'
            'SettingValue' = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffK')
        }

        Add-AzDataTableEntity @Table -Entity $AddObject -Force

        Write-LogMessage -API 'NinjaOneAutoMap_Queue' -Headers 'CIPP' -message "NinjaOne Synchronization Queued for $(($TenantsToProcess | Measure-Object).count) Tenants" -Sev 'Info'
    } catch {
        Write-LogMessage -API 'Scheduler_Billing' -tenant 'none' -message "Could not start NinjaOne Sync $($_.Exception.Message)" -sev Error
    }

}
#EndRegion './Public/NinjaOne/Invoke-NinjaOneSync.ps1' 41
#Region './Public/NinjaOne/Invoke-NinjaOneTenantSync.ps1' -1

function Invoke-NinjaOneTenantSync {
    [CmdletBinding()]
    param (
        $QueueItem
    )
    try {
        $StartQueueTime = Get-Date
        Write-Information "$(Get-Date) - Starting NinjaOne Sync"

        $MappingTable = Get-CIPPTable -TableName CippMapping
        $CurrentMap = (Get-CIPPAzDataTableEntity @MappingTable -Filter "PartitionKey eq 'NinjaOneMapping'")
        $CurrentMap | ForEach-Object {
            if ($Null -ne $_.lastEndTime -and $_.lastEndTime -ne '') {
                $_.lastEndTime = (Get-Date($_.lastEndTime))
            } else {
                $_ | Add-Member -NotePropertyName lastEndTime -NotePropertyValue $Null -Force
            }

            if ($Null -ne $_.lastStartTime -and $_.lastStartTime -ne '') {
                $_.lastStartTime = (Get-Date($_.lastStartTime))
            } else {
                $_ | Add-Member -NotePropertyName lastStartTime -NotePropertyValue $Null -Force
            }
        }

        $StartTime = Get-Date

        # Parse out the Tenant we are processing
        $MappedTenant = $QueueItem.MappedTenant

        # Check for active instances for this tenant
        $CurrentItem = $CurrentMap | Where-Object { $_.RowKey -eq $MappedTenant.RowKey }

        $StartDate = try { Get-Date($CurrentItem.lastStartTime) } catch { $Null }
        $EndDate = try { Get-Date($CurrentItem.lastEndTime) } catch { $Null }

        if (($null -ne $CurrentItem.lastStartTime) -and ($StartDate -gt (Get-Date).ToUniversalTime().AddMinutes(-10)) -and ( $Null -eq $CurrentItem.lastEndTime -or ($StartDate -gt $EndDate))) {
            throw "NinjaOne Sync for Tenant $($MappedTenant.RowKey) is still running, please wait 10 minutes and try again."
        }

        # Set Last Start Time
        $MappingTable = Get-CIPPTable -TableName CippMapping
        $CurrentItem | Add-Member -NotePropertyName lastStartTime -NotePropertyValue ([string]$(($StartQueueTime).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ'))) -Force
        $CurrentItem | Add-Member -NotePropertyName lastStatus -NotePropertyValue 'Running' -Force
        if ($Null -ne $CurrentItem.lastEndTime -and $CurrentItem.lastEndTime -ne '' ) {
            $CurrentItem.lastEndTime = ([string]$(($CurrentItem.lastEndTime).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')))
        }
        Add-CIPPAzDataTableEntity @MappingTable -Entity $CurrentItem -Force


        # Fetch Custom NinjaOne Settings
        $Table = Get-CIPPTable -TableName Config
        $NinjaSettings = (Get-CIPPAzDataTableEntity @Table)
        $CIPPUrl = ($NinjaSettings | Where-Object { $_.RowKey -eq 'CIPPURL' }).Value


        $Customer = Get-Tenants -IncludeErrors | Where-Object { $_.customerId -eq $MappedTenant.RowKey }
        Write-Information "Processing: $($Customer.displayName) - Queued for $((New-TimeSpan -Start $StartQueueTime -End $StartTime).TotalSeconds)"

        Write-LogMessage -tenant $Customer.defaultDomainName -API 'NinjaOneSync' -message "Processing NinjaOne Synchronization for $($Customer.displayName) - Queued for $((New-TimeSpan -Start $StartQueueTime -End $StartTime).TotalSeconds)" -Sev 'Info'

        if (($Customer | Measure-Object).count -ne 1) {
            throw "Unable to match the received ID to a tenant QueueItem: $($QueueItem | ConvertTo-Json -Depth 100 | Out-String) Matched Customer: $($Customer| ConvertTo-Json -Depth 100 | Out-String)"
        }

        $TenantFilter = $Customer.defaultDomainName
        $NinjaOneOrg = $MappedTenant.IntegrationId


        # Get the NinjaOne general extension settings.
        $Table = Get-CIPPTable -TableName Extensionsconfig
        $Configuration = ((Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json).NinjaOne

        $AllowedNinjaHostnames = @(
            'app.ninjarmm.com',
            'eu.ninjarmm.com',
            'oc.ninjarmm.com',
            'ca.ninjarmm.com',
            'us2.ninjarmm.com'
        )

        if ($AllowedNinjaHostnames -notcontains $Configuration.Instance) {
            throw "NinjaOne URL is invalid. Allowed hostnames are: $($AllowedNinjaHostnames -join ', ')"
        }

        # Pull the list of field Mappings so we know which fields to render.
        $MappedFields = [pscustomobject]@{}
        $CIPPMapping = Get-CIPPTable -TableName CippMapping
        $Filter = "PartitionKey eq 'NinjaOneFieldMapping'"
        Get-CIPPAzDataTableEntity @CIPPMapping -Filter $Filter | Where-Object { $Null -ne $_.IntegrationId -and $_.IntegrationId -ne '' } | ForEach-Object {
            $MappedFields | Add-Member -NotePropertyName $_.RowKey -NotePropertyValue $($_.IntegrationId)
        }

        # Get NinjaOne Devices
        $Token = Get-NinjaOneToken -configuration $Configuration
        $After = 0
        $PageSize = 1000
        $NinjaDevices = do {
            $Result = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/devices-detailed?pageSize=$PageSize&after=$After&df=org = $($NinjaOneOrg)" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100
            $Result
            $ResultCount = ($Result.id | Measure-Object -Maximum)
            $After = $ResultCount.maximum

        } while ($ResultCount.count -eq $PageSize)

        Write-Information 'Fetched NinjaOne Devices'

        [System.Collections.Generic.List[PSCustomObject]]$NinjaOneUserDocs = @()

        if ($Configuration.UserDocumentsEnabled -eq $True) {
            # Get NinjaOne User Documents
            $UserDocTemplate = [PSCustomObject]@{
                name          = 'CIPP - Microsoft 365 Users'
                allowMultiple = $true
                fields        = @(
                    [PSCustomObject]@{
                        fieldLabel                = 'User Links'
                        fieldName                 = 'cippUserLinks'
                        fieldType                 = 'WYSIWYG'
                        fieldTechnicianPermission = 'READ_ONLY'
                        fieldScriptPermission     = 'NONE'
                        fieldApiPermission        = 'READ_WRITE'
                        fieldContent              = @{
                            required         = $False
                            advancedSettings = @{
                                expandLargeValueOnRender = $True
                            }
                        }
                    },
                    [PSCustomObject]@{
                        fieldLabel                = 'User Summary'
                        fieldName                 = 'cippUserSummary'
                        fieldType                 = 'WYSIWYG'
                        fieldTechnicianPermission = 'READ_ONLY'
                        fieldScriptPermission     = 'NONE'
                        fieldApiPermission        = 'READ_WRITE'
                        fieldContent              = @{
                            required         = $False
                            advancedSettings = @{
                                expandLargeValueOnRender = $True
                            }
                        }
                    },
                    [PSCustomObject]@{
                        fieldLabel                = 'User Devices'
                        fieldName                 = 'cippUserDevices'
                        fieldType                 = 'WYSIWYG'
                        fieldTechnicianPermission = 'READ_ONLY'
                        fieldScriptPermission     = 'NONE'
                        fieldApiPermission        = 'READ_WRITE'
                        fieldContent              = @{
                            required         = $False
                            advancedSettings = @{
                                expandLargeValueOnRender = $True
                            }
                        }
                    },
                    [PSCustomObject]@{
                        fieldLabel                = 'User Groups'
                        fieldName                 = 'cippUserGroups'
                        fieldType                 = 'WYSIWYG'
                        fieldTechnicianPermission = 'READ_ONLY'
                        fieldScriptPermission     = 'NONE'
                        fieldApiPermission        = 'READ_WRITE'
                        fieldContent              = @{
                            required         = $False
                            advancedSettings = @{
                                expandLargeValueOnRender = $True
                            }
                        }
                    },
                    [PSCustomObject]@{
                        fieldLabel                = 'User ID'
                        fieldName                 = 'cippUserID'
                        fieldType                 = 'TEXT'
                        fieldTechnicianPermission = 'READ_ONLY'
                        fieldScriptPermission     = 'NONE'
                        fieldApiPermission        = 'READ_WRITE'
                    },
                    [PSCustomObject]@{
                        fieldLabel                = 'User UPN'
                        fieldName                 = 'cippUserUPN'
                        fieldType                 = 'TEXT'
                        fieldTechnicianPermission = 'READ_ONLY'
                        fieldScriptPermission     = 'NONE'
                        fieldApiPermission        = 'READ_WRITE'
                    }
                )
            }

            $NinjaOneUsersTemplate = Invoke-NinjaOneDocumentTemplate -Template $UserDocTemplate -Token $Token


            # Get NinjaOne Users
            [System.Collections.Generic.List[PSCustomObject]]$NinjaOneUserDocs = ((Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organization/documents?organizationIds=$($NinjaOneOrg)&templateIds=$($NinjaOneUsersTemplate.id)" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100)

            foreach ($NinjaDoc in $NinjaOneUserDocs) {
                $ParsedFields = [pscustomobject]@{}
                foreach ($Field in $NinjaDoc.Fields) {
                    if ($Field.value.text) {
                        $FieldVal = $Field.value.text
                    } else {
                        $FieldVal = $Field.value
                    }
                    $ParsedFields | Add-Member -NotePropertyName $Field.name -NotePropertyValue $FieldVal
                }
                $NinjaDoc | Add-Member -NotePropertyName 'ParsedFields' -NotePropertyValue $ParsedFields -Force
            }

            Write-Information 'Fetched NinjaOne User Docs'
        }

        [System.Collections.Generic.List[PSCustomObject]]$NinjaOneLicenseDocs = @()
        if ($Configuration.LicenseDocumentsEnabled) {
            # NinjaOne License Documents
            $LicenseDocTemplate = [PSCustomObject]@{
                name          = 'CIPP - Microsoft 365 Licenses'
                allowMultiple = $true
                fields        = @(
                    [PSCustomObject]@{
                        fieldLabel                = 'License Summary'
                        fieldName                 = 'cippLicenseSummary'
                        fieldType                 = 'WYSIWYG'
                        fieldTechnicianPermission = 'READ_ONLY'
                        fieldScriptPermission     = 'NONE'
                        fieldApiPermission        = 'READ_WRITE'
                        fieldContent              = @{
                            required         = $False
                            advancedSettings = @{
                                expandLargeValueOnRender = $True
                            }
                        }
                    },
                    [PSCustomObject]@{
                        fieldLabel                = 'License Users'
                        fieldName                 = 'cippLicenseUsers'
                        fieldType                 = 'WYSIWYG'
                        fieldTechnicianPermission = 'READ_ONLY'
                        fieldScriptPermission     = 'NONE'
                        fieldApiPermission        = 'READ_WRITE'
                        fieldContent              = @{
                            required         = $False
                            advancedSettings = @{
                                expandLargeValueOnRender = $True
                            }
                        }
                    },
                    [PSCustomObject]@{
                        fieldLabel                = 'License ID'
                        fieldName                 = 'cippLicenseID'
                        fieldType                 = 'TEXT'
                        fieldTechnicianPermission = 'READ_ONLY'
                        fieldScriptPermission     = 'NONE'
                        fieldApiPermission        = 'READ_WRITE'
                        fieldContent              = @{
                            required = $False
                        }
                    }
                )
            }

            $NinjaOneLicenseTemplate = Invoke-NinjaOneDocumentTemplate -Template $LicenseDocTemplate -Token $Token

            # Get NinjaOne Licenses
            [System.Collections.Generic.List[PSCustomObject]]$NinjaOneLicenseDocs = ((Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organization/documents?organizationIds=$($NinjaOneOrg)&templateIds=$($NinjaOneLicenseTemplate.id)" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100)

            foreach ($NinjaLic in $NinjaOneLicenseDocs) {
                $ParsedFields = [pscustomobject]@{}
                foreach ($Field in $NinjaLic.Fields) {
                    if ($Field.value.text) {
                        $FieldVal = $Field.value.text
                    } else {
                        $FieldVal = $Field.value
                    }
                    $ParsedFields | Add-Member -NotePropertyName $Field.name -NotePropertyValue $FieldVal
                }
                $NinjaLic | Add-Member -NotePropertyName 'ParsedFields' -NotePropertyValue $ParsedFields -Force
            }

            Write-Information 'Fetched NinjaOne License Docs'
        }


        # Create the update objects we will use to update NinjaOne
        $NinjaOrgUpdate = [PSCustomObject]@{}
        [System.Collections.Generic.List[PSCustomObject]]$NinjaLicenseUpdates = @()
        [System.Collections.Generic.List[PSCustomObject]]$NinjaLicenseCreation = @()

        # Replace direct Graph/Exchange calls with cached data
        $ExtensionCache = Get-CippExtensionReportingData -TenantFilter $Customer.defaultDomainName -IncludeMailboxes

        # Map cached data to variables
        $Users = $ExtensionCache.Users
        $licensedUsers = $Users | Where-Object { $null -ne $_.assignedLicenses.skuId }
        $AllRoles = $ExtensionCache.AllRoles
        $Devices = $ExtensionCache.Devices
        $DeviceCompliancePolicies = $ExtensionCache.DeviceCompliancePolicies
        $OneDriveDetails = $ExtensionCache.OneDriveUsage
        $CASFull = $ExtensionCache.CASMailbox
        $MailboxDetailedFull = $ExtensionCache.Mailboxes
        $MailboxStatsFull = $ExtensionCache.MailboxUsage
        $Permissions = $ExtensionCache.MailboxPermissions
        $SecureScore = $ExtensionCache.SecureScore
        $SecureScoreProfiles = $ExtensionCache.SecureScoreControlProfiles
        $TenantDetails = $ExtensionCache.Organization
        $RawDomains = $ExtensionCache.Domains
        $AllGroups = $ExtensionCache.Groups
        $Licenses = $ExtensionCache.Licenses
        $RawDomains = $ExtensionCache.Domains
        $AllConditionalAccessPolicies = $ExtensionCache.ConditionalAccess

        $CurrentSecureScore = ($SecureScore | Sort-Object createDateTime -Descending | Select-Object -First 1)
        $MaxSecureScoreRank = ($SecureScoreProfiles.rank | Measure-Object -Maximum).maximum

        $MaxSecureScore = $CurrentSecureScore.maxScore

        [System.Collections.Generic.List[PSCustomObject]]$SecureScoreParsed = foreach ($Score in $CurrentSecureScore.controlScores) {
            $MatchedProfile = $SecureScoreProfiles | Where-Object { $_.id -eq $Score.controlName }
            [PSCustomObject]@{
                Category             = $Score.controlCategory
                'Recommended Action' = $MatchedProfile.title
                'Score Impact'       = [System.Math]::Round((((($MatchedProfile.maxScore) - ($Score.score)) / $MaxSecureScore) * 100), 2)
                Link                 = "https://security.microsoft.com/securescore?actionId=$($Score.controlName)&viewid=actions&tid=$($Customer.customerId)"
                name                 = $Score.controlName
                score                = $Score.score
                IsApplicable         = $Score.IsApplicable
                scoreInPercentage    = $Score.scoreInPercentage
                maxScore             = $MatchedProfile.maxScore
                rank                 = $MatchedProfile.rank
                adjustedRank         = $MaxSecureScoreRank - $MatchedProfile.rank

            }
        }

        # Grab licensed users
        $licensedUsers = $Users | Where-Object { $null -ne $_.AssignedLicenses.SkuId } | Sort-Object UserPrincipalName

        $Roles = foreach ($Role in $AllRoles) {
            # Get members from inline property (no longer separate cache entries)
            $Members = $Role.members
            [PSCustomObject]@{
                ID            = $Role.id
                DisplayName   = $Role.displayName
                Description   = $Role.description
                Members       = $Members
                ParsedMembers = if ($Members) { $Members.displayName -join ', ' } else { '' }
            }
        }

        $AdminUsers = (($Roles | Where-Object { $_.Displayname -match 'Administrator' }).Members | Where-Object { $null -ne $_.displayName })

        Write-Verbose "$(Get-Date) - Fetching Domains"

        $customerDomains = ($RawDomains | Where-Object { $_.IsVerified -eq $true }).id -join ', ' | Out-String

        Write-Verbose "$(Get-Date) - Parsing Licenses"

        # Get the license overview for the tenant
        if ($Licenses) {
            $LicensesParsed = $Licenses | Where-Object { $_.PrepaidUnits.Enabled -gt 0 } | Select-Object @{N = 'License Name'; E = { $_.skuPartNumber } }, @{N = 'Active'; E = { $_.PrepaidUnits.Enabled } }, @{N = 'Consumed'; E = { $_.ConsumedUnits } }, @{N = 'Unused'; E = { $_.PrepaidUnits.Enabled - $_.ConsumedUnits } }
        }

        Write-Verbose "$(Get-Date) - Parsing Device Compliance Policies"

        $DeviceComplianceDetails = foreach ($Policy in $DeviceCompliancePolicies) {
            $StatusItems = Get-CIPPDbItem -TenantFilter $Customer.defaultDomainName -Type "IntuneDeviceCompliancePolicies_$($Policy.id)" | Where-Object { $_.RowKey -notlike '*-Count' }
            $DeviceStatuses = if ($StatusItems) { $StatusItems | ForEach-Object { $_.Data | ConvertFrom-Json } } else { @() }
            [pscustomobject]@{
                ID             = $Policy.id
                DisplayName    = $Policy.displayName
                DeviceStatuses = $DeviceStatuses
            }
        }

        Write-Verbose "$(Get-Date) - Parsing Groups"

        $Groups = foreach ($Group in $AllGroups) {
            # Get members from inline property (no longer separate cache entries)
            $Members = $Group.members
            [pscustomobject]@{
                ID          = $Group.id
                DisplayName = $Group.displayName
                Members     = $Members
            }
        }
        Write-Verbose "$(Get-Date) - Parsing Conditional Access Polcies"

        $ConditionalAccessMembers = foreach ($CAPolicy in $AllConditionalAccessPolicies) {
            #Setup User Array
            [System.Collections.Generic.List[PSCustomObject]]$CAMembers = @()

            # Check for All Include
            if ($CAPolicy.conditions.users.includeUsers -contains 'All') {
                $Users | ForEach-Object { $null = $CAMembers.add($_.id) }
            } else {
                # Add any specific all users to the array
                $CAPolicy.conditions.users.includeUsers | ForEach-Object { $null = $CAMembers.add($_) }
            }

            # Now all members of groups
            foreach ($CAIGroup in $CAPolicy.conditions.users.includeGroups) {
                foreach ($Member in ($Groups | Where-Object { $_.id -eq $CAIGroup }).Members) {
                    $null = $CAMembers.add($Member.id)
                }
            }

            # Now all members of roles
            foreach ($CAIRole in $CAPolicy.conditions.users.includeRoles) {
                foreach ($Member in ($Roles | Where-Object { $_.id -eq $CAIRole }).Members) {
                    $null = $CAMembers.add($Member.id)
                }
            }

            # Parse to Unique members
            $CAMembers = $CAMembers | Select-Object -Unique

            if ($CAMembers) {
                # Now remove excluded users
                $CAPolicy.conditions.users.excludeUsers | ForEach-Object { $null = $CAMembers.remove($_) }

                # Excluded Groups
                foreach ($CAEGroup in $CAPolicy.conditions.users.excludeGroups) {
                    foreach ($Member in ($Groups | Where-Object { $_.id -eq $CAEGroup }).Members) {
                        $null = $CAMembers.remove($Member.id)
                    }
                }

                # Excluded Roles
                foreach ($CAIRole in $CAPolicy.conditions.users.excludeRoles) {
                    foreach ($Member in ($Roles | Where-Object { $_.id -eq $CAERole }).Members) {
                        $null = $CAMembers.remove($Member.id)
                    }
                }
            }

            [pscustomobject]@{
                ID          = $CAPolicy.id
                DisplayName = $CAPolicy.DisplayName
                Members     = $CAMembers
            }
        }

        $FetchEnd = Get-Date

        ############################ Format and Synchronize to NinjaOne ############################
        $DeviceTable = Get-CippTable -tablename 'CacheNinjaOneParsedDevices'
        $DeviceMapTable = Get-CippTable -tablename 'NinjaOneDeviceMap'


        $DeviceFilter = "PartitionKey eq '$($Customer.CustomerId)'"
        [System.Collections.Generic.List[PSCustomObject]]$RawParsedDevices = Get-CIPPAzDataTableEntity @DeviceTable -Filter $DeviceFilter
        if (($RawParsedDevices | Measure-Object).count -eq 0) {
            [System.Collections.Generic.List[PSCustomObject]]$ParsedDevices = @()
        } else {
            [System.Collections.Generic.List[PSCustomObject]]$ParsedDevices = $RawParsedDevices.RawDevice | ForEach-Object { $_ | ConvertFrom-Json -Depth 100 }
        }

        [System.Collections.Generic.List[PSCustomObject]]$DeviceMap = Get-CIPPAzDataTableEntity @DeviceMapTable -Filter $DeviceFilter
        if (($DeviceMap | Measure-Object).count -eq 0) {
            [System.Collections.Generic.List[PSCustomObject]]$DeviceMap = @()
        }

        $DevicesToProcess = $Devices | Where-Object { $_.id -notin $ParsedDevices.id }

        # Parse Devices
        foreach ($Device in $DevicesToProcess) {

            # First lets match on serial (normalize by removing spaces for comparison)
            $NormalizedDeviceSerial = $Device.SerialNumber -replace '\s', ''
            $MatchedNinjaDevice = $NinjaDevices | Where-Object {
                ($_.system.biosSerialNumber -replace '\s', '') -eq $NormalizedDeviceSerial -or
                ($_.system.serialNumber -replace '\s', '') -eq $NormalizedDeviceSerial
            }

            # See if we found just one device, if not match on name
            if (($MatchedNinjaDevice | Measure-Object).count -ne 1) {
                $MatchedNinjaDevice = $NinjaDevices | Where-Object { $_.systemName -eq $Device.deviceName -or $_.dnsName -eq $Device.deviceName }
            }

            # Check on a match again and set name
            if (($MatchedNinjaDevice | Measure-Object).count -eq 1) {
                $ParsedDeviceName = '<a href="https://' + ($Configuration.Instance -replace '/ws', '') + '/#/deviceDashboard/' + $MatchedNinjaDevice.id + '/overview" target="_blank">' + $Device.deviceName + '</a>'
            } else {
                continue
            }

            # Match Users
            [System.Collections.Generic.List[String]]$DeviceUsers = @()
            [System.Collections.Generic.List[String]]$DeviceUserIDs = @()
            [System.Collections.Generic.List[PSCustomObject]]$DeviceUsersDetail = @()

            $MappedDevice = ($DeviceMap | Where-Object { $_.M365ID -eq $device.id })
            if (($MappedDevice | Measure-Object).count -eq 0) {
                $DeviceMapItem = [PSCustomObject]@{
                    PartitionKey = $Customer.CustomerId
                    RowKey       = $device.AzureADDeviceId
                    NinjaOneID   = $MatchedNinjaDevice.id
                    M365ID       = $device.id
                }
                $DeviceMap.Add($DeviceMapItem)
                Add-CIPPAzDataTableEntity @DeviceMapTable -Entity $DeviceMapItem -Force

            } elseif ($MappedDevice.NinjaOneID -ne $MatchedNinjaDevice.id) {
                $MappedDevice.NinjaOneID = $MatchedNinjaDevice.id
                Add-CIPPAzDataTableEntity @DeviceMapTable -Entity $MappedDevice -Force
            }




            foreach ($DeviceUser in $Device.usersloggedon) {
                $FoundUser = ($Users | Where-Object { $_.id -eq $DeviceUser.userid })
                $DeviceUsers.add($FoundUser.DisplayName)
                $DeviceUserIDs.add($DeviceUser.userId)
                $DeviceUsersDetail.add([pscustomobject]@{
                        id        = $FoundUser.Id
                        name      = $FoundUser.displayName
                        upn       = $FoundUser.userPrincipalName
                        lastlogin = ($DeviceUser.lastLogOnDateTime).ToString('yyyy-MM-dd')
                    }
                )
            }

            # Compliance Polciies
            [System.Collections.Generic.List[PSCustomObject]]$DevicePolcies = @()
            foreach ($Policy in $DeviceComplianceDetails) {
                if ($device.deviceName -in $Policy.DeviceStatuses.deviceDisplayName) {
                    $Status = $Policy.DeviceStatuses | Where-Object { $_.deviceDisplayName -eq $device.deviceName }
                    foreach ($Stat in $Status) {
                        if ($Stat.status -ne 'unknown') {
                            $DevicePolcies.add([PSCustomObject]@{
                                    Name           = $Policy.DisplayName
                                    User           = $Stat.username
                                    Status         = $Stat.status
                                    'Last Report'  = "$(Get-Date($Stat.lastReportedDateTime[0]) -Format 'yyyy-MM-dd HH:mm:ss')"
                                    'Grace Expiry' = "$(Get-Date($Stat.complianceGracePeriodExpirationDateTime[0]) -Format 'yyyy-MM-dd HH:mm:ss')"
                                })
                        }
                    }

                }
            }

            # Device Groups
            $DeviceGroups = foreach ($Group in $Groups) {
                if ($device.azureADDeviceId -in $Group.members.deviceId) {
                    [PSCustomObject]@{
                        Name = $Group.displayName
                    }
                }
            }

            $ParsedDevice = [PSCustomObject]@{
                PartitionKey        = $Customer.CustomerId
                RowKey              = $device.AzureADDeviceId
                id                  = $Device.id
                Name                = $Device.deviceName
                SerialNumber        = $Device.serialNumber
                OS                  = $Device.operatingSystem
                OSVersion           = $Device.osversion
                Enrolled            = $Device.enrolledDateTime
                Compliance          = $Device.complianceState
                LastSync            = $Device.lastSyncDateTime
                PrimaryUser         = $Device.userDisplayName
                Owner               = $Device.ownerType
                DeviceType          = $Device.DeviceType
                Make                = $Device.make
                Model               = $Device.model
                ManagementState     = $Device.managementState
                RegistrationState   = $Device.deviceRegistrationState
                JailBroken          = $Device.jailBroken
                EnrollmentType      = $Device.deviceEnrollmentType
                EntraIDRegistration = $Device.azureADRegistered
                EntraIDID           = $Device.azureADDeviceId
                JoinType            = $Device.joinType
                SecurityPatchLevel  = $Device.securityPatchLevel
                Users               = $DeviceUsers -join ', '
                UserIDs             = $DeviceUserIDs
                UserDetails         = $DeviceUsersDetail
                CompliancePolicies  = $DevicePolcies
                Groups              = $DeviceGroups
                NinjaDevice         = $MatchedNinjaDevice
                DeviceLink          = $ParsedDeviceName
            }

            Add-CIPPAzDataTableEntity @DeviceTable -Entity @{
                PartitionKey = $Customer.CustomerId
                RowKey       = $device.AzureADDeviceId
                RawDevice    = "$($ParsedDevice | ConvertTo-Json -Depth 100 -Compress)"
            } -Force

            $ParsedDevices.add($ParsedDevice)

            ### Update NinjaOne Device Fields
            if ($MatchedNinjaDevice) {
                $NinjaDeviceUpdate = [PSCustomObject]@{}
                if ($MappedFields.DeviceLinks) {
                    $DeviceLinksData = @(
                        @{
                            Name = 'Entra ID'
                            Link = "https://entra.microsoft.com/$($Customer.defaultDomainName)/#view/Microsoft_AAD_Devices/DeviceDetailsMenuBlade/~/Properties/deviceId/$($Device.azureADDeviceId)"
                            Icon = 'fab fa-microsoft'
                        },
                        @{
                            Name = 'Intune (Devices)'
                            Link = "https://intune.microsoft.com/$($Customer.defaultDomainName)/#view/Microsoft_Intune_Devices/DeviceSettingsMenuBlade/~/overview/mdmDeviceId/$($Device.id)"
                            Icon = 'fas fa-laptop'
                        },
                        @{
                            Name = 'View Devices in CIPP'
                            Link = "https://$($CIPPURL)/endpoint/MEM/devices?tenantFilter=$($Customer.defaultDomainName)"
                            Icon = 'far fa-eye'
                        }
                    )



                    $DeviceLinksHTML = Get-NinjaOneLinks -Data $DeviceLinksData -SmallCols 2 -MedCols 3 -LargeCols 3 -XLCols 3

                    $DeviceLinksHtml = '<div class="row"><div class="col-md-12 col-lg-6 d-flex">' + $DeviceLinksHTML + '</div></div>'

                    $NinjaDeviceUpdate | Add-Member -NotePropertyName $MappedFields.DeviceLinks -NotePropertyValue @{'html' = $DeviceLinksHtml }


                }

                if ($MappedFields.DeviceSummary) {

                    # Set Compliance Status
                    if ($Device.complianceState -eq 'compliant') {
                        $Compliance = '<i class="fas fa-check-circle" title="Device Compliant" style="color:#26A644;"></i>&nbsp;&nbsp; Compliant'
                    } else {
                        $Compliance = '<i class="fas fa-times-circle" title="Device Not Compliant" style="color:#D53948;"></i>&nbsp;&nbsp; Not Compliant'
                    }

                    # Device Details
                    $DeviceDetailsData = [PSCustomObject]@{
                        'Device Name'        = $Device.deviceName
                        'Primary User'       = $Device.userDisplayName
                        'Primary User Email' = $Device.userPrincipalName
                        'Owner'              = $Device.ownerType
                        'Enrolled'           = $Device.enrolledDateTime
                        'Last Checkin'       = $Device.lastSyncDateTime
                        'Compliant'          = $Compliance
                        'Management Type'    = $Device.managementAgent
                    }

                    $DeviceDetailsCard = Get-NinjaOneInfoCard -Title 'Device Details' -Data $DeviceDetailsData -Icon 'fas fa-laptop'

                    # Device Hardware
                    $DeviceHardwareData = [PSCustomObject]@{
                        'Serial Number' = $Device.serialNumber
                        'OS'            = $Device.operatingSystem
                        'OS Versions'   = $Device.osVersion
                        'Chassis'       = $Device.chassisType
                        'Model'         = $Device.model
                        'Manufacturer'  = $Device.manufacturer
                    }

                    $DeviceHardwareCard = Get-NinjaOneInfoCard -Title 'Device Details' -Data $DeviceHardwareData -Icon 'fas fa-microchip'

                    # Device Enrollment
                    $DeviceEnrollmentData = [PSCustomObject]@{
                        'Enrollment Type'                = $Device.deviceEnrollmentType
                        'Join Type'                      = $Device.joinType
                        'Registration State'             = $Device.deviceRegistrationState
                        'Autopilot Enrolled'             = $Device.autopilotEnrolled
                        'Device Guard Requirements'      = $Device.hardwareinformation.deviceGuardVirtualizationBasedSecurityHardwareRequirementState
                        'Virtualistation Based Security' = $Device.hardwareinformation.deviceGuardVirtualizationBasedSecurityState
                        'Credential Guard'               = $Device.hardwareinformation.deviceGuardLocalSystemAuthorityCredentialGuardState
                    }

                    $DeviceEnrollmentCard = Get-NinjaOneInfoCard -Title 'Device Enrollment' -Data $DeviceEnrollmentData -Icon 'fas fa-table-list'


                    # Compliance Policies
                    $DevicePoliciesFormatted = $DevicePolcies | ConvertTo-Html -As Table -Fragment
                    $DevicePoliciesHTML = ([System.Web.HttpUtility]::HtmlDecode($DevicePoliciesFormatted) -replace '<th>', '<th style="white-space: nowrap;">') -replace '<td>', '<td style="white-space: nowrap;">'
                    $TitleLink = "https://intune.microsoft.com/$($Customer.defaultDomainName)/#view/Microsoft_Intune_Devices/DeviceSettingsMenuBlade/~/compliance/mdmDeviceId/$($Device.id)/primaryUserId/"
                    $DeviceCompliancePoliciesCard = Get-NinjaOneCard -Title 'Device Compliance Policies' -Body $DevicePoliciesHTML -Icon 'fas fa-list-check' -TitleLink $TitleLink

                    # Device Groups
                    $DeviceGroupsTable = foreach ($Group in $Groups) {
                        if ($device.azureADDeviceId -in $Group.members.deviceId) {
                            [PSCustomObject]@{
                                Name = $Group.displayName
                            }
                        }
                    }
                    $DeviceGroupsFormatted = $DeviceGroupsTable | ConvertTo-Html -Fragment
                    $DeviceGroupsHTML = ([System.Web.HttpUtility]::HtmlDecode($DeviceGroupsFormatted) -replace '<th>', '<th style="white-space: nowrap;">') -replace '<td>', '<td style="white-space: nowrap;">'
                    $DeviceGroupsCard = Get-NinjaOneCard -Title 'Device Groups' -Body $DeviceGroupsHTML -Icon 'fas fa-layer-group'

                    $DeviceSummaryHTML = '<div class="row g-3">' +
                    '<div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $DeviceDetailsCard +
                    '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $DeviceHardwareCard +
                    '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $DeviceEnrollmentCard +
                    '</div><div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 d-flex">' + $DeviceCompliancePoliciesCard +
                    '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $DeviceGroupsCard +
                    '</div></div>'

                    $NinjaDeviceUpdate | Add-Member -NotePropertyName $MappedFields.DeviceSummary -NotePropertyValue @{'html' = $DeviceSummaryHTML }
                }
            }

            if ($MappedFields.DeviceCompliance) {
                if ($Device.complianceState -eq 'compliant') {
                    $Compliant = 'Compliant'
                } else {
                    $Compliant = 'Non-Compliant'
                }
                $NinjaDeviceUpdate | Add-Member -NotePropertyName $MappedFields.DeviceCompliance -NotePropertyValue $Compliant

            }

            # Update Device
            if ($MappedFields.DeviceSummary -or $MappedFields.DeviceLinks -or $MappedFields.DeviceCompliance) {
                try {
                    $UpdateBody = $NinjaDeviceUpdate | ConvertTo-Json -Depth 100
                    $Result = Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/device/$($MatchedNinjaDevice.id)/custom-fields" -Method PATCH -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json; charset=utf-8' -Body $UpdateBody
                } catch {
                    Write-Verbose "Error details: $($_ | ConvertTo-Json -Depth 5)"
                }
            }
        }

        # Enable Device Updates Subscription if needed.
        if ($MappedFields.DeviceCompliance) {
            New-CIPPGraphSubscription -TenantFilter $TenantFilter -TypeofSubscription 'updated' -BaseURL $CIPPUrl -Resource 'devices' -EventType 'DeviceUpdate' -Headers 'NinjaOneSync'
        }

        Write-Information 'Processed Devices'

        ########## Create / Update User Objects

        if ($Configuration.LicensedOnly -eq $True) {
            $SyncUsers = $licensedUsers
        } else {
            $SyncUsers = $Users
        }


        $UsersTable = Get-CippTable -tablename 'CacheNinjaOneParsedUsers'
        $UsersUpdateTable = Get-CippTable -tablename 'CacheNinjaOneUsersUpdate'
        $UsersMapTable = Get-CippTable -tablename 'NinjaOneUserMap'


        $UsersFilter = "PartitionKey eq '$($Customer.CustomerId)'"
        [System.Collections.Generic.List[PSCustomObject]]$ParsedUsers = Get-CIPPAzDataTableEntity @UsersTable -Filter $UsersFilter
        if (($ParsedUsers | Measure-Object).count -eq 0) {
            [System.Collections.Generic.List[PSCustomObject]]$ParsedUsers = @()
        }

        [System.Collections.Generic.List[PSCustomObject]]$NinjaUserCache = Get-CIPPAzDataTableEntity @UsersUpdateTable -Filter $UsersFilter
        if (($NinjaUserCache | Measure-Object).count -eq 0) {
            [System.Collections.Generic.List[PSCustomObject]]$NinjaUserCache = @()
        }

        [System.Collections.Generic.List[PSCustomObject]]$UsersMap = Get-CIPPAzDataTableEntity @UsersMapTable -Filter $UsersFilter
        if (($UsersMap | Measure-Object).count -eq 0) {
            [System.Collections.Generic.List[PSCustomObject]]$UsersMap = @()
        }

        [System.Collections.Generic.List[PSCustomObject]]$NinjaUserUpdates = $NinjaUserCache | Where-Object { $_.action -eq 'Update' }
        if (($NinjaUserUpdates | Measure-Object).count -eq 0) {
            [System.Collections.Generic.List[PSCustomObject]]$NinjaUserUpdates = @()
        }

        [System.Collections.Generic.List[PSCustomObject]]$NinjaUserCreation = $NinjaUserCache | Where-Object { $_.action -eq 'Create' }
        if (($NinjaUserCreation | Measure-Object).count -eq 0) {
            [System.Collections.Generic.List[PSCustomObject]]$NinjaUserCreation = @()
        }


        foreach ($user in $SyncUsers | Where-Object { $_.id -notin $ParsedUsers.RowKey }) {
            try {

                $NinjaOneUser = $NinjaOneUserDocs | Where-Object { $_.ParsedFields.cippUserID -eq $User.ID }
                if (($NinjaOneUser | Measure-Object).count -gt 1) {
                    throw 'Multiple Users with the same ID found'
                }


                $UserGroups = foreach ($Group in $Groups) {
                    if ($User.id -in $Group.Members.id) {
                        $FoundGroup = $AllGroups | Where-Object { $_.id -eq $Group.id }
                        [PSCustomObject]@{
                            'Display Name'   = $FoundGroup.displayName
                            'Mail Enabled'   = $FoundGroup.mailEnabled
                            'Mail'           = $FoundGroup.mail
                            'Security Group' = $FoundGroup.securityEnabled
                            'Group Types'    = $FoundGroup.groupTypes -join ','
                        }
                    }
                }


                $UserPolicies = foreach ($cap in $ConditionalAccessMembers) {
                    if ($User.id -in $Cap.Members) {
                        $temp = [PSCustomObject]@{
                            displayName = $cap.displayName
                        }
                        $temp
                    }
                }

                #$PermsRequest = ''
                $StatsRequest = ''
                $MailboxDetailedRequest = ''
                $CASRequest = ''

                $CASRequest = $CASFull | Where-Object { $_.ExternalDirectoryObjectId -eq $User.iD }
                $MailboxDetailedRequest = $MailboxDetailedFull | Where-Object { $_.ExternalDirectoryObjectId -eq $User.iD }
                $StatsRequest = $MailboxStatsFull | Where-Object { $_.userPrincipalName -eq $User.UserPrincipalName }


                $ParsedPerms = foreach ($Perm in $Permissions) {
                    if ($Perm.User -ne 'NT AUTHORITY\SELF') {
                        [pscustomobject]@{
                            User         = $Perm.User
                            AccessRights = $Perm.PermissionList.AccessRights -join ', '
                        }
                    }
                }

                try {
                    $TotalItemSize = [math]::Round($StatsRequest.storageUsedInBytes / 1Gb, 2)
                } catch {
                    $TotalItemSize = 0
                }

                $UserMailSettings = [pscustomobject]@{
                    ForwardAndDeliver        = $MailboxDetailedRequest.DeliverToMailboxAndForward
                    ForwardingAddress        = $MailboxDetailedRequest.ForwardingAddress + ' ' + $MailboxDetailedRequest.ForwardingSmtpAddress
                    LitigationHold           = $MailboxDetailedRequest.LitigationHoldEnabled
                    HiddenFromAddressLists   = $MailboxDetailedRequest.HiddenFromAddressListsEnabled
                    EWSEnabled               = $CASRequest.EwsEnabled
                    MailboxMAPIEnabled       = $CASRequest.MAPIEnabled
                    MailboxOWAEnabled        = $CASRequest.OWAEnabled
                    MailboxImapEnabled       = $CASRequest.ImapEnabled
                    MailboxPopEnabled        = $CASRequest.PopEnabled
                    MailboxActiveSyncEnabled = $CASRequest.ActiveSyncEnabled
                    Permissions              = $ParsedPerms
                    ProhibitSendQuota        = $StatsRequest.prohibitSendQuotaInBytes
                    ProhibitSendReceiveQuota = $StatsRequest.prohibitSendReceiveQuotaInBytes
                    ItemCount                = [math]::Round($StatsRequest.itemCount, 2)
                    TotalItemSize            = $StatsRequest.totalItemSize
                    StorageUsedInBytes       = $StatsRequest.storageUsedInBytes
                }


                $UserDevicesDetailsRaw = $ParsedDevices | Where-Object { $User.id -in $_.UserIDS }


                $UserDevices = foreach ($UserDevice in $ParsedDevices | Where-Object { $User.id -in $_.UserIDS }) {

                    $MatchedNinjaDevice = $UserDevice.NinjaDevice
                    $ParsedDeviceName = $UserDevice.DeviceLink

                    # Set Last Login Time
                    $LastLoginTime = ($UserDevice.UserDetails | Where-Object { $_.id -eq $User.id }).lastLogin
                    if (!$LastLoginTime) {
                        $LastLoginTime = 'Unknown'
                    }

                    # Set Compliance Status
                    if ($UserDevice.Compliance -eq 'compliant') {
                        $ComplianceIcon = '<i class="fas fa-check-circle" title="Device Compliant" style="color:#26A644;"></i>'
                    } else {
                        $ComplianceIcon = '<i class="fas fa-times-circle" title="Device Not Compliant" style="color:#D53948;"></i>'
                    }

                    # OS Icon
                    $OSIcon = switch ($UserDevice.OS) {
                        'Windows' { '<i class="fab fa-windows"></i>' }
                        'iOS' { '<i class="fab fa-apple"></i>' }
                        'Android' { '<i class="fab fa-android"></i>' }
                        'macOS' { '<i class="fab fa-apple"></i>' }
                    }

                    '<li>' + "$ComplianceIcon $OSIcon $($ParsedDeviceName) ($LastLoginTime)</li>"

                }


                $aliases = (($user.ProxyAddresses | Where-Object { $_ -cnotmatch 'SMTP' -and $_ -notmatch '.onmicrosoft.com' }) -replace 'SMTP:', ' ') -join ', '


                $userLicenses = ($user.AssignedLicenses.SkuID | ForEach-Object {
                        $UserLic = $_
                        try {
                            $SkuPartNumber = ($Licenses | Where-Object { $_.SkuId -eq $UserLic }).SkuPartNumber
                            '<li>' + "$($SkuPartNumber)</li>"
                        } catch {}
                    }) -join ''



                $UserOneDriveStats = $OneDriveDetails | Where-Object { $_.ownerPrincipalName -eq $User.userPrincipalName } | Select-Object -First 1
                $UserOneDriveUse = $UserOneDriveStats.storageUsedInBytes / 1GB
                $UserOneDriveTotal = $UserOneDriveStats.storageAllocatedInBytes / 1GB

                if ($UserOneDriveTotal) {
                    $OneDriveUse = [PSCustomObject]@{
                        Enabled = $True
                        Used    = $UserOneDriveUse
                        Total   = $UserOneDriveTotal
                        Percent = ($UserOneDriveUse / $UserOneDriveTotal) * 100
                    }

                    $OneDriveUseColor = if ($OneDriveUse.Percent -ge 95) {
                        '#D53948'
                    } elseif ($OneDriveUse.Percent -ge 85) {
                        '#FFA500'
                    } else {
                        '#26A644'
                    }

                    $OneDriveParsed = '<div class="pt-3 pb-3 linechart"><div style="width: ' + $OneDriveUse.Percent + '%; background-color: ' + $OneDriveUseColor + ';"></div><div style="width: ' + (100 - $OneDriveUse.Percent) + '%; background-color: #CCCCCC;"></div></div>'

                } else {
                    $OneDriveUse = [PSCustomObject]@{
                        Enabled = $False
                        Used    = 0
                        Total   = 0
                        Percent = 0
                    }

                    $OneDriveParsed = 'Not Enabled'
                }


                if ($UserOneDriveStats) {
                    $OneDriveCardData = [PSCustomObject]@{
                        'One Drive URL'            = '<a href="' + ($UserOneDriveStats.siteUrl) + '">' + ($UserOneDriveStats.siteUrl) + '</a>'
                        'Is Deleted'               = "$($UserOneDriveStats.isDeleted)"
                        'Last Activity Date'       = "$($UserOneDriveStats.lastActivityDate)"
                        'File Count'               = "$($UserOneDriveStats.fileCount)"
                        'Active File Count'        = "$($UserOneDriveStats.activeFileCount)"
                        'Storage Used (Byte)'      = "$($UserOneDriveStats.storageUsedInBytes)"
                        'Storage Allocated (Byte)' = "$($UserOneDriveStats.storageAllocatedInBytes)"
                        'One Drive Usage'          = $OneDriveParsed

                    }
                } else {
                    $OneDriveCardData = [PSCustomObject]@{
                        'One Drive' = 'Disabled'
                    }
                }


                $UserMailboxStats = $MailboxStatsFull | Where-Object { $_.userPrincipalName -eq $User.userPrincipalName } | Select-Object -First 1
                $UserMailUse = $UserMailboxStats.storageUsedInBytes / 1GB
                $UserMailTotal = $UserMailboxStats.prohibitSendReceiveQuotaInBytes / 1GB


                if ($UserMailTotal) {
                    $MailboxUse = [PSCustomObject]@{
                        Enabled = $True
                        Used    = $UserMailUse
                        Total   = $UserMailTotal
                        Percent = ($UserMailUse / $UserMailTotal) * 100
                    }

                    $MailboxUseColor = if ($MailboxUse.Percent -ge 95) {
                        '#D53948'
                    } elseif ($MailboxUse.Percent -ge 85) {
                        '#FFA500'
                    } else {
                        '#26A644'
                    }

                    $MailboxParsed = '<div class="pt-3 pb-3 linechart"><div style="width: ' + $MailboxUse.Percent + '%; background-color: ' + $MailboxUseColor + ';"></div><div style="width: ' + (100 - $MailboxUse.Percent) + '%; background-color: #CCCCCC;"></div></div>'

                } else {
                    $MailboxUse = [PSCustomObject]@{
                        Enabled = $False
                        Used    = 0
                        Total   = 0
                        Percent = 0
                    }

                    $MailboxParsed = 'Not Enabled'
                }


                if ($UserMailSettings.ProhibitSendQuota) {
                    # Calculate GB values for display
                    try {
                        $MailboxProhibitSendQuota = [math]::Round($UserMailSettings.ProhibitSendQuota / 1024 / 1024 / 1024, 2)
                        $MailboxProhibitSendReceiveQuota = [math]::Round($UserMailSettings.ProhibitSendReceiveQuota / 1024 / 1024 / 1024, 2)
                        $MailboxStorageUsed = [math]::Round($UserMailSettings.StorageUsedInBytes / 1024 / 1024 / 1024, 2)
                    } catch {
                        $MailboxProhibitSendQuota = 0
                        $MailboxProhibitSendReceiveQuota = 0
                        $MailboxStorageUsed = 0
                    }

                    $MailboxDetailsCardData = [PSCustomObject]@{
                        #'Permissions'                 = "$($UserMailSettings.Permissions | ConvertTo-Html -Fragment | Out-String)"
                        'Prohibit Send Quota'         = "$($MailboxProhibitSendQuota) GB"
                        'Prohibit Send Receive Quota' = "$($MailboxProhibitSendReceiveQuota) GB"
                        'Item Count'                  = "$($UserMailSettings.ItemCount)"
                        'Total Mailbox Size'          = "$($MailboxStorageUsed) GB"
                        'Mailbox Usage'               = $MailboxParsed
                    }

                    $MailboxSettingsCard = [PSCustomObject]@{
                        'Forward and Deliver'       = "$($UserMailSettings.ForwardAndDeliver)"
                        'Forwarding Address'        = "$($UserMailSettings.ForwardingAddress)"
                        'Litigation Hold'           = "$($UserMailSettings.LitigationHold)"
                        'Hidden From Address Lists' = "$($UserMailSettings.HiddenFromAddressLists)"
                        'EWS Enabled'               = "$($UserMailSettings.EWSEnabled)"
                        'MAPI Enabled'              = "$($UserMailSettings.MailboxMAPIEnabled)"
                        'OWA Enabled'               = "$($UserMailSettings.MailboxOWAEnabled)"
                        'IMAP Enabled'              = "$($UserMailSettings.MailboxImapEnabled)"
                        'POP Enabled'               = "$($UserMailSettings.MailboxPopEnabled)"
                        'Active Sync Enabled'       = "$($UserMailSettings.MailboxActiveSyncEnabled)"
                    }
                } else {
                    $MailboxDetailsCardData = [PSCustomObject]@{
                        Exchange = 'Disabled'
                    }
                    $MailboxSettingsCard = [PSCustomObject]@{
                        Exchange = 'Disabled'
                    }
                }

                if ($UserPolicies) {
                    # Format Conditional Access Policies
                    $UserPoliciesFormatted = '<ul>'
                    foreach ($Policy in $UserPolicies) {
                        $UserPoliciesFormatted = $UserPoliciesFormatted + "<li>$($Policy.displayName)</li>"
                    }
                    $UserPoliciesFormatted = $UserPoliciesFormatted + '</ul>'
                } else {
                    $UserPoliciesFormatted = 'No Conditional Access Policies Assigned'
                }


                $UserOverviewCard = [PSCustomObject]@{
                    'User Name'           = "$($User.displayName)"
                    'User Principal Name' = "$($User.userPrincipalName)"
                    'User ID'             = "$($User.ID)"
                    'User Enabled'        = "$($User.accountEnabled)"
                    'Job Title'           = "$($User.jobTitle)"
                    'Mobile Phone'        = "$($User.mobilePhone)"
                    'Business Phones'     = "$($User.businessPhones -join ', ')"
                    'Office Location'     = "$($User.officeLocation)"
                    'Aliases'             = "$aliases"
                    'Licenses'            = "$($userLicenses)"
                }


                $Microsoft365UserLinksData = @(
                    @{
                        Name = 'Entra ID'
                        Link = "https://aad.portal.azure.com/$($Customer.defaultDomainName)/#blade/Microsoft_AAD_IAM/UserDetailsMenuBlade/Profile/userId/$($User.id)"
                        Icon = 'fas fa-users-cog'
                    },
                    @{
                        Name = 'Sign-In Logs'
                        Link = "https://aad.portal.azure.com/$($Customer.defaultDomainName)/#blade/Microsoft_AAD_IAM/UserDetailsMenuBlade/SignIns/userId/$($User.id)"
                        Icon = 'fas fa-users-cog'
                    },
                    @{
                        Name = 'Teams Admin'
                        Link = "https://admin.teams.microsoft.com/users/$($User.id)/account?delegatedOrg=$($Customer.defaultDomainName)"
                        Icon = 'fas fa-users'
                    },
                    @{
                        Name = 'Intune (User)'
                        Link = "https://endpoint.microsoft.com/$($Customer.defaultDomainName)/#blade/Microsoft_AAD_IAM/UserDetailsMenuBlade/Profile/userId/$($User.ID)"
                        Icon = 'fas fa-laptop'
                    },
                    @{
                        Name = 'Intune (Devices)'
                        Link = "https://endpoint.microsoft.com/$($Customer.defaultDomainName)/#blade/Microsoft_AAD_IAM/UserDetailsMenuBlade/Devices/userId/$($User.ID)"
                        Icon = 'fas fa-laptop'
                    }
                )

                $CIPPUserLinksData = @(
                    @{
                        Name = 'View User'
                        Link = "https://$($CIPPURL)/identity/administration/users/user?userId=$($User.id)&tenantFilter=$($Customer.defaultDomainName)"
                        Icon = 'far fa-eye'
                    },
                    @{
                        Name = 'Edit User'
                        Link = "https://$($CIPPURL)/identity/administration/users/user/edit?userId=$($User.id)&tenantFilter=$($Customer.defaultDomainName)"
                        Icon = 'fas fa-users-cog'
                    },
                    @{
                        Name = 'Research Compromise'
                        Link = "https://$($CIPPURL)/identity/administration/users/user/bec?userId=$($User.id)&tenantFilter=$($Customer.defaultDomainName)"
                        Icon = 'fas fa-user-secret'
                    }
                )

                # Actions
                $ActionsHTML = @"
                                <a href="https://$($CIPPUrl)/identity/administration/users/user?userId=$($User.id)&tenantFilter=$($Customer.defaultDomainName)" title="View in CIPP" class="btn secondary"><i class="fas fa-shield-halved" style="color: #337ab7;"></i></a>&nbsp;
                                <a href="https://entra.microsoft.com/$($Customer.DefaultDomainName)/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/overview/userId/$($User.id)/hidePreviewBanner~/true" title="View in Entra ID" class="btn secondary"><i class="fab fa-microsoft" style="color: #337ab7;"></i></a>&nbsp;
"@


                # Return Data for Users Summary Table
                $ParsedUser = [PSCustomObject]@{
                    PartitionKey   = "$($Customer.CustomerId)"
                    RowKey         = "$($User.id)"
                    Name           = "$($User.displayName)"
                    UPN            = "$($User.userPrincipalName)"
                    Aliases        = "$(($User.proxyAddresses -replace 'SMTP:', '') -join ', ')"
                    Licenses       = "<ul>$userLicenses</ul>"
                    Mailbox        = "$($MailboxUse)"
                    MailboxParsed  = "$($MailboxParsed)"
                    OneDrive       = "$($OneDriveUse)"
                    OneDriveParsed = "$($OneDriveParsed)"
                    Devices        = "<ul>$($UserDevices -join '')</ul>"
                    Actions        = "$($ActionsHTML)"
                }


                Add-CIPPAzDataTableEntity @UsersTable -Entity $ParsedUser -Force
                $ParsedUsers.add($ParsedUser)


                if ($Configuration.UserDocumentsEnabled -eq $True) {

                    # Format into Ninja HTML
                    # Links
                    $M365UserLinksHTML = Get-NinjaOneLinks -Data $Microsoft365UserLinksData -Title 'Portals' -SmallCols 2 -MedCols 3 -LargeCols 3 -XLCols 3
                    $CIPPUserLinksHTML = Get-NinjaOneLinks -Data $CIPPUserLinksData -Title 'CIPP Links' -SmallCols 2 -MedCols 3 -LargeCols 3 -XLCols 3
                    $UserLinksHTML = '<div class="row g-3"><div class="col-md-12 col-lg-6 d-flex">' + $M365UserLinksHTML + '</div><div class="col-md-12 col-lg-6 d-flex">' + $CIPPUserLinksHTML + '</div></div>'


                    # UsersSummaryCards:
                    $UserOverviewCardHTML = Get-NinjaOneInfoCard -Title 'User Details' -Data $UserOverviewCard -Icon 'fas fa-user'
                    $MailboxDetailsCardHTML = Get-NinjaOneInfoCard -Title 'Mailbox Details' -Data $MailboxDetailsCardData -Icon 'fas fa-envelope'
                    $MailboxSettingsCardHTML = Get-NinjaOneInfoCard -Title 'Mailbox Settings' -Data $MailboxSettingsCard -Icon 'fas fa-envelope'
                    $OneDriveCardHTML = Get-NinjaOneInfoCard -Title 'OneDrive Details' -Data $OneDriveCardData -Icon 'fas fa-envelope'
                    $UserPolciesCard = Get-NinjaOneCard -Title 'Assigned Conditional Access Policies' -Body $UserPoliciesFormatted


                    $UserSummaryHTML = '<div class="row g-3">' +
                    '<div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $UserOverviewCardHTML +
                    '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $MailboxDetailsCardHTML +
                    '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $MailboxSettingsCardHTML +
                    '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $OneDriveCardHTML +
                    '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $UserPolciesCard +
                    '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $DeviceSummaryCardHTML +
                    '</div></div></div>'


                    $UserDeviceDetailsTable = $UserDevicesDetailsRaw | Select-Object @{N = 'Name'; E = { $_.DeviceLink } },
                    @{n = 'Enrolled'; e = { $_.Enrolled } },
                    @{n = 'Last Sync'; e = { $_.LastSync } },
                    @{n = 'OS'; e = { $_.OS } },
                    @{n = 'OS Version'; e = { $_.OSVersion } },
                    @{n = 'State'; e = { $_.Compliance } },
                    @{n = 'Model'; e = { $_.Model } },
                    @{n = 'Manufacturer'; e = { $_.Make } }

                    $UserDeviceDetailHTML = $UserDeviceDetailsTable | ConvertTo-Html -As Table -Fragment
                    $UserDeviceDetailHTML = ([System.Web.HttpUtility]::HtmlDecode($UserDeviceDetailHTML) -replace '<th>', '<th style="white-space: nowrap;">') -replace '<td>', '<td style="white-space: nowrap;">'


                    $UserFields = @{
                        cippUserLinks   = @{'html' = $UserLinksHTML }
                        cippUserSummary = @{'html' = $UserSummaryHTML }
                        cippUserGroups  = @{'html' = "$($UserGroups | ConvertTo-Html -As Table -Fragment)" }
                        cippUserDevices = @{'html' = $UserDeviceDetailHTML }
                        cippUserID      = $User.id
                        cippUserUPN     = $User.userPrincipalName
                    }


                    if ($NinjaOneUser) {
                        $UpdateObject = [PSCustomObject]@{
                            PartitionKey = $Customer.CustomerId
                            RowKey       = $User.id
                            Action       = 'Update'
                            Body         = "$(@{
                            documentId   = $NinjaOneUser.documentId
                            documentName = "$($User.displayName) ($($User.userPrincipalName))"
                            fields       = $UserFields
                        } | ConvertTo-Json -Depth 100)"
                        }
                        $NinjaUserUpdates.Add($UpdateObject)
                        Add-CIPPAzDataTableEntity @UsersUpdateTable -Entity $UpdateObject -Force

                    } else {
                        $CreateObject = [PSCustomObject]@{
                            PartitionKey = $Customer.CustomerId
                            RowKey       = $User.id
                            Action       = 'Create'
                            Body         = "$(@{
                            documentName       = "$($User.displayName) ($($User.userPrincipalName))"
                            documentTemplateId = ($NinjaOneUsersTemplate.id)
                            organizationId     = [int]$NinjaOneOrg
                            fields             = $UserFields
                        } | ConvertTo-Json -Depth 100)"
                        }
                        $NinjaUserCreation.Add($CreateObject)
                        Add-CIPPAzDataTableEntity @UsersUpdateTable -Entity $CreateObject -Force
                    }


                    $CreatedUsers = $Null
                    $UpdatedUsers = $Null

                    try {
                        # Create New Users
                        if (($NinjaUserCreation | Measure-Object).count -ge 100) {
                            Write-Information 'Creating NinjaOne Users'
                            [System.Collections.Generic.List[PSCustomObject]]$CreatedUsers = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organization/documents" -Method POST -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json; charset=utf-8' -Body ("[$($NinjaUserCreation.body -join ',')]") -EA Stop).content | ConvertFrom-Json -Depth 100
                            Remove-AzDataTableEntity -Force @UsersUpdateTable -Entity $NinjaUserCreation
                            [System.Collections.Generic.List[PSCustomObject]]$NinjaUserCreation = @()
                        }
                    } catch {
                        Write-Information "Bulk Creation Error, but may have been successful as only 1 record with an issue could have been the cause: $_"
                    }

                    try {
                        # Update Users
                        if (($NinjaUserUpdates | Measure-Object).count -ge 100) {
                            Write-Information 'Updating NinjaOne Users'
                            [System.Collections.Generic.List[PSCustomObject]]$UpdatedUsers = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organization/documents" -Method PATCH -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json; charset=utf-8' -Body ("[$($NinjaUserUpdates.body -join ',')]") -EA Stop).content | ConvertFrom-Json -Depth 100
                            Remove-AzDataTableEntity -Force @UsersUpdateTable -Entity $NinjaUserUpdates
                            [System.Collections.Generic.List[PSCustomObject]]$NinjaUserUpdates = @()
                        }
                    } catch {
                        Write-Information "Bulk Update Errored, but may have been successful as only 1 record with an issue could have been the cause: $_"
                    }


                    [System.Collections.Generic.List[PSCustomObject]]$UserDocResults = $UpdatedUsers + $CreatedUsers

                    if (($UserDocResults | Where-Object { $Null -ne $_ -and $_ -ne '' } | Measure-Object).count -ge 1) {
                        $UserDocResults | Where-Object { $Null -ne $_ -and $_ -ne '' } | ForEach-Object {
                            $UserDoc = $_
                            if ($UserDoc.updatedFields) {
                                $Field = $UserDoc.updatedFields | Where-Object { $_.name -eq 'cippUserID' }
                            } else {
                                $Field = $UserDoc.fields | Where-Object { $_.name -eq 'cippUserID' }
                            }

                            if ($Null -ne $Field.value -and $Field.value -ne '') {

                                $MappedUser = ($UsersMap | Where-Object { $_.M365ID -eq $Field.value })
                                if (($MappedUser | Measure-Object).count -eq 0) {
                                    $UserMapItem = [PSCustomObject]@{
                                        PartitionKey = $Customer.CustomerId
                                        RowKey       = $Field.value
                                        NinjaOneID   = $UserDoc.documentId
                                        M365ID       = $Field.value
                                    }
                                    $UsersMap.Add($UserMapItem)
                                    Add-CIPPAzDataTableEntity @UsersMapTable -Entity $UserMapItem -Force

                                } elseif ($MappedUser.NinjaOneID -ne $UserDoc.documentId) {
                                    $MappedUser.NinjaOneID = $UserDoc.documentId
                                    Add-CIPPAzDataTableEntity @UsersMapTable -Entity $MappedUser -Force
                                }
                            } else {
                                Write-Error "Unmatched Doc: $($UserDoc | ConvertTo-Json -Depth 100)"
                            }

                        }

                    }


                }
            } catch {
                Write-Error "User $($User.UserPrincipalName): A fatal error occurred while processing user $_"
            }

        }



        $CreatedUsers = $Null
        $UpdatedUsers = $Null

        if ($Configuration.UserDocumentsEnabled -eq $True) {
            try {
                # Create New Users
                if (($NinjaUserCreation | Measure-Object).count -ge 1) {
                    Write-Information 'Creating NinjaOne Users'
                    [System.Collections.Generic.List[PSCustomObject]]$CreatedUsers = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organization/documents" -Method POST -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json; charset=utf-8' -Body ("[$($NinjaUserCreation.body -join ',')]") -EA Stop).content | ConvertFrom-Json -Depth 100
                    Remove-AzDataTableEntity -Force @UsersUpdateTable -Entity $NinjaUserCreation

                }
            } catch {
                Write-Information "Bulk Creation Error, but may have been successful as only 1 record with an issue could have been the cause: $_"
            }

            try {
                # Update Users
                if (($NinjaUserUpdates | Measure-Object).count -ge 1) {
                    Write-Information 'Updating NinjaOne Users'
                    [System.Collections.Generic.List[PSCustomObject]]$UpdatedUsers = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organization/documents" -Method PATCH -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json; charset=utf-8' -Body ("[$($NinjaUserUpdates.body -join ',')]") -EA Stop).content | ConvertFrom-Json -Depth 100
                    Remove-AzDataTableEntity -Force @UsersUpdateTable -Entity $NinjaUserUpdates
                }
            } catch {
                Write-Information "Bulk Update Errored, but may have been successful as only 1 record with an issue could have been the cause: $_"
            }

            ### Relationship Mapping
            # Parse out the NinjaOne ID to MS ID


            [System.Collections.Generic.List[PSCustomObject]]$UserDocResults = $UpdatedUsers + $CreatedUsers

            if (($UserDocResults | Where-Object { $Null -ne $_ -and $_ -ne '' } | Measure-Object).count -ge 1) {
                $UserDocResults | Where-Object { $Null -ne $_ -and $_ -ne '' } | ForEach-Object {
                    $UserDoc = $_
                    if ($UserDoc.updatedFields) {
                        $Field = $UserDoc.updatedFields | Where-Object { $_.name -eq 'cippUserID' }
                    } else {
                        $Field = $UserDoc.fields | Where-Object { $_.name -eq 'cippUserID' }
                    }

                    if ($Null -ne $Field.value -and $Field.value -ne '') {

                        $MappedUser = ($UsersMap | Where-Object { $_.M365ID -eq $Field.value })
                        if (($MappedUser | Measure-Object).count -eq 0) {
                            $UserMapItem = [PSCustomObject]@{
                                PartitionKey = $Customer.CustomerId
                                RowKey       = $Field.value
                                NinjaOneID   = $UserDoc.documentId
                                M365ID       = $Field.value
                            }
                            $UsersMap.Add($UserMapItem)
                            Add-CIPPAzDataTableEntity @UsersMapTable -Entity $UserMapItem -Force

                        } elseif ($MappedUser.NinjaOneID -ne $UserDoc.documentId) {
                            $MappedUser.NinjaOneID = $UserDoc.documentId
                            Add-CIPPAzDataTableEntity @UsersMapTable -Entity $MappedUser -Force
                        }
                    } else {
                        Write-Error "Unmatched Doc: $($UserDoc | ConvertTo-Json -Depth 100)"
                    }

                }
            }


            # Relate Users to Devices
            foreach ($LinkDevice in $ParsedDevices | Where-Object { $null -ne $_.NinjaDevice }) {
                $RelatedItems = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/related-items/with-entity/NODE/$($LinkDevice.NinjaDevice.id)" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100
                [System.Collections.Generic.List[PSCustomObject]]$Relations = @()
                foreach ($LinkUser in $LinkDevice.UserIDs) {
                    $MatchedUser = $UsersMap | Where-Object { $_.M365ID -eq $LinkUser }
                    if (($MatchedUser | Measure-Object).count -eq 1) {
                        $ExistingRelation = $RelatedItems | Where-Object { $_.relEntityType -eq 'DOCUMENT' -and $_.relEntityId -eq $MatchedUser.NinjaOneID }
                        if (!$ExistingRelation) {
                            $Relations.Add(
                                [PSCustomObject]@{
                                    relEntityType = 'DOCUMENT'
                                    relEntityId   = $MatchedUser.NinjaOneID
                                }
                            )
                        }
                    }
                }



                try {
                    # Update Relations
                    if (($Relations | Measure-Object).count -ge 1) {
                        Write-Information 'Updating Relations'
                        $Null = Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/related-items/entity/NODE/$($LinkDevice.NinjaDevice.id)/relations" -Method POST -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json' -Body ($Relations | ConvertTo-Json -Depth 100 -AsArray) -EA Stop
                        Write-Information 'Completed Update'
                    }
                } catch {
                    Write-Information "Creating Relations Failed: $_"
                }
            }
        }

        ### License Document Details
        if ($Configuration.LicenseDocumentsEnabled -eq $True) {

            $LicenseDetails = foreach ($License in $Licenses) {
                $MatchedSubscriptions = $License.TermInfo
                Write-Information "License info: $($License | ConvertTo-Json -Depth 100)"
                $FriendlyLicenseName = $License.skuPartNumber

                $LicenseUsers = foreach ($SubUser in $Users) {
                    $MatchedLicense = $SubUser.assignedLicenses | Where-Object { $License.skuId -in $_.skuId }
                    $MatchedPlans = $SubUser.AssignedPlans | Where-Object { $_.servicePlanId -in $License.servicePlans.servicePlanID }
                    if (($MatchedLicense | Measure-Object).count -gt 0 ) {
                        $SubRelUserID = ($UsersMap | Where-Object { $_.M365ID -eq $SubUser.id }).NinjaOneID
                        if ($SubRelUserID) {
                            $LicUserName = '<a href="' + "https://$($Configuration.Instance)/#/customerDashboard/$($NinjaOneOrg)/documentation/appsAndServices/$($NinjaOneUsersTemplate.id)/$($SubRelUserID)" + '" target="_blank">' + $SubUser.displayName + '</a>'
                        } else {
                            $LicUserName = $SubUser.displayName
                        }
                        [PSCustomObject]@{
                            Name               = $LicUserName
                            UPN                = $SubUser.userPrincipalName
                            'License Assigned' = $(try { $(Get-Date(($MatchedPlans | Group-Object assignedDateTime | Sort-Object Count -Desc | Select-Object -First 1).name) -Format u) } catch { 'Unknown' })
                            NinjaUserDocID     = $SubRelUserID
                        }
                    }
                }

                $LicenseUsersHTML = $LicenseUsers | Select-Object -ExcludeProperty NinjaUserDocID | ConvertTo-Html -As Table -Fragment
                $LicenseUsersHTML = ([System.Web.HttpUtility]::HtmlDecode($LicenseUsersHTML) -replace '<th>', '<th style="white-space: nowrap;">') -replace '<td>', '<td style="white-space: nowrap;">'

                $LicenseSummary = [PSCustomObject]@{
                    'License Name' = $FriendlyLicenseName
                    'Tenant Used'  = $License.consumedUnits
                    'Tenant Total' = $License.prepaidUnits.enabled
                    'SKU ID'       = $License.skuId
                }
                $LicenseOverviewCardHTML = Get-NinjaOneInfoCard -Title 'License Details' -Data $LicenseSummary -Icon 'fas fa-file-invoice'

                $SubscriptionsHTML = $MatchedSubscriptions | Select-Object @{'n' = 'Subscription Licenses'; 'e' = { $_.totalLicenses } },
                @{'n' = 'Created'; 'e' = { $_.createdDateTime } },
                @{'n' = 'Renewal'; 'e' = { $_.nextLifecycleDateTime } },
                @{'n' = 'Trial'; 'e' = { $_.isTrial } },
                @{'n' = 'Status'; 'e' = { $_.Status } } | ConvertTo-Html -As Table -Fragment

                $SubscriptionsHTML = ([System.Web.HttpUtility]::HtmlDecode($SubscriptionsHTML) -replace '<th>', '<th style="white-space: nowrap;">') -replace '<td>', '<td style="white-space: nowrap;">'
                $SubscriptionCardHTML = Get-NinjaOneCard -Title 'Subscriptions' -Body $SubscriptionsHTML -Icon 'fas fa-file-invoice'


                $LicenseItemsTable = $License.servicePlans | Select-Object @{n = 'Plan Name'; e = { convert-skuname -skuname $_.servicePlanName } }, @{n = 'Applies To'; e = { $_.appliesTo } }, @{n = 'Provisioning Status'; e = { $_.provisioningStatus } }
                $LicenseItemsHTML = $LicenseItemsTable | ConvertTo-Html -As Table -Fragment
                $LicenseItemsHTML = ([System.Web.HttpUtility]::HtmlDecode($LicenseItemsHTML) -replace '<th>', '<th style="white-space: nowrap;">') -replace '<td>', '<td style="white-space: nowrap;">'

                $LicenseItemsCardHTML = Get-NinjaOneCard -Title 'License Items' -Body $LicenseItemsHTML -Icon 'fas fa-chart-bar'


                $LicenseSummaryHTML = '<div class="row g-3">' +
                '<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 d-flex">' + $LicenseOverviewCardHTML +
                '</div><div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 d-flex">' + $SubscriptionCardHTML +
                '</div><div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 d-flex">' + $LicenseItemsCardHTML +
                '</div></div>'

                $NinjaOneLicense = $NinjaOneLicenseDocs | Where-Object { $_.ParsedFields.cippLicenseID -eq $License.ID }

                $LicenseFields = @{
                    cippLicenseSummary = @{'html' = $LicenseSummaryHTML }
                    cippLicenseUsers   = @{'html' = $LicenseUsersHTML }
                    cippLicenseID      = $License.skuId
                }


                if ($NinjaOneLicense) {
                    $UpdateObject = [PSCustomObject]@{
                        documentId   = $NinjaOneLicense.documentId
                        documentName = "$FriendlyLicenseName"
                        fields       = $LicenseFields
                    }
                    $NinjaLicenseUpdates.Add($UpdateObject)
                } else {
                    $CreateObject = [PSCustomObject]@{
                        documentName       = "$FriendlyLicenseName"
                        documentTemplateId = [int]($NinjaOneLicenseTemplate.id)
                        organizationId     = [int]$NinjaOneOrg
                        fields             = $LicenseFields
                    }
                    $NinjaLicenseCreation.Add($CreateObject)
                }

                [PSCustomObject]@{
                    Name  = "$FriendlyLicenseName"
                    Users = $LicenseUsers.NinjaUserDocID
                }

            }

            try {
                # Create New Subscriptions
                if (($NinjaLicenseCreation | Measure-Object).count -ge 1) {
                    Write-Information 'Creating NinjaOne Licenses'
                    [System.Collections.Generic.List[PSCustomObject]]$CreatedLicenses = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organization/documents" -Method POST -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json; charset=utf-8' -Body ($NinjaLicenseCreation | ConvertTo-Json -Depth 100 -AsArray) -EA Stop).content | ConvertFrom-Json -Depth 100
                }
            } catch {
                Write-Information "Bulk Creation Error, but may have been successful as only 1 record with an issue could have been the cause: $_"
            }

            try {
                # Update Subscriptions
                if (($NinjaLicenseUpdates | Measure-Object).count -ge 1) {
                    Write-Information 'Updating NinjaOne Licenses'
                    [System.Collections.Generic.List[PSCustomObject]]$UpdatedLicenses = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organization/documents" -Method PATCH -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json; charset=utf-8' -Body ($NinjaLicenseUpdates | ConvertTo-Json -Depth 100 -AsArray) -EA Stop).content | ConvertFrom-Json -Depth 100
                    Write-Information 'Completed Update'
                }
            } catch {
                Write-Information "Bulk Update Errored, but may have been successful as only 1 record with an issue could have been the cause: $_"
            }

            [System.Collections.Generic.List[PSCustomObject]]$LicenseDocs = $CreatedLicenses + $UpdatedLicenses

            if ($Configuration.LicenseDocumentsEnabled -eq $True -and $Configuration.UserDocumentsEnabled -eq $True) {
                # Relate Subscriptions to Users
                foreach ($LinkLic in $LicenseDetails) {
                    $MatchedLicDoc = $LicenseDocs | Where-Object { $_.documentName -eq $LinkLic.name }
                    if (($MatchedLicDoc | Measure-Object).count -eq 1) {
                        # Remove existing relations
                        $RelatedItems = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/related-items/with-entity/DOCUMENT/$($MatchedLicDoc.documentId)" -Method GET -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100
                        [System.Collections.Generic.List[PSCustomObject]]$Relations = @()
                        foreach ($LinkUser in $LinkLic.Users) {
                            $ExistingRelation = $RelatedItems | Where-Object { $_.relEntityType -eq 'DOCUMENT' -and $_.relEntityId -eq $LinkUser }
                            if (!$ExistingRelation) {
                                $Relations.Add(
                                    [PSCustomObject]@{
                                        relEntityType = 'DOCUMENT'
                                        relEntityId   = $LinkUser
                                    }
                                )
                            }
                        }


                        try {
                            # Update Relations
                            if (($Relations | Measure-Object).count -ge 1) {
                                Write-Information 'Updating Relations'
                                $Null = Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/related-items/entity/DOCUMENT/$($($MatchedLicDoc.documentId))/relations" -Method POST -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json' -Body ($Relations | ConvertTo-Json -Depth 100 -AsArray) -EA Stop
                                Write-Information 'Completed Update'
                            }
                        } catch {
                            Write-Information "Creating Relations Failed: $_"
                        }

                        #Remove relations
                        foreach ($DelUser in $RelatedItems | Where-Object { $_.relEntityType -eq 'DOCUMENT' -and $_.relEntityId -notin $LinkLic.Users }) {
                            try {
                                $RelatedItems = (Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/related-items/$($DelUser.id)" -Method Delete -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json').content | ConvertFrom-Json -Depth 100
                            } catch {
                                Write-Information "Failed to remove relation $($DelUser.id) from $($LinkLic.name)"
                            }
                        }
                    }
                }
            }

        }

        #######################################################################



        ### M365 Links Section
        if ($MappedFields.TenantLinks) {
            $ManagementLinksData = @(
                @{
                    Name = 'M365 Admin Portal'
                    Link = "https://admin.cloud.microsoft?delegatedOrg=$($customer.defaultDomainName)"
                    Icon = 'fas fa-cogs'
                },
                @{
                    Name = 'Exchange Portal'
                    Link = "https://admin.cloud.microsoft/exchange?delegatedOrg=$($Customer.defaultDomainName)"
                    Icon = 'fas fa-mail-bulk'
                },
                @{
                    Name = 'Entra Portal'
                    Link = "https://entra.microsoft.com/$($Customer.defaultDomainName)"
                    Icon = 'fas fa-users-cog'
                },
                @{
                    Name = 'Intune Portal'
                    Link = "https://intune.microsoft.com/$($customer.defaultDomainName)/"
                    Icon = 'fas fa-laptop'
                },
                @{
                    Name = 'SharePoint Admin'
                    Link = "https://admin.microsoft.com/Partner/beginclientsession.aspx?CTID=$($Customer.customerId)&CSDEST=SharePoint"
                    Icon = 'fas fa-shapes'
                },
                @{
                    Name = 'Teams Admin'
                    Link = "https://admin.teams.microsoft.com?delegatedOrg=$($Customer.defaultDomainName)"
                    Icon = 'fas fa-users'
                },
                @{
                    Name = 'Security Portal'
                    Link = "https://security.microsoft.com/?tid=$($Customer.customerId)"
                    Icon = 'fas fa-building-shield'
                },
                @{
                    Name = 'Compliance Portal'
                    Link = "https://purview.microsoft.com/?tid=$($Customer.customerId)"
                    Icon = 'fas fa-user-shield'
                },
                @{
                    Name = 'Azure Portal'
                    Link = "https://portal.azure.com/$($customer.defaultDomainName)"
                    Icon = 'fas fa-server'
                },
                @{
                    Name = 'Power Platform Portal'
                    Link = "https://admin.powerplatform.microsoft.com/account/login/$($Customer.customerId)"
                    Icon = 'fa-solid fa-robot'
                },
                @{
                    Name = 'Power BI Portal'
                    Link = "https://app.powerbi.com/admin-portal?ctid=$($Customer.customerId)"
                    Icon = 'fas fa-bar-chart'
                }

            )

            $M365LinksHTML = Get-NinjaOneLinks -Data $ManagementLinksData -Title 'Portals' -SmallCols 2 -MedCols 3 -LargeCols 3 -XLCols 3

            $CIPPLinksData = @(

                @{
                    Name = 'CIPP Tenant Dashboard'
                    Link = "https://$CIPPUrl/?tenantFilter=$($Customer.defaultDomainName)"
                    Icon = 'fas fa-shield-halved'
                },
                @{
                    Name = 'List Users'
                    Link = "https://$CIPPUrl/identity/administration/users?tenantFilter=$($Customer.defaultDomainName)"
                    Icon = 'fas fa-user'
                },
                @{
                    Name = 'List Groups'
                    Link = "https://$CIPPUrl/identity/administration/groups?tenantFilter=$($Customer.defaultDomainName)"
                    Icon = 'fas fa-users'
                },
                @{
                    Name = 'List Devices'
                    Link = "https://$CIPPUrl/endpoint/MEM/devices?tenantFilter=$($Customer.defaultDomainName)"
                    Icon = 'fas fa-laptop'
                },
                @{
                    Name = 'Create User'
                    Link = "https://$CIPPUrl/identity/administration/users/add?tenantFilter=$($Customer.defaultDomainName)"
                    Icon = 'fas fa-user-plus'
                },
                @{
                    Name = 'Create Group'
                    Link = "https://$CIPPUrl/identity/administration/groups/add?tenantFilter=$($Customer.defaultDomainName)"
                    Icon = 'fas fa-user-group'
                }
            )

            $CIPPLinksHTML = Get-NinjaOneLinks -Data $CIPPLinksData -Title 'CIPP Actions' -SmallCols 2 -MedCols 3 -LargeCols 3 -XLCols 3

            $LinksHtml = '<div class="row g-3"><div class="col-md-12 col-lg-6 d-flex"' + $M365LinksHtml + '</div><div class="col-md-12 col-lg-6 d-flex">' + $CIPPLinksHTML + '</div></div>'

            $NinjaOrgUpdate | Add-Member -NotePropertyName $MappedFields.TenantLinks -NotePropertyValue @{'html' = $LinksHtml }

        }


        if ($MappedFields.TenantSummary) {
            ### Tenant Overview Card
            $ParsedAdmins = [PSCustomObject]@{}

            $AdminUsers | Select-Object displayname, userPrincipalName -Unique | ForEach-Object {
                $ParsedAdmins | Add-Member -NotePropertyName $_.displayname -NotePropertyValue $_.userPrincipalName -Force
            }

            $TenantDetailsItems = [PSCustomObject]@{
                'Tenant Name'    = $Customer.displayName
                'Default Domain' = $Customer.defaultDomainName
                'Tenant ID'      = $Customer.customerId
                'Creation Date'  = $TenantDetails.createdDateTime
                'Domains'        = $customerDomains
                'Admin Users'    = ($AdminUsers | ForEach-Object { "$($_.DisplayName)" }) -join ', '

            }

            $TenantSummaryCard = Get-NinjaOneInfoCard -Title 'Tenant Details' -Data $TenantDetailsItems -Icon 'fas fa-building'

            ### Users details card
            $TotalUsersCount = ($Users | Measure-Object).count
            $GuestUsersCount = ($Users | Where-Object { $_.UserType -eq 'Guest' } | Measure-Object).count
            $LicensedUsersCount = ($licensedUsers | Measure-Object).count
            $UnlicensedUsersCount = $TotalUsersCount - $GuestUsersCount - $LicensedUsersCount
            $UsersEnabledCount = ($Users | Where-Object { $_.accountEnabled -eq $True } | Measure-Object).count

            # Enabled Users

            $Data = @(
                @{
                    Label  = 'Sign-In Enabled'
                    Amount = $UsersEnabledCount
                    Colour = '#26A644'
                },
                @{
                    Label  = 'Sign-In Blocked'
                    Amount = $TotalUsersCount - $UsersEnabledCount
                    Colour = '#D53948'
                }
            )


            $UsersEnabledChartHTML = Get-NinjaInLineBarGraph -Title 'User Status' -Data $Data -KeyInLine

            # User Types

            $Data = @(
                @{
                    Label  = 'Licensed'
                    Amount = $LicensedUsersCount
                    Colour = '#55ACBF'
                },
                @{
                    Label  = 'Unlicensed'
                    Amount = $UnlicensedUsersCount
                    Colour = '#3633B7'
                },
                @{
                    Label  = 'Guests'
                    Amount = $GuestUsersCount
                    Colour = '#8063BF'
                }
            )

            $UsersTypesChartHTML = Get-NinjaInLineBarGraph -Title 'User Types' -Data $Data -KeyInLine

            # Create the Users Card

            $TitleLink = "https://$CIPPUrl/identity/administration/users?tenantFilter=$($Customer.defaultDomainName)"

            $UsersCardBodyHTML = $UsersEnabledChartHTML + $UsersTypesChartHTML

            $UserSummaryCardHTML = Get-NinjaOneCard -Title 'User Details' -Body $UsersCardBodyHTML -Icon 'fas fa-users' -TitleLink $TitleLink



            ### Device Details Card
            $TotalDeviceswCount = ($Devices | Measure-Object).count
            $ComplianceDevicesCount = ($Devices | Where-Object { $_.complianceState -eq 'compliant' } | Measure-Object).count
            $WindowsCount = ($Devices | Where-Object { $_.operatingSystem -eq 'Windows' } | Measure-Object).count
            $IOSCount = ($Devices | Where-Object { $_.operatingSystem -eq 'iOS' } | Measure-Object).count
            $AndroidCount = ($Devices | Where-Object { $_.operatingSystem -eq 'Android' } | Measure-Object).count
            $MacOSCount = ($Devices | Where-Object { $_.operatingSystem -eq 'macOS' } | Measure-Object).count
            $OnlineInLast30Days = ($Devices | Where-Object { $_.lastSyncDateTime -gt ((Get-Date).AddDays(-30)) } | Measure-Object).Count


            # Compliance Devices
            $Data = @(
                @{
                    Label  = 'Compliant'
                    Amount = $ComplianceDevicesCount
                    Colour = '#26A644'
                },
                @{
                    Label  = 'Non Compliant'
                    Amount = $TotalDeviceswCount - $ComplianceDevicesCount
                    Colour = '#D53948'
                }
            )


            $DeviceComplianceChartHTML = Get-NinjaInLineBarGraph -Title 'Device Compliance' -Data $Data -KeyInLine

            # Device OS Types

            $Data = @(
                @{
                    Label  = 'Windows'
                    Amount = $WindowsCount
                    Colour = '#0078D7'
                },
                @{
                    Label  = 'macOS'
                    Amount = $MacOSCount
                    Colour = '#A3AAAE'
                },
                @{
                    Label  = 'Android'
                    Amount = $AndroidCount
                    Colour = '#3DDC84'
                },
                @{
                    Label  = 'iOS'
                    Amount = $IOSCount
                    Colour = '#007AFF'
                }
            )

            $DeviceOsChartHTML = Get-NinjaInLineBarGraph -Title 'Device Operating Systems' -Data $Data -KeyInLine

            # Last online time

            $Data = @(
                @{
                    Label  = 'Online in last 30 days'
                    Amount = $OnlineInLast30Days
                    Colour = '#26A644'
                },
                @{
                    Label  = 'Not seen for 30+ days'
                    Amount = $TotalDeviceswCount - $OnlineInLast30Days
                    Colour = '#CCCCCC'
                }
            )

            $DeviceOnlineChartHTML = Get-NinjaInLineBarGraph -Title 'Devices Online in the last 30 days' -Data $Data -KeyInLine

            # Create the Devices Card

            $TitleLink = "https://$CIPPUrl/endpoint/MEM/devices?tenantFilter=$($Customer.defaultDomainName)"

            $DeviceCardBodyHTML = $DeviceComplianceChartHTML + $DeviceOsChartHTML + $DeviceOnlineChartHTML

            $DeviceSummaryCardHTML = Get-NinjaOneCard -Title 'Device Details' -Body $DeviceCardBodyHTML -Icon 'fas fa-network-wired' -TitleLink $TitleLink

            #### Secure Score Card
            $Top5Actions = ($SecureScoreParsed | Where-Object { $_.scoreInPercentage -ne 100 } | Sort-Object 'Score Impact', adjustedRank -Descending) | Select-Object -First 5

            # Score Chart
            $Data = [PSCustomObject]@(
                @{
                    Label  = 'Current Score'
                    Amount = $CurrentSecureScore.currentScore
                    Colour = '#26A644'
                },
                @{
                    Label  = 'Points to Obtain'
                    Amount = $MaxSecureScore - $CurrentSecureScore.currentScore
                    Colour = '#CCCCCC'
                }
            )

            try {
                $SecureScoreHTML = Get-NinjaInLineBarGraph -Title "Secure Score - $([System.Math]::Round((($CurrentSecureScore.currentScore / $MaxSecureScore) * 100),2))%" -Data $Data -KeyInLine -NoCount -NoSort
            } catch {
                $SecureScoreHTML = 'No Secure Score Data Available'
            }

            # Recommended Actions HTML
            $RecommendedActionsHTML = $Top5Actions | Select-Object 'Recommended Action', @{n = 'Score Impact'; e = { "+$($_.scoreImpact)%" } }, Category, @{n = 'Link'; e = { '<a href="' + $_.link + '" target="_blank"><i class="fas fa-arrow-up-right-from-square" style="color: #337ab7;"></i></a>' } } | ConvertTo-Html -As Table -Fragment

            $TitleLink = "https://security.microsoft.com/securescore?viewid=overview&tid=$($Customer.customerId)"

            $SecureScoreCardBodyHTML = $SecureScoreHTML + [System.Web.HttpUtility]::HtmlDecode($RecommendedActionsHTML) -replace '<th>', '<th style="white-space: nowrap;">'
            $SecureScoreCardBodyHTML = $SecureScoreCardBodyHTML -replace '<td>', '<td>'

            $SecureScoreSummaryCardHTML = Get-NinjaOneCard -Title 'Secure Score' -Body $SecureScoreCardBodyHTML -Icon 'fas fa-shield' -TitleLink $TitleLink


            ### CIPP Applied Standards Cards
            try {
                $StandardsDefinitions = Invoke-RestMethod -Uri 'https://raw.githubusercontent.com/KelvinTegelaar/CIPP/refs/heads/main/src/data/standards.json'
                $AppliedStandards = Get-CIPPStandards -TenantFilter $Customer.defaultDomainName
                $Templates = Get-CIPPTable 'templates'
                $StandardTemplates = Get-CIPPAzDataTableEntity @Templates -Filter "PartitionKey eq 'StandardsTemplateV2'"

                $ParsedStandards = foreach ($Standard in $AppliedStandards) {
                    Write-Information "Processing Standard: $($Standard | ConvertTo-Json -Depth 10)"
                    if ($Standard.TemplateId.Count -gt 1) {
                        $TemplateListTemplates = foreach ($TemplateId in $Standard.TemplateId) {
                            if ($TemplateId) {
                                ($StandardTemplates | Where-Object { $_.RowKey -eq $TemplateId }).JSON | ConvertFrom-Json
                            }
                        }
                    } else {
                        $Template = ($StandardTemplates | Where-Object { $_.RowKey -eq $Standard.TemplateId }).JSON | ConvertFrom-Json
                    }
                    $StandardInfo = $StandardsDefinitions | Where-Object { ($_.name -replace 'standards.', '') -eq $Standard.Standard }
                    $StandardLabel = $StandardInfo.label
                    $ParsedActions = foreach ($Action in $Standard.Settings.PSObject.Properties) {
                        if ($Action.Value -eq $true -and $Action.Name -in @('remediate', 'report', 'alert')) {
                            (Get-Culture).TextInfo.ToTitleCase($Action.Name)
                        }
                    }

                    # Handle template-based standards that have lists of templates
                    if ($Standard.Standard -in @('IntuneTemplate', 'ConditionalAccessTemplate', 'GroupTemplate')) {
                        # For template standards, create separate entries for each template
                        foreach ($Property in $Standard.Settings.PSObject.Properties) {
                            if ($Property.Value -is [Array]) {
                                $x = 0
                                foreach ($TemplateItem in $Property.Value) {
                                    $TemplateName = $null
                                    $TemplateActions = @()

                                    Write-Information "Processing Template Item: $($TemplateItem | ConvertTo-Json -Depth 10)"
                                    # Get template name
                                    if ($TemplateItem.TemplateList.label) {
                                        $TemplateName = $TemplateItem.TemplateList.label
                                    } elseif ($TemplateItem.'TemplateList-Tags'.label) {
                                        $TemplateName = $TemplateItem.'TemplateList-Tags'.label
                                    } else {
                                        $TemplateName = $TemplateItem.TemplateList.displayName
                                    }

                                    # Get template-specific actions
                                    foreach ($ItemAction in $TemplateItem.PSObject.Properties) {
                                        if ($ItemAction.Value -eq $true -and $ItemAction.Name -in @('remediate', 'report', 'alert')) {
                                            $TemplateActions += (Get-Culture).TextInfo.ToTitleCase($ItemAction.Name)
                                        }
                                    }

                                    # If no template-specific actions, use standard-level actions
                                    if ($TemplateActions.Count -eq 0) {
                                        $TemplateActions = $ParsedActions
                                    }

                                    if ($TemplateName) {
                                        [PSCustomObject]@{
                                            Standard = "$StandardLabel - $TemplateName"
                                            Template = $TemplateListTemplates[$x].templateName
                                            Actions  = $TemplateActions -join ', '
                                        }
                                    }
                                    $x++
                                }
                            }
                        }
                    } else {
                        # For non-template standards, use the original logic
                        [PSCustomObject]@{
                            Standard = $StandardLabel
                            Template = $Template.templateName
                            Actions  = $ParsedActions -join ', '
                        }
                    }
                }
                $ParsedStandardsHTML = $ParsedStandards | ConvertTo-Html -As Table -Fragment
                $StandardsTableHTML = '<div class="field-container">' + (([System.Web.HttpUtility]::HtmlDecode($ParsedStandardsHTML) -replace '<th>', '<th style="white-space: nowrap;">') -replace '<td>', '<td style="white-space: nowrap;">') + '</div>'
            } catch {
                $StandardsTableHTML = 'No standards applied or error retrieving standards'
            }
            $TitleLink = "https://$CIPPUrl/tenant/standards/list-standards"
            $CIPPStandardsSummaryCardHTML = Get-NinjaOneCard -Title 'CIPP Applied Standards' -Body $StandardsTableHTML -Icon 'fas fa-shield-halved' -TitleLink $TitleLink

            ### License Card
            Write-Information 'License Details'
            $LicenseTableHTML = $LicensesParsed | Sort-Object 'License Name' | ConvertTo-Html -As Table -Fragment
            $LicenseTableHTML = '<div class="field-container">' + (([System.Web.HttpUtility]::HtmlDecode($LicenseTableHTML) -replace '<th>', '<th style="white-space: nowrap;">') -replace '<td>', '<td style="white-space: nowrap;">') + '</div>'

            $TitleLink = "https://$CIPPUrl/tenant/reports/list-licenses?tenantFilter=$($Customer.defaultDomainName)"
            $LicensesSummaryCardHTML = Get-NinjaOneCard -Title 'Licenses' -Body $LicenseTableHTML -Icon 'fas fa-chart-bar' -TitleLink $TitleLink


            ### Summary Stats
            Write-Information 'Widget Details'

            [System.Collections.Generic.List[PSCustomObject]]$WidgetData = @()

            ### Fetch BPA Data
            $Table = get-cipptable 'cachebpav2'
            $BPAData = (Get-CIPPAzDataTableEntity @Table -Filter "PartitionKey eq '$($Customer.customerId)'")

            if ($Null -ne $BPAData.Timestamp) {
                ## BPA Data Widgets
                # Shared Mailboxes with Enabled Users
                #$WidgetData.add([PSCustomObject]@{
                #        Value       = $(
                #            $SharedSendMailboxCount = ($BpaData.SharedMailboxeswithenabledusers | ConvertFrom-Json | Measure-Object).count
                #            if ($SharedSendMailboxCount -ne 0) {
                #                $ResultColour = '#D53948'
                #            } else {
                #                $ResultColour = '#26A644'
                #            }
                #            $SharedSendMailboxCount
                #        )
                #        Description = 'Shared Mailboxes with enabled users'
                #        Colour      = $ResultColour
                #        Link        = "https://$CIPPUrl/tenant/standards/bpa-report?SearchNow=true&Report=CIPP+Best+Practices+v1.0+-+Tenant+view&tenantFilter=$($Customer.customerId)"
                #    })

                # Unused Licenses
                $WidgetData.add([PSCustomObject]@{
                        Value       = $(
                            try {
                                $BPAUnusedLicenses = (($BpaData.Unusedlicenses | ConvertFrom-Json -ErrorAction SilentlyContinue).availableUnits | Measure-Object -Sum).sum
                            } catch {
                                $BPAUnusedLicenses = 'Failed to retrieve unused licenses'
                            }
                            if ($BPAUnusedLicenses -ne 0) {
                                $ResultColour = '#D53948'
                            } else {
                                $ResultColour = '#26A644'
                            }
                            $BPAUnusedLicenses
                        )
                        Description = 'Unused Licenses'
                        Colour      = $ResultColour
                        Link        = "https://$CIPPUrl/tenant/standards/bpa-report?tenantFilter=$($Customer.defaultDomainName)"
                    })


                # Unified Audit Log
                $WidgetData.add([PSCustomObject]@{
                        Value       = $(if ($BPAData.UnifiedAuditLog -eq $True) {
                                $ResultColour = '#26A644'
                                '<i class="fas fa-circle-check"></i>'
                            } else {
                                $ResultColour = '#D53948'
                                '<i class="fas fa-circle-xmark"></i>'
                            }
                        )
                        Description = 'Unified Audit Log'
                        Colour      = $ResultColour
                        Link        = "https://security.microsoft.com/auditlogsearch?viewid=Async%20Search&tid=$($Customer.customerId)"
                    })

                # Passwords Never Expire
                $WidgetData.add([PSCustomObject]@{
                        Value       = $(if ($BPAData.PasswordNeverExpires -eq $True) {
                                $ResultColour = '#26A644'
                                '<i class="fas fa-circle-check"></i>'
                            } else {
                                $ResultColour = '#D53948'
                                '<i class="fas fa-circle-xmark"></i>'
                            }
                        )
                        Description = 'Password Never Expires'
                        Colour      = $ResultColour
                        Link        = "https://$CIPPUrl/tenant/standards/bpa-report?tenantFilter=$($Customer.defaultDomainName)"
                    })

                # oAuth App Consent
                $WidgetData.add([PSCustomObject]@{
                        Value       = $(if ($BPAData.OAuthAppConsent -eq $True) {
                                $ResultColour = '#26A644'
                                '<i class="fas fa-circle-check"></i>'
                            } else {
                                $ResultColour = '#D53948'
                                '<i class="fas fa-circle-xmark"></i>'
                            }
                        )
                        Description = 'OAuth App Consent'
                        Colour      = $ResultColour
                        Link        = "https://entra.microsoft.com/$($Customer.defaultDomainName)/#view/Microsoft_AAD_IAM/ConsentPoliciesMenuBlade/~/UserSettings"
                    })

            }

            # Blocked Senders
            $BlockedSenderCount = ($BlockedSenders | Measure-Object).count
            if ($BlockedSenderCount -eq 0) {
                $BlockedSenderColour = '#26A644'
            } else {
                $BlockedSenderColour = '#D53948'
            }
            $WidgetData.add([PSCustomObject]@{
                    Value       = $BlockedSenderCount
                    Description = 'Blocked Senders'
                    Colour      = $BlockedSenderColour
                    Link        = "https://security.microsoft.com/restrictedentities?tid=$($Customer.customerId)"
                })

            # Licensed Users
            $WidgetData.add([PSCustomObject]@{
                    Value       = ($licensedUsers | Measure-Object).count
                    Description = 'Licensed Users'
                    Colour      = '#CCCCCC'
                    Link        = "https://$CIPPUrl/identity/administration/users?tenantFilter=$($Customer.defaultDomainName)"
                })

            # Devices
            $WidgetData.add([PSCustomObject]@{
                    Value       = ($Devices | Measure-Object).count
                    Description = 'Devices'
                    Colour      = '#CCCCCC'
                    Link        = "https://$CIPPUrl/endpoint/MEM/devices?tenantFilter=$($Customer.defaultDomainName)"
                })

            # Groups
            $WidgetData.add([PSCustomObject]@{
                    Value       = ($AllGroups | Measure-Object).count
                    Description = 'Groups'
                    Colour      = '#CCCCCC'
                    Link        = "https://$CIPPUrl/identity/administration/groups?tenantFilter=$($Customer.defaultDomainName)"
                })

            # Roles
            $WidgetData.add([PSCustomObject]@{
                    Value       = ($AllRoles | Measure-Object).count
                    Description = 'Roles'
                    Colour      = '#CCCCCC'
                    Link        = "https://$CIPPUrl/identity/administration/roles?tenantFilter=$($Customer.defaultDomainName)"
                })


            # AAD Premium
            if ( 'AADPremiumService' -in $TenantDetails.assignedPlans.service) {
                $AADPremiumStatus = '<i class="fas fa-circle-check"></i>'
            } else {
                $AADPremiumStatus = '<i class="fas fa-circle-xmark"></i>'
            }
            $WidgetData.add([PSCustomObject]@{
                    Value       = $AADPremiumStatus
                    Description = 'AAD Premium'
                    Colour      = '#CCCCCC'
                    Link        = "https://entra.microsoft.com/$($Customer.customerId)/#view/Microsoft_AAD_IAM/TenantOverview.ReactView"
                })

            # WindowsDefenderATP
            if ( 'WindowsDefenderATP' -in $TenantDetails.assignedPlans.service) {
                $DefenderStatus = '<i class="fas fa-circle-check"></i>'
            } else {
                $DefenderStatus = '<i class="fas fa-circle-xmark"></i>'
            }
            $WidgetData.add([PSCustomObject]@{
                    Value       = $DefenderStatus
                    Description = 'Windows Defender'
                    Colour      = '#CCCCCC'
                    Link        = "https://security.microsoft.com/machines?category=endpoints&tid=$($Customer.DefaultDomainName)#"
                })

            # On Prem Sync
            if ( $TenantDetails.onPremisesSyncEnabled -eq $true) {
                $OnPremSyncStatus = '<i class="fas fa-circle-check"></i>'
            } else {
                $OnPremSyncStatus = '<i class="fas fa-circle-xmark"></i>'
            }
            $WidgetData.add([PSCustomObject]@{
                    Value       = $OnPremSyncStatus
                    Description = 'AD Connect'
                    Colour      = '#CCCCCC'
                    Link        = "https://entra.microsoft.com/$($Customer.customerId)/#view/Microsoft_AAD_IAM/DirectoriesADConnectBlade"
                })






            Write-Information 'Summary Details'
            $SummaryDetailsCardHTML = Get-NinjaOneWidgetCard -Data $WidgetData -Icon 'fas fa-building' -SmallCols 2 -MedCols 3 -LargeCols 4 -XLCols 6 -NoCard


            # Create the Tenant Summary Field
            Write-Information 'Complete Tenant Summary'
            $TenantSummaryHTML = '<div class="field-container">' + $SummaryDetailsCardHTML + '</div>' +
            '<div class="row g-3">' +
            '<div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $TenantSummaryCard +
            '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $LicensesSummaryCardHTML +
            '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $DeviceSummaryCardHTML +
            '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $CIPPStandardsSummaryCardHTML +
            '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $SecureScoreSummaryCardHTML +
            '</div><div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 d-flex">' + $UserSummaryCardHTML +
            '</div></div></div>'

            $NinjaOrgUpdate | Add-Member -NotePropertyName $MappedFields.TenantSummary -NotePropertyValue @{'html' = $TenantSummaryHTML }



        }

        if ($MappedFields.UsersSummary) {
            Write-Information 'User Details Section'

            $UsersTableFornatted = $ParsedUsers | Sort-Object name | Select-Object -First 100 Name,
            @{n = 'User Principal Name'; e = { $_.UPN } },
            #Aliases,
            Licenses,
            @{n = 'Mailbox Usage'; e = { $_.MailboxParsed } },
            @{n = 'One Drive Usage'; e = { $_.OneDriveParsed } },
            @{n = 'Devices (Last Login)'; e = { $_.Devices } },
            Actions


            $UsersTableHTML = $UsersTableFornatted | ConvertTo-Html -As Table -Fragment

            $UsersTableHTML = ([System.Web.HttpUtility]::HtmlDecode($UsersTableHTML) -replace '<th>', '<th style="white-space: nowrap;">') -replace '<td>', '<td style="white-space: nowrap;">'

            if ($ParsedUsers.count -gt 100) {
                $Overflow = @"
                <div class="info-card">
    <i class="info-icon fa-solid fa-circle-info"></i>
    <div class="info-text">
        <div class="info-title">$($ParsedUsers.count) users found in Tenant</div>
        <div class="info-description">
            Only the first 100 users are displayed here. To see all users please <a href="https://$CIPPUrl/identity/administration/users?tenantFilter=$($Customer.defaultDomainName)" target="_blank">view users in CIPP</a>.
        </div>
    </div>
</div>
"@
            } else {
                $Overflow = ''
            }

            $NinjaOrgUpdate | Add-Member -NotePropertyName $MappedFields.UsersSummary -NotePropertyValue @{'html' = $Overflow + $UsersTableHTML }

        }



        Write-Information 'Posting Details'

        $Token = Get-NinjaOneToken -configuration $Configuration

        #Write-Information "Ninja Body: $($NinjaOrgUpdate | ConvertTo-Json -Depth 100)"
        $Result = Invoke-WebRequest -Uri "https://$($Configuration.Instance)/api/v2/organization/$($MappedTenant.IntegrationId)/custom-fields" -Method PATCH -Headers @{Authorization = "Bearer $($token.access_token)" } -ContentType 'application/json; charset=utf-8' -Body ($NinjaOrgUpdate | ConvertTo-Json -Depth 100)


        Write-Information 'Cleaning Users Cache'
        if (($ParsedUsers | Measure-Object).count -gt 0) {
            Remove-AzDataTableEntity -Force @UsersTable -Entity ($ParsedUsers | Select-Object PartitionKey, RowKey)
        }

        Write-Information 'Cleaning Device Cache'
        if (($ParsedDevices | Measure-Object).count -gt 0) {
            Remove-AzDataTableEntity -Force @DeviceTable -Entity ($ParsedDevices | Select-Object PartitionKey, RowKey)
        }

        Write-Information "Total Fetch Time: $((New-TimeSpan -Start $StartTime -End $FetchEnd).TotalSeconds)"
        Write-Information "Completed Total Time: $((New-TimeSpan -Start $StartTime -End (Get-Date)).TotalSeconds)"

        # Set Last End Time
        $CurrentItem | Add-Member -NotePropertyName lastEndTime -NotePropertyValue ([string]$((Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ'))) -Force
        $CurrentItem | Add-Member -NotePropertyName lastStatus -NotePropertyValue 'Completed' -Force
        Add-CIPPAzDataTableEntity @MappingTable -Entity $CurrentItem -Force

        Write-LogMessage -tenant $Customer.defaultDomainName -API 'NinjaOneSync' -message "Completed NinjaOne Sync for $($Customer.displayName). Queued for $((New-TimeSpan -Start $StartQueueTime -End $StartTime).TotalSeconds) seconds. Data fetched in $((New-TimeSpan -Start $StartTime -End $FetchEnd).TotalSeconds) seconds. Total processing time $((New-TimeSpan -Start $StartTime -End (Get-Date)).TotalSeconds) seconds" -Sev 'info'

    } catch {
        $Message = if ($_.ErrorDetails.Message) {
            Get-NormalizedError -Message $_.ErrorDetails.Message
            Write-Information (Get-CippException -Exception $_ | ConvertTo-Json)
        } else {
            $_.Exception.message
        }
        Write-Error "Failed NinjaOne Processing for $($Customer.displayName) Linenumber: $($_.InvocationInfo.ScriptLineNumber) Error:  $Message"
        Write-LogMessage -tenant $Customer.defaultDomainName -API 'NinjaOneSync' -message "Failed NinjaOne Processing for $($Customer.displayName) Linenumber: $($_.InvocationInfo.ScriptLineNumber) Error: $Message" -Sev 'Error'
        $CurrentItem | Add-Member -NotePropertyName lastEndTime -NotePropertyValue ([string]$((Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ'))) -Force
        $CurrentItem | Add-Member -NotePropertyName lastStatus -NotePropertyValue 'Failed' -Force
        Add-CIPPAzDataTableEntity @MappingTable -Entity $CurrentItem -Force
    }
    return $true
}
#EndRegion './Public/NinjaOne/Invoke-NinjaOneTenantSync.ps1' 2233
#Region './Public/NinjaOne/NinjaOneHelper.ps1' -1

function Get-NinjaOneTitle($Title, $Icon, $TitleLink, $TitleSize, $TitleClass) {
    Return $(if ($TitleSize) { '<' + $TitleSize }else { '<span ' }) + $(if ($TitleClass) { ' class="' + $TitleClass + '"' }) + '>' + $(if ($Icon) { '<i class="' + $Icon + '"></i>&nbsp;&nbsp;' }) + $Title + $(if ($TitleLink) { '&nbsp;&nbsp;<a href="' + $TitleLink + '" target="_blank" class="text-decoration-none"><i class="fas fa-arrow-up-right-from-square fa-2xs" style="color: #337ab7;"></i></a>' }) + $(if ($TitleSize) { "</$TitleSize>" }else { '</span>' })
}

### HTML Formatters ###
# Bar Graph
function Get-NinjaInLineBarGraph ($Data, [string]$Title, [string]$Icon, [string]$TitleLink, [switch]$KeyInLine, [switch]$NoCount, [switch]$NoSort) {
    <# 
    Example: 
    $Data = @(
        @{
            Label = 'Licensed'
            Amount = 3
            Colour = '#55ACBF'
        },
        @{
            Label = 'Unlicensed'
            Amount = 1
            Colour = '#3633B7'
        },
        @{
            Label = 'Guests'
            Amount = 10
            Colour = '#8063BF'
        }
    )
    Get-NinjaInLineBarGraph -Title "Users" -Data $Data -KeyInLine

    #>

    if (!$NoSort) {
        $Data = $Data | Sort-Object Amount -Descending
    }

    $Total = ($Data.Amount | measure-object -sum).sum
    [System.Collections.Generic.List[String]]$OutputHTML = @()

    if ($Title) {
        $OutputHTML.add((Get-NinjaOneTitle -Icon $Icon -Title ($Title + $(if (!$NoCount) { " ($Total)" })) -TitleLink $TitleLink))
    }

    $OutputHTML.add('<div class="pb-3 pt-3 linechart">')

    foreach ($Item in $Data) {
        $OutputHTML.add(@"
        <div style="width: $(($Item.Amount / $Total) * 100)%; background-color: $($Item.Colour);"></div>
"@)

    }

    $OutputHTML.add('</div>')

    if ($KeyInline) {
        $OutputHTML.add('<ul class="unstyled p-3" style="display: flex; justify-content: space-between;">')
    } else {
        $OutputHTML.add('<ul class="unstyled p-3" >')
    }

    foreach ($Item in $Data) {
        $OutputHTML.add(@"
        <li><span class="chart-key" style="background-color: $($Item.Colour);"></span><span > $($Item.Label) ($($Item.Amount))</span></li>
"@)

    }

    $OutputHTML.add('</ul>')

    return $OutputHTML -join ''


}

#### List of Links
function Get-NinjaOneLinks ($Data, $Title, [string]$Icon, [string]$TitleLink, [int]$SmallCols, [int]$MedCols, [int]$LargeCols, [int]$XLCols) {
    <#
$ManagementLinksData = @(
        @{
            Name = 'M365 Admin Portal'
            Link = "https://portal.office.com/Partner/BeginClientSession.aspx?CTID=$($customer.CustomerId)&CSDEST=o365admincenter"
            Icon = 'fas fa-cogs'
        },
        @{
            Name = 'Exchange Admin Portal'
            Link = "https://outlook.office365.com/ecp/?rfr=Admin_o365&exsvurl=1&delegatedOrg=$($Customer.DefaultDomainName)"
            Icon = 'fas fa-mail-bulk'
        },
        @{
            Name = 'Entra Admin'
            Link = "https://aad.portal.azure.com/$($Customer.DefaultDomainName)"
            Icon = 'fas fa-users-cog'
        })

        Get-NinjaOneLinks -Title 'M365 Admin Links' -Data $ManagementLinksData
#>

    [System.Collections.Generic.List[String]]$OutputHTML = @()

    $OutputHTML.add('<div class="card flex-grow-1">')

    if ($Title) {
        $OutputHTML.add('<div class="card-title-box"><div class="card-title">' + $(if ($Icon) { '<i class="' + $Icon + '"></i>&nbsp;&nbsp;' }) + $Title + '</div>')

        if ($TitleLink) {
            $OutputHTML.add('<div class="card-link-box"><a href="' + $TitleLink + '" target="_blank" class="card-link"><i class="fas fa-arrow-up-right-from-square"></i></a></div>')
        }

        $OutputHTML.add('</div>')
    }

    $OutputHTML.add('<div class="card-body">')
    $OutputHTML.add('<ul class="row unstyled">')

    $CSSCols = Get-NinjaOneCSSCol -SmallCols $SmallCols -MedCols $MedCols -LargeCols $LargeCols -XLCols $XLCols

   
    foreach ($Item in $Data) {


        $OutputHTML.add(@"
        <li class="$CSSCols"><a href="$($Item.Link)" target="_blank">$(if ($Item.Icon){"<span><i class=`"$($Item.Icon)`"></i>&nbsp;&nbsp;</span>"})<span style="text-align: center;">$($Item.Name)</span></a></li>
"@)

    }

    $OutputHTML.add('</ul></div></div>')

    return $OutputHTML -join ''

}


function Get-NinjaOneWidgetCard($Title, $Data, [string]$Icon, [string]$TitleLink, [int]$SmallCols, [int]$MedCols, [int]$LargeCols, [int]$XLCols, [Switch]$NoCard) {
    <#
    $Data = @(
        @{
            Value = 20
            Description = 'Users'
            Colour = '#CCCCCC'
            Link = 'https://example.com/users'
        },
        @{
            Value = 42
            Description = 'Devices'
            Colour = '#CCCCCC'
            Link = 'https://example.com/devices'
        }
    )
    
    $HTML = Get-NinjaOneWidgetCard -Title 'Summary Details' -Data $Data -Icon 'fas fa-building' -TitleLink 'http://example.com' -Columns 3

    #>

    $CSSCols = Get-NinjaOneCSSCol -SmallCols $SmallCols -MedCols $MedCols -LargeCols $LargeCols -XLCols $XLCols


    [System.Collections.Generic.List[String]]$OutputHTML = @()
    
    $OutputHTML.add('<div class="row d-flex m-1 justify-content-center align-items-center">')


    foreach ($Item in $Data) {

        $HTML = @"
    <div class="$CSSCols">
    <div class="stat-card">
    <div class="stat-value"><a href="$($Item.Link)" target="_blank"><span style="color: $($Item.Colour);">$($Item.Value)</span></a></div>
    <div class="stat-desc"><a href="$($Item.Link)" target="_blank"><span style="font-size: 18px;"><span style="white-space:nowrap;">$($Item.Description)</span></span></a></div>
        </div>
    </div>
"@

        $OutputHTML.add($HTML)

    }

    $OutputHTML.add('</div>')

    if ($NoCard) {
        return $OutputHTML -join ''
    } else {
        Return Get-NinjaOneCard -Title $Title -Body ($OutputHTML -join '') -Icon $Icon -TitleLink $TitleLink
    }

}

Function Get-NinjaOneCSSCol($SmallCols, $MedCols, $LargeCols, $XLCols) {
    $SmallCSS = "col-sm-$([Math]::Floor(12 / $SmallCols))"
    $MediumCSS = "col-md-$([Math]::Floor(12 / $MedCols))"
    $LargeCSS = "col-lg-$([Math]::Floor(12 / $LargeCols))"
    $XLCSS = "col-xl-$([Math]::Floor(12 / $XLCols))"

    Return "$SmallCSS $MediumCSS $LargeCSS $XLCSS"
}

function Get-NinjaOneCard($Title, $Body, [string]$Icon, [string]$TitleLink, [String]$Classes) {
    <#
    $Info = 'This is the body of a card it is wrapped in a paragraph'

    Get-NinjaOneCard -Title "Tenant Details" -Data $Info
    #>

    [System.Collections.Generic.List[String]]$OutputHTML = @()

    $OutputHTML.add('<div class="card flex-grow-1' + $(if ($classes) { ' ' + $classes }) + '" >')

    if ($Title) {
        $OutputHTML.add('<div class="card-title-box"><div class="card-title" >' + $(if ($Icon) { '<i class="' + $Icon + '"></i>&nbsp;&nbsp;' }) + $Title + '</div>')

        if ($TitleLink) {
            $OutputHTML.add('<div class="card-link-box"><a href="' + $TitleLink + '" target="_blank" class="card-link" ><i class="fas fa-arrow-up-right-from-square" style="color: #337ab7;"></i></a></div>')
        }

        $OutputHTML.add('</div>')
    }

    $OutputHTML.add('<div class="card-body" >')
    $OutputHTML.add('<p class="card-text" >' + $Body + '</p>')
       
    $OutputHTML.add('</div></div>')

    return $OutputHTML -join ''
    
}

function Get-NinjaOneInfoCard($Title, $Data, [string]$Icon, [string]$TitleLink) {
    <#
    $TenantDetailsItems = [PSCustomObject]@{
        'Name' = $Customer.displayName
        'Default Domain' = $Customer.defaultDomainName
        'Tenant ID' = $Customer.customerId
        'Domains' = $customerDomains
        'Admin Users' = ($AdminUsers | ForEach-Object {"$($_.displayname) ($($_.userPrincipalName))"}) -join ', '
        'Creation Date' = $TenantDetails.createdDateTime
    }

    Get-NinjaOneInfoCard -Title "Tenant Details" -Data $TenantDetailsItems
    #>

    [System.Collections.Generic.List[String]]$ItemsHTML = @()

    foreach ($Item in $Data.PSObject.Properties) {
        $ItemsHTML.add('<p ><b >' + $Item.Name + '</b><br />' + $Item.Value + '</p>')
    }

    return Get-NinjaOneCard -Title $Title -Body ($ItemsHTML -join '') -Icon $Icon -TitleLink $TitleLink
       
}

#EndRegion './Public/NinjaOne/NinjaOneHelper.ps1' 249
#Region './Public/NinjaOne/Push-NinjaOneQueue.ps1' -1

function Push-NinjaOneQueue {
    # Input bindings are passed in via param block.
    param($Item)

    # Write out the queue message and metadata to the information log.
    Write-Host "PowerShell NinjaOne queue trigger function processed work item: $($Item.NinjaAction)"

    Switch ($Item.NinjaAction) {
        'StartAutoMapping' { Invoke-NinjaOneOrgMapping }
        'AutoMapTenant' { Invoke-NinjaOneOrgMappingTenant -QueueItem $Item }
        'SyncTenant' { Invoke-NinjaOneTenantSync -QueueItem $Item }
        'SyncTenants' { Invoke-NinjaOneSync }
    }
    return $true
}
#EndRegion './Public/NinjaOne/Push-NinjaOneQueue.ps1' 16
#Region './Public/NinjaOne/Set-NinjaOneFieldMapping.ps1' -1

function Set-NinjaOneFieldMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping,
        $APIName,
        $Request,
        $TriggerMetadata
    )

    $SettingsTable = Get-CIPPTable -TableName NinjaOneSettings
    foreach ($Mapping in $Request.Body.PSObject.Properties) {
        $AddObject = @{
            PartitionKey    = 'NinjaOneFieldMapping'
            RowKey          = "$($mapping.name)"
            IntegrationId   = "$($mapping.value.value)"
            IntegrationName = "$($mapping.value.label)"
        }

        Add-AzDataTableEntity @CIPPMapping -Entity $AddObject -Force
        Write-LogMessage -API $APINAME -headers $Request.Headers -message "Added mapping for $($mapping.name)." -Sev 'Info'
    }
    $Result = [pscustomobject]@{'Results' = 'Successfully edited mapping table.' }

    Return $Result
}
#EndRegion './Public/NinjaOne/Set-NinjaOneFieldMapping.ps1' 26
#Region './Public/NinjaOne/Set-NinjaOneOrgMapping.ps1' -1

function Set-NinjaOneOrgMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping,
        $APIName,
        $Request
    )

    Get-CIPPAzDataTableEntity @CIPPMapping -Filter "PartitionKey eq 'NinjaOneMapping'" | ForEach-Object {
        Remove-AzDataTableEntity -Force @CIPPMapping -Entity $_
    }
    foreach ($Mapping in $Request.Body) {
        if ($Mapping.TenantId) {
            $AddObject = @{
                PartitionKey    = 'NinjaOneMapping'
                RowKey          = "$($mapping.TenantId)"
                IntegrationId   = "$($mapping.IntegrationId)"
                IntegrationName = "$($mapping.IntegrationName)"
            }
        }
        Add-CIPPAzDataTableEntity @CIPPMapping -Entity $AddObject -Force
        Write-LogMessage -API $APINAME -headers $Request.Headers -message "Added mapping for $($mapping.name)." -Sev 'Info'
    }
    $Result = [pscustomobject]@{'Results' = 'Successfully edited mapping table.' }

    Return $Result
}
#EndRegion './Public/NinjaOne/Set-NinjaOneOrgMapping.ps1' 28
#Region './Public/PwPush/Get-PwPushAccount.ps1' -1

function Get-PwPushAccount {
    $Table = Get-CIPPTable -TableName Extensionsconfig
    $ParsedConfig = (Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json -ErrorAction SilentlyContinue
    $Configuration = $ParsedConfig.PWPush
    if ($Configuration.Enabled -eq $true -and $Configuration.UseBearerAuth -eq $true) {
        Set-PwPushConfig -Configuration $Configuration -FullConfiguration $ParsedConfig
        Get-PushAccount
    } else {
        return @(@{
                name = 'PWPush Pro is not enabled or configured. Make sure to save the configuration first.';
                id   = ''
            })
    }
}
#EndRegion './Public/PwPush/Get-PwPushAccount.ps1' 15
#Region './Public/PwPush/New-PwPushLink.ps1' -1

function New-PwPushLink {
    [CmdletBinding(SupportsShouldProcess)]
    Param(
        $Payload
    )

    try {
        $Table = Get-CIPPTable -TableName Extensionsconfig
        $ConfigEntity = Get-CIPPAzDataTableEntity @Table

        # Check if the config entity exists and has a config property
        if (-not $ConfigEntity -or [string]::IsNullOrEmpty($ConfigEntity.config)) {
            return $false
        }

        # Safely parse the JSON configuration
        try {
            $ParsedConfig = $ConfigEntity.config | ConvertFrom-Json -ErrorAction Stop
            $Configuration = $ParsedConfig.PWPush
        } catch {
            return $false
        }

        # Check if PWPush section exists in configuration
        if (-not $Configuration) {
            return $false
        }

        # Check if PwPush is enabled
        if ($Configuration.Enabled -ne $true) {
            return $false
        }

        # Proceed with creating the PwPush link
        try {
            Set-PwPushConfig -Configuration $Configuration -FullConfiguration $ParsedConfig
            $PushParams = @{
                Payload = $Payload
            }
            if ($Configuration.ExpireAfterDays) { $PushParams.ExpireAfterDays = $Configuration.ExpireAfterDays }
            if ($Configuration.ExpireAfterViews) { $PushParams.ExpireAfterViews = $Configuration.ExpireAfterViews }
            if ($Configuration.DeletableByViewer) { $PushParams.DeletableByViewer = $Configuration.DeletableByViewer }
            if ($Configuration.AccountId) { $PushParams.AccountId = $Configuration.AccountId.value }
            if (![string]::IsNullOrEmpty($Configuration.DefaultPassphrase)) { $PushParams.Passphrase = $Configuration.DefaultPassphrase }

            if ($PSCmdlet.ShouldProcess('Create a new PwPush link')) {
                $Link = New-Push @PushParams
                if ($Configuration.RetrievalStep) {
                    return $Link.LinkRetrievalStep -replace '/r/r', '/r'
                }
                return $Link.Link
            }
        } catch {
            $LogData = [PSCustomObject]@{
                'Response'  = if ($Link) { $Link } else { 'No response' }
                'Exception' = Get-CippException -Exception $_
            }
            Write-LogMessage -API PwPush -Message "Failed to create a new PwPush link: $($_.Exception.Message)" -Sev 'Error' -LogData $LogData
            Write-LogMessage -API PwPush -Message "Continuing without PwPush link due to error" -sev 'Warning'
            return $false
        }
    } catch {
        Write-LogMessage -API PwPush -Message "Unexpected error in PwPush configuration handling: $($_.Exception.Message)" -Sev 'Error'
        return $false
    }
}
#EndRegion './Public/PwPush/New-PwPushLink.ps1' 67
#Region './Public/PwPush/Set-PwPushConfig.ps1' -1

function Set-PwPushConfig {
    <#
    .SYNOPSIS
    Sets PwPush configuration

    .DESCRIPTION
    Sets PwPush configuration from CIPP Extension config

    .PARAMETER Configuration
    Configuration object

    .PARAMETER FullConfiguration
    Full parsed configuration object including CFZTNA settings
    #>
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        $Configuration,
        $FullConfiguration
    )
    $InitParams = @{}
    if ($Configuration.BaseUrl) {
        $InitParams.BaseUrl = $Configuration.BaseUrl
    }
    if (![string]::IsNullOrEmpty($Configuration.EmailAddress) -or $Configuration.UseBearerAuth -eq $true) {
        $ApiKey = Get-ExtensionAPIKey -Extension 'PWPush'
        if ($Configuration.UseBearerAuth -eq $true) {
            $InitParams.Bearer = $ApiKey
        } elseif (![string]::IsNullOrEmpty($ApiKey)) {
            if (![string]::IsNullOrEmpty($Configuration.EmailAddress)) {
                $InitParams.EmailAddress = $Configuration.EmailAddress
            }
            $InitParams.APIKey = $ApiKey
        }
    }

    $Module = Get-Module PassPushPosh -ListAvailable
    Write-Information "PWPush Version: $($Module.Version)"
    if ($PSCmdlet.ShouldProcess('Initialize-PassPushPosh')) {
        Write-Information ($InitParams | ConvertTo-Json)
        Initialize-PassPushPosh @InitParams
    }

    if ($Configuration.CFEnabled -eq $true -and $FullConfiguration.CFZTNA.Enabled -eq $true) {
        $CFAPIKey = Get-ExtensionAPIKey -Extension 'CFZTNA'
        $PPPModule = Get-Module PassPushPosh
        & $PPPModule {
            if (-not $Script:PPPHeaders) {
                $Script:PPPHeaders = @{}
            }
            $Script:PPPHeaders['CF-Access-Client-Id'] = $args[0]
            $Script:PPPHeaders['CF-Access-Client-Secret'] = $args[1]
        } $FullConfiguration.CFZTNA.ClientId "$CFAPIKey"
        Write-Information 'CF-Access-Client-Id and CF-Access-Client-Secret headers added to PWPush API request'
    }
}

#EndRegion './Public/PwPush/Set-PwPushConfig.ps1' 57
#Region './Public/Sherweb/Get-SherwebAuthentication.ps1' -1

function Get-SherwebAuthentication {
    $Table = Get-CIPPTable -TableName Extensionsconfig
    $Config = ((Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json).Sherweb
    $APIKey = Get-ExtensionAPIKey -Extension 'Sherweb'

    $AuthBody = @{
        client_id     = $Config.clientId
        client_secret = $APIKey
        scope         = 'service-provider'
        grant_type    = 'client_credentials'
    }

    $Token = (Invoke-RestMethod -Uri 'https://api.sherweb.com/auth/oidc/connect/token' -Method POST -Body $AuthBody).access_token
    $authHeader = @{
        Authorization               = "Bearer $Token"
        'Ocp-Apim-Subscription-Key' = $Config.SubscriptionKey
    }

    return $authHeader
}
#EndRegion './Public/Sherweb/Get-SherwebAuthentication.ps1' 21
#Region './Public/Sherweb/Get-SherwebCatalog.ps1' -1

function Get-SherwebCatalog {
    param(
        [Parameter(Mandatory = $false)]
        [string]$CustomerId,
        [string]$TenantFilter
    )

    if ($TenantFilter) {
        $TenantFilter = (Get-Tenants -TenantFilter $TenantFilter).customerId
        $CustomerId = Get-ExtensionMapping -Extension 'Sherweb' | Where-Object { $_.RowKey -eq $TenantFilter } | Select-Object -ExpandProperty IntegrationId
    }

    if (![string]::IsNullOrEmpty($CustomerId)) {
        Write-Information "Getting catalog for $CustomerId"
        $AuthHeader = Get-SherwebAuthentication
        $SubscriptionsList = Invoke-RestMethod -Uri "https://api.sherweb.com/service-provider/v1/customer-catalogs/$CustomerId" -Method GET -Headers $AuthHeader
        return $SubscriptionsList.catalogItems
    } else {
        throw 'No Sherweb mapping found'
    }
}
#EndRegion './Public/Sherweb/Get-SherwebCatalog.ps1' 22
#Region './Public/Sherweb/Get-SherwebCurrentSubscription.ps1' -1

function Get-SherwebCurrentSubscription {
    param(
        [Parameter(Mandatory = $false)]
        [string]$TenantFilter,
        [string]$CustomerId,
        [string]$SKU,
        [string]$ProductName
    )
    if ($TenantFilter) {
        $TenantFilter = (Get-Tenants -TenantFilter $TenantFilter).customerId
        $CustomerId = Get-ExtensionMapping -Extension 'Sherweb' | Where-Object { $_.RowKey -eq $TenantFilter } | Select-Object -ExpandProperty IntegrationId
    }

    Write-Information "Getting current subscription for $CustomerId"
    $AuthHeader = Get-SherwebAuthentication
    $Uri = "https://api.sherweb.com/service-provider/v1/billing/subscriptions/details?customerId=$CustomerId"
    $SubscriptionDetails = Invoke-RestMethod -Uri $Uri -Method GET -Headers $AuthHeader

    $AllSubscriptions = $SubscriptionDetails.items

    if ($SKU) {
        return $AllSubscriptions | Where-Object { $_.sku -eq $SKU }
    } elseif ($ProductName) {
        return $AllSubscriptions | Where-Object { $_.productName -eq $ProductName }
    } else {
        return $AllSubscriptions
    }
}
#EndRegion './Public/Sherweb/Get-SherwebCurrentSubscription.ps1' 29
#Region './Public/Sherweb/Get-SherwebCustomerConfiguration.ps1' -1

function Get-SherwebCustomerConfiguration {
    param(
        [Parameter(Mandatory = $true)]
        [string]$CustomerId,
        [string]$TenantFilter
    )
    if ($TenantFilter) {
        $TenantFilter = (Get-Tenants -TenantFilter $TenantFilter).customerId
        $CustomerId = Get-ExtensionMapping -Extension 'Sherweb' | Where-Object { $_.RowKey -eq $TenantFilter } | Select-Object -ExpandProperty IntegrationId
    }
    $AuthHeader = Get-SherwebAuthentication
    $Uri = "https://api.sherweb.com/service-provider/v1/customers/$($CustomerId)/platforms-configurations/"
    $CustomerConfig = Invoke-RestMethod -Uri $Uri -Method GET -Headers $AuthHeader
    $customerPlatforms = foreach ($Config in $CustomerConfig.configuredPlatforms) {
        #https://api.sherweb.com/service-provider/v1/customers/{customerId}/platforms/{platformId}/details
        $Uri = "https://api.sherweb.com/service-provider/v1/customers/$($CustomerId)/platforms/$($Config.id)/details"
        Invoke-RestMethod -Uri $Uri -Method GET -Headers $AuthHeader
    }
    return $customerPlatforms

}
#EndRegion './Public/Sherweb/Get-SherwebCustomerConfiguration.ps1' 22
#Region './Public/Sherweb/Get-SherwebCustomers.ps1' -1

function Get-SherwebCustomers {
    $AuthHeader = Get-SherwebAuthentication
    $CustomersList = Invoke-RestMethod -Uri 'https://api.sherweb.com/service-provider/v1/customers' -Method GET -Headers $AuthHeader
    return $CustomersList.items
}
#EndRegion './Public/Sherweb/Get-SherwebCustomers.ps1' 6
#Region './Public/Sherweb/Get-SherwebMapping.ps1' -1

function Get-SherwebMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping
    )

    $ExtensionMappings = Get-ExtensionMapping -Extension 'Sherweb'

    $Tenants = Get-Tenants -IncludeErrors
    $Mappings = foreach ($Mapping in $ExtensionMappings) {
        $Tenant = $Tenants | Where-Object { $_.customerId -eq $Mapping.RowKey }
        if ($Tenant) {
            [PSCustomObject]@{
                TenantId        = $Tenant.customerId
                Tenant          = $Tenant.displayName
                TenantDomain    = $Tenant.defaultDomainName
                IntegrationId   = $Mapping.IntegrationId
                IntegrationName = $Mapping.IntegrationName
            }
        }
    }
    try {
        $SherwebCustomers = Get-SherwebCustomers | ForEach-Object {
            [PSCustomObject]@{
                name  = $_.displayName
                value = "$($_.id)"
            }
        }
    } catch {
        $Message = if ($_.ErrorDetails.Message) {
            Get-NormalizedError -Message $_.ErrorDetails.Message
        } else {
            $_.Exception.message
        }

        Write-LogMessage -Message "Could not get Sherweb Companies, error: $Message " -Level Error -tenant 'CIPP' -API 'SherwebMapping'
        $SherwebCustomers = @(@{name = "Could not get Sherweb Companies, error: $Message"; value = '-1' })
    }

    $MappingObj = [PSCustomObject]@{
        Companies = @($SherwebCustomers)
        Mappings  = @($Mappings)
    }

    return $MappingObj

}
#EndRegion './Public/Sherweb/Get-SherwebMapping.ps1' 48
#Region './Public/Sherweb/Get-SherwebOrderStatus.ps1' -1

function Get-SherwebOrderStatus {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RequestTrackingId
    )
    $AuthHeader = Get-SherwebAuthentication
    $Uri = "https://api.sherweb.com/service-provider/v1/tracking/$RequestTrackingId"
    $Tracking = Invoke-RestMethod -Uri $Uri -Method GET -Headers $AuthHeader
    return $Tracking
}
#EndRegion './Public/Sherweb/Get-SherwebOrderStatus.ps1' 11
#Region './Public/Sherweb/Remove-SherwebSubscription.ps1' -1

function Remove-SherwebSubscription {
    param(
        [Parameter(Mandatory = $false)]
        [string]$CustomerId,
        [Parameter(Mandatory = $true)]
        [string[]]$SubscriptionIds,
        [string]$TenantFilter,
        $Headers
    )

    if ($Headers) {
        # Get extension config and check for AllowedCustomRoles
        $Table = Get-CIPPTable -TableName Extensionsconfig
        $ExtensionConfig = (Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json
        $Config = $ExtensionConfig.Sherweb

        $AllowedRoles = $Config.AllowedCustomRoles.value
        if ($AllowedRoles -and $Headers.'x-ms-client-principal') {
            $UserRoles = Get-CIPPAccessRole -Headers $Headers
            $Allowed = $false
            foreach ($Role in $UserRoles) {
                if ($AllowedRoles -contains $Role) {
                    Write-Information "User has allowed CIPP role: $Role"
                    $Allowed = $true
                    break
                }
            }
            if (-not $Allowed) {
                throw 'This user is not allowed to modify Sherweb Licenses.'
            }
        }
    }


    if ($TenantFilter) {
        $TenantFilter = (Get-Tenants -TenantFilter $TenantFilter).customerId
        $CustomerId = Get-ExtensionMapping -Extension 'Sherweb' | Where-Object { $_.RowKey -eq $TenantFilter } | Select-Object -ExpandProperty IntegrationId
    }
    $AuthHeader = Get-SherwebAuthentication
    $Body = ConvertTo-Json -Depth 10 -InputObject @{
        subscriptionIds = @($SubscriptionIds)
    }

    $Uri = "https://api.sherweb.com/service-provider/v1/billing/subscriptions/cancellations?customerId=$CustomerId"
    $Cancel = Invoke-RestMethod -Uri $Uri -Method POST -Headers $AuthHeader -Body $Body -ContentType 'application/json'
    return $Cancel
}
#EndRegion './Public/Sherweb/Remove-SherwebSubscription.ps1' 48
#Region './Public/Sherweb/Set-SherwebMapping.ps1' -1

function Set-SherwebMapping {
    [CmdletBinding()]
    param (
        $CIPPMapping,
        $APIName,
        $Request
    )
    Get-CIPPAzDataTableEntity @CIPPMapping -Filter "PartitionKey eq 'SherwebMapping'" | ForEach-Object {
        Remove-AzDataTableEntity -Force @CIPPMapping -Entity $_
    }
    foreach ($Mapping in $Request.Body) {
        Write-Host "Adding mapping for $($mapping.IntegrationId)"
        $AddObject = @{
            PartitionKey    = 'SherwebMapping'
            RowKey          = "$($mapping.TenantId)"
            IntegrationId   = "$($mapping.IntegrationId)"
            IntegrationName = "$($mapping.IntegrationName)"
        }

        Add-CIPPAzDataTableEntity @CIPPMapping -Entity $AddObject -Force
        Write-LogMessage -API $APINAME -headers $Request.Headers -message "Added mapping for $($mapping.name)." -Sev 'Info'
    }
    $Result = [pscustomobject]@{'Results' = 'Successfully edited mapping table.' }

    Return $Result
}
#EndRegion './Public/Sherweb/Set-SherwebMapping.ps1' 27
#Region './Public/Sherweb/Set-SherwebSubscription.ps1' -1

function Set-SherwebSubscription {
    param(
        [Parameter(Mandatory = $false)]
        [string]$CustomerId,
        [Parameter(Mandatory = $true)]
        [string]$SKU,
        [int]$Quantity,
        [int]$Add,
        [int]$Remove,
        [string]$TenantFilter,
        $Headers
    )

    if ($Headers) {
        # Get extension config and check for AllowedCustomRoles
        $Table = Get-CIPPTable -TableName Extensionsconfig
        $ExtensionConfig = (Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json
        $Config = $ExtensionConfig.Sherweb

        $AllowedRoles = $Config.AllowedCustomRoles.value
        if ($AllowedRoles -and $Headers.'x-ms-client-principal') {
            $UserRoles = Get-CIPPAccessRole -Headers $Headers
            $Allowed = $false
            foreach ($Role in $UserRoles) {
                if ($AllowedRoles -contains $Role) {
                    Write-Information "User has allowed CIPP role: $Role"
                    $Allowed = $true
                    break
                }
            }
            if (-not $Allowed) {
                throw 'This user is not allowed to modify Sherweb subscriptions.'
            }
        }
    }

    if ($TenantFilter) {
        $TenantFilter = (Get-Tenants -TenantFilter $TenantFilter).customerId
        $CustomerId = Get-ExtensionMapping -Extension 'Sherweb' | Where-Object { $_.RowKey -eq $TenantFilter } | Select-Object -ExpandProperty IntegrationId
    }
    $AuthHeader = Get-SherwebAuthentication
    $ExistingSubscription = Get-SherwebCurrentSubscription -CustomerId $CustomerId -SKU $SKU

    if (-not $ExistingSubscription) {
        if ($Add -or $Remove) {
            throw "Unable to Add or Remove. No existing subscription with SKU '$SKU' found."
        }

        if (-not $Quantity -or $Quantity -le 0) {
            throw 'A valid Quantity must be specified to create a new subscription when none currently exists.'
        }
        $OrderBody = ConvertTo-Json -Depth 10 -InputObject @{
            cartItems = @(
                @{
                    sku      = $SKU
                    quantity = $Quantity
                }
            )
            orderedBy = 'CIPP-API'
        }
        $OrderUri = "https://api.sherweb.com/service-provider/v1/orders?customerId=$CustomerId"
        $Order = Invoke-RestMethod -Uri $OrderUri -Method POST -Headers $AuthHeader -Body $OrderBody -ContentType 'application/json'
        if ($Order -match 'Internal Server Error' -and $Add -gt 0) {
            throw 'An error occurred while attempting to create a new subscription. Please check the Cumulus portal to ensure this customer has been provisioned for Microsoft 365.'
        }
        return $Order

    } else {
        $SubscriptionId = $ExistingSubscription[0].id
        $CurrentQuantity = $ExistingSubscription[0].quantity

        if ($Add) {
            $FinalQuantity = $CurrentQuantity + $Add
        } elseif ($Remove) {
            $FinalQuantity = $CurrentQuantity - $Remove
            if ($FinalQuantity -lt 0) {
                throw "Cannot remove more licenses than currently allocated. Current: $CurrentQuantity, Attempting to remove: $Remove."
            }
        } else {
            if (-not $Quantity -or $Quantity -le 0) {
                throw 'A valid Quantity must be specified if Add/Remove are not used.'
            }
            $FinalQuantity = $Quantity
        }
        $Body = ConvertTo-Json -Depth 10 -InputObject @{
            subscriptionAmendmentParameters = @(
                @{
                    subscriptionId = $SubscriptionId
                    newQuantity    = $FinalQuantity
                }
            )
        }
        $Uri = "https://api.sherweb.com/service-provider/v1/billing/subscriptions/amendments?customerId=$CustomerId"
        $Update = Invoke-RestMethod -Uri $Uri -Method POST -Headers $AuthHeader -Body $Body -ContentType 'application/json'
        return $Update
    }
}
#EndRegion './Public/Sherweb/Set-SherwebSubscription.ps1' 98
#Region './Public/Sherweb/Test-SherwebMigrationAccounts.ps1' -1

function Test-SherwebMigrationAccounts {
    [CmdletBinding()]
    param (
        $TenantFilter
    )

    $Table = Get-CIPPTable -TableName Extensionsconfig
    $ExtensionConfig = (Get-CIPPAzDataTableEntity @Table).config | ConvertFrom-Json
    $Config = $ExtensionConfig.Sherweb
    #First get a list of all subscribed skus for this tenant, that are in the transfer window.
    $Licenses = (Get-CIPPLicenseOverview -TenantFilter $TenantFilter) | Where-Object { $null -ne $_.terminfo -and $_.terminfo.TransferWindow -le 7 }

    #now check if this exact count of licenses is available at Sherweb, if not, we need to migrate them.
    $SherwebLicenses = Get-SherwebCurrentSubscription -TenantFilter $TenantFilter
    $LicencesToMigrate = foreach ($License in $Licenses) {
        foreach ($termInfo in $License.terminfo) {
            $matchedSherweb = $SherwebLicenses | Where-Object { $_.quantity -eq $termInfo.TotalLicenses -and $_.commitmentTerm.termEndDate -eq $termInfo.NextLifecycle }
            if (-not $matchedSherweb) {
                [PSCustomObject]@{
                    LicenseName                  = ($Licenses | Where-Object { $_.skuId -eq $License.skuId }).license
                    SkuId                        = $License.skuId
                    SubscriptionId               = $termInfo.SubscriptionId
                    Term                         = $termInfo.Term
                    NextLifecycle                = $termInfo.NextLifecycle
                    TotalLicensesAtUnknownCSP    = $termInfo.TotalLicenses
                    TotalLicensesAvailableInM365 = ($Licenses | Where-Object { $_.skuId -eq $License.skuId }).TotalLicenses
                }

            }
        }
    }

    switch -wildcard ($config.migrationMethods) {
        '*notify*' {
            $Subject = "Sherweb Migration: $($TenantFilter) - $($LicencesToMigrate.Count) licenses to migrate"
            $HTMLContent = New-CIPPAlertTemplate -Data $LicencesToMigrate -Format 'html' -InputObject 'sherwebmig'
            $JSONContent = New-CIPPAlertTemplate -Data $LicencesToMigrate -Format 'json' -InputObject 'sherwebmig'
            Send-CIPPAlert -Type 'email' -Title $Subject -HTMLContent $HTMLContent.htmlcontent -TenantFilter $tenant -APIName 'Alerts'
            Send-CIPPAlert -Type 'psa' -Title $Subject -HTMLContent $HTMLContent.htmlcontent -TenantFilter $standardsTenant -APIName 'Alerts'
            Send-CIPPAlert -Type 'webhook' -JSONContent $JSONContent -TenantFilter $Tenant -APIName 'Alerts'
        }
        '*buy*' {
            try {
                $PotentialLicenses = Get-SherwebCatalog -TenantFilter $TenantFilter | Where-Object { $_.microsoftSkuId -in $LicencesToMigrate.SkuId -and $_.sku -like "*$($Config.migrateToLicense)" }
                if (!$PotentialLicenses) {
                    throw 'cannot buy new license: no matching license found in catalog'
                } else {
                    $PotentialLicenses | ForEach-Object {
                        Set-SherwebSubscription -TenantFilter $TenantFilter -SKU $PotentialLicenses.sku -Quantity $LicencesToMigrate.TotalLicensesAtUnknownCSP
                    }
                }
            } catch {
                $Subject = "Sherweb Migration: $($TenantFilter) - Failed to buy licenses."
                $HTMLContent = New-CIPPAlertTemplate -Data $LicencesToMigrate -Format 'html' -InputObject 'sherwebmigBuyFail'
                $JSONContent = New-CIPPAlertTemplate -Data $LicencesToMigrate -Format 'json' -InputObject 'sherwebmigBuyFail'
                Send-CIPPAlert -Type 'email' -Title $Subject -HTMLContent $HTMLContent.htmlcontent -TenantFilter $tenant -APIName 'Alerts'
                Send-CIPPAlert -Type 'psa' -Title $Subject -HTMLContent $HTMLContent.htmlcontent -TenantFilter $standardsTenant -APIName 'Alerts'
                Send-CIPPAlert -Type 'webhook' -JSONContent $JSONContent -TenantFilter $Tenant -APIName 'Alerts'
            }

        }
        '*Cancel' {
            try {
                $tenantid = (Get-Tenants -TenantFilter $TenantFilter).customerId
                $Pax8Config = $ExtensionConfig.Pax8
                $Pax8ClientId = $Pax8Config.clientId
                $Pax8ClientSecret = Get-ExtensionAPIKey -Extension 'Pax8'
                $paxBody = @{
                    client_id     = $Pax8ClientId
                    client_secret = $Pax8ClientSecret
                    audience      = 'https://api.pax8.com'
                    grant_type    = 'client_credentials'
                }
                $Token = Invoke-RestMethod -Uri 'https://api.pax8.com/v1/token' -Method POST -Headers $headers -ContentType 'application/json' -Body $paxBody
                $headers = @{ Authorization = "Bearer $($Token.access_token)" }
                $cancelSubList = Invoke-RestMethod -Uri "https://api.pax8.com/v1/subscriptions?page=0&size=10&status=Active&companyId=$($tenantid)" -Method GET -Headers $headers | Where-Object -Property productId -In $LicencesToMigrate.SkuId
                $cancelSubList | ForEach-Object {
                    $response = Invoke-RestMethod -Uri "https://api.pax8.com/v1/subscriptions/$($_.subscriptionId)" -Method DELETE -Headers $headers -ContentType 'application/json' -Body ($body | ConvertTo-Json)
                }

            } catch {
                $Subject = 'Sherweb Migration: Pax Migration failed'
                $HTMLContent = New-CIPPAlertTemplate -Data $LicencesToMigrate -Format 'html' -InputObject 'sherwebmigfailpax'
                $JSONContent = New-CIPPAlertTemplate -Data $LicencesToMigrate -Format 'json' -InputObject 'sherwebmigfailpax'
                Send-CIPPAlert -Type 'email' -Title $Subject -HTMLContent $HTMLContent.htmlcontent -TenantFilter $tenant -APIName 'Alerts'
                Send-CIPPAlert -Type 'psa' -Title $Subject -HTMLContent $HTMLContent.htmlcontent -TenantFilter $standardsTenant -APIName 'Alerts'
                Send-CIPPAlert -Type 'webhook' -JSONContent $JSONContent -TenantFilter $Tenant -APIName 'Alerts'
            }
        }

    }
}
#EndRegion './Public/Sherweb/Test-SherwebMigrationAccounts.ps1' 93
