#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO101.ps1' -1

function Invoke-CippTestCISAMSEXO101 {
    <#
    .SYNOPSIS
    Tests MS.EXO.10.1 - Emails SHALL be filtered by attachment file types

    .DESCRIPTION
    Checks if malware filter policies have file filtering enabled

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $MalwarePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoMalwareFilterPolicies'

        if (-not $MalwarePolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoMalwareFilterPolicies cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Emails SHALL be filtered by attachment file types' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO101' -TenantFilter $Tenant
            return
        }

        $FailedPolicies = $MalwarePolicies | Where-Object { -not $_.EnableFileFilter }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: All $($MalwarePolicies.Count) malware filter policy/policies have file filtering enabled."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) of $($MalwarePolicies.Count) malware filter policy/policies do not have file filtering enabled:`n`n"
            $Result += "| Policy Name | File Filter Enabled |`n"
            $Result += "| :---------- | :------------------ |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Name) | $($Policy.EnableFileFilter) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO101' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Emails SHALL be filtered by attachment file types' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Emails SHALL be filtered by attachment file types' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO101' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO101.ps1' 48
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO102.ps1' -1

function Invoke-CippTestCISAMSEXO102 {
    <#
    .SYNOPSIS
    Tests MS.EXO.10.2 - Emails identified as malware SHALL be quarantined or dropped

    .DESCRIPTION
    Checks if malware filter policies quarantine or delete emails with malware

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $MalwarePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoMalwareFilterPolicies'

        if (-not $MalwarePolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoMalwareFilterPolicies cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Emails identified as malware SHALL be quarantined or dropped' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO102' -TenantFilter $Tenant
            return
        }

        $AcceptableActions = @('DeleteMessage', 'Quarantine')
        $FailedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $MalwarePolicies) {
            if ($Policy.Action -notin $AcceptableActions) {
                $FailedPolicies.Add([PSCustomObject]@{
                    'Policy Name' = $Policy.Name
                    'Current Action' = $Policy.Action
                    'Expected' = 'DeleteMessage or Quarantine'
                })
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: All $($MalwarePolicies.Count) malware filter policy/policies quarantine or delete emails with malware."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) of $($MalwarePolicies.Count) malware filter policy/policies do not quarantine or delete malware:`n`n"
            $Result += "| Policy Name | Current Action | Expected |`n"
            $Result += "| :---------- | :------------- | :------- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.'Policy Name') | $($Policy.'Current Action') | $($Policy.Expected) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO102' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Emails identified as malware SHALL be quarantined or dropped' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Emails identified as malware SHALL be quarantined or dropped' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO102' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO102.ps1' 59
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO103.ps1' -1

function Invoke-CippTestCISAMSEXO103 {
    <#
    .SYNOPSIS
    Tests MS.EXO.10.3 - Email scanning SHALL be capable of reviewing emails after delivery (ZAP)

    .DESCRIPTION
    Checks if Zero-hour Auto Purge (ZAP) is enabled for malware protection

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $MalwarePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoMalwareFilterPolicies'

        if (-not $MalwarePolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoMalwareFilterPolicies cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Email scanning SHALL be capable of reviewing emails after delivery' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO103' -TenantFilter $Tenant
            return
        }

        $FailedPolicies = $MalwarePolicies | Where-Object { -not $_.ZapEnabled }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: All $($MalwarePolicies.Count) malware filter policy/policies have ZAP (Zero-hour Auto Purge) enabled."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) of $($MalwarePolicies.Count) malware filter policy/policies do not have ZAP enabled:`n`n"
            $Result += "| Policy Name | ZAP Enabled |`n"
            $Result += "| :---------- | :---------- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Name) | $($Policy.ZapEnabled) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO103' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Email scanning SHALL be capable of reviewing emails after delivery' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Email scanning SHALL be capable of reviewing emails after delivery' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO103' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO103.ps1' 48
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO11.ps1' -1

function Invoke-CippTestCISAMSEXO11 {
    <#
    .SYNOPSIS
    Tests MS.EXO.1.1 - Automatic forwarding to external domains SHALL be disabled

    .DESCRIPTION
    Checks if automatic forwarding to external domains is disabled across all remote domains

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $RemoteDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoRemoteDomain'

        if (-not $RemoteDomains) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoRemoteDomain cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Automatic forwarding to external domains SHALL be disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO11' -TestType 'Identity' -TenantFilter $Tenant
            return
        }

        $ForwardingEnabledDomains = $RemoteDomains | Where-Object { $_.AutoForwardEnabled -eq $true }

        if (($ForwardingEnabledDomains | Measure-Object).Count -eq 0) {
            $Result = '✅ **Pass**: Automatic forwarding to external domains is disabled for all remote domains.'
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($ForwardingEnabledDomains.Count) domain(s) have automatic forwarding enabled:`n`n"
            $Result += "| Domain Name | Auto Forward |`n"
            $Result += "| :---------- | :----------- |`n"
            foreach ($Domain in $ForwardingEnabledDomains) {
                $Result += "| $($Domain.DomainName) | $($Domain.AutoForwardEnabled) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO11' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Automatic forwarding to external domains SHALL be disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Automatic forwarding to external domains SHALL be disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO11' -TestType 'Identity' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO11.ps1' 48
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO111.ps1' -1

function Invoke-CippTestCISAMSEXO111 {
    <#
    .SYNOPSIS
    Tests MS.EXO.11.1 - Impersonation protection checks SHOULD be used

    .DESCRIPTION
    Checks if both standard and strict EOP/ATP preset security policies are enabled

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $PresetPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoPresetSecurityPolicy'

        if (-not $PresetPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoPresetSecurityPolicy cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Impersonation protection checks SHOULD be used' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Email Protection' -TestId 'CISAMSEXO111' -TenantFilter $Tenant
            return
        }

        $StandardEOP = $PresetPolicies | Where-Object { $_.Identity -eq 'Standard Preset Security Policy' -and $_.State -eq 'Enabled' }
        $StrictEOP = $PresetPolicies | Where-Object { $_.Identity -eq 'Strict Preset Security Policy' -and $_.State -eq 'Enabled' }

        $StandardATP = $PresetPolicies | Where-Object { $_.Identity -like '*Preset Security Policy*' -and $_.ImpersonationProtectionState -eq 'Enabled' }

        $EnabledPolicies = @()
        if ($StandardEOP) { $EnabledPolicies += 'Standard EOP' }
        if ($StrictEOP) { $EnabledPolicies += 'Strict EOP' }
        if ($StandardATP) { $EnabledPolicies += "$($StandardATP.Count) ATP policy/policies with impersonation protection" }

        if ($EnabledPolicies.Count -gt 0) {
            $Result = "✅ **Pass**: Preset security policies with impersonation protection are enabled:`n`n"
            $Result += ($EnabledPolicies | ForEach-Object { "- $_" }) -join "`n"
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: No preset security policies with impersonation protection enabled.`n`n"
            $Result += "Enable Standard or Strict preset security policies to provide impersonation protection."
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO111' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Impersonation protection checks SHOULD be used' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Impersonation protection checks SHOULD be used' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Email Protection' -TestId 'CISAMSEXO111' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO111.ps1' 53
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO112.ps1' -1

function Invoke-CippTestCISAMSEXO112 {
    <#
    .SYNOPSIS
    Tests MS.EXO.11.2 - User warnings, comparable to the user safety tips included with EOP, SHOULD be displayed

    .DESCRIPTION
    Checks if impersonation safety tips are enabled in preset security policies

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $PresetPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoPresetSecurityPolicy'

        if (-not $PresetPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoPresetSecurityPolicy cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'User warnings comparable to EOP safety tips SHOULD be displayed' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Email Protection' -TestId 'CISAMSEXO112' -TenantFilter $Tenant
            return
        }

        $PoliciesWithTips = $PresetPolicies | Where-Object {
            ($_.EnableSimilarUsersSafetyTips -eq $true) -or
            ($_.EnableSimilarDomainsSafetyTips -eq $true) -or
            ($_.EnableUnusualCharactersSafetyTips -eq $true)
        }

        if ($PoliciesWithTips.Count -gt 0) {
            $Result = "✅ **Pass**: $($PoliciesWithTips.Count) policy/policies have impersonation safety tips enabled:`n`n"
            $Result += "| Policy | Similar Users Tips | Similar Domains Tips | Unusual Characters Tips |`n"
            $Result += "| :----- | :----------------- | :------------------- | :---------------------- |`n"
            foreach ($Policy in $PoliciesWithTips) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableSimilarUsersSafetyTips) | $($Policy.EnableSimilarDomainsSafetyTips) | $($Policy.EnableUnusualCharactersSafetyTips) |`n"
            }
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: No policies found with impersonation safety tips enabled.`n`n"
            $Result += "Enable safety tips in preset security policies to warn users about potential impersonation."
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO112' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'User warnings comparable to EOP safety tips SHOULD be displayed' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'User warnings comparable to EOP safety tips SHOULD be displayed' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Email Protection' -TestId 'CISAMSEXO112' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO112.ps1' 53
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO113.ps1' -1

function Invoke-CippTestCISAMSEXO113 {
    <#
    .SYNOPSIS
    Tests MS.EXO.11.3 - Mailbox intelligence SHALL be enabled

    .DESCRIPTION
    Checks if mailbox intelligence and impersonation protection are enabled in preset security policies

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $PresetPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoPresetSecurityPolicy'

        if (-not $PresetPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoPresetSecurityPolicy cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Mailbox intelligence SHALL be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO113' -TenantFilter $Tenant
            return
        }

        $PoliciesWithIntelligence = $PresetPolicies | Where-Object {
            ($_.EnableMailboxIntelligence -eq $true) -and
            ($_.EnableMailboxIntelligenceProtection -eq $true)
        }

        if ($PoliciesWithIntelligence.Count -gt 0) {
            $Result = "✅ **Pass**: $($PoliciesWithIntelligence.Count) policy/policies have mailbox intelligence enabled:`n`n"
            $Result += "| Policy | Mailbox Intelligence | Intelligence Protection | State |`n"
            $Result += "| :----- | :------------------- | :---------------------- | :---- |`n"
            foreach ($Policy in $PoliciesWithIntelligence) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableMailboxIntelligence) | $($Policy.EnableMailboxIntelligenceProtection) | $($Policy.State) |`n"
            }
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: No policies found with mailbox intelligence enabled.`n`n"
            $Result += 'Enable mailbox intelligence in preset security policies for AI-powered impersonation protection.'
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO113' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Mailbox intelligence SHALL be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Mailbox intelligence SHALL be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO113' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO113.ps1' 52
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO121.ps1' -1

function Invoke-CippTestCISAMSEXO121 {
    <#
    .SYNOPSIS
    Tests MS.EXO.12.1 - Allowed senders list SHOULD NOT be used

    .DESCRIPTION
    Checks if tenant allow/block list has allowed senders configured

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $AllowBlockList = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoTenantAllowBlockList'

        if ($null -eq $AllowBlockList) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoTenantAllowBlockList cache not found. Please refresh the cache for this tenant.' -Risk 'Medium' -Name 'Allowed sender lists SHOULD NOT be used' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO121' -TenantFilter $Tenant
            return
        }

        $AllowedSenders = $AllowBlockList | Where-Object { $_.Action -eq 'Allow' -and $_.ListType -eq 'Sender' }

        if ($AllowedSenders.Count -eq 0) {
            $Result = '✅ **Pass**: No allowed senders configured in tenant allow/block list.'
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($AllowedSenders.Count) allowed sender(s) configured in tenant allow/block list"
            if ($AllowedSenders.Count -gt 10) {
                $Result += ' (showing first 10)'
            }
            $Result += ":`n`n"
            $Result += "| Value | Action | List Type |`n"
            $Result += "| :---- | :----- | :-------- |`n"
            foreach ($Sender in ($AllowedSenders | Select-Object -First 10)) {
                $Result += "| $($Sender.Value) | $($Sender.Action) | $($Sender.ListType) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO121' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Allowed sender lists SHOULD NOT be used' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Allowed sender lists SHOULD NOT be used' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO121' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO121.ps1' 52
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO122.ps1' -1

function Invoke-CippTestCISAMSEXO122 {
    <#
    .SYNOPSIS
    Tests MS.EXO.12.2 - Safe lists SHOULD NOT be enabled

    .DESCRIPTION
    Checks if anti-spam policies have safe lists disabled

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $SpamPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $SpamPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoHostedContentFilterPolicy cache not found. Please refresh the cache for this tenant.' -Risk 'Medium' -Name 'Safe lists SHOULD NOT be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO122' -TenantFilter $Tenant
            return
        }

        $FailedPolicies = $SpamPolicies | Where-Object { $_.EnableSafeList -eq $true }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: All $($SpamPolicies.Count) anti-spam policy/policies have safe lists disabled."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) of $($SpamPolicies.Count) anti-spam policy/policies have safe lists enabled:`n`n"
            $Result += "| Policy Name | Safe List Enabled |`n"
            $Result += "| :---------- | :---------------- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Name) | $($Policy.EnableSafeList) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO122' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Safe lists SHOULD NOT be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Safe lists SHOULD NOT be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO122' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO122.ps1' 48
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO131.ps1' -1

function Invoke-CippTestCISAMSEXO131 {
    <#
    .SYNOPSIS
    Tests MS.EXO.13.1 - Mailbox auditing SHALL be enabled

    .DESCRIPTION
    Checks if mailbox auditing is enabled in Exchange Online organization config

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $OrgConfig = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoOrganizationConfig'

        if (-not $OrgConfig) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoOrganizationConfig cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Mailbox auditing SHALL be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Audit & Compliance' -TestId 'CISAMSEXO131' -TenantFilter $Tenant
            return
        }

        $OrgConfigObject = $OrgConfig | Select-Object -First 1

        if ($OrgConfigObject.AuditDisabled -eq $false) {
            $Result = '✅ **Pass**: Mailbox auditing is enabled for the organization.'
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: Mailbox auditing is disabled for the organization.`n`n"
            $Result += "**Current Setting:**`n"
            $Result += "- AuditDisabled: $($OrgConfigObject.AuditDisabled)"
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO131' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Mailbox auditing SHALL be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Audit & Compliance'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Mailbox auditing SHALL be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Audit & Compliance' -TestId 'CISAMSEXO131' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO131.ps1' 45
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO141.ps1' -1

function Invoke-CippTestCISAMSEXO141 {
    <#
    .SYNOPSIS
    Tests MS.EXO.14.1 - High confidence spam SHALL be quarantined

    .DESCRIPTION
    Checks if high confidence spam action is set to Quarantine in anti-spam policies

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $SpamPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $SpamPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoHostedContentFilterPolicy cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'High confidence spam SHALL be quarantined' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO141' -TenantFilter $Tenant
            return
        }

        $FailedPolicies = $SpamPolicies | Where-Object { $_.HighConfidenceSpamAction -ne 'Quarantine' }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: All $($SpamPolicies.Count) anti-spam policy/policies quarantine high confidence spam."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) of $($SpamPolicies.Count) anti-spam policy/policies do not quarantine high confidence spam:`n`n"
            $Result += "| Policy Name | Current Action | Expected |`n"
            $Result += "| :---------- | :------------- | :------- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.'Policy Name') | $($Policy.'Current Action') | $($Policy.Expected) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO141' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'High confidence spam SHALL be quarantined' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'High confidence spam SHALL be quarantined' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO141' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO141.ps1' 48
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO142.ps1' -1

function Invoke-CippTestCISAMSEXO142 {
    <#
    .SYNOPSIS
    Tests MS.EXO.14.2 - Spam SHALL be moved to junk email or quarantine

    .DESCRIPTION
    Checks if spam action is set to MoveToJmf or Quarantine in anti-spam policies

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $SpamPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $SpamPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoHostedContentFilterPolicy cache not found. Please refresh the cache for this tenant.' -Risk 'Medium' -Name 'Spam SHALL be moved to junk email or quarantine' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO142' -TenantFilter $Tenant
            return
        }

        $AcceptableActions = @('MoveToJmf', 'Quarantine')
        $FailedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $SpamPolicies) {
            if ($Policy.SpamAction -notin $AcceptableActions) {
                $FailedPolicies.Add([PSCustomObject]@{
                        'Policy Name'    = $Policy.Name
                        'Current Action' = $Policy.SpamAction
                        'Expected'       = 'MoveToJmf or Quarantine'
                    })
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: All $($SpamPolicies.Count) anti-spam policy/policies move spam to junk folder or quarantine."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) of $($SpamPolicies.Count) anti-spam policy/policies do not properly handle spam:`n`n"
            $Result += "| Policy Name | Current Action | Expected |`n"
            $Result += "| :---------- | :------------- | :------- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.'Policy Name') | $($Policy.'Current Action') | $($Policy.Expected) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO142' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Spam SHALL be moved to junk email or quarantine' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Spam SHALL be moved to junk email or quarantine' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO142' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO142.ps1' 59
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO143.ps1' -1

function Invoke-CippTestCISAMSEXO143 {
    <#
    .SYNOPSIS
    Tests MS.EXO.14.3 - Spam filter bypass SHALL be disabled

    .DESCRIPTION
    Checks if anti-spam policies have empty allowed senders and domains lists

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $SpamPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $SpamPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoHostedContentFilterPolicy cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Allowed senders SHOULD NOT be added to anti-spam filter' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO143' -TenantFilter $Tenant
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $SpamPolicies) {
            $AllowedSenders = if ($Policy.AllowedSenders) { $Policy.AllowedSenders.Count } else { 0 }
            $AllowedSenderDomains = if ($Policy.AllowedSenderDomains) { $Policy.AllowedSenderDomains.Count } else { 0 }

            if ($AllowedSenders -gt 0 -or $AllowedSenderDomains -gt 0) {
                $FailedPolicies.Add([PSCustomObject]@{
                        'Policy Name'     = $Policy.Name
                        'Allowed Senders' = $AllowedSenders
                        'Allowed Domains' = $AllowedSenderDomains
                        'Issue'           = 'Has allowed senders/domains that bypass spam filtering'
                    })
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: All $($SpamPolicies.Count) anti-spam policy/policies have no spam filter bypasses configured."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) of $($SpamPolicies.Count) anti-spam policy/policies have spam filter bypasses configured:`n`n"
            $Result += "| Policy Name | Allowed Senders | Allowed Domains | Issue |`n"
            $Result += "| :---------- | :-------------- | :-------------- | :---- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.'Policy Name') | $($Policy.'Allowed Senders') | $($Policy.'Allowed Domains') | $($Policy.Issue) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO143' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Allowed senders SHOULD NOT be added to anti-spam filter' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Allowed senders SHOULD NOT be added to anti-spam filter' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO143' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO143.ps1' 62
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO151.ps1' -1

function Invoke-CippTestCISAMSEXO151 {
    <#
    .SYNOPSIS
    Tests MS.EXO.15.1 - URL comparison with a block-list SHOULD be enabled

    .DESCRIPTION
    Checks if Safe Links policies have URL scanning enabled

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $SafeLinksPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $SafeLinksPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoSafeLinksPolicies cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'URL comparison with block-list SHOULD be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO151' -TenantFilter $Tenant
            return
        }

        $FailedPolicies = $SafeLinksPolicies | Where-Object { -not $_.EnableSafeLinksForEmail }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: All $($SafeLinksPolicies.Count) Safe Links policy/policies have URL comparison with block-list enabled."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) of $($SafeLinksPolicies.Count) Safe Links policy/policies do not have URL scanning enabled:`n`n"
            $Result += "| Policy Name | Safe Links for Email |`n"
            $Result += "| :---------- | :------------------- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Name) | $($Policy.EnableSafeLinksForEmail) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO151' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'URL comparison with block-list SHOULD be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'URL comparison with block-list SHOULD be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO151' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO151.ps1' 48
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO152.ps1' -1

function Invoke-CippTestCISAMSEXO152 {
    <#
    .SYNOPSIS
    Tests MS.EXO.15.2 - Real-time suspicious URL and file-link scanning SHOULD be enabled

    .DESCRIPTION
    Checks if Safe Links policies have real-time link scanning enabled

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $SafeLinksPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $SafeLinksPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoSafeLinksPolicies cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Real-time suspicious URL scanning SHOULD be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO152' -TenantFilter $Tenant
            return
        }

        $FailedPolicies = $SafeLinksPolicies | Where-Object { -not $_.ScanUrls }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: All $($SafeLinksPolicies.Count) Safe Links policy/policies have real-time URL scanning enabled."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) of $($SafeLinksPolicies.Count) Safe Links policy/policies do not have real-time URL scanning enabled:`n`n"
            $Result += "| Policy Name | Scan URLs |`n"
            $Result += "| :---------- | :-------- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Name) | $($Policy.ScanUrls) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO152' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Real-time suspicious URL scanning SHOULD be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Real-time suspicious URL scanning SHOULD be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO152' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO152.ps1' 48
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO153.ps1' -1

function Invoke-CippTestCISAMSEXO153 {
    <#
    .SYNOPSIS
    Tests MS.EXO.15.3 - User click tracking SHOULD be disabled

    .DESCRIPTION
    Checks if Safe Links policies have click tracking disabled for privacy

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $SafeLinksPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $SafeLinksPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoSafeLinksPolicies cache not found. Please refresh the cache for this tenant.' -Risk 'Medium' -Name 'User click tracking SHOULD be disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO153' -TenantFilter $Tenant
            return
        }

        $FailedPolicies = $SafeLinksPolicies | Where-Object { $_.TrackUserClicks -eq $true }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: All $($SafeLinksPolicies.Count) Safe Links policy/policies have click tracking disabled."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) of $($SafeLinksPolicies.Count) Safe Links policy/policies have click tracking enabled:`n`n"
            $Result += "| Policy Name | Track User Clicks |`n"
            $Result += "| :---------- | :---------------- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Name) | $($Policy.TrackUserClicks) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO153' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'User click tracking SHOULD be disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'User click tracking SHOULD be disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO153' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO153.ps1' 48
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO171.ps1' -1

function Invoke-CippTestCISAMSEXO171 {
    <#
    .SYNOPSIS
    Tests MS.EXO.17.1 - Microsoft Purview Audit (Standard) logging SHALL be enabled

    .DESCRIPTION
    Checks if unified audit log ingestion is enabled

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $AuditConfig = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAdminAuditLogConfig'

        if (-not $AuditConfig) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoAdminAuditLogConfig cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Microsoft Purview Audit logging SHALL be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Audit & Compliance' -TestId 'CISAMSEXO171' -TenantFilter $Tenant
            return
        }

        $AuditConfigObject = $AuditConfig | Select-Object -First 1

        if ($AuditConfigObject.UnifiedAuditLogIngestionEnabled -eq $true) {
            $Result = "✅ **Pass**: Microsoft Purview Audit (Standard) logging is enabled.`n`n"
            $Result += "**Current Settings:**`n"
            $Result += "- UnifiedAuditLogIngestionEnabled: $($AuditConfigObject.UnifiedAuditLogIngestionEnabled)"
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: Microsoft Purview Audit (Standard) logging is not enabled.`n`n"
            $Result += "**Current Settings:**`n"
            $Result += "- UnifiedAuditLogIngestionEnabled: $($AuditConfigObject.UnifiedAuditLogIngestionEnabled)"
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO171' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Microsoft Purview Audit logging SHALL be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Audit & Compliance'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Microsoft Purview Audit logging SHALL be enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Audit & Compliance' -TestId 'CISAMSEXO171' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO171.ps1' 47
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO173.ps1' -1

function Invoke-CippTestCISAMSEXO173 {
    <#
    .SYNOPSIS
    Tests MS.EXO.17.3 - Audit logs SHALL be maintained for at least the minimum duration

    .DESCRIPTION
    Checks if admin audit log is enabled (provides 1 year retention)

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $AuditConfig = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAdminAuditLogConfig'

        if (-not $AuditConfig) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoAdminAuditLogConfig cache not found. Please refresh the cache for this tenant.' -Risk 'Medium' -Name 'Audit logs SHALL be maintained for at least 1 year' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Audit & Compliance' -TestId 'CISAMSEXO173' -TenantFilter $Tenant
            return
        }

        $AuditConfigObject = $AuditConfig | Select-Object -First 1

        if ($AuditConfigObject.AdminAuditLogEnabled -eq $true) {
            $Result = "✅ **Pass**: Admin audit log is enabled (provides 1 year retention).`n`n"
            $Result += "**Current Settings:**`n"
            $Result += "- AdminAuditLogEnabled: $($AuditConfigObject.AdminAuditLogEnabled)"
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: Admin audit log is not enabled.`n`n"
            $Result += "**Current Settings:**`n"
            $Result += "- AdminAuditLogEnabled: $($AuditConfigObject.AdminAuditLogEnabled)"
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO173' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Audit logs SHALL be maintained for at least 1 year' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Audit & Compliance'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Audit logs SHALL be maintained for at least 1 year' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Audit & Compliance' -TestId 'CISAMSEXO173' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO173.ps1' 47
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO31.ps1' -1

function Invoke-CippTestCISAMSEXO31 {
    <#
    .SYNOPSIS
    Tests MS.EXO.3.1 - DKIM SHOULD be enabled for all domains

    .DESCRIPTION
    Checks if DKIM (DomainKeys Identified Mail) signing is enabled for all accepted domains

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $DkimConfigs = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoDkimSigningConfig'
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'

        if (-not $DkimConfigs -or -not $AcceptedDomains) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'Required cache (ExoDkimSigningConfig or ExoAcceptedDomains) not found. Please refresh the cache for this tenant.' -Risk 'Medium' -Name 'DKIM SHOULD be enabled for all domains' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Email Authentication' -TestId 'CISAMSEXO31' -TenantFilter $Tenant
            return
        }

        # Filter to non-internal accepted domains
        $SendingDomains = $AcceptedDomains | Where-Object { -not $_.SendingFromDomainDisabled }

        if (($SendingDomains | Measure-Object).Count -eq 0) {
            Add-CippTestResult -Status 'Passed' -ResultMarkdown '✅ **Pass**: No sending domains found to check DKIM configuration.' -Risk 'Medium' -Name 'DKIM SHOULD be enabled for all domains' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Email Authentication' -TestId 'CISAMSEXO31' -TenantFilter $Tenant
            return
        }

        $FailedDomains = [System.Collections.Generic.List[object]]::new()

        foreach ($Domain in $SendingDomains) {
            $DkimConfig = $DkimConfigs | Where-Object { $_.Domain -eq $Domain.DomainName }

            if (-not $DkimConfig -or -not $DkimConfig.Enabled) {
                $FailedDomains.Add([PSCustomObject]@{
                    'Domain' = $Domain.DomainName
                    'DKIM Enabled' = if ($DkimConfig) { $DkimConfig.Enabled } else { 'Not Configured' }
                    'Status' = if (-not $DkimConfig) { 'No DKIM config found' } else { 'DKIM disabled' }
                })
            }
        }

        if ($FailedDomains.Count -eq 0) {
            $Result = "✅ **Pass**: DKIM is enabled for all $($SendingDomains.Count) sending domain(s)."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedDomains.Count) of $($SendingDomains.Count) domain(s) do not have DKIM properly enabled:`n`n"
            $Result += "| Domain | DKIM Enabled | Status |`n"
            $Result += "| :----- | :----------- | :----- |`n"
            foreach ($Domain in $FailedDomains) {
                $Result += "| $($Domain.Domain) | $($Domain.'DKIM Enabled') | $($Domain.Status) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO31' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'DKIM SHOULD be enabled for all domains' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Email Authentication'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'DKIM SHOULD be enabled for all domains' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Email Authentication' -TestId 'CISAMSEXO31' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO31.ps1' 69
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO51.ps1' -1

function Invoke-CippTestCISAMSEXO51 {
    <#
    .SYNOPSIS
    Tests MS.EXO.5.1 - SMTP AUTH SHALL be disabled for all users

    .DESCRIPTION
    Checks if SMTP authentication is disabled in CAS Mailbox settings

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $CASMailboxes = Get-CIPPTestData -TenantFilter $Tenant -Type 'CASMailbox'

        if (-not $CASMailboxes) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'CASMailbox cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'SMTP AUTH SHALL be disabled in Exchange Online' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Email Authentication' -TestId 'CISAMSEXO51' -TenantFilter $Tenant
            return
        }

        $FailedMailboxes = $CASMailboxes | Where-Object { $_.SmtpClientAuthenticationDisabled -eq $false }

        if ($FailedMailboxes.Count -eq 0) {
            $Result = "✅ **Pass**: SMTP authentication is disabled for all $($CASMailboxes.Count) mailbox(es)."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedMailboxes.Count) of $($CASMailboxes.Count) mailbox(es) have SMTP authentication enabled"
            if ($FailedMailboxes.Count -gt 10) {
                $Result += ' (showing first 10)'
            }
            $Result += ":`n`n"
            $Result += "| Display Name | Identity | SMTP Auth Disabled |`n"
            $Result += "| :----------- | :------- | :----------------- |`n"
            foreach ($Mailbox in ($FailedMailboxes | Select-Object -First 10)) {
                $Result += "| $($Mailbox.DisplayName) | $($Mailbox.Identity) | $($Mailbox.SmtpClientAuthenticationDisabled) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO51' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'SMTP AUTH SHALL be disabled in Exchange Online' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Email Authentication'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'SMTP AUTH SHALL be disabled in Exchange Online' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Email Authentication' -TestId 'CISAMSEXO51' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO51.ps1' 52
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO61.ps1' -1

function Invoke-CippTestCISAMSEXO61 {
    <#
    .SYNOPSIS
    Tests MS.EXO.6.1 - Contact folders SHALL NOT be shared with all domains

    .DESCRIPTION
    Checks if sharing policies allow sharing contact folders with external domains

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $SharingPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSharingPolicy'

        if (-not $SharingPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoSharingPolicy cache not found. Please refresh the cache for this tenant.' -Risk 'Medium' -Name 'Contact folders SHALL NOT be shared with all domains' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data Protection' -TestId 'CISAMSEXO61' -TenantFilter $Tenant
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $SharingPolicies) {
            if ($Policy.Enabled) {
                # Check if any domain allows contact sharing (ContactsSharing capability)
                $ContactSharingDomains = $Policy.Domains | Where-Object { $_ -match 'ContactsSharing' }
                if ($ContactSharingDomains) {
                    $FailedPolicies.Add([PSCustomObject]@{
                            'Policy Name' = $Policy.Name
                            'Enabled'     = $Policy.Enabled
                            'Issue'       = 'Allows contact sharing with external domains'
                        })
                }
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Result = '✅ **Pass**: No sharing policies allow contact folder sharing with external domains.'
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) sharing policy/policies allow contact folder sharing:`n`n"
            $Result += "| Policy Name | Enabled | Issue |`n"
            $Result += "| :---------- | :------ | :---- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.'Policy Name') | $($Policy.Enabled) | $($Policy.Issue) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO61' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Contact folders SHALL NOT be shared with all domains' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Contact folders SHALL NOT be shared with all domains' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data Protection' -TestId 'CISAMSEXO61' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO61.ps1' 62
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO62.ps1' -1

function Invoke-CippTestCISAMSEXO62 {
    <#
    .SYNOPSIS
    Tests MS.EXO.6.2 - Calendar details SHALL NOT be shared with all domains

    .DESCRIPTION
    Checks if sharing policies allow sharing calendar details with external domains

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $SharingPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSharingPolicy'

        if (-not $SharingPolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoSharingPolicy cache not found. Please refresh the cache for this tenant.' -Risk 'Medium' -Name 'Calendar details SHALL NOT be shared with all domains' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data Protection' -TestId 'CISAMSEXO62' -TenantFilter $Tenant
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $SharingPolicies) {
            if ($Policy.Enabled) {
                # Check if wildcard domain (*) allows detailed calendar sharing
                $WildcardDomains = $Policy.Domains | Where-Object { $_ -match '^\*:' -and $_ -match 'CalendarSharing(FreeBusyDetail|All)' }
                if ($WildcardDomains) {
                    $FailedPolicies.Add([PSCustomObject]@{
                        'Policy Name' = $Policy.Name
                        'Enabled' = $Policy.Enabled
                        'Issue' = 'Allows detailed calendar sharing with all domains'
                        'Domains' = ($WildcardDomains -join ', ')
                    })
                }
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Result = "✅ **Pass**: No sharing policies allow detailed calendar sharing with all domains."
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) sharing policy/policies allow detailed calendar sharing with all domains:`n`n"
            $Result += "| Policy Name | Enabled | Issue |`n"
            $Result += "| :---------- | :------ | :---- |`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.'Policy Name') | $($Policy.Enabled) | $($Policy.Issue) |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO62' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Calendar details SHALL NOT be shared with all domains' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Calendar details SHALL NOT be shared with all domains' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data Protection' -TestId 'CISAMSEXO62' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO62.ps1' 63
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO71.ps1' -1

function Invoke-CippTestCISAMSEXO71 {
    <#
    .SYNOPSIS
    Tests MS.EXO.7.1 - External sender warnings SHALL be implemented

    .DESCRIPTION
    Checks if external sender warnings are enabled in Exchange Online organization config

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $OrgConfig = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoOrganizationConfig'

        if (-not $OrgConfig) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoOrganizationConfig cache not found. Please refresh the cache for this tenant.' -Risk 'Medium' -Name 'External sender warnings SHALL be implemented' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO71' -TenantFilter $Tenant
            return
        }

        $OrgConfigObject = $OrgConfig | Select-Object -First 1

        if ($OrgConfigObject.ExternalInOutlook -eq $true) {
            $Result = '✅ **Pass**: External sender warnings are enabled in Outlook.'
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: External sender warnings are not enabled in Outlook.`n`n"
            $Result += "**Current Setting:**`n"
            $Result += "- ExternalInOutlook: $($OrgConfigObject.ExternalInOutlook)"
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO71' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'External sender warnings SHALL be implemented' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'External sender warnings SHALL be implemented' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO71' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO71.ps1' 45
#Region './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO95.ps1' -1

function Invoke-CippTestCISAMSEXO95 {
    <#
    .SYNOPSIS
    Tests MS.EXO.9.5 - At a minimum, click-to-run files SHOULD be blocked

    .DESCRIPTION
    Checks if malware filter policies block click-to-run executables (.exe, .cmd, .vbe)

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    try {
        $MalwarePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoMalwareFilterPolicies'

        if (-not $MalwarePolicies) {
            Add-CippTestResult -Status 'Skipped' -ResultMarkdown 'ExoMalwareFilterPolicies cache not found. Please refresh the cache for this tenant.' -Risk 'High' -Name 'Click-to-run files SHOULD be blocked' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO95' -TenantFilter $Tenant
            return
        }

        $RequiredBlockedTypes = @('cmd', 'exe', 'vbe')
        $FailedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $MalwarePolicies) {
            if (-not $Policy.EnableFileFilter) {
                # Policy doesn't have file filtering enabled at all
                $FailedPolicies.Add([PSCustomObject]@{
                        'Policy Name'         = $Policy.Name
                        'File Filter Enabled' = $false
                        'Issue'               = 'File filtering not enabled'
                    })
                continue
            }

            # Check if required types are blocked
            $BlockedTypes = $Policy.FileTypes
            $MissingTypes = $RequiredBlockedTypes | Where-Object { $_ -notin $BlockedTypes }

            if ($MissingTypes) {
                $FailedPolicies.Add([PSCustomObject]@{
                        'Policy Name'           = $Policy.Name
                        'File Filter Enabled'   = $true
                        'Missing Blocked Types' = ($MissingTypes -join ', ')
                    })
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Result = '✅ **Pass**: All malware filter policies block click-to-run files (.exe, .cmd, .vbe).'
            $Status = 'Passed'
        } else {
            $Result = "❌ **Fail**: $($FailedPolicies.Count) malware filter policy/policies do not properly block click-to-run executables:`n`n"
            $Result += "| Policy Name | File Filter Enabled | Missing Blocked Types |`n"
            $Result += "| :---------- | :------------------ | :-------------------- |`n"
            foreach ($Policy in $FailedPolicies) {
                $fileFilterValue = if ($Policy.'File Filter Enabled') { $Policy.'File Filter Enabled' } else { $Policy.'Issue' }
                $missingTypes = if ($Policy.'Missing Blocked Types') { $Policy.'Missing Blocked Types' } else { 'N/A' }
                $Result += "| $($Policy.'Policy Name') | $fileFilterValue | $missingTypes |`n"
            }
            $Status = 'Failed'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CISAMSEXO95' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Click-to-run files SHOULD be blocked' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Email Protection'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Add-CippTestResult -Status 'Failed' -ResultMarkdown "Test execution failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Click-to-run files SHOULD be blocked' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Email Protection' -TestId 'CISAMSEXO95' -TenantFilter $Tenant
    }
}
#EndRegion './Public/Tests/CISA/Identity/Invoke-CippTestCISAMSEXO95.ps1' 75
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady001.ps1' -1

function Invoke-CippTestCopilotReady001 {
    <#
    .SYNOPSIS
    Tenant has at least one Microsoft 365 Copilot prerequisite license
    #>
    param($Tenant)

    # Service plan names that indicate a qualifying Copilot base license.
    # All Microsoft 365 Copilot-eligible plans (E3, E5, Business Basic/Standard/Premium, F1, F3, A1/A3/A5)
    # include Teams (TEAMS1 or MCOSTANDARD). Using service plans avoids dependency on SKU part number
    # values — CIPP's LicenseOverview caches friendly display names, not raw API SKU codes.
    # https://learn.microsoft.com/en-us/copilot/microsoft-365/microsoft-365-copilot-licensing
    $PrerequisiteServicePlans = @('TEAMS1', 'MCOSTANDARD')

    try {
        $LicenseData = Get-CIPPTestData -TenantFilter $Tenant -Type 'LicenseOverview'

        if (-not $LicenseData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady001' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No license data found in database. Data collection may not yet have run for this tenant.' -Risk 'High' -Name 'Tenant has M365 Copilot prerequisite licenses' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        $EligibleSkus = [System.Collections.Generic.List[object]]::new()
        $AssignableCount = 0

        foreach ($Sku in $LicenseData) {
            $HasQualifyingPlan = $Sku.ServicePlans | Where-Object { $_.servicePlanName -in $PrerequisiteServicePlans }
            if ($HasQualifyingPlan -and [int]$Sku.TotalLicenses -gt 0) {
                $EligibleSkus.Add($Sku) | Out-Null
                $AssignableCount += [int]$Sku.TotalLicenses
            }
        }

        if ($EligibleSkus.Count -gt 0) {
            $Status = 'Passed'
            $Result = "Tenant has **$($EligibleSkus.Count)** eligible prerequisite license plan(s) covering **$AssignableCount** seats that qualify for Microsoft 365 Copilot.`n`n"
            $Result += "| License | Total Seats | Assigned |`n"
            $Result += "|---------|------------|---------|`n"
            foreach ($Sku in $EligibleSkus) {
                $Result += "| $($Sku.License) | $($Sku.TotalLicenses) | $($Sku.CountUsed) |`n"
            }
        } else {
            $Status = 'Failed'
            $Result = "No Microsoft 365 Copilot prerequisite licenses were found in this tenant.`n`n"
            $Result += 'Users must have an eligible M365 plan before a Copilot add-on license can be assigned. '
            $Result += 'See [Microsoft licensing requirements](https://learn.microsoft.com/en-us/copilot/microsoft-365/microsoft-365-copilot-licensing) for the full list.'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady001' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Tenant has M365 Copilot prerequisite licenses' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady001: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady001' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Tenant has M365 Copilot prerequisite licenses' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady001.ps1' 57
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady002.ps1' -1

function Invoke-CippTestCopilotReady002 {
    <#
    .SYNOPSIS
    Microsoft 365 Copilot licenses are assigned and available seats remain
    #>
    param($Tenant)

    # Copilot add-on licenses are matched by friendly name (License field) since CIPP's LicenseOverview
    # caches display names rather than raw SKU part numbers. All Copilot add-on SKUs contain 'Copilot'.
    # Service plan anchor: 'COPILOT' is present in all Copilot add-on SKUs.
    $CopilotServicePlan = 'COPILOT'

    try {
        $LicenseData = Get-CIPPTestData -TenantFilter $Tenant -Type 'LicenseOverview'

        if (-not $LicenseData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady002' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No license data found in database. Data collection may not yet have run for this tenant.' -Risk 'High' -Name 'Microsoft 365 Copilot licenses assigned' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $CopilotLicenses = [System.Collections.Generic.List[object]]::new()
        $TotalEnabled = 0
        $TotalConsumed = 0
        $TotalAvailable = 0

        foreach ($Sku in $LicenseData) {
            $IsCopilot = ($Sku.License -match 'Copilot') -or
            ($Sku.ServicePlans | Where-Object { $_.servicePlanName -match $CopilotServicePlan })
            if ($IsCopilot) {
                $CopilotLicenses.Add($Sku) | Out-Null
                $Enabled = [int]$Sku.TotalLicenses
                $Consumed = [int]$Sku.CountUsed
                $TotalEnabled += $Enabled
                $TotalConsumed += $Consumed
                $TotalAvailable += ($Enabled - $Consumed)
            }
        }

        if ($CopilotLicenses.Count -eq 0) {
            $Status = 'Failed'
            $Result = "No Microsoft 365 Copilot add-on licenses were found in this tenant.`n`n"
            $Result += 'Purchase Microsoft 365 Copilot licenses and assign them to eligible users to enable Copilot features.'
        } elseif ($TotalConsumed -eq 0) {
            $Status = 'Failed'
            $Result = "Microsoft 365 Copilot licenses exist (**$TotalEnabled** seats) but **none are assigned** to any users.`n`n"
            $Result += "| License | Total Seats | Assigned | Available |`n"
            $Result += "|---------|------------|----------|-----------|`n"
            foreach ($Sku in $CopilotLicenses) {
                $Available = [int]$Sku.TotalLicenses - [int]$Sku.CountUsed
                $Result += "| $($Sku.License) | $($Sku.TotalLicenses) | $($Sku.CountUsed) | $Available |`n"
            }
        } else {
            $Status = 'Passed'
            $Result = "Microsoft 365 Copilot licenses are purchased and assigned.`n`n"
            $Result += "| License | Total Seats | Assigned | Available |`n"
            $Result += "|---------|------------|----------|-----------|`n"
            foreach ($Sku in $CopilotLicenses) {
                $Available = [int]$Sku.TotalLicenses - [int]$Sku.CountUsed
                $Result += "| $($Sku.License) | $($Sku.TotalLicenses) | $($Sku.CountUsed) | $Available |`n"
            }
            if ($TotalAvailable -gt 0) {
                $Result += "`n**$TotalAvailable unassigned seat(s)** are available to assign to additional users."
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady002' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Microsoft 365 Copilot licenses assigned' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady002: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady002' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Microsoft 365 Copilot licenses assigned' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady002.ps1' 74
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady003.ps1' -1

function Invoke-CippTestCopilotReady003 {
    <#
    .SYNOPSIS
    Users have Microsoft 365 desktop apps activated (Copilot prerequisite)
    #>
    param($Tenant)

    # Copilot in Word, Excel, PowerPoint, and Outlook requires the M365 desktop client (Windows or Mac).
    # The MS readiness assessment checks "Office Activations" — whether users have activated
    # M365 Apps on a desktop platform. Users with only web or mobile activations cannot use
    # Copilot's in-app document generation and editing features.
    # We cross-reference the activation report with licensed users (assignedPlans service 'MicrosoftOffice')
    # so that users who have never opened the app at all are counted as unactivated, not silently omitted.
    # Threshold: at least 70% of M365 Apps licensed users have a desktop (Windows/Mac) activation.
    $DesktopThresholdPercent = 70

    try {
        $ActivationData = Get-CIPPTestData -TenantFilter $Tenant -Type 'OfficeActivations'
        $AllUsers = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        if (-not $ActivationData -and -not $AllUsers) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady003' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Office activation or user data found in database. Data collection may not yet have run for this tenant.' -Risk 'High' -Name 'Users have M365 desktop apps activated' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        # Build a lookup of activation data keyed by UPN for fast cross-referencing
        $ActivationLookup = @{}
        if ($ActivationData) {
            foreach ($Entry in ($ActivationData | Where-Object { $_.userPrincipalName -and $_.userPrincipalName -ne '' })) {
                $ActivationLookup[$Entry.userPrincipalName.ToLower()] = $Entry
            }
        }

        # Filter Users cache to those with an active M365 Apps (desktop) license plan.
        # assignedPlans entries with service 'MicrosoftOffice' and capabilityStatus 'Enabled'
        # indicate the user holds a license that includes M365 desktop applications.
        $LicensedUsers = @($AllUsers | Where-Object {
            $_.userPrincipalName -and $_.accountEnabled -eq $true -and
            ($_.assignedPlans | Where-Object { $_.service -eq 'MicrosoftOffice' -and $_.capabilityStatus -eq 'Enabled' })
        })

        if ($LicensedUsers.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady003' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No users with an active M365 Apps license were found. Desktop activation check is not applicable.' -Risk 'High' -Name 'Users have M365 desktop apps activated' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        # For each licensed user, check if they have a desktop activation in the activation report.
        # Users absent from the report entirely are counted as unactivated.
        $NoDesktopUsers = [System.Collections.Generic.List[object]]::new()
        $DesktopCount = 0
        foreach ($User in $LicensedUsers) {
            $Activation = $ActivationLookup[$User.userPrincipalName.ToLower()]
            if ($Activation -and (([int]($Activation.windows ?? 0) + [int]($Activation.mac ?? 0)) -gt 0)) {
                $DesktopCount++
            } else {
                $NoDesktopUsers.Add([pscustomobject]@{
                    displayName       = $User.displayName
                    userPrincipalName = $User.userPrincipalName
                    web               = if ($Activation) { $Activation.web } else { 0 }
                    android           = if ($Activation) { $Activation.android } else { 0 }
                    ios               = if ($Activation) { $Activation.ios } else { 0 }
                    neverActivated    = ($null -eq $Activation)
                })
            }
        }

        $TotalUsers = $LicensedUsers.Count
        $DesktopPercent = if ($TotalUsers -gt 0) { [math]::Round(($DesktopCount / $TotalUsers) * 100, 1) } else { 0 }

        if ($DesktopPercent -ge $DesktopThresholdPercent) {
            $Status = 'Passed'
            $Result = "**$DesktopCount of $TotalUsers licensed users ($DesktopPercent%)** have Microsoft 365 Apps activated on a desktop platform (Windows or Mac) — above the $DesktopThresholdPercent% threshold.`n`n"
            $Result += "These users can access Copilot features in desktop Word, Excel, PowerPoint, and Outlook."
        } else {
            $Status = 'Failed'
            $Result = "Only **$DesktopCount of $TotalUsers licensed users ($DesktopPercent%)** have Microsoft 365 Apps activated on a desktop platform — below the $DesktopThresholdPercent% threshold.`n`n"
            $Result += "Copilot in Word, Excel, PowerPoint, and Outlook requires the M365 desktop application. "
            $Result += "Users with only web or mobile activations, or who have never activated at all, cannot use Copilot's in-document features.`n`n"
            if ($NoDesktopUsers.Count -gt 0 -and $NoDesktopUsers.Count -le 20) {
                $Result += "**Users without desktop activation:**`n"
                foreach ($User in $NoDesktopUsers) {
                    if ($User.neverActivated) {
                        $PlatformStr = ' (never activated)'
                    } else {
                        $Platforms = @()
                        if ([int]($User.web ?? 0) -gt 0) { $Platforms += 'Web' }
                        if ([int]($User.android ?? 0) -gt 0 -or [int]($User.ios ?? 0) -gt 0) { $Platforms += 'Mobile' }
                        $PlatformStr = if ($Platforms) { " ($(($Platforms -join ', ')) only)" } else { ' (no activations)' }
                    }
                    $Result += "- $($User.displayName) ($($User.userPrincipalName))$PlatformStr`n"
                }
            } elseif ($NoDesktopUsers.Count -gt 20) {
                $NeverActivated = @($NoDesktopUsers | Where-Object { $_.neverActivated }).Count
                $Result += "**$($NoDesktopUsers.Count) users** have no desktop M365 Apps activation"
                if ($NeverActivated -gt 0) { $Result += " ($NeverActivated have never activated on any platform)" }
                $Result += '.`n'
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady003' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Users have M365 desktop apps activated' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady003: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady003' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Users have M365 desktop apps activated' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady003.ps1' 108
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady004.ps1' -1

function Invoke-CippTestCopilotReady004 {
    <#
    .SYNOPSIS
    Users are actively using Exchange Online email (Copilot value indicator)
    #>
    param($Tenant)

    # Copilot for Outlook adds AI-assisted email drafting, summarization, and coaching.
    # The MS readiness report checks "Uses Outlook Email" (usesOutlookEmail) — whether users
    # sent at least one email in the past 30 days. Users not in the readiness report at all
    # have never used any M365 product and are also counted as inactive.
    # Threshold: at least 50% of licensed active users are using Outlook email.
    $ActivityThresholdPercent = 50

    try {
        $ReadinessData = Get-CIPPTestData -TenantFilter $Tenant -Type 'CopilotReadinessActivity'
        $AllUsers = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        if (-not $ReadinessData -and -not $AllUsers) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady004' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Copilot readiness activity or user data found in database. Data collection may not yet have run for this tenant.' -Risk 'Medium' -Name 'Users are actively using Exchange Online email' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        # Build lookup of readiness data keyed by UPN
        $ReadinessLookup = @{}
        if ($ReadinessData) {
            foreach ($Entry in ($ReadinessData | Where-Object { $_.userPrincipalName })) {
                $ReadinessLookup[$Entry.userPrincipalName.ToLower()] = $Entry
            }
        }

        # Use licensed active users as the denominator — users absent from the report have never used M365
        $LicensedUsers = @($AllUsers | Where-Object {
                $_.userPrincipalName -and $_.accountEnabled -eq $true -and
                ($_.assignedPlans | Where-Object { $_.capabilityStatus -eq 'Enabled' })
            })

        if ($LicensedUsers.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady004' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No licensed active users found in the tenant.' -Risk 'Medium' -Name 'Users are actively using Exchange Online email' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $InactiveUsers = [System.Collections.Generic.List[string]]::new()
        $ActiveCount = 0
        foreach ($User in $LicensedUsers) {
            $Readiness = $ReadinessLookup[$User.userPrincipalName.ToLower()]
            if ($Readiness -and $Readiness.usesOutlookEmail -eq $true) {
                $ActiveCount++
            } else {
                $InactiveUsers.Add($User.userPrincipalName)
            }
        }

        $TotalUsers = $LicensedUsers.Count
        $ActivityPercent = if ($TotalUsers -gt 0) { [math]::Round(($ActiveCount / $TotalUsers) * 100, 1) } else { 0 }

        if ($ActivityPercent -ge $ActivityThresholdPercent) {
            $Status = 'Passed'
            $Result = "**$ActiveCount of $TotalUsers licensed users ($ActivityPercent%)** sent email in the past 30 days — above the $ActivityThresholdPercent% threshold.`n`n"
            $Result += 'These users are good candidates for Copilot in Outlook, which provides AI-assisted drafting, summarization, and email coaching.'
        } else {
            $Status = 'Failed'
            $Result = "Only **$ActiveCount of $TotalUsers licensed users ($ActivityPercent%)** sent email in the past 30 days — below the $ActivityThresholdPercent% threshold.`n`n"
            $Result += 'Copilot for Outlook delivers the most value to active email users. '
            $Result += "Consider reviewing Exchange Online license assignment and adoption before rolling out Copilot.`n`n"
            if ($InactiveUsers.Count -gt 0 -and $InactiveUsers.Count -le 20) {
                $Result += "**Inactive users (no Outlook email in 30 days):**`n"
                foreach ($Upn in $InactiveUsers) { $Result += "- $Upn`n" }
            } elseif ($InactiveUsers.Count -gt 20) {
                $Result += "**$($InactiveUsers.Count) users** had no Outlook email activity in the past 30 days."
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady004' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Users are actively using Exchange Online email' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady004: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady004' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Users are actively using Exchange Online email' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady004.ps1' 82
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady005.ps1' -1

function Invoke-CippTestCopilotReady005 {
    <#
    .SYNOPSIS
    Users are actively using Microsoft Teams (Copilot value indicator)
    #>
    param($Tenant)

    # Copilot for Teams provides meeting summaries, chat thread recaps, and real-time assistance.
    # The MS readiness report checks usesTeamsMeetings and usesTeamsChat — whether users attended
    # a meeting or participated in chat in the past 30 days. Users not in the readiness report
    # at all have never used any M365 product and are also counted as inactive.
    # Threshold: at least 50% of licensed active users have any Teams activity.
    $ActivityThresholdPercent = 50

    try {
        $ReadinessData = Get-CIPPTestData -TenantFilter $Tenant -Type 'CopilotReadinessActivity'
        $AllUsers = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        if (-not $ReadinessData -and -not $AllUsers) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady005' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Copilot readiness activity or user data found in database. Data collection may not yet have run for this tenant.' -Risk 'Medium' -Name 'Users are actively using Microsoft Teams' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        # Build lookup of readiness data keyed by UPN
        $ReadinessLookup = @{}
        if ($ReadinessData) {
            foreach ($Entry in ($ReadinessData | Where-Object { $_.userPrincipalName })) {
                $ReadinessLookup[$Entry.userPrincipalName.ToLower()] = $Entry
            }
        }

        # Use licensed active users as the denominator — users absent from the report have never used M365
        $LicensedUsers = @($AllUsers | Where-Object {
                $_.userPrincipalName -and $_.accountEnabled -eq $true -and
                ($_.assignedPlans | Where-Object { $_.capabilityStatus -eq 'Enabled' })
            })

        if ($LicensedUsers.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady005' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No licensed active users found in the tenant.' -Risk 'Medium' -Name 'Users are actively using Microsoft Teams' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $InactiveUsers = [System.Collections.Generic.List[string]]::new()
        $ActiveCount = 0
        foreach ($User in $LicensedUsers) {
            $Readiness = $ReadinessLookup[$User.userPrincipalName.ToLower()]
            if ($Readiness -and ($Readiness.usesTeamsMeetings -eq $true -or $Readiness.usesTeamsChat -eq $true)) {
                $ActiveCount++
            } else {
                $InactiveUsers.Add($User.userPrincipalName)
            }
        }

        $TotalUsers = $LicensedUsers.Count
        $ActivityPercent = if ($TotalUsers -gt 0) { [math]::Round(($ActiveCount / $TotalUsers) * 100, 1) } else { 0 }

        if ($ActivityPercent -ge $ActivityThresholdPercent) {
            $Status = 'Passed'
            $Result = "**$ActiveCount of $TotalUsers licensed users ($ActivityPercent%)** used Teams meetings or chat in the past 30 days — above the $ActivityThresholdPercent% threshold.`n`n"
            $Result += 'These users are strong candidates for Copilot in Teams, which provides meeting summaries, chat recaps, and real-time meeting assistance.'
        } else {
            $Status = 'Failed'
            $Result = "Only **$ActiveCount of $TotalUsers licensed users ($ActivityPercent%)** used Teams meetings or chat in the past 30 days — below the $ActivityThresholdPercent% threshold.`n`n"
            $Result += 'Copilot for Teams delivers the most value to users who regularly use chat and meetings. '
            $Result += "Consider driving Teams adoption before or alongside a Copilot rollout.`n`n"
            if ($InactiveUsers.Count -gt 0 -and $InactiveUsers.Count -le 20) {
                $Result += "**Inactive users (no Teams activity in 30 days):**`n"
                foreach ($Upn in $InactiveUsers) { $Result += "- $Upn`n" }
            } elseif ($InactiveUsers.Count -gt 20) {
                $Result += "**$($InactiveUsers.Count) users** had no Teams meetings or chat activity in the past 30 days."
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady005' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Users are actively using Microsoft Teams' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady005: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady005' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Users are actively using Microsoft Teams' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady005.ps1' 82
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady006.ps1' -1

function Invoke-CippTestCopilotReady006 {
    <#
    .SYNOPSIS
    Users are actively using OneDrive/SharePoint for file collaboration (Copilot value indicator)
    #>
    param($Tenant)

    # Copilot adds the most value when users actively store and collaborate on files.
    # The MS readiness report checks usesOfficeDocs \u2014 whether users worked on a document or
    # file in OneDrive or SharePoint in the past 30 days. Users not in the readiness report
    # at all have never used any M365 product and are also counted as inactive.
    # Threshold: at least 50% of licensed active users are using Office docs.
    $ActivityThresholdPercent = 50

    try {
        $ReadinessData = Get-CIPPTestData -TenantFilter $Tenant -Type 'CopilotReadinessActivity'
        $AllUsers = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        if (-not $ReadinessData -and -not $AllUsers) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady006' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Copilot readiness activity or user data found in database. Data collection may not yet have run for this tenant.' -Risk 'Medium' -Name 'Users are actively using OneDrive/SharePoint' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        # Build lookup of readiness data keyed by UPN
        $ReadinessLookup = @{}
        if ($ReadinessData) {
            foreach ($Entry in ($ReadinessData | Where-Object { $_.userPrincipalName })) {
                $ReadinessLookup[$Entry.userPrincipalName.ToLower()] = $Entry
            }
        }

        # Use licensed active users as the denominator \u2014 users absent from the report have never used M365
        $LicensedUsers = @($AllUsers | Where-Object {
                $_.userPrincipalName -and $_.accountEnabled -eq $true -and
                ($_.assignedPlans | Where-Object { $_.capabilityStatus -eq 'Enabled' })
            })

        if ($LicensedUsers.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady006' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No licensed active users found in the tenant.' -Risk 'Medium' -Name 'Users are actively using OneDrive/SharePoint' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $InactiveUsers = [System.Collections.Generic.List[string]]::new()
        $ActiveCount = 0
        foreach ($User in $LicensedUsers) {
            $Readiness = $ReadinessLookup[$User.userPrincipalName.ToLower()]
            if ($Readiness -and $Readiness.usesOfficeDocs -eq $true) {
                $ActiveCount++
            } else {
                $InactiveUsers.Add($User.userPrincipalName)
            }
        }

        $TotalUsers = $LicensedUsers.Count
        $ActivityPercent = if ($TotalUsers -gt 0) { [math]::Round(($ActiveCount / $TotalUsers) * 100, 1) } else { 0 }

        if ($ActivityPercent -ge $ActivityThresholdPercent) {
            $Status = 'Passed'
            $Result = "**$ActiveCount of $TotalUsers licensed users ($ActivityPercent%)** worked on OneDrive or SharePoint files in the past 30 days \u2014 above the $ActivityThresholdPercent% threshold.`n`n"
            $Result += 'These users are strong candidates for Copilot, which provides the most value when users actively collaborate on files in Microsoft 365.'
        } else {
            $Status = 'Failed'
            $Result = "Only **$ActiveCount of $TotalUsers licensed users ($ActivityPercent%)** worked on OneDrive or SharePoint files in the past 30 days \u2014 below the $ActivityThresholdPercent% threshold.`n`n"
            $Result += 'Copilot delivers the most value when users regularly store and collaborate on files in OneDrive and SharePoint. '
            $Result += "Consider driving file collaboration adoption before or alongside a Copilot rollout.`n`n"
            if ($InactiveUsers.Count -gt 0 -and $InactiveUsers.Count -le 20) {
                $Result += "**Inactive users (no Office doc activity in 30 days):**`n"
                foreach ($Upn in $InactiveUsers) { $Result += "- $Upn`n" }
            } elseif ($InactiveUsers.Count -gt 20) {
                $Result += "**$($InactiveUsers.Count) users** had no OneDrive or SharePoint file activity in the past 30 days."
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady006' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Users are actively using OneDrive/SharePoint' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady006: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady006' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Users are actively using OneDrive/SharePoint' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady006.ps1' 82
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady007.ps1' -1

function Invoke-CippTestCopilotReady007 {
    <#
    .SYNOPSIS
    Users are on a qualified Microsoft 365 Apps update channel (Copilot prerequisite)
    #>
    param($Tenant)

    # Copilot features in Word, Excel, PowerPoint, Outlook, and OneNote require the M365 desktop
    # client to be on Current Channel or Monthly Enterprise Channel — the two "qualified" update
    # channels that receive Copilot feature updates. Users on Semi-Annual Enterprise Channel or
    # other slower channels will not receive Copilot features even with a valid license.
    # Users not in the readiness report at all have never used any M365 product and are counted
    # as not on a qualified channel.
    # Threshold: at least 70% of licensed active users are on a qualified update channel. Risk: High.
    $ChannelThresholdPercent = 70

    try {
        $ReadinessData = Get-CIPPTestData -TenantFilter $Tenant -Type 'CopilotReadinessActivity'
        $AllUsers = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        if (-not $ReadinessData -and -not $AllUsers) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady007' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Copilot readiness activity or user data found in database. Data collection may not yet have run for this tenant.' -Risk 'High' -Name 'Users are on a qualified M365 Apps update channel' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        # Build lookup of readiness data keyed by UPN
        $ReadinessLookup = @{}
        if ($ReadinessData) {
            foreach ($Entry in ($ReadinessData | Where-Object { $_.userPrincipalName })) {
                $ReadinessLookup[$Entry.userPrincipalName.ToLower()] = $Entry
            }
        }

        # Filter to users with an active M365 Apps (desktop) license plan — update channel only
        # applies to users with a license that includes M365 Apps for desktop.
        $LicensedUsers = @($AllUsers | Where-Object {
            $_.userPrincipalName -and $_.accountEnabled -eq $true -and
            ($_.assignedPlans | Where-Object { $_.service -eq 'MicrosoftOffice' -and $_.capabilityStatus -eq 'Enabled' })
        })

        if ($LicensedUsers.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady007' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No users with an active M365 Apps license were found. Update channel check is not applicable.' -Risk 'High' -Name 'Users are on a qualified M365 Apps update channel' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        $NotQualifiedUsers = [System.Collections.Generic.List[string]]::new()
        $QualifiedCount = 0
        foreach ($User in $LicensedUsers) {
            $Readiness = $ReadinessLookup[$User.userPrincipalName.ToLower()]
            if ($Readiness -and $Readiness.onQualifiedUpdateChannel -eq $true) {
                $QualifiedCount++
            } else {
                $NotQualifiedUsers.Add($User.userPrincipalName)
            }
        }

        $TotalUsers = $LicensedUsers.Count
        $ChannelPercent = if ($TotalUsers -gt 0) { [math]::Round(($QualifiedCount / $TotalUsers) * 100, 1) } else { 0 }

        if ($ChannelPercent -ge $ChannelThresholdPercent) {
            $Status = 'Passed'
            $Result = "**$QualifiedCount of $TotalUsers M365 Apps licensed users ($ChannelPercent%)** are on Current Channel or Monthly Enterprise Channel — above the $ChannelThresholdPercent% threshold.`n`n"
            $Result += 'These users will receive Copilot feature updates for desktop Word, Excel, PowerPoint, Outlook, and OneNote.'
        } else {
            $Status = 'Failed'
            $Result = "Only **$QualifiedCount of $TotalUsers M365 Apps licensed users ($ChannelPercent%)** are on a qualified update channel — below the $ChannelThresholdPercent% threshold.`n`n"
            $Result += 'Copilot in M365 desktop apps requires **Current Channel** or **Monthly Enterprise Channel**. '
            $Result += "Users on Semi-Annual Enterprise Channel or other update rings will not receive Copilot features.`n`n"
            $Result += "To remediate, update the Microsoft 365 Apps update channel via Microsoft Intune, Microsoft 365 admin center, or Group Policy.`n`n"
            if ($NotQualifiedUsers.Count -gt 0 -and $NotQualifiedUsers.Count -le 20) {
                $Result += "**Users not on a qualified update channel:**`n"
                foreach ($Upn in $NotQualifiedUsers) { $Result += "- $Upn`n" }
            } elseif ($NotQualifiedUsers.Count -gt 20) {
                $Result += "**$($NotQualifiedUsers.Count) users** are not on a qualified update channel."
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady007' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Users are on a qualified M365 Apps update channel' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady007: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady007' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Users are on a qualified M365 Apps update channel' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady007.ps1' 86
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady008.ps1' -1

function Invoke-CippTestCopilotReady008 {
    <#
    .SYNOPSIS
    Copilot candidate tier breakdown - which users are most ready for Copilot
    #>
    param($Tenant)

    # Score each licensed user across 6 readiness signals from the Copilot readiness report.
    # This is informational — no hard pass/fail — it shows who would benefit most from Copilot.
    # Signal scoring: hasCopilotLicenseAssigned, onQualifiedUpdateChannel, usesTeamsMeetings,
    # usesTeamsChat, usesOutlookEmail, usesOfficeDocs. All booleans, each worth 1 point.
    # High: >=4 signals (power users, best Copilot ROI)
    # Medium: 3 signals (engaged users, good candidates)
    # Low: <=2 signals (low engagement, limited Copilot benefit without adoption work first)

    try {
        $ReadinessData = Get-CIPPTestData -TenantFilter $Tenant -Type 'CopilotReadinessActivity'
        $AllUsers = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        if (-not $ReadinessData -and -not $AllUsers) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady008' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Copilot readiness activity or user data found in database. Data collection may not yet have run for this tenant.' -Risk 'Informational' -Name 'Copilot candidate tier breakdown' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $ReadinessLookup = @{}
        if ($ReadinessData) {
            foreach ($Entry in ($ReadinessData | Where-Object { $_.userPrincipalName })) {
                $ReadinessLookup[$Entry.userPrincipalName.ToLower()] = $Entry
            }
        }

        $LicensedUsers = @($AllUsers | Where-Object {
                $_.userPrincipalName -and $_.accountEnabled -eq $true -and
                ($_.assignedPlans | Where-Object { $_.capabilityStatus -eq 'Enabled' })
            })

        if ($LicensedUsers.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady008' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No licensed active users found in the tenant.' -Risk 'Informational' -Name 'Copilot candidate tier breakdown' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $HighTier = [System.Collections.Generic.List[string]]::new()
        $MediumTier = [System.Collections.Generic.List[string]]::new()
        $LowTier = [System.Collections.Generic.List[string]]::new()

        foreach ($User in $LicensedUsers) {
            $R = $ReadinessLookup[$User.userPrincipalName.ToLower()]
            $Score = 0
            if ($R) {
                if ($R.hasCopilotLicenseAssigned -eq $true) { $Score++ }
                if ($R.onQualifiedUpdateChannel -eq $true) { $Score++ }
                if ($R.usesTeamsMeetings -eq $true) { $Score++ }
                if ($R.usesTeamsChat -eq $true) { $Score++ }
                if ($R.usesOutlookEmail -eq $true) { $Score++ }
                if ($R.usesOfficeDocs -eq $true) { $Score++ }
            }

            if ($Score -ge 4) {
                $HighTier.Add($User.userPrincipalName)
            } elseif ($Score -ge 3) {
                $MediumTier.Add($User.userPrincipalName)
            } else {
                $LowTier.Add($User.userPrincipalName)
            }
        }

        $Total = $LicensedUsers.Count
        $HighPct = [math]::Round(($HighTier.Count / $Total) * 100, 1)
        $MedPct = [math]::Round(($MediumTier.Count / $Total) * 100, 1)
        $LowPct = [math]::Round(($LowTier.Count / $Total) * 100, 1)

        $Result = "## Copilot Candidate Tier Breakdown`n`n"
        $Result += "Scoring is based on 6 readiness signals from the Microsoft 365 Copilot Readiness report (30-day window).`n`n"
        $Result += "| Tier | Users | % of Tenant | Description |`n"
        $Result += "|------|-------|-------------|-------------|`n"
        $Result += "| **High** (≥4 signals) | $($HighTier.Count) | $HighPct% | Power M365 users — strongest Copilot ROI |`n"
        $Result += "| **Medium** (3 signals) | $($MediumTier.Count) | $MedPct% | Engaged users — good Copilot candidates |`n"
        $Result += "| **Low** (≤2 signals) | $($LowTier.Count) | $LowPct% | Low engagement — adopt M365 basics first |`n"
        $Result += "`n**Signals scored:** Copilot license assigned, qualified update channel, Teams meetings, Teams chat, Outlook email, Office documents (each = 1 point)`n"

        if ($HighTier.Count -gt 0 -and $HighTier.Count -le 20) {
            $Result += "`n**High tier users:**`n"
            foreach ($Upn in $HighTier) { $Result += "- $Upn`n" }
        } elseif ($HighTier.Count -gt 20) {
            $Result += "`n*$($HighTier.Count) users are in the high tier — use the Microsoft 365 Copilot Readiness report in the admin center for the full list.*`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady008' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Copilot candidate tier breakdown' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady008: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady008' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Copilot candidate tier breakdown' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady008.ps1' 96
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady009.ps1' -1

function Invoke-CippTestCopilotReady009 {
    <#
    .SYNOPSIS
    Majority of licensed users are Medium or High Copilot candidates (adoption readiness)
    #>
    param($Tenant)

    # Using the same 6-signal scoring as test 008. Pass if at least 70% of licensed users
    # score Medium (3 signals) or above — indicating the tenant has broad enough M365 engagement
    # to make a Copilot rollout worthwhile without first needing a major adoption campaign.
    $AdoptionThresholdPercent = 70

    try {
        $ReadinessData = Get-CIPPTestData -TenantFilter $Tenant -Type 'CopilotReadinessActivity'
        $AllUsers = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        if (-not $ReadinessData -and -not $AllUsers) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady009' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Copilot readiness activity or user data found in database. Data collection may not yet have run for this tenant.' -Risk 'High' -Name 'Majority of users are Copilot-ready (Medium or above)' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        $ReadinessLookup = @{}
        if ($ReadinessData) {
            foreach ($Entry in ($ReadinessData | Where-Object { $_.userPrincipalName })) {
                $ReadinessLookup[$Entry.userPrincipalName.ToLower()] = $Entry
            }
        }

        $LicensedUsers = @($AllUsers | Where-Object {
                $_.userPrincipalName -and $_.accountEnabled -eq $true -and
                ($_.assignedPlans | Where-Object { $_.capabilityStatus -eq 'Enabled' })
            })

        if ($LicensedUsers.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady009' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No licensed active users found in the tenant.' -Risk 'High' -Name 'Majority of users are Copilot-ready (Medium or above)' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        $MediumOrAbove = 0
        $LowCount = 0
        foreach ($User in $LicensedUsers) {
            $R = $ReadinessLookup[$User.userPrincipalName.ToLower()]
            $Score = 0
            if ($R) {
                if ($R.hasCopilotLicenseAssigned -eq $true) { $Score++ }
                if ($R.onQualifiedUpdateChannel -eq $true) { $Score++ }
                if ($R.usesTeamsMeetings -eq $true) { $Score++ }
                if ($R.usesTeamsChat -eq $true) { $Score++ }
                if ($R.usesOutlookEmail -eq $true) { $Score++ }
                if ($R.usesOfficeDocs -eq $true) { $Score++ }
            }
            if ($Score -ge 3) { $MediumOrAbove++ } else { $LowCount++ }
        }

        $Total = $LicensedUsers.Count
        $ReadyPercent = [math]::Round(($MediumOrAbove / $Total) * 100, 1)

        if ($ReadyPercent -ge $AdoptionThresholdPercent) {
            $Status = 'Passed'
            $Result = "**$MediumOrAbove of $Total licensed users ($ReadyPercent%)** score Medium or above on Copilot readiness signals — above the $AdoptionThresholdPercent% threshold.`n`n"
            $Result += 'This tenant has strong M365 engagement across the user base and is well-positioned for a Copilot rollout.'
        } else {
            $Status = 'Failed'
            $Result = "Only **$MediumOrAbove of $Total licensed users ($ReadyPercent%)** score Medium or above on Copilot readiness signals — below the $AdoptionThresholdPercent% threshold.`n`n"
            $Result += "**$LowCount users** have low M365 engagement (≤2 of 6 signals). Copilot delivers the most value where users are already active across Teams, Outlook, and Office apps.`n`n"
            $Result += "Consider running an M365 adoption campaign — focused on Teams meetings, Teams chat, Outlook, and OneDrive/SharePoint file usage — before or alongside a Copilot rollout.`n`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady009' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Majority of users are Copilot-ready (Medium or above)' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady009: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady009' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Majority of users are Copilot-ready (Medium or above)' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady009.ps1' 77
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady010.ps1' -1

function Invoke-CippTestCopilotReady010 {
    <#
    .SYNOPSIS
    All licensed users have MFA registered (security prerequisite for Copilot rollout)
    #>
    param($Tenant)

    # MFA is a security baseline requirement before rolling out Copilot. Copilot has broad access
    # to tenant data; ensuring accounts are MFA-protected reduces risk of compromised accounts
    # being used to extract information via Copilot. Pass if 100% of licensed active users
    # have isMfaRegistered = true in their registration details.

    try {
        $UserRegistrationDetails = Get-CIPPTestData -TenantFilter $Tenant -Type 'UserRegistrationDetails'
        $AllUsers = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        if (-not $UserRegistrationDetails -or -not $AllUsers) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady010' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No MFA registration or user data found in database. Data collection may not yet have run for this tenant.' -Risk 'High' -Name 'All licensed users have MFA registered' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        # Build lookup by UPN for matching
        $RegLookup = @{}
        foreach ($Reg in ($UserRegistrationDetails | Where-Object { $_.userPrincipalName })) {
            $RegLookup[$Reg.userPrincipalName.ToLower()] = $Reg
        }

        $LicensedUsers = @($AllUsers | Where-Object {
                $_.userPrincipalName -and $_.accountEnabled -eq $true -and
                ($_.assignedPlans | Where-Object { $_.capabilityStatus -eq 'Enabled' })
            })

        if ($LicensedUsers.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady010' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No licensed active users found in the tenant.' -Risk 'High' -Name 'All licensed users have MFA registered' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        $NotRegistered = [System.Collections.Generic.List[string]]::new()
        $RegisteredCount = 0

        foreach ($User in $LicensedUsers) {
            $Reg = $RegLookup[$User.userPrincipalName.ToLower()]
            if ($Reg -and $Reg.isMfaRegistered -eq $true) {
                $RegisteredCount++
            } else {
                $NotRegistered.Add($User.userPrincipalName)
            }
        }

        $Total = $LicensedUsers.Count
        $RegisteredPercent = [math]::Round(($RegisteredCount / $Total) * 100, 1)

        if ($NotRegistered.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All **$Total licensed users** have MFA registered — the tenant meets the MFA security baseline for Copilot deployment."
        } else {
            $Status = 'Failed'
            $Result = "**$($NotRegistered.Count) of $Total licensed users ($([math]::Round(($NotRegistered.Count / $Total) * 100, 1))%)** do not have MFA registered.`n`n"
            $Result += 'MFA is a security baseline requirement before deploying Copilot. Accounts without MFA present elevated risk when Copilot has access to tenant data.`n`n'
            $Result += "Remediate by enforcing MFA via Conditional Access or per-user MFA, and requiring users to register via [aka.ms/mfasetup](https://aka.ms/mfasetup).`n`n"
            if ($NotRegistered.Count -le 20) {
                $Result += "**Users without MFA registered:**`n"
                foreach ($Upn in $NotRegistered) { $Result += "- $Upn`n" }
            } else {
                $Result += "**$($NotRegistered.Count) users** do not have MFA registered."
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady010' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'All licensed users have MFA registered' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady010: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady010' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'All licensed users have MFA registered' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady010.ps1' 77
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady011.ps1' -1

function Invoke-CippTestCopilotReady011 {
    <#
    .SYNOPSIS
    Tenant has at least one enabled Conditional Access policy (security prerequisite for Copilot)
    #>
    param($Tenant)

    # CA policies are a key security control before deploying Copilot. Without CA, there is no
    # baseline enforcement of MFA at sign-in, device compliance, or location-based access controls.
    # Pass if at least one CA policy with state = 'enabled' exists.
    # Skipped if the tenant does not have Azure AD Premium (no CA capability).

    try {
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $CAPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady011' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Conditional Access policy data found in database. The tenant may not have Azure AD Premium, or data collection may not yet have run.' -Risk 'High' -Name 'Tenant has enabled Conditional Access policies' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        $EnabledPolicies = @($CAPolicies | Where-Object { $_.state -eq 'enabled' })
        $ReportOnlyPolicies = @($CAPolicies | Where-Object { $_.state -eq 'enabledForReportingButNotEnforced' })

        if ($EnabledPolicies.Count -gt 0) {
            $Status = 'Passed'
            $Result = "**$($EnabledPolicies.Count) enabled Conditional Access polic$(if ($EnabledPolicies.Count -eq 1) { 'y' } else { 'ies' })** found in the tenant.`n`n"
            $Result += "| Policy Name | State |`n"
            $Result += "|-------------|-------|`n"
            foreach ($Policy in ($EnabledPolicies | Sort-Object displayName)) {
                $Result += "| $($Policy.displayName) | Enabled |`n"
            }
            if ($ReportOnlyPolicies.Count -gt 0) {
                $Result += "`n*$($ReportOnlyPolicies.Count) additional polic$(if ($ReportOnlyPolicies.Count -eq 1) { 'y is' } else { 'ies are' }) in report-only mode and not enforcing access controls.*"
            }
        } else {
            $Status = 'Failed'
            $Result = "No enabled Conditional Access policies were found in this tenant.`n`n"
            if ($ReportOnlyPolicies.Count -gt 0) {
                $Result += "**$($ReportOnlyPolicies.Count) polic$(if ($ReportOnlyPolicies.Count -eq 1) { 'y is' } else { 'ies are' }) in report-only mode** but not enforcing.`n`n"
            }
            $Result += 'Conditional Access is the primary mechanism for enforcing MFA, device compliance, and access controls in Entra ID. '
            $Result += 'Before deploying Copilot, establish at least a baseline CA policy requiring MFA for all users. '
            $Result += 'See [Microsoft CA policy templates](https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-conditional-access-policy-common) to get started.'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady011' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Tenant has enabled Conditional Access policies' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady011: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady011' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Tenant has enabled Conditional Access policies' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady011.ps1' 54
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady012.ps1' -1

function Invoke-CippTestCopilotReady012 {
    <#
    .SYNOPSIS
    Users cannot freely create groups, tenants, or register applications (governance baseline)
    #>
    param($Tenant)

    # Unrestricted group/tenant/app creation by regular users is a governance risk, especially
    # with Copilot in place. Copilot can surface content from any group or app a user has access
    # to. Restricting self-service creation reduces shadow IT and ensures data governance controls
    # are applied to new resources before Copilot can interact with them.
    # Pass if all four permissions are restricted (false).

    try {
        $AuthPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady012' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No authorization policy data found in database. Data collection may not yet have run for this tenant.' -Risk 'Medium' -Name 'User self-service creation is restricted (groups, tenants, apps)' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $Perms = $AuthPolicy.defaultUserRolePermissions

        $Checks = [ordered]@{
            allowedToCreateGroups         = 'Create Microsoft 365 groups'
            allowedToCreateTenants        = 'Create new Azure AD tenants'
            allowedToCreateApps           = 'Register applications'
            allowedToCreateSecurityGroups = 'Create security groups'
        }

        $Issues = [System.Collections.Generic.List[string]]::new()
        $Restricted = [System.Collections.Generic.List[string]]::new()

        foreach ($Check in $Checks.GetEnumerator()) {
            $Value = $Perms."$($Check.Key)"
            if ($Value -eq $true) {
                $Issues.Add($Check.Value)
            } else {
                $Restricted.Add($Check.Value)
            }
        }

        # Also check allowedToCreateTenants at the top-level policy (older API surface)
        if ($AuthPolicy.allowedToCreateTenants -eq $true -and -not $Issues.Contains('Create new Azure AD tenants')) {
            $Issues.Add('Create new Azure AD tenants (top-level policy)')
        }

        if ($Issues.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All user self-service creation permissions are restricted — users cannot create groups, tenants, or register applications without admin involvement.`n`n"
            $Result += 'This reduces shadow IT risk and ensures governance controls apply to new M365 resources before Copilot can interact with them.'
        } else {
            $Status = 'Failed'
            $Result = "**$($Issues.Count) user permission$(if ($Issues.Count -eq 1) { '' } else { 's' })** allow unrestricted self-service creation.`n`n"
            $Result += "| Permission | Status |`n"
            $Result += "|------------|--------|`n"
            foreach ($Issue in $Issues) {
                $Result += "| $Issue | ⚠️ Unrestricted |`n"
            }
            foreach ($Ok in $Restricted) {
                $Result += "| $Ok | ✅ Restricted |`n"
            }
            $Result += "`nWith Copilot deployed, unrestricted group and app creation increases the risk of uncontrolled data exposure. "
            $Result += 'Restrict these permissions via **Entra ID → User settings** and **Group settings** to ensure new resources go through a governed process.'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady012' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'User self-service creation is restricted (groups, tenants, apps)' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady012: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady012' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'User self-service creation is restricted (groups, tenants, apps)' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady012.ps1' 75
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady013.ps1' -1

function Invoke-CippTestCopilotReady013 {
    <#
    .SYNOPSIS
    Tenant has active sensitivity labels configured in Microsoft Purview
    #>
    param($Tenant)

    # Sensitivity labels are a governance control that helps classify and protect data before
    # Copilot is deployed. Copilot respects sensitivity labels when generating content and can
    # apply labels to created documents. Having labels configured means the tenant has a data
    # classification framework in place. Skipped if no Purview/AIP license is present.

    try {
        $Labels = Get-CIPPTestData -TenantFilter $Tenant -Type 'SensitivityLabels'

        if ($null -eq $Labels) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady013' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No sensitivity label data found in database. The tenant may not have a Microsoft Purview/AIP license (M365 Business Premium, E3, or E5), or data collection may not yet have run.' -Risk 'Medium' -Name 'Tenant has sensitivity labels configured in Purview' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        $ActiveLabels = @($Labels | Where-Object { $_.isActive -eq $true })

        if ($ActiveLabels.Count -gt 0) {
            $Status = 'Passed'
            $Result = "**$($ActiveLabels.Count) active sensitivity label$(if ($ActiveLabels.Count -eq 1) { '' } else { 's' })** found in the tenant.`n`n"
            $Result += "| Label | Parent | Has Protection |`n"
            $Result += "|-------|--------|---------------|`n"
            foreach ($Label in ($ActiveLabels | Sort-Object sensitivity)) {
                $ParentName = if ($Label.parent -and $Label.parent.name) { $Label.parent.name } else { '—' }
                $HasProtection = if ($Label.hasProtection -eq $true) { '✅ Yes' } else { 'No' }
                $Result += "| $($Label.name) | $ParentName | $HasProtection |`n"
            }
            $Result += "`nCopilot can respect and apply these labels when creating or summarizing content."
        } else {
            $Status = 'Failed'
            $Result = "No active sensitivity labels were found in this tenant.`n`n"
            $Result += 'Sensitivity labels classify and protect organizational data — helping ensure Copilot-generated content is appropriately marked. '
            $Result += 'Configure labels in the [Microsoft Purview compliance portal](https://compliance.microsoft.com/informationprotection) before deploying Copilot.'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady013' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Tenant has sensitivity labels configured in Purview' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady013: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady013' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Tenant has sensitivity labels configured in Purview' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady013.ps1' 49
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady014.ps1' -1

function Invoke-CippTestCopilotReady014 {
    <#
    .SYNOPSIS
    Tenant has enabled DLP policies to protect sensitive data (governance prerequisite for Copilot)
    #>
    param($Tenant)

    # DLP policies prevent sensitive data from being shared inappropriately. With Copilot in place,
    # DLP becomes more important — Copilot can surface sensitive content in responses. Having at
    # least one enabled DLP policy signals the tenant has begun data governance. Skipped if no
    # Purview/AIP license is present (required to run compliance PS commands).

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'DlpCompliancePolicies'

        if ($null -eq $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady014' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No DLP policy data found in database. The tenant may not have a Microsoft Purview/AIP license (M365 Business Premium, E3, or E5), or data collection may not yet have run.' -Risk 'Medium' -Name 'Tenant has enabled DLP policies configured' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
            return
        }

        $EnabledPolicies = @($Policies | Where-Object { $_.Mode -eq 'Enable' -and $_.Enabled -eq $true })
        $AllPolicies = @($Policies)

        if ($EnabledPolicies.Count -gt 0) {
            $Status = 'Passed'
            $Result = "**$($EnabledPolicies.Count) enabled DLP polic$(if ($EnabledPolicies.Count -eq 1) { 'y' } else { 'ies' })** found in the tenant.`n`n"
            $Result += "| Policy | Workload | Enabled |`n"
            $Result += "|--------|----------|---------|`n"
            foreach ($Policy in ($AllPolicies | Sort-Object DisplayName)) {
                $IsEnabled = if ($Policy.Mode -eq 'Enable' -and $Policy.Enabled -eq $true) { '✅ Yes' } else { 'No' }
                $Workload = if ($Policy.Workload) { $Policy.Workload } else { '—' }
                $Result += "| $($Policy.DisplayName) | $Workload | $IsEnabled |`n"
            }
        } else {
            $Status = 'Failed'
            $Result = "No enabled DLP policies were found in this tenant.`n`n"
            if ($AllPolicies.Count -gt 0) {
                $Result += "**$($AllPolicies.Count) polic$(if ($AllPolicies.Count -eq 1) { 'y exists' } else { 'ies exist' })** but none are enabled.`n`n"
            }
            $Result += 'Data Loss Prevention policies help protect sensitive information from being shared inappropriately — a critical control when Copilot can surface content broadly. '
            $Result += 'Enable or create DLP policies in the [Microsoft Purview compliance portal](https://compliance.microsoft.com/datalossprevention) before deploying Copilot.'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady014' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Tenant has enabled DLP policies configured' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady014: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady014' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Tenant has enabled DLP policies configured' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady014.ps1' 52
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady015.ps1' -1

function Invoke-CippTestCopilotReady015 {
    <#
    .SYNOPSIS
    Per-user Microsoft 365 Copilot usage detail (informational, 30-day period)
    #>
    param($Tenant)

    # Reports which users are actively using Copilot features across M365 apps.
    # This is purely informational — it shows who is getting value from Copilot
    # and which apps are seeing the most engagement.

    try {
        $UsageData = Get-CIPPTestData -TenantFilter $Tenant -Type 'CopilotUsageUserDetail'

        if (-not $UsageData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady015' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Copilot usage data found in database. Data collection may not yet have run for this tenant.' -Risk 'Informational' -Name 'Microsoft 365 Copilot usage per user' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $ActiveUsers = @($UsageData | Where-Object { $_.userPrincipalName -and $_.userPrincipalName -ne 'Not applicable' })

        if ($ActiveUsers.Count -eq 0) {
            $Result = "No Microsoft 365 Copilot usage was detected in the past 30 days.`n`n"
            $Result += 'This tenant either has no Copilot licenses assigned, or users have not yet started using Copilot features. '
            $Result += 'See tests CopilotReady001 and CopilotReady002 to check licensing status.'
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady015' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Microsoft 365 Copilot usage per user' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        # Determine which app columns are present
        $SampleUser = $ActiveUsers | Select-Object -First 1
        $AppColumns = $SampleUser.PSObject.Properties.Name | Where-Object {
            $_ -notin @('userPrincipalName', 'displayName', 'lastActivityDate', 'reportRefreshDate', 'reportPeriod', 'id')
        }

        $Result = "**$($ActiveUsers.Count) users** had Copilot activity in the past 30 days.`n`n"

        # Build table header from available columns
        $Headers = @('User', 'Last Active') + $AppColumns
        $Result += '| ' + ($Headers -join ' | ') + " |`n"
        $Result += '| ' + (($Headers | ForEach-Object { '---' }) -join ' | ') + " |`n"

        $DisplayUsers = $ActiveUsers | Sort-Object lastActivityDate -Descending | Select-Object -First 50
        foreach ($User in $DisplayUsers) {
            $LastActive = if ($User.lastActivityDate) { $User.lastActivityDate } else { 'N/A' }
            $Row = "| $($User.userPrincipalName) | $LastActive |"
            foreach ($Col in $AppColumns) {
                $Val = $User.$Col
                $Row += " $Val |"
            }
            $Result += "$Row`n"
        }

        if ($ActiveUsers.Count -gt 50) {
            $Result += "`n*Showing 50 of $($ActiveUsers.Count) active users.*"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady015' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Microsoft 365 Copilot usage per user' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady015: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady015' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Microsoft 365 Copilot usage per user' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady015.ps1' 66
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady016.ps1' -1

function Invoke-CippTestCopilotReady016 {
    <#
    .SYNOPSIS
    Microsoft 365 Copilot active user count summary by app (informational, 30-day period)
    #>
    param($Tenant)

    # Reports aggregate active user counts per Copilot app (Teams, Outlook, Word, Excel, etc.)
    # for the past 30 days. Informational — shows which apps are driving Copilot adoption
    # and where engagement is low.

    try {
        $SummaryData = Get-CIPPTestData -TenantFilter $Tenant -Type 'CopilotUserCountSummary'

        if (-not $SummaryData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady016' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Copilot user count summary data found in database. Data collection may not yet have run for this tenant.' -Risk 'Informational' -Name 'Copilot active user count by app' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $Summary = if ($SummaryData -is [array]) { $SummaryData | Select-Object -First 1 } else { $SummaryData }

        # Get numeric app columns — exclude metadata fields
        $MetaFields = @('reportRefreshDate', 'reportPeriod', 'reportDate', 'id')
        $AppCounts = $Summary.PSObject.Properties | Where-Object {
            $_.Name -notin $MetaFields -and
            $null -ne $_.Value -and
            $_.Value -is [ValueType] -and
            $_.Value -isnot [bool]
        }

        $TotalAppCount = ($AppCounts | Measure-Object -Property Value -Sum).Sum ?? 0
        if (-not $AppCounts -or $TotalAppCount -eq 0) {
            $Result = "No Microsoft 365 Copilot usage was detected in the past 30 days.`n`n"
            $Result += 'This tenant either has no Copilot licenses assigned or users have not yet started using Copilot features.'
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady016' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Copilot active user count by app' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $Result = "## Copilot Active Users by App (Last 30 Days)`n`n"
        $Result += "| App | Active Users |`n"
        $Result += "|-----|-------------|`n"

        foreach ($App in ($AppCounts | Sort-Object Value -Descending)) {
            # Format the property name to be more readable — insert space before each capital
            # that follows a lowercase letter to avoid double-spacing sequences like 'AI' -> 'A I'
            $AppName = $App.Name -replace '([a-z])([A-Z])', '$1 $2' -replace 'Active Users', ''
            $Result += "| $($AppName.Trim()) | $($App.Value) |`n"
        }

        if ($Summary.reportRefreshDate) {
            $Result += "`n*Data as of $($Summary.reportRefreshDate).*"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady016' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Copilot active user count by app' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady016: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady016' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Copilot active user count by app' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady016.ps1' 62
#Region './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady017.ps1' -1

function Invoke-CippTestCopilotReady017 {
    <#
    .SYNOPSIS
    Microsoft 365 Copilot active user count trend - is adoption growing or declining?
    #>
    param($Tenant)

    # Uses the 7-day trend report to determine whether Copilot active user counts are
    # growing, stable, or declining. Compares the most recent day to the earliest day
    # in the trend window. Declining trend is flagged as a warning — it may indicate
    # user disengagement with Copilot and may warrant an adoption campaign.

    try {
        $TrendData = Get-CIPPTestData -TenantFilter $Tenant -Type 'CopilotUserCountTrend'

        if (-not $TrendData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady017' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Copilot user count trend data found in database. Data collection may not yet have run for this tenant.' -Risk 'Informational' -Name 'Copilot adoption trend (7-day)' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        $TrendPoints = @($TrendData | Where-Object { $_.reportDate } | Sort-Object reportDate)

        if ($TrendPoints.Count -eq 0) {
            $Result = "No Microsoft 365 Copilot usage trend data was found for the past 7 days.`n`n"
            $Result += 'This tenant either has no Copilot licenses assigned or users have not yet started using Copilot features.'
            Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady017' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Copilot adoption trend (7-day)' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
            return
        }

        # Find a consistent active user count field
        $CountField = $TrendPoints[0].PSObject.Properties.Name | Where-Object {
            $_ -notmatch 'report|date|id' -and $TrendPoints[0].$_ -match '^\d+$'
        } | Select-Object -First 1

        # Build trend table
        $Result = "## Copilot Active User Trend (Last 7 Days)`n`n"
        $Result += "| Date | Active Users |`n"
        $Result += "|------|-------------|`n"

        foreach ($Point in $TrendPoints) {
            $Count = if ($CountField) { $Point.$CountField } else { 'N/A' }
            $Result += "| $($Point.reportDate) | $Count |`n"
        }

        # Determine trend direction if we have a count field and at least 2 data points
        $Status = 'Informational'
        if ($CountField -and $TrendPoints.Count -ge 2) {
            $Earliest = [int]($TrendPoints[0].$CountField)
            $Latest = [int]($TrendPoints[-1].$CountField)
            $Delta = $Latest - $Earliest

            if ($Delta -gt 0) {
                $TrendIcon = '📈'
                $TrendText = "**Trending up** — active Copilot users increased by $Delta over the 7-day window."
            } elseif ($Delta -eq 0) {
                $TrendIcon = '➡️'
                $TrendText = '**Stable** — active Copilot user count is unchanged over the 7-day window.'
            } else {
                $TrendIcon = '📉'
                $TrendText = "**Trending down** — active Copilot users decreased by $([math]::Abs($Delta)) over the 7-day window. Consider reviewing adoption activities to re-engage users."
            }

            $Result += "`n$TrendIcon $TrendText"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady017' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Informational' -Name 'Copilot adoption trend (7-day)' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test CopilotReady017: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'CopilotReady017' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Copilot adoption trend (7-day)' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Copilot Readiness'
    }
}
#EndRegion './Public/Tests/CopilotReadiness/Identity/Invoke-CippTestCopilotReady017.ps1' 74
#Region './Public/Tests/Custom/Invoke-CippTestCustomScripts.ps1' -1

function Invoke-CippTestCustomScripts {
    <#
    .SYNOPSIS
    Run enabled custom scripts as CIPP tests
    #>
    param(
        $Tenant,
        [string]$ScriptGuid
    )

    try {
        $Table = Get-CippTable -tablename 'CustomPowershellScripts'
        $Filter = "PartitionKey eq 'CustomScript' and ScriptGuid eq '$ScriptGuid'"
        $Scripts = @(Get-CIPPAzDataTableEntity @Table -Filter $Filter)
        if (-not $Scripts) {
            return
        }

        $LatestScripts = $Scripts | Group-Object -Property ScriptGuid | ForEach-Object {
            $_.Group | Sort-Object -Property Version -Descending | Select-Object -First 1
        }

        if (-not [string]::IsNullOrWhiteSpace($ScriptGuid) -and $LatestScripts.Count -eq 0) {
            Write-Information "No latest custom script found for ScriptGuid: $ScriptGuid"
            return
        }

        foreach ($Script in $LatestScripts) {
            # We can't prefilter this on table lookup as each script version has its own Enabled property, so we need to check here if the latest version is enabled
            $IsEnabled = if ($Script.PSObject.Properties['Enabled']) { [bool]$Script.Enabled } else { $true }
            if (-not $IsEnabled) {
                continue
            }
            $ShouldAlert = $false
            if ($Script.PSObject.Properties['AlertOnFailure']) {
                $ShouldAlert = [bool]$Script.AlertOnFailure
            }

            $ResultMode = if ($Script.PSObject.Properties['ResultMode'] -and -not [string]::IsNullOrWhiteSpace($Script.ResultMode)) { $Script.ResultMode } else { 'Auto' }

            $TestId = "CustomScript-$($Script.ScriptGuid)"
            $ScriptName = if ([string]::IsNullOrWhiteSpace($Script.ScriptName)) { $TestId } else { $Script.ScriptName }
            try {
                $Result = New-CippCustomScriptExecution -ScriptGuid $Script.ScriptGuid -TenantFilter $Tenant -Parameters @{}

                # Check for explicit status wrapper: @{ CIPPStatus = 'Pass'|'Fail'|'Info'; CIPPResults = @(...); CIPPResultMarkdown = '...' }
                $ExplicitStatus = $null
                $ExplicitMarkdown = $null
                $ResultData = $Result
                if ($Result -is [hashtable] -and $Result.ContainsKey('CIPPStatus')) {
                    $ExplicitStatus = $Result['CIPPStatus']
                    $ResultData = if ($Result.ContainsKey('CIPPResults')) { $Result['CIPPResults'] } else { $null }
                    $ExplicitMarkdown = if ($Result.ContainsKey('CIPPResultMarkdown')) { $Result['CIPPResultMarkdown'] } else { $null }
                } elseif ($Result -is [PSCustomObject] -and $Result.PSObject.Properties['CIPPStatus']) {
                    $ExplicitStatus = $Result.CIPPStatus
                    $ResultData = if ($Result.PSObject.Properties['CIPPResults']) { $Result.CIPPResults } else { $null }
                    $ExplicitMarkdown = if ($Result.PSObject.Properties['CIPPResultMarkdown']) { $Result.CIPPResultMarkdown } else { $null }
                }

                $FailedRows = @($ResultData) | Where-Object {
                    $null -ne $_ -and
                    -not ($_ -is [bool] -and -not $_) -and
                    -not ($_ -is [string] -and [string]::IsNullOrWhiteSpace($_))
                }

                # Determine final status based on ResultMode
                $ResultDataJson = if ($FailedRows.Count -gt 0) { $FailedRows | ConvertTo-Json -Depth 10 -Compress } else { '[]' }

                # Auto-detected status from output, then apply explicit override if present
                $AutoStatus = if ($FailedRows.Count -gt 0) { 'Failed' } else { 'Passed' }
                $ValidExplicitStatuses = @('Passed', 'Failed', 'Info')
                if ($ExplicitStatus -and $ExplicitStatus -in $ValidExplicitStatuses) {
                    $AutoStatus = $ExplicitStatus
                }

                $FinalStatus = switch ($ResultMode) {
                    'AlwaysPass' { 'Passed' }
                    'AlwaysInfo' { 'Info' }
                    default { $AutoStatus }
                }

                $ResultMarkdown = if (-not [string]::IsNullOrWhiteSpace($ExplicitMarkdown)) { $ExplicitMarkdown } else { '' }
                Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Custom' -Status $FinalStatus -ResultDataJson $ResultDataJson -ResultMarkdown $ResultMarkdown -Risk ($Script.Risk ?? 'Medium') -Name $ScriptName -Pillar $Script.Pillar -UserImpact $Script.UserImpact -ImplementationEffort $Script.ImplementationEffort -Category 'Custom Script'

                if ($ShouldAlert -and $AutoStatus -eq 'Failed') {
                    Write-AlertMessage -tenant $Tenant -message "Custom script test failed: $ScriptName ($($Script.ScriptGuid))"
                }
            } catch {
                $ErrorMessage = Get-CippException -Exception $_
                $FinalStatus = switch ($ResultMode) {
                    'AlwaysPass' { 'Passed' }
                    'AlwaysInfo' { 'Info' }
                    default { 'Failed' }
                }
                Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Custom' -Status $FinalStatus -ResultMarkdown "Custom script execution failed: $($ErrorMessage.NormalizedError)" -Risk ($Script.Risk ?? 'Medium') -Name $ScriptName -Pillar $Script.Pillar -UserImpact $Script.UserImpact -ImplementationEffort $Script.ImplementationEffort -Category 'Custom Script'
                if ($ShouldAlert -and $ResultMode -eq 'Auto') {
                    Write-AlertMessage -tenant $Tenant -message "Custom script execution failed: $ScriptName ($($Script.ScriptGuid)) - $($ErrorMessage.NormalizedError)"
                }
            }
        }
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run custom script tests: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
    }
}
#EndRegion './Public/Tests/Custom/Invoke-CippTestCustomScripts.ps1' 106
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF01.ps1' -1

function Invoke-CippTestEIDSCAAF01 {
    <#
    .SYNOPSIS
    FIDO2 - State
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF01' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'FIDO2 - State' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
            return
        }

        $Fido2Config = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Fido2' }

        if (-not $Fido2Config) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'FIDO2 configuration not found in Authentication Methods Policy.' -Risk 'Low' -Name 'FIDO2 - State' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
            return
        }

        if ($Fido2Config.state -eq 'enabled') {
            $Status = 'Passed'
            $Result = 'FIDO2 authentication method is enabled'
        } else {
            $Status = 'Failed'
            $Result = @"
FIDO2 security keys should be enabled to provide strong, phishing-resistant authentication.

**Current Configuration:**
- State: $($Fido2Config.state)

**Recommended Configuration:**
- State: enabled

Enabling FIDO2 provides users with a secure, passwordless authentication option.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF01' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'FIDO2 - State' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'FIDO2 - State' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF01.ps1' 48
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF02.ps1' -1

function Invoke-CippTestEIDSCAAF02 {
    <#
    .SYNOPSIS
    FIDO2 - Self-Service
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF02' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'FIDO2 - Self-Service' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $Fido2Config = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Fido2' }

        if (-not $Fido2Config) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF02' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'FIDO2 configuration not found in Authentication Methods Policy.' -Risk 'Low' -Name 'FIDO2 - Self-Service' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        if ($Fido2Config.isSelfServiceRegistrationAllowed -eq $true) {
            $Status = 'Passed'
            $Result = 'FIDO2 self-service registration is enabled'
        } else {
            $Status = 'Failed'
            $Result = @"
FIDO2 self-service registration should be enabled to allow users to register their own security keys.

**Current Configuration:**
- isSelfServiceRegistrationAllowed: $($Fido2Config.isSelfServiceRegistrationAllowed)

**Recommended Configuration:**
- isSelfServiceRegistrationAllowed: true

Enabling self-service registration improves user experience and adoption of FIDO2 security keys.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF02' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'FIDO2 - Self-Service' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF02' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'FIDO2 - Self-Service' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF02.ps1' 48
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF03.ps1' -1

function Invoke-CippTestEIDSCAAF03 {
    <#
    .SYNOPSIS
    FIDO2 - Attestation
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF03' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'FIDO2 - Attestation' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
            return
        }

        $Fido2Config = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Fido2' }

        if (-not $Fido2Config) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF03' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'FIDO2 configuration not found in Authentication Methods Policy.' -Risk 'Medium' -Name 'FIDO2 - Attestation' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
            return
        }

        if ($Fido2Config.isAttestationEnforced -eq $true) {
            $Status = 'Passed'
            $Result = 'FIDO2 attestation enforcement is enabled'
        } else {
            $Status = 'Failed'
            $Result = @"
FIDO2 attestation should be enforced to verify the authenticity and security of FIDO2 security keys.

**Current Configuration:**
- isAttestationEnforced: $($Fido2Config.isAttestationEnforced)

**Recommended Configuration:**
- isAttestationEnforced: true

Enforcing attestation ensures that only trusted and verified security keys can be registered.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF03' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'FIDO2 - Attestation' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF03' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'FIDO2 - Attestation' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF03.ps1' 48
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF04.ps1' -1

function Invoke-CippTestEIDSCAAF04 {
    <#
    .SYNOPSIS
    FIDO2 - Key Restrictions
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF04' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'FIDO2 - Key Restrictions' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
            return
        }

        $Fido2Config = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Fido2' }

        if (-not $Fido2Config) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF04' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'FIDO2 configuration not found in Authentication Methods Policy.' -Risk 'Medium' -Name 'FIDO2 - Key Restrictions' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
            return
        }

        if ($Fido2Config.keyRestrictions.isEnforced -eq $true) {
            $Status = 'Passed'
            $Result = 'FIDO2 key restrictions are enforced'
        } else {
            $Status = 'Failed'
            $Result = @"
FIDO2 key restrictions should be enforced to control which security keys can be registered.

**Current Configuration:**
- keyRestrictions.isEnforced: $($Fido2Config.keyRestrictions.isEnforced)

**Recommended Configuration:**
- keyRestrictions.isEnforced: true

Enforcing key restrictions helps ensure only approved security keys are used in your organization.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF04' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'FIDO2 - Key Restrictions' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF04' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'FIDO2 - Key Restrictions' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF04.ps1' 48
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF05.ps1' -1

function Invoke-CippTestEIDSCAAF05 {
    <#
    .SYNOPSIS
    FIDO2 - Restricted Keys
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF05' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'FIDO2 - Restricted Keys' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
            return
        }

        $Fido2Config = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Fido2' }

        if (-not $Fido2Config) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF05' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'FIDO2 configuration not found in Authentication Methods Policy.' -Risk 'Medium' -Name 'FIDO2 - Restricted Keys' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
            return
        }

        $aaGuids = $Fido2Config.keyRestrictions.aaGuids
        if ($aaGuids -and $aaGuids.Count -gt 0) {
            $Status = 'Passed'
            $Result = "FIDO2 key restrictions have specific AAGuids configured ($($aaGuids.Count) GUIDs)"
        } else {
            $Status = 'Failed'
            $Result = @"
FIDO2 key restrictions should specify AAGuids to control which authenticator models can be registered.

**Current Configuration:**
- keyRestrictions.aaGuids: Empty or not configured

**Recommended Configuration:**
- keyRestrictions.aaGuids: Should contain one or more AAGuids

Specifying AAGuids allows you to restrict registration to specific, approved security key models.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF05' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'FIDO2 - Restricted Keys' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF05' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'FIDO2 - Restricted Keys' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF05.ps1' 49
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF06.ps1' -1

function Invoke-CippTestEIDSCAAF06 {
    <#
    .SYNOPSIS
    FIDO2 - Specific Keys
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF06' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'FIDO2 - Specific Keys' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
            return
        }

        $Fido2Config = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Fido2' }

        if (-not $Fido2Config) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF06' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'FIDO2 configuration not found in Authentication Methods Policy.' -Risk 'Medium' -Name 'FIDO2 - Specific Keys' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
            return
        }

        $aaGuids = $Fido2Config.keyRestrictions.aaGuids
        $enforcementType = $Fido2Config.keyRestrictions.enforcementType

        if ($aaGuids -and $aaGuids.Count -gt 0 -and $enforcementType -in @('allow', 'block')) {
            $Status = 'Passed'
            $Result = "FIDO2 key restrictions are properly configured with enforcement type '$enforcementType' and $($aaGuids.Count) AAGuids"
        } else {
            $Status = 'Failed'
            $Result = @"
FIDO2 key restrictions should have both AAGuids configured and a valid enforcement type (allow or block).

**Current Configuration:**
- keyRestrictions.aaGuids: $($aaGuids.Count) GUIDs configured
- keyRestrictions.enforcementType: $enforcementType

**Recommended Configuration:**
- keyRestrictions.aaGuids: One or more AAGuids
- keyRestrictions.enforcementType: 'allow' or 'block'

Proper enforcement type ensures the AAGuids list is actively used to control key registration.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF06' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'FIDO2 - Specific Keys' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAF06' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'FIDO2 - Specific Keys' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAF06.ps1' 53
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAG01.ps1' -1

function Invoke-CippTestEIDSCAAG01 {
    <#
    .SYNOPSIS
    Authentication Methods - Policy Migration
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAG01' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Authentication Methods - Policy Migration' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $MigrationState = $AuthMethodsPolicy.policyMigrationState

        if ($MigrationState -in @('migrationComplete', '')) {
            $Status = 'Passed'
            $Result = "Policy migration is complete or not applicable: $MigrationState"
        } else {
            $Status = 'Failed'
            $Result = @"
The authentication methods policy migration should be complete.

**Current Configuration:**
- policyMigrationState: $MigrationState

**Recommended Configuration:**
- policyMigrationState: migrationComplete or empty

Complete the migration to use the modern authentication methods policy.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAG01' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Authentication Methods - Policy Migration' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAG01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Authentication Methods - Policy Migration' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAG01.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAG02.ps1' -1

function Invoke-CippTestEIDSCAAG02 {
    <#
    .SYNOPSIS
    Authentication Methods - Report Suspicious Activity
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAG02' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Authentication Methods - Report Suspicious Activity' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $SuspiciousActivityState = $AuthMethodsPolicy.reportSuspiciousActivitySettings.state

        if ($SuspiciousActivityState -eq 'enabled') {
            $Status = 'Passed'
            $Result = 'Report suspicious activity is enabled'
        } else {
            $Status = 'Failed'
            $Result = @"
Report suspicious activity should be enabled to allow users to report fraudulent MFA attempts.

**Current Configuration:**
- reportSuspiciousActivitySettings.state: $SuspiciousActivityState

**Recommended Configuration:**
- reportSuspiciousActivitySettings.state: enabled

This feature helps detect and prevent unauthorized access attempts.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAG02' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Authentication Methods - Report Suspicious Activity' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAG02' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Authentication Methods - Report Suspicious Activity' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAG02.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAG03.ps1' -1

function Invoke-CippTestEIDSCAAG03 {
    <#
    .SYNOPSIS
    Authentication Methods - Suspicious Activity Target
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAG03' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Authentication Methods - Suspicious Activity Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $IncludeTargetId = $AuthMethodsPolicy.reportSuspiciousActivitySettings.includeTarget.id

        if ($IncludeTargetId -eq 'all_users') {
            $Status = 'Passed'
            $Result = 'Report suspicious activity is enabled for all users'
        } else {
            $Status = 'Failed'
            $Result = @"
Report suspicious activity should be enabled for all users.

**Current Configuration:**
- reportSuspiciousActivitySettings.includeTarget.id: $IncludeTargetId

**Recommended Configuration:**
- reportSuspiciousActivitySettings.includeTarget.id: all_users

All users should be able to report suspicious authentication attempts.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAG03' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Authentication Methods - Suspicious Activity Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAG03' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Authentication Methods - Suspicious Activity Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAG03.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM01.ps1' -1

function Invoke-CippTestEIDSCAAM01 {
    <#
    .SYNOPSIS
    MS Authenticator - State
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM01' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'MS Authenticator - State' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $MethodConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'MicrosoftAuthenticator' }

        if ($MethodConfig.state -eq 'enabled') {
            $Status = 'Passed'
            $Result = 'Microsoft Authenticator authentication method is enabled.'
        } else {
            $Status = 'Failed'
            $Result = "Microsoft Authenticator authentication method is not enabled. Current state: $($MethodConfig.state)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM01' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'MS Authenticator - State' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'MS Authenticator - State' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM01.ps1' 33
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM02.ps1' -1

function Invoke-CippTestEIDSCAAM02 {
    <#
    .SYNOPSIS
    MS Authenticator - OTP Disabled
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM02' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'MS Authenticator - OTP Disabled' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $MethodConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'MicrosoftAuthenticator' }

        if ($MethodConfig.isSoftwareOathEnabled -eq $false) {
            $Status = 'Passed'
            $Result = 'Microsoft Authenticator software OATH is disabled.'
        } else {
            $Status = 'Failed'
            $Result = "Microsoft Authenticator software OATH is enabled. It should be disabled."
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM02' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'MS Authenticator - OTP Disabled' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM02' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'MS Authenticator - OTP Disabled' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM02.ps1' 33
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM03.ps1' -1

function Invoke-CippTestEIDSCAAM03 {
    <#
    .SYNOPSIS
    MS Authenticator - Number Matching
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM03' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'MS Authenticator - Number Matching' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $MethodConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'MicrosoftAuthenticator' }

        if ($MethodConfig.featureSettings.numberMatchingRequiredState.state -eq 'enabled') {
            $Status = 'Passed'
            $Result = 'Microsoft Authenticator number matching is enabled.'
        } else {
            $Status = 'Failed'
            $Result = "Microsoft Authenticator number matching is not enabled. Current state: $($MethodConfig.featureSettings.numberMatchingRequiredState.state)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM03' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'MS Authenticator - Number Matching' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM03' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'MS Authenticator - Number Matching' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM03.ps1' 33
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM04.ps1' -1

function Invoke-CippTestEIDSCAAM04 {
    <#
    .SYNOPSIS
    MS Authenticator - Number Matching Target
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM04' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'MS Authenticator - Number Matching Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $MethodConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'MicrosoftAuthenticator' }

        if ($MethodConfig.featureSettings.numberMatchingRequiredState.includeTarget.id -eq 'all_users') {
            $Status = 'Passed'
            $Result = 'Microsoft Authenticator number matching targets all users.'
        } else {
            $Status = 'Failed'
            $Result = "Microsoft Authenticator number matching does not target all users. Current target: $($MethodConfig.featureSettings.numberMatchingRequiredState.includeTarget.id)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM04' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'MS Authenticator - Number Matching Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM04' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'MS Authenticator - Number Matching Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM04.ps1' 33
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM06.ps1' -1

function Invoke-CippTestEIDSCAAM06 {
    <#
    .SYNOPSIS
    MS Authenticator - Show App Name
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM06' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'MS Authenticator - Show App Name' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $MethodConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'MicrosoftAuthenticator' }

        if ($MethodConfig.featureSettings.displayAppInformationRequiredState.state -eq 'enabled') {
            $Status = 'Passed'
            $Result = 'Microsoft Authenticator app information display is enabled.'
        } else {
            $Status = 'Failed'
            $Result = "Microsoft Authenticator app information display is not enabled. Current state: $($MethodConfig.featureSettings.displayAppInformationRequiredState.state)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM06' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'MS Authenticator - Show App Name' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM06' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'MS Authenticator - Show App Name' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM06.ps1' 33
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM07.ps1' -1

function Invoke-CippTestEIDSCAAM07 {
    <#
    .SYNOPSIS
    MS Authenticator - Show App Name Target
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM07' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'MS Authenticator - Show App Name Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $MethodConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'MicrosoftAuthenticator' }

        if ($MethodConfig.featureSettings.displayAppInformationRequiredState.includeTarget.id -eq 'all_users') {
            $Status = 'Passed'
            $Result = 'Microsoft Authenticator app information display targets all users.'
        } else {
            $Status = 'Failed'
            $Result = "Microsoft Authenticator app information display does not target all users. Current target: $($MethodConfig.featureSettings.displayAppInformationRequiredState.includeTarget.id)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM07' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'MS Authenticator - Show App Name Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM07' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'MS Authenticator - Show App Name Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM07.ps1' 33
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM09.ps1' -1

function Invoke-CippTestEIDSCAAM09 {
    <#
    .SYNOPSIS
    MS Authenticator - Show Location
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM09' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'MS Authenticator - Show Location' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $MethodConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'MicrosoftAuthenticator' }

        if ($MethodConfig.featureSettings.displayLocationInformationRequiredState.state -eq 'enabled') {
            $Status = 'Passed'
            $Result = 'Microsoft Authenticator location information display is enabled.'
        } else {
            $Status = 'Failed'
            $Result = "Microsoft Authenticator location information display is not enabled. Current state: $($MethodConfig.featureSettings.displayLocationInformationRequiredState.state)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM09' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'MS Authenticator - Show Location' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM09' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'MS Authenticator - Show Location' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}

#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM09.ps1' 34
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM10.ps1' -1

function Invoke-CippTestEIDSCAAM10 {
    <#
    .SYNOPSIS
    MS Authenticator - Show Location Target
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM10' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'MS Authenticator - Show Location Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $MethodConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'MicrosoftAuthenticator' }

        if ($MethodConfig.featureSettings.displayLocationInformationRequiredState.includeTarget.id -eq 'all_users') {
            $Status = 'Passed'
            $Result = 'Microsoft Authenticator location information display targets all users.'
        } else {
            $Status = 'Failed'
            $Result = "Microsoft Authenticator location information display does not target all users. Current target: $($MethodConfig.featureSettings.displayLocationInformationRequiredState.includeTarget.id)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM10' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'MS Authenticator - Show Location Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAM10' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'MS Authenticator - Show Location Target' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAM10.ps1' 33
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP01.ps1' -1

function Invoke-CippTestEIDSCAAP01 {
    <#
    .SYNOPSIS
    Authorization Policy - Self-Service Password Reset for Admins
    #>
    param($Tenant)

    try {
        $AuthorizationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthorizationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP01' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Authorization Policy - Self-Service Password Reset for Admins' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authorization Policy'
            return
        }

        $AllowedToUseSSPR = $AuthorizationPolicy.allowedToUseSSPR

        if ($AllowedToUseSSPR -eq $false) {
            $Status = 'Passed'
            $Result = 'Self-service password reset for administrators is disabled'
        } else {
            $Status = 'Failed'
            $Result = @"
Self-service password reset for administrators should be disabled for enhanced security.

**Current Configuration:**
- allowedToUseSSPR: $AllowedToUseSSPR

**Recommended Configuration:**
- allowedToUseSSPR: false

Administrators should follow more stringent password reset procedures rather than self-service options.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP01' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Authorization Policy - Self-Service Password Reset for Admins' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Authorization Policy - Self-Service Password Reset for Admins' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP01.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP04.ps1' -1

function Invoke-CippTestEIDSCAAP04 {
    <#
    .SYNOPSIS
    Authorization Policy - Guest Invite Restrictions
    #>
    param($Tenant)

    try {
        $AuthorizationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthorizationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP04' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Authorization Policy - Guest Invite Restrictions' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
            return
        }

        $AllowInvitesFrom = $AuthorizationPolicy.allowInvitesFrom

        if ($AllowInvitesFrom -in @('adminsAndGuestInviters', 'none')) {
            $Status = 'Passed'
            $Result = "Guest invite restrictions are properly configured: $AllowInvitesFrom"
        } else {
            $Status = 'Failed'
            $Result = @"
Guest invite restrictions should be set to limit who can invite guests for enhanced security.

**Current Configuration:**
- allowInvitesFrom: $AllowInvitesFrom

**Recommended Configuration:**
- allowInvitesFrom: adminsAndGuestInviters OR none

Restricting guest invitations helps maintain control over external access to your tenant.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP04' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Authorization Policy - Guest Invite Restrictions' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP04' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Authorization Policy - Guest Invite Restrictions' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP04.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP05.ps1' -1

function Invoke-CippTestEIDSCAAP05 {
    <#
    .SYNOPSIS
    Authorization Policy - Email-Based Subscription Sign-up
    #>
    param($Tenant)

    try {
        $AuthorizationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthorizationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP05' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Authorization Policy - Email-Based Subscription Sign-up' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authorization Policy'
            return
        }

        $AllowedToSignUp = $AuthorizationPolicy.allowedToSignUpEmailBasedSubscriptions

        if ($AllowedToSignUp -eq $false) {
            $Status = 'Passed'
            $Result = 'Email-based subscription sign-up is disabled'
        } else {
            $Status = 'Failed'
            $Result = @"
Email-based subscription sign-up should be disabled to prevent unauthorized subscriptions.

**Current Configuration:**
- allowedToSignUpEmailBasedSubscriptions: $AllowedToSignUp

**Recommended Configuration:**
- allowedToSignUpEmailBasedSubscriptions: false

Disabling email-based subscriptions helps maintain control over tenant access.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP05' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Authorization Policy - Email-Based Subscription Sign-up' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP05' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Authorization Policy - Email-Based Subscription Sign-up' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP05.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP06.ps1' -1

function Invoke-CippTestEIDSCAAP06 {
    <#
    .SYNOPSIS
    Authorization Policy - Email Validation Join
    #>
    param($Tenant)

    try {
        $AuthorizationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthorizationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP06' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Authorization Policy - Email Validation Join' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authorization Policy'
            return
        }

        $AllowEmailVerified = $AuthorizationPolicy.allowEmailVerifiedUsersToJoinOrganization

        if ($AllowEmailVerified -eq $false) {
            $Status = 'Passed'
            $Result = 'Users cannot join the tenant by email validation'
        } else {
            $Status = 'Failed'
            $Result = @"
Email-validated users should not be allowed to join the organization to prevent unauthorized access.

**Current Configuration:**
- allowEmailVerifiedUsersToJoinOrganization: $AllowEmailVerified

**Recommended Configuration:**
- allowEmailVerifiedUsersToJoinOrganization: false

Disabling this feature prevents unauthorized users from self-registering into your tenant.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP06' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Authorization Policy - Email Validation Join' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP06' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Authorization Policy - Email Validation Join' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP06.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP07.ps1' -1

function Invoke-CippTestEIDSCAAP07 {
    <#
    .SYNOPSIS
    Authorization Policy - Guest User Access
    #>
    param($Tenant)

    try {
        $AuthorizationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthorizationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP07' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Authorization Policy - Guest User Access' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
            return
        }

        $GuestUserRoleId = $AuthorizationPolicy.guestUserRoleId
        $ExpectedRoleId = '2af84b1e-32c8-42b7-82bc-daa82404023b'

        if ($GuestUserRoleId -eq $ExpectedRoleId) {
            $Status = 'Passed'
            $Result = 'Guest user access is restricted (most restrictive)'
        } else {
            $Status = 'Failed'
            $Result = @"
Guest user access should be set to the most restrictive level for enhanced security.

**Current Configuration:**
- guestUserRoleId: $GuestUserRoleId

**Recommended Configuration:**
- guestUserRoleId: $ExpectedRoleId (Most restrictive guest permissions)

This setting limits what guest users can see and do in your directory.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP07' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Authorization Policy - Guest User Access' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP07' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Authorization Policy - Guest User Access' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP07.ps1' 44
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP08.ps1' -1

function Invoke-CippTestEIDSCAAP08 {
    <#
    .SYNOPSIS
    Authorization Policy - User Consent Policy
    #>
    param($Tenant)

    try {
        $AuthorizationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthorizationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP08' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Authorization Policy - User Consent Policy' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
            return
        }

        $ConsentPolicy = $AuthorizationPolicy.permissionGrantPolicyIdsAssignedToDefaultUserRole
        $ExpectedPolicy = 'ManagePermissionGrantsForSelf.microsoft-user-default-low'

        if ($ConsentPolicy -contains $ExpectedPolicy) {
            $Status = 'Passed'
            $Result = 'User consent policy is set to low-risk permissions'
        } else {
            $Status = 'Failed'
            $Result = @"
User consent policy should be configured to only allow consent for low-risk applications.

**Current Configuration:**
- permissionGrantPolicyIdsAssignedToDefaultUserRole: $($ConsentPolicy -join ', ')

**Recommended Configuration:**
- permissionGrantPolicyIdsAssignedToDefaultUserRole: $ExpectedPolicy

This limits users to only consent to applications with low-risk permissions.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP08' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Authorization Policy - User Consent Policy' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP08' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Authorization Policy - User Consent Policy' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP08.ps1' 44
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP09.ps1' -1

function Invoke-CippTestEIDSCAAP09 {
    <#
    .SYNOPSIS
    Authorization Policy - Consent for Risky Apps
    #>
    param($Tenant)

    try {
        $AuthorizationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthorizationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP09' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Authorization Policy - Consent for Risky Apps' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
            return
        }

        $AllowConsentRiskyApps = $AuthorizationPolicy.allowUserConsentForRiskyApps

        if ($AllowConsentRiskyApps -eq $false) {
            $Status = 'Passed'
            $Result = 'User consent for risky apps is disabled'
        } else {
            $Status = 'Failed'
            $Result = @"
User consent for risk-based apps should be disabled to prevent users from consenting to potentially malicious applications.

**Current Configuration:**
- allowUserConsentForRiskyApps: $AllowConsentRiskyApps

**Recommended Configuration:**
- allowUserConsentForRiskyApps: false

Disabling this prevents users from consenting to apps identified as risky.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP09' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Authorization Policy - Consent for Risky Apps' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP09' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Authorization Policy - Consent for Risky Apps' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP09.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP10.ps1' -1

function Invoke-CippTestEIDSCAAP10 {
    <#
    .SYNOPSIS
    Authorization Policy - Users Can Create Apps
    #>
    param($Tenant)

    try {
        $AuthorizationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthorizationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP10' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Authorization Policy - Users Can Create Apps' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
            return
        }

        $AllowedToCreateApps = $AuthorizationPolicy.defaultUserRolePermissions.allowedToCreateApps

        if ($AllowedToCreateApps -eq $false) {
            $Status = 'Passed'
            $Result = 'Users cannot create application registrations'
        } else {
            $Status = 'Failed'
            $Result = @"
Users should not be allowed to create application registrations by default to maintain control over applications.

**Current Configuration:**
- defaultUserRolePermissions.allowedToCreateApps: $AllowedToCreateApps

**Recommended Configuration:**
- defaultUserRolePermissions.allowedToCreateApps: false

Only authorized users should be able to register applications in your tenant.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP10' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Authorization Policy - Users Can Create Apps' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP10' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Authorization Policy - Users Can Create Apps' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP10.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP14.ps1' -1

function Invoke-CippTestEIDSCAAP14 {
    <#
    .SYNOPSIS
    Authorization Policy - Users Can Read Other Users
    #>
    param($Tenant)

    try {
        $AuthorizationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthorizationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP14' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Authorization Policy - Users Can Read Other Users' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
            return
        }

        $AllowedToReadOtherUsers = $AuthorizationPolicy.defaultUserRolePermissions.allowedToReadOtherUsers

        if ($AllowedToReadOtherUsers -eq $true) {
            $Status = 'Passed'
            $Result = 'Users can read other users (standard behavior for collaboration)'
        } else {
            $Status = 'Failed'
            $Result = @"
Users should be allowed to read other users' basic profile information for collaboration purposes.

**Current Configuration:**
- defaultUserRolePermissions.allowedToReadOtherUsers: $AllowedToReadOtherUsers

**Recommended Configuration:**
- defaultUserRolePermissions.allowedToReadOtherUsers: true

This setting enables basic collaboration features like Teams and SharePoint.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP14' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Authorization Policy - Users Can Read Other Users' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAP14' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Authorization Policy - Users Can Read Other Users' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authorization Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAP14.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAS04.ps1' -1

function Invoke-CippTestEIDSCAAS04 {
    <#
    .SYNOPSIS
    SMS - No Sign-In
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAS04' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'SMS - No Sign-In' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $SmsConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Sms' }

        if (-not $SmsConfig) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAS04' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'SMS authentication configuration not found in Authentication Methods Policy.' -Risk 'High' -Name 'SMS - No Sign-In' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $InvalidTargets = @()
        if ($SmsConfig.includeTargets) {
            foreach ($target in $SmsConfig.includeTargets) {
                if ($target.isUsableForSignIn -ne $false) {
                    $InvalidTargets += $target.id
                }
            }
        }

        if ($InvalidTargets.Count -eq 0) {
            $Status = 'Passed'
            $Result = 'SMS authentication is not allowed for sign-in on any targets'
        } else {
            $Status = 'Failed'
            $Result = @"
SMS should not be allowed for sign-in as it is vulnerable to SIM swap and interception attacks. SMS should only be used for MFA verification, not primary authentication.

**Current Configuration:**
- Targets with sign-in enabled: $($InvalidTargets.Count)

**Recommended Configuration:**
- All includeTargets should have isUsableForSignIn: false

Disabling SMS for sign-in while keeping it for MFA provides better security.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAS04' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'SMS - No Sign-In' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAS04' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'SMS - No Sign-In' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAS04.ps1' 57
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAT01.ps1' -1

function Invoke-CippTestEIDSCAAT01 {
    <#
    .SYNOPSIS
    Temp Access Pass - State
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAT01' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Temp Access Pass - State' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $TAPConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'TemporaryAccessPass' }

        if (-not $TAPConfig) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAT01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'Temporary Access Pass configuration not found in Authentication Methods Policy.' -Risk 'Medium' -Name 'Temp Access Pass - State' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        if ($TAPConfig.state -eq 'enabled') {
            $Status = 'Passed'
            $Result = 'Temporary Access Pass is enabled'
        } else {
            $Status = 'Failed'
            $Result = @"
Temporary Access Pass should be enabled to facilitate secure onboarding of passwordless authentication methods.

**Current Configuration:**
- State: $($TAPConfig.state)

**Recommended Configuration:**
- State: enabled

Enabling TAP allows administrators to securely onboard users to passwordless authentication.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAT01' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Temp Access Pass - State' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAT01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Temp Access Pass - State' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAT01.ps1' 48
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAT02.ps1' -1

function Invoke-CippTestEIDSCAAT02 {
    <#
    .SYNOPSIS
    Temp Access Pass - One-Time
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAT02' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Temp Access Pass - One-Time' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $TAPConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'TemporaryAccessPass' }

        if (-not $TAPConfig) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAT02' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'Temporary Access Pass configuration not found in Authentication Methods Policy.' -Risk 'Medium' -Name 'Temp Access Pass - One-Time' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        if ($TAPConfig.isUsableOnce -eq $true) {
            $Status = 'Passed'
            $Result = 'Temporary Access Pass is configured for one-time use'
        } else {
            $Status = 'Failed'
            $Result = @"
Temporary Access Pass should be configured for one-time use to minimize security risks.

**Current Configuration:**
- isUsableOnce: $($TAPConfig.isUsableOnce)

**Recommended Configuration:**
- isUsableOnce: true

One-time use reduces the risk of TAP credential theft or misuse.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAT02' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Temp Access Pass - One-Time' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAT02' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Temp Access Pass - One-Time' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAT02.ps1' 48
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAV01.ps1' -1

function Invoke-CippTestEIDSCAAV01 {
    <#
    .SYNOPSIS
    Voice Call - Disabled
    #>
    param($Tenant)

    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAV01' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Voice Call - Disabled' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        $VoiceConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Voice' }

        if (-not $VoiceConfig) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAV01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'Voice authentication configuration not found in Authentication Methods Policy.' -Risk 'Medium' -Name 'Voice Call - Disabled' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
            return
        }

        if ($VoiceConfig.state -eq 'disabled') {
            $Status = 'Passed'
            $Result = 'Voice call authentication is disabled'
        } else {
            $Status = 'Failed'
            $Result = @"
Voice call authentication should be disabled as it is susceptible to social engineering and SIM swap attacks.

**Current Configuration:**
- State: $($VoiceConfig.state)

**Recommended Configuration:**
- State: disabled

Disabling voice calls reduces the attack surface by eliminating a less secure authentication method.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAV01' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Voice Call - Disabled' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAAV01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Voice Call - Disabled' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Authentication Methods'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAAV01.ps1' 48
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACP01.ps1' -1

function Invoke-CippTestEIDSCACP01 {
    <#
    .SYNOPSIS
    Consent Policy Settings - Group owner consent for apps accessing data
    #>
    param($Tenant)

    try {
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACP01' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Consent Policy Settings - Group owner consent for apps accessing data' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Consent Policy'
            return
        }

        $SettingValue = ($Settings.values | Where-Object { $_.name -eq 'EnableGroupSpecificConsent' }).value

        if ($SettingValue -eq 'False') {
            $Status = 'Passed'
            $Result = 'Group owner consent for apps is disabled'
        } else {
            $Status = 'Failed'
            $Result = @"
Group owner consent should be disabled to prevent unauthorized app permissions.

**Current Configuration:**
- EnableGroupSpecificConsent: $SettingValue

**Recommended Configuration:**
- EnableGroupSpecificConsent: False
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACP01' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Consent Policy Settings - Group owner consent for apps accessing data' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Consent Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACP01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Consent Policy Settings - Group owner consent for apps accessing data' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Consent Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACP01.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACP03.ps1' -1

function Invoke-CippTestEIDSCACP03 {
    <#
    .SYNOPSIS
    Consent Policy Settings - Block user consent for risky apps
    #>
    param($Tenant)

    try {
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACP03' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Consent Policy Settings - Block user consent for risky apps' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Consent Policy'
            return
        }

        $SettingValue = ($Settings.values | Where-Object { $_.name -eq 'BlockUserConsentForRiskyApps' }).value

        if ($SettingValue -eq 'true') {
            $Status = 'Passed'
            $Result = 'User consent for risky apps is blocked'
        } else {
            $Status = 'Failed'
            $Result = @"
User consent for risky apps should be blocked to prevent security risks.

**Current Configuration:**
- BlockUserConsentForRiskyApps: $SettingValue

**Recommended Configuration:**
- BlockUserConsentForRiskyApps: true
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACP03' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Consent Policy Settings - Block user consent for risky apps' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Consent Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACP03' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Consent Policy Settings - Block user consent for risky apps' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Consent Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACP03.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACP04.ps1' -1

function Invoke-CippTestEIDSCACP04 {
    <#
    .SYNOPSIS
    Consent Policy Settings - Users can request admin consent
    #>
    param($Tenant)

    try {
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACP04' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Consent Policy Settings - Users can request admin consent' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
            return
        }

        $SettingValue = ($Settings.values | Where-Object { $_.name -eq 'EnableAdminConsentRequests' }).value

        if ($SettingValue -eq 'true') {
            $Status = 'Passed'
            $Result = 'Users can request admin consent for apps'
        } else {
            $Status = 'Failed'
            $Result = @"
Users should be able to request admin consent to enable proper app approval workflows.

**Current Configuration:**
- EnableAdminConsentRequests: $SettingValue

**Recommended Configuration:**
- EnableAdminConsentRequests: true
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACP04' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Consent Policy Settings - Users can request admin consent' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACP04' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Consent Policy Settings - Users can request admin consent' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACP04.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACR01.ps1' -1

function Invoke-CippTestEIDSCACR01 {
    <#
    .SYNOPSIS
    Admin Consent - Enabled
    #>
    param($Tenant)

    try {
        $AdminConsentPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AdminConsentRequestPolicy'

        if (-not $AdminConsentPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR01' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Admin Consent - Enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
            return
        }

        if ($AdminConsentPolicy.isEnabled -eq $true) {
            $Status = 'Passed'
            $Result = 'Admin consent request workflow is enabled'
        } else {
            $Status = 'Failed'
            $Result = @"
Admin consent request workflow should be enabled to allow users to request administrator approval for applications.

**Current Configuration:**
- isEnabled: $($AdminConsentPolicy.isEnabled)

**Recommended Configuration:**
- isEnabled: true

Enabling this workflow provides a secure process for users to request access to applications requiring admin consent.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR01' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Admin Consent - Enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Admin Consent - Enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACR01.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACR02.ps1' -1

function Invoke-CippTestEIDSCACR02 {
    <#
    .SYNOPSIS
    Admin Consent - Notify Reviewers
    #>
    param($Tenant)

    try {
        $AdminConsentPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AdminConsentRequestPolicy'

        if (-not $AdminConsentPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR02' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Admin Consent - Notify Reviewers' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
            return
        }

        if ($AdminConsentPolicy.notifyReviewers -eq $true) {
            $Status = 'Passed'
            $Result = 'Admin consent reviewers are notified of new requests'
        } else {
            $Status = 'Failed'
            $Result = @"
Admin consent reviewers should be notified when new consent requests are submitted.

**Current Configuration:**
- notifyReviewers: $($AdminConsentPolicy.notifyReviewers)

**Recommended Configuration:**
- notifyReviewers: true

Enabling notifications ensures reviewers are promptly informed of pending consent requests.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR02' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Admin Consent - Notify Reviewers' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR02' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Admin Consent - Notify Reviewers' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACR02.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACR03.ps1' -1

function Invoke-CippTestEIDSCACR03 {
    <#
    .SYNOPSIS
    Admin Consent - Reminders
    #>
    param($Tenant)

    try {
        $AdminConsentPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AdminConsentRequestPolicy'

        if (-not $AdminConsentPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR03' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Admin Consent - Reminders' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
            return
        }

        if ($AdminConsentPolicy.remindersEnabled -eq $true) {
            $Status = 'Passed'
            $Result = 'Admin consent request reminders are enabled'
        } else {
            $Status = 'Failed'
            $Result = @"
Admin consent request reminders should be enabled to ensure timely review of pending requests.

**Current Configuration:**
- remindersEnabled: $($AdminConsentPolicy.remindersEnabled)

**Recommended Configuration:**
- remindersEnabled: true

Enabling reminders helps prevent consent requests from being overlooked or delayed.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR03' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Admin Consent - Reminders' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR03' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Admin Consent - Reminders' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACR03.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACR04.ps1' -1

function Invoke-CippTestEIDSCACR04 {
    <#
    .SYNOPSIS
    Admin Consent - Duration
    #>
    param($Tenant)

    try {
        $AdminConsentPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AdminConsentRequestPolicy'

        if (-not $AdminConsentPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR04' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Admin Consent - Duration' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
            return
        }

        $RequestDuration = $AdminConsentPolicy.requestDurationInDays

        if ($RequestDuration -le 30) {
            $Status = 'Passed'
            $Result = "Admin consent request duration is set to $RequestDuration days (30 days or less)"
        } else {
            $Status = 'Failed'
            $Result = @"
Admin consent request duration should be set to 30 days or less to ensure timely review.

**Current Configuration:**
- requestDurationInDays: $RequestDuration

**Recommended Configuration:**
- requestDurationInDays: 30 or less

A shorter duration ensures consent requests are reviewed and processed in a timely manner.
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR04' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Admin Consent - Duration' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCACR04' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Admin Consent - Duration' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Consent Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCACR04.ps1' 43
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAPR01.ps1' -1

function Invoke-CippTestEIDSCAPR01 {
    <#
    .SYNOPSIS
    Password Rule Settings - Password Protection Mode
    #>
    param($Tenant)

    try {
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR01' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Password Rule Settings - Password Protection Mode' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Password Policy'
            return
        }

        $SettingValue = ($Settings.values | Where-Object { $_.name -eq 'BannedPasswordCheckOnPremisesMode' }).value

        if ($SettingValue -eq 'Enforce') {
            $Status = 'Passed'
            $Result = 'Password protection mode is set to Enforce'
        } else {
            $Status = 'Failed'
            $Result = @"
Password protection mode should be set to Enforce to prevent weak passwords.

**Current Configuration:**
- BannedPasswordCheckOnPremisesMode: $SettingValue

**Recommended Configuration:**
- BannedPasswordCheckOnPremisesMode: Enforce
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR01' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Password Rule Settings - Password Protection Mode' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Password Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR01' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Password Rule Settings - Password Protection Mode' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Password Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAPR01.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAPR02.ps1' -1

function Invoke-CippTestEIDSCAPR02 {
    <#
    .SYNOPSIS
    Password Rule Settings - Enable password protection on Windows Server Active Directory
    #>
    param($Tenant)

    try {
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR02' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Password Rule Settings - Enable password protection on Windows Server Active Directory' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Password Policy'
            return
        }

        $SettingValue = ($Settings.values | Where-Object { $_.name -eq 'EnableBannedPasswordCheckOnPremises' }).value

        if ($SettingValue -eq 'True') {
            $Status = 'Passed'
            $Result = 'Password protection is enabled for on-premises Active Directory'
        } else {
            $Status = 'Failed'
            $Result = @"
Password protection should be enabled for on-premises Active Directory to prevent weak passwords.

**Current Configuration:**
- EnableBannedPasswordCheckOnPremises: $SettingValue

**Recommended Configuration:**
- EnableBannedPasswordCheckOnPremises: True
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR02' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Password Rule Settings - Enable password protection on Windows Server Active Directory' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Password Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR02' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Password Rule Settings - Enable password protection on Windows Server Active Directory' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Password Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAPR02.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAPR03.ps1' -1

function Invoke-CippTestEIDSCAPR03 {
    <#
    .SYNOPSIS
    Password Rule Settings - Enforce custom list
    #>
    param($Tenant)

    try {
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR03' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Password Rule Settings - Enforce custom list' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Password Policy'
            return
        }

        $SettingValue = ($Settings.values | Where-Object { $_.name -eq 'EnableBannedPasswordCheck' }).value

        if ($SettingValue -eq 'True') {
            $Status = 'Passed'
            $Result = 'Custom banned password list is enforced'
        } else {
            $Status = 'Failed'
            $Result = @"
Custom banned password list should be enforced to prevent common weak passwords.

**Current Configuration:**
- EnableBannedPasswordCheck: $SettingValue

**Recommended Configuration:**
- EnableBannedPasswordCheck: True
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR03' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Password Rule Settings - Enforce custom list' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Password Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR03' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Password Rule Settings - Enforce custom list' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Password Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAPR03.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAPR05.ps1' -1

function Invoke-CippTestEIDSCAPR05 {
    <#
    .SYNOPSIS
    Password Rule Settings - Lockout duration in seconds
    #>
    param($Tenant)

    try {
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR05' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Password Rule Settings - Lockout duration in seconds' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Password Policy'
            return
        }

        $SettingValue = ($Settings.values | Where-Object { $_.name -eq 'LockoutDurationInSeconds' }).value

        if ([int]$SettingValue -ge 60) {
            $Status = 'Passed'
            $Result = "Lockout duration is set to $SettingValue seconds (minimum 60 seconds required)"
        } else {
            $Status = 'Failed'
            $Result = @"
Lockout duration should be at least 60 seconds to protect against brute force attacks.

**Current Configuration:**
- LockoutDurationInSeconds: $SettingValue

**Recommended Configuration:**
- LockoutDurationInSeconds: 60 or greater
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR05' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Password Rule Settings - Lockout duration in seconds' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Password Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR05' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Password Rule Settings - Lockout duration in seconds' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Password Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAPR05.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAPR06.ps1' -1

function Invoke-CippTestEIDSCAPR06 {
    <#
    .SYNOPSIS
    Password Rule Settings - Lockout threshold
    #>
    param($Tenant)

    try {
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR06' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Password Rule Settings - Lockout threshold' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Password Policy'
            return
        }

        $SettingValue = ($Settings.values | Where-Object { $_.name -eq 'LockoutThreshold' }).value

        if ([int]$SettingValue -le 10) {
            $Status = 'Passed'
            $Result = "Lockout threshold is set to $SettingValue failed attempts (maximum 10 attempts recommended)"
        } else {
            $Status = 'Failed'
            $Result = @"
Lockout threshold should be 10 or fewer failed attempts to protect against brute force attacks.

**Current Configuration:**
- LockoutThreshold: $SettingValue

**Recommended Configuration:**
- LockoutThreshold: 10 or fewer
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR06' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Password Rule Settings - Lockout threshold' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Password Policy'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAPR06' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Password Rule Settings - Lockout threshold' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Password Policy'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAPR06.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAST08.ps1' -1

function Invoke-CippTestEIDSCAST08 {
    <#
    .SYNOPSIS
    Classification and M365 Groups - Allow Guests to become Group Owner
    #>
    param($Tenant)

    try {
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAST08' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Classification and M365 Groups - Allow Guests to become Group Owner' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Group Settings'
            return
        }

        $SettingValue = ($Settings.values | Where-Object { $_.name -eq 'AllowGuestsToBeGroupOwner' }).value

        if ($SettingValue -eq 'false') {
            $Status = 'Passed'
            $Result = 'Guests are not allowed to become group owners'
        } else {
            $Status = 'Failed'
            $Result = @"
Guests should not be allowed to become group owners to maintain proper access control.

**Current Configuration:**
- AllowGuestsToBeGroupOwner: $SettingValue

**Recommended Configuration:**
- AllowGuestsToBeGroupOwner: false
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAST08' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Classification and M365 Groups - Allow Guests to become Group Owner' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Group Settings'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAST08' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Classification and M365 Groups - Allow Guests to become Group Owner' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Group Settings'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAST08.ps1' 41
#Region './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAST09.ps1' -1

function Invoke-CippTestEIDSCAST09 {
    <#
    .SYNOPSIS
    Classification and M365 Groups - Allow Guests to have access to groups content
    #>
    param($Tenant)

    try {
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAST09' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Classification and M365 Groups - Allow Guests to have access to groups content' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Group Settings'
            return
        }

        $SettingValue = ($Settings.values | Where-Object { $_.name -eq 'AllowGuestsToAccessGroups' }).value

        if ($SettingValue -eq 'True') {
            $Status = 'Passed'
            $Result = 'Guests are allowed to access groups content'
        } else {
            $Status = 'Failed'
            $Result = @"
Guests should be allowed to access groups content for proper collaboration.

**Current Configuration:**
- AllowGuestsToAccessGroups: $SettingValue

**Recommended Configuration:**
- AllowGuestsToAccessGroups: True
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAST09' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Classification and M365 Groups - Allow Guests to have access to groups content' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Group Settings'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'EIDSCAST09' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Classification and M365 Groups - Allow Guests to have access to groups content' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Group Settings'
    }
}
#EndRegion './Public/Tests/EIDSCA/Identity/Invoke-CippTestEIDSCAST09.ps1' 41
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest001.ps1' -1

function Invoke-CippTestGenericTest001 {
    <#
    .SYNOPSIS
    Tenant License Overview — informational summary of all licenses in the tenant
    #>
    param($Tenant)

    try {
        $LicenseData = Get-CIPPTestData -TenantFilter $Tenant -Type 'LicenseOverview'

        if (-not $LicenseData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest001' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No license data found in the reporting database. Please sync the License Overview cache first.' -Risk 'Informational' -Name 'Tenant License Overview' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $Licenses = @($LicenseData)
        $TotalLicenses = ($Licenses | ForEach-Object { [int]$_.TotalLicenses } | Measure-Object -Sum).Sum
        $TotalUsed = ($Licenses | ForEach-Object { [int]$_.CountUsed } | Measure-Object -Sum).Sum
        $OverallUtilization = if ($TotalLicenses -gt 0) { [math]::Round(($TotalUsed / $TotalLicenses) * 100, 1) } else { 0 }

        $Result = "**Total Licenses:** $TotalLicenses | **In Use:** $TotalUsed | **Overall Utilization:** $OverallUtilization%`n`n"

        $Result += "| License | In Use | Total | Available | Utilization |`n"
        $Result += "|---------|--------|-------|-----------|-------------|`n"

        foreach ($License in ($Licenses | Sort-Object { [int]$_.TotalLicenses } -Descending)) {
            $LicName = $License.License
            $Used = [int]$License.CountUsed
            $Total = [int]$License.TotalLicenses
            $Available = $Total - $Used
            $Util = if ($Total -gt 0) { [math]::Round(($Used / $Total) * 100, 0) } else { 0 }
            $UtilIcon = if ($Util -ge 90) { "🟢 $Util%" } elseif ($Util -ge 70) { "🟡 $Util%" } else { "🟢 $Util%" }
            $Result += "| $LicName | $Used | $Total | $Available | $UtilIcon |`n"
        }


        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest001' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Tenant License Overview' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest001: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest001' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Tenant License Overview' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest001.ps1' 45
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest002.ps1' -1

function Invoke-CippTestGenericTest002 {
    <#
    .SYNOPSIS
    User License Overview — which users have which licenses assigned
    #>
    param($Tenant)

    try {
        $LicenseData = Get-CIPPTestData -TenantFilter $Tenant -Type 'LicenseOverview'

        if (-not $LicenseData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest002' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No license data found in the reporting database. Please sync the License Overview cache first.' -Risk 'Informational' -Name 'User License Overview' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $Licenses = @($LicenseData)

        # Build a map of user -> licenses
        $UserLicenseMap = @{}
        foreach ($License in $Licenses) {
            if (-not $License.AssignedUsers) { continue }
            $AssignedUsers = if ($License.AssignedUsers -is [string]) {
                try { $License.AssignedUsers | ConvertFrom-Json } catch { @() }
            } else { $License.AssignedUsers }

            foreach ($User in $AssignedUsers) {
                $UPN = $User.userPrincipalName
                if (-not $UPN) { continue }
                if (-not $UserLicenseMap.ContainsKey($UPN)) {
                    $UserLicenseMap[$UPN] = @{
                        DisplayName = $User.displayName
                        Licenses    = [System.Collections.Generic.List[string]]::new()
                    }
                }
                $UserLicenseMap[$UPN].Licenses.Add($License.License)
            }
        }

        if ($UserLicenseMap.Count -eq 0) {
            $Result = "No users with assigned licenses were found in the cached data.`n`nThis may indicate that the license data has not been synced recently, or no licenses have been assigned to individual users."
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest002' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'User License Overview' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $Result = "**Total Licensed Users:** $($UserLicenseMap.Count)`n`n"

        $Result += "| User | Licenses |`n"
        $Result += "|------|----------|`n"

        $SortedUsers = $UserLicenseMap.GetEnumerator() | Sort-Object { $_.Value.DisplayName }
        $DisplayCount = 0
        foreach ($Entry in $SortedUsers) {
            $DisplayName = $Entry.Value.DisplayName
            $LicList = ($Entry.Value.Licenses | Sort-Object) -join ', '
            $Result += "| $DisplayName | $LicList |`n"
            $DisplayCount++
            if ($DisplayCount -ge 100) { break }
        }

        if ($UserLicenseMap.Count -gt 100) {
            $Result += "`n*Showing 100 of $($UserLicenseMap.Count) licensed users.*`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest002' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'User License Overview' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest002: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest002' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'User License Overview' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest002.ps1' 72
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest003.ps1' -1

function Invoke-CippTestGenericTest003 {
    <#
    .SYNOPSIS
    License Renewal Report — upcoming renewal dates, terms, and trial status
    #>
    param($Tenant)

    try {
        $LicenseData = Get-CIPPTestData -TenantFilter $Tenant -Type 'LicenseOverview'

        if (-not $LicenseData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest003' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No license data found in the reporting database. Please sync the License Overview cache first.' -Risk 'Informational' -Name 'License Renewal Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $Licenses = @($LicenseData)

        $Result = ""

        $HasRenewals = $false
        $TrialCount = 0
        $UpcomingRenewals = [System.Collections.Generic.List[PSCustomObject]]::new()

        foreach ($License in $Licenses) {
            $TermInfo = if ($License.TermInfo -is [string]) {
                try { $License.TermInfo | ConvertFrom-Json } catch { @() }
            } else { $License.TermInfo }

            if (-not $TermInfo) { continue }

            foreach ($Term in $TermInfo) {
                $HasRenewals = $true
                if ($Term.IsTrial -eq $true) { $TrialCount++ }
                $UpcomingRenewals.Add([PSCustomObject]@{
                    License        = $License.License
                    Status         = $Term.Status
                    Term           = $Term.Term
                    Seats          = $Term.TotalLicenses
                    DaysUntilRenew = $Term.DaysUntilRenew
                    NextRenewal    = if ($Term.NextLifecycle) { ([datetime]$Term.NextLifecycle).ToString('yyyy-MM-dd') } else { 'Unknown' }
                    IsTrial        = $Term.IsTrial
                })
            }
        }

        if (-not $HasRenewals) {
            $Result += 'No subscription renewal information is available. This may indicate non-standard licensing or the data has not been synced recently.'
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest003' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'License Renewal Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        if ($TrialCount -gt 0) {
            $Result += "**⚠️ $TrialCount trial subscription(s) detected.** Trial licenses will expire and may cause users to lose access if not converted to paid subscriptions.`n`n"
        }

        $UrgentRenewals = @($UpcomingRenewals | Where-Object { $_.DaysUntilRenew -le 30 -and $_.DaysUntilRenew -ge 0 })
        if ($UrgentRenewals.Count -gt 0) {
            $Result += "**🔴 $($UrgentRenewals.Count) subscription(s) renewing within 30 days** — review these to ensure billing and seat counts are correct.`n`n"
        }

        $Sorted = $UpcomingRenewals | Sort-Object DaysUntilRenew

        $Result += "| License | Status | Billing Term | Seats | Renews In | Renewal Date | Trial |`n"
        $Result += "|---------|--------|--------------|-------|-----------|--------------|-------|`n"

        foreach ($Renewal in $Sorted) {
            $DaysLabel = if ($null -eq $Renewal.DaysUntilRenew) { 'Unknown' }
            elseif ($Renewal.DaysUntilRenew -lt 0) { 'Past due' }
            elseif ($Renewal.DaysUntilRenew -eq 0) { 'Today' }
            else { "$($Renewal.DaysUntilRenew) days" }
            $TrialLabel = if ($Renewal.IsTrial -eq $true) { '⚠️ Yes' } else { 'No' }
            $StatusIcon = switch ($Renewal.Status) {
                'Enabled' { "✅ $($Renewal.Status)" }
                'Warning' { "⚠️ $($Renewal.Status)" }
                'Suspended' { "🔴 $($Renewal.Status)" }
                'Deleted' { "❌ $($Renewal.Status)" }
                default { $Renewal.Status }
            }
            $Result += "| $($Renewal.License) | $StatusIcon | $($Renewal.Term) | $($Renewal.Seats) | $DaysLabel | $($Renewal.NextRenewal) | $TrialLabel |`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest003' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'License Renewal Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest003: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest003' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'License Renewal Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest003.ps1' 90
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest004.ps1' -1

function Invoke-CippTestGenericTest004 {
    <#
    .SYNOPSIS
    Tenant MFA Report — full MFA posture overview for all accounts
    #>
    param($Tenant)

    try {
        $MFAData = Get-CIPPTestData -TenantFilter $Tenant -Type 'MFAState'

        if (-not $MFAData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest004' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No MFA state data found in the reporting database. Please sync the MFA State cache first.' -Risk 'Informational' -Name 'Tenant MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $Users = @($MFAData | Where-Object { $_.UPN })
        if ($Users.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest004' -TestType 'Identity' -Status 'Informational' -ResultMarkdown 'MFA state data was found but contained no user records.' -Risk 'Informational' -Name 'Tenant MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $TotalUsers = $Users.Count
        $MFARegistered = @($Users | Where-Object { $_.MFARegistration -eq $true }).Count
        $MFACapable = @($Users | Where-Object { $_.MFACapable -eq $true }).Count
        $CoveredByCA = @($Users | Where-Object { $_.CoveredByCA -like 'Enforced*' }).Count
        $CoveredBySD = @($Users | Where-Object { $_.CoveredBySD -eq $true }).Count
        $PerUserMFA = @($Users | Where-Object { $_.PerUser -in @('Enforced', 'Enabled') }).Count
        $NotProtected = @($Users | Where-Object { $_.CoveredByCA -notlike 'Enforced*' -and $_.CoveredBySD -ne $true -and $_.PerUser -notin @('Enforced', 'Enabled') }).Count
        $AdminCount = @($Users | Where-Object { $_.IsAdmin -eq $true }).Count
        $MFARegPct = if ($TotalUsers -gt 0) { [math]::Round(($MFARegistered / $TotalUsers) * 100, 1) } else { 0 }

        $Result = "### Summary`n`n"
        $Result += "| Metric | Count |`n"
        $Result += "|--------|-------|`n"
        $Result += "| Total Accounts | $TotalUsers |`n"
        $Result += "| Admin Accounts | $AdminCount |`n"
        $Result += "| Registered for MFA | $MFARegistered ($MFARegPct%) |`n"
        $Result += "| MFA Capable | $MFACapable |`n"
        $Result += "| Protected by Conditional Access | $CoveredByCA |`n"
        $Result += "| Protected by Security Defaults | $CoveredBySD |`n"
        $Result += "| Using Per-User MFA (Legacy) | $PerUserMFA |`n"
        $Result += "| **Not Protected by Any MFA Policy** | **$NotProtected** |`n`n"

        if ($NotProtected -gt 0) {
            $Result += "**⚠️ $NotProtected account(s) have no MFA enforcement.** These accounts are at significantly higher risk of compromise. Consider enabling Conditional Access policies to require MFA for all users.`n`n"
        }

        $Result += "### All Accounts`n`n"
        $Result += "| Display Name | MFA Registered | MFA Method | Protected By | Account Type |`n"
        $Result += "|-------------|----------------|------------|--------------|--------------|`n"

        $DisplayUsers = $Users | Sort-Object DisplayName | Select-Object -First 100
        foreach ($User in $DisplayUsers) {
            $Name = $User.DisplayName
            $Registered = if ($User.MFARegistration -eq $true) { '✅ Yes' } else { '❌ No' }
            $Methods = if ($User.MFAMethods) {
                $MethodList = if ($User.MFAMethods -is [string]) {
                    try { ($User.MFAMethods | ConvertFrom-Json) -join ', ' } catch { $User.MFAMethods }
                } else { ($User.MFAMethods) -join ', ' }
                $MethodList -replace 'microsoftAuthenticator', 'Authenticator' -replace 'phoneAuthentication', 'Phone' -replace 'fido2', 'FIDO2' -replace 'softwareOneTimePasscode', 'Software OTP' -replace 'emailAuthentication', 'Email' -replace 'windowsHelloForBusiness', 'Windows Hello' -replace 'temporaryAccessPass', 'Temp Pass'
            } else { 'None' }
            $Protection = if ($User.CoveredByCA -like 'Enforced*') { "Conditional Access" }
            elseif ($User.CoveredBySD -eq $true) { 'Security Defaults' }
            elseif ($User.PerUser -in @('Enforced', 'Enabled')) { "Per-User MFA ($($User.PerUser))" }
            else { '❌ None' }
            $AcctType = if ($User.IsAdmin -eq $true) { '🔑 Admin' } else { 'User' }
            $Result += "| $Name | $Registered | $Methods | $Protection | $AcctType |`n"
        }

        if ($Users.Count -gt 100) {
            $Result += "`n*Showing 100 of $($Users.Count) accounts.*`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest004' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Tenant MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest004: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest004' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Tenant MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest004.ps1' 82
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest005.ps1' -1

function Invoke-CippTestGenericTest005 {
    <#
    .SYNOPSIS
    Admin MFA Report — MFA posture for administrator accounts only
    #>
    param($Tenant)

    try {
        $MFAData = Get-CIPPTestData -TenantFilter $Tenant -Type 'MFAState'

        if (-not $MFAData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest005' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No MFA state data found in the reporting database. Please sync the MFA State cache first.' -Risk 'Informational' -Name 'Admin MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $Admins = @($MFAData | Where-Object { $_.UPN -and $_.IsAdmin -eq $true })

        if ($Admins.Count -eq 0) {
            $Result = "No administrator accounts were found in the MFA state data. This is unusual and may indicate the data needs to be re-synced."
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest005' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Admin MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $TotalAdmins = $Admins.Count
        $MFARegistered = @($Admins | Where-Object { $_.MFARegistration -eq $true }).Count
        $NotProtected = @($Admins | Where-Object { $_.CoveredByCA -notlike 'Enforced*' -and $_.CoveredBySD -ne $true -and $_.PerUser -notin @('Enforced', 'Enabled') }).Count
        $MFARegPct = if ($TotalAdmins -gt 0) { [math]::Round(($MFARegistered / $TotalAdmins) * 100, 1) } else { 0 }

        $Result = "**Total Admins:** $TotalAdmins | **MFA Registered:** $MFARegistered ($MFARegPct%)"
        if ($NotProtected -gt 0) {
            $Result += " | **⚠️ Unprotected: $NotProtected**"
        }
        $Result += "`n`n"

        if ($NotProtected -gt 0) {
            $Result += "**🔴 Critical: $NotProtected admin account(s) have no MFA enforcement.** Admin accounts without MFA are the #1 target for attackers. This should be addressed immediately.`n`n"
        } elseif ($MFARegistered -eq $TotalAdmins) {
            $Result += "**✅ All admin accounts have MFA registered and enforced.** Great job keeping your most privileged accounts secured.`n`n"
        }

        $Result += "| Display Name | MFA Registered | MFA Method | Protected By | Account Enabled |`n"
        $Result += "|-------------|----------------|------------|--------------|-----------------|`n"

        foreach ($Admin in ($Admins | Sort-Object DisplayName)) {
            $Name = $Admin.DisplayName
            $Registered = if ($Admin.MFARegistration -eq $true) { '✅ Yes' } else { '❌ No' }
            $Methods = if ($Admin.MFAMethods) {
                $MethodList = if ($Admin.MFAMethods -is [string]) {
                    try { ($Admin.MFAMethods | ConvertFrom-Json) -join ', ' } catch { $Admin.MFAMethods }
                } else { ($Admin.MFAMethods) -join ', ' }
                $MethodList -replace 'microsoftAuthenticator', 'Authenticator' -replace 'phoneAuthentication', 'Phone' -replace 'fido2', 'FIDO2' -replace 'softwareOneTimePasscode', 'Software OTP' -replace 'emailAuthentication', 'Email' -replace 'windowsHelloForBusiness', 'Windows Hello' -replace 'temporaryAccessPass', 'Temp Pass'
            } else { 'None' }
            $Protection = if ($Admin.CoveredByCA -like 'Enforced*') { "Conditional Access" }
            elseif ($Admin.CoveredBySD -eq $true) { 'Security Defaults' }
            elseif ($Admin.PerUser -in @('Enforced', 'Enabled')) { "Per-User MFA ($($Admin.PerUser))" }
            else { '❌ None' }
            $Enabled = if ($Admin.AccountEnabled -eq $true) { 'Yes' } else { 'Disabled' }
            $Result += "| $Name | $Registered | $Methods | $Protection | $Enabled |`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest005' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Admin MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest005: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest005' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Admin MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest005.ps1' 69
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest006.ps1' -1

function Invoke-CippTestGenericTest006 {
    <#
    .SYNOPSIS
    User MFA Report — MFA posture for standard (non-admin) user accounts
    #>
    param($Tenant)

    try {
        $MFAData = Get-CIPPTestData -TenantFilter $Tenant -Type 'MFAState'

        if (-not $MFAData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest006' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No MFA state data found in the reporting database. Please sync the MFA State cache first.' -Risk 'Informational' -Name 'User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $StandardUsers = @($MFAData | Where-Object { $_.UPN -and $_.IsAdmin -ne $true })

        if ($StandardUsers.Count -eq 0) {
            $Result = "No standard (non-admin) user accounts were found in the MFA state data."
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest006' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $TotalUsers = $StandardUsers.Count
        $MFARegistered = @($StandardUsers | Where-Object { $_.MFARegistration -eq $true }).Count
        $NotProtected = @($StandardUsers | Where-Object { $_.CoveredByCA -notlike 'Enforced*' -and $_.CoveredBySD -ne $true -and $_.PerUser -notin @('Enforced', 'Enabled') }).Count
        $MFARegPct = if ($TotalUsers -gt 0) { [math]::Round(($MFARegistered / $TotalUsers) * 100, 1) } else { 0 }

        $Result = "**Total Users:** $TotalUsers | **MFA Registered:** $MFARegistered ($MFARegPct%)"
        if ($NotProtected -gt 0) {
            $Result += " | **Unprotected: $NotProtected**"
        }
        $Result += "`n`n"

        if ($NotProtected -gt 0) {
            $Result += "**⚠️ $NotProtected user account(s) have no MFA enforcement.** Consider enabling a Conditional Access policy that requires MFA for all users.`n`n"
        }

        $Result += "| Display Name | MFA Registered | MFA Method | Protected By | User Type |`n"
        $Result += "|-------------|----------------|------------|--------------|-----------|`n"

        $DisplayUsers = $StandardUsers | Sort-Object DisplayName | Select-Object -First 100
        foreach ($User in $DisplayUsers) {
            $Name = $User.DisplayName
            $Registered = if ($User.MFARegistration -eq $true) { '✅ Yes' } else { '❌ No' }
            $Methods = if ($User.MFAMethods) {
                $MethodList = if ($User.MFAMethods -is [string]) {
                    try { ($User.MFAMethods | ConvertFrom-Json) -join ', ' } catch { $User.MFAMethods }
                } else { ($User.MFAMethods) -join ', ' }
                $MethodList -replace 'microsoftAuthenticator', 'Authenticator' -replace 'phoneAuthentication', 'Phone' -replace 'fido2', 'FIDO2' -replace 'softwareOneTimePasscode', 'Software OTP' -replace 'emailAuthentication', 'Email' -replace 'windowsHelloForBusiness', 'Windows Hello' -replace 'temporaryAccessPass', 'Temp Pass'
            } else { 'None' }
            $Protection = if ($User.CoveredByCA -like 'Enforced*') { "Conditional Access" }
            elseif ($User.CoveredBySD -eq $true) { 'Security Defaults' }
            elseif ($User.PerUser -in @('Enforced', 'Enabled')) { "Per-User MFA ($($User.PerUser))" }
            else { '❌ None' }
            $UserType = if ($User.UserType -eq 'Guest') { 'Guest' } else { 'Member' }
            $Result += "| $Name | $Registered | $Methods | $Protection | $UserType |`n"
        }

        if ($StandardUsers.Count -gt 100) {
            $Result += "`n*Showing 100 of $($StandardUsers.Count) user accounts.*`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest006' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest006: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest006' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest006.ps1' 72
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest007.ps1' -1

function Invoke-CippTestGenericTest007 {
    <#
    .SYNOPSIS
    Licensed User MFA Report — MFA posture for licensed users only
    #>
    param($Tenant)

    try {
        $MFAData = Get-CIPPTestData -TenantFilter $Tenant -Type 'MFAState'

        if (-not $MFAData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest007' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No MFA state data found in the reporting database. Please sync the MFA State cache first.' -Risk 'Informational' -Name 'Licensed User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $LicensedUsers = @($MFAData | Where-Object { $_.UPN -and $_.isLicensed -eq $true })

        if ($LicensedUsers.Count -eq 0) {
            $Result = "No licensed user accounts were found in the MFA state data. This may indicate no licenses have been assigned or the data needs to be re-synced."
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest007' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Licensed User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $TotalUsers = $LicensedUsers.Count
        $MFARegistered = @($LicensedUsers | Where-Object { $_.MFARegistration -eq $true }).Count
        $NotProtected = @($LicensedUsers | Where-Object { $_.CoveredByCA -notlike 'Enforced*' -and $_.CoveredBySD -ne $true -and $_.PerUser -notin @('Enforced', 'Enabled') }).Count
        $Admins = @($LicensedUsers | Where-Object { $_.IsAdmin -eq $true }).Count
        $MFARegPct = if ($TotalUsers -gt 0) { [math]::Round(($MFARegistered / $TotalUsers) * 100, 1) } else { 0 }

        $Result = "**Licensed Users:** $TotalUsers | **Admins among them:** $Admins | **MFA Registered:** $MFARegistered ($MFARegPct%)"
        if ($NotProtected -gt 0) {
            $Result += " | **Unprotected: $NotProtected**"
        }
        $Result += "`n`n"

        if ($NotProtected -gt 0) {
            $Result += "**⚠️ $NotProtected licensed user(s) have no MFA enforcement.** These accounts have access to company data and email but are not protected by any MFA policy.`n`n"
        }

        $Result += "| Display Name | Role | MFA Registered | MFA Method | Protected By |`n"
        $Result += "|-------------|------|----------------|------------|--------------|`n"

        $DisplayUsers = $LicensedUsers | Sort-Object DisplayName | Select-Object -First 100
        foreach ($User in $DisplayUsers) {
            $Name = $User.DisplayName
            $Role = if ($User.IsAdmin -eq $true) { '🔑 Admin' } else { 'User' }
            $Registered = if ($User.MFARegistration -eq $true) { '✅ Yes' } else { '❌ No' }
            $Methods = if ($User.MFAMethods) {
                $MethodList = if ($User.MFAMethods -is [string]) {
                    try { ($User.MFAMethods | ConvertFrom-Json) -join ', ' } catch { $User.MFAMethods }
                } else { ($User.MFAMethods) -join ', ' }
                $MethodList -replace 'microsoftAuthenticator', 'Authenticator' -replace 'phoneAuthentication', 'Phone' -replace 'fido2', 'FIDO2' -replace 'softwareOneTimePasscode', 'Software OTP' -replace 'emailAuthentication', 'Email' -replace 'windowsHelloForBusiness', 'Windows Hello' -replace 'temporaryAccessPass', 'Temp Pass'
            } else { 'None' }
            $Protection = if ($User.CoveredByCA -like 'Enforced*') { "Conditional Access" }
            elseif ($User.CoveredBySD -eq $true) { 'Security Defaults' }
            elseif ($User.PerUser -in @('Enforced', 'Enabled')) { "Per-User MFA ($($User.PerUser))" }
            else { '❌ None' }
            $Result += "| $Name | $Role | $Registered | $Methods | $Protection |`n"
        }

        if ($LicensedUsers.Count -gt 100) {
            $Result += "`n*Showing 100 of $($LicensedUsers.Count) licensed user accounts.*`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest007' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Licensed User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest007: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest007' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Licensed User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest007.ps1' 73
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest008.ps1' -1

function Invoke-CippTestGenericTest008 {
    <#
    .SYNOPSIS
    Legacy Per-User MFA Report — accounts still using per-user MFA enforcement
    #>
    param($Tenant)

    try {
        $MFAData = Get-CIPPTestData -TenantFilter $Tenant -Type 'MFAState'

        if (-not $MFAData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest008' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No MFA state data found in the reporting database. Please sync the MFA State cache first.' -Risk 'Informational' -Name 'Legacy Per-User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $AllUsers = @($MFAData | Where-Object { $_.UPN })
        $PerUserMFAUsers = @($AllUsers | Where-Object { $_.PerUser -in @('Enforced', 'Enabled') })

        $Result = ""

        if ($PerUserMFAUsers.Count -eq 0) {
            $Result += "**✅ No accounts are using legacy Per-User MFA.** Your tenant is not relying on the deprecated per-user MFA enforcement method.`n`n"
            $Result += "Make sure your accounts are protected by Conditional Access policies or Security Defaults instead."
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest008' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Legacy Per-User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $EnforcedCount = @($PerUserMFAUsers | Where-Object { $_.PerUser -eq 'Enforced' }).Count
        $EnabledCount = @($PerUserMFAUsers | Where-Object { $_.PerUser -eq 'Enabled' }).Count
        $AdminsAffected = @($PerUserMFAUsers | Where-Object { $_.IsAdmin -eq $true }).Count

        $Result += "### Current Status`n`n"
        $Result += "**⚠️ $($PerUserMFAUsers.Count) account(s) are still using legacy Per-User MFA.**`n`n"
        $Result += "| Status | Count |`n"
        $Result += "|--------|-------|`n"
        $Result += "| Per-User MFA Enforced | $EnforcedCount |`n"
        $Result += "| Per-User MFA Enabled | $EnabledCount |`n"
        if ($AdminsAffected -gt 0) {
            $Result += "| Admin Accounts Affected | $AdminsAffected |`n"
        }
        $Result += "`n"

        $Result += "### Accounts Using Per-User MFA`n`n"
        $Result += "The following accounts should be migrated to Conditional Access policies:`n`n"
        $Result += "| Display Name | Per-User MFA Status | Also Covered by CA | Account Type | Licensed |`n"
        $Result += "|-------------|--------------------|--------------------|--------------|----------|`n"

        foreach ($User in ($PerUserMFAUsers | Sort-Object DisplayName)) {
            $Name = $User.DisplayName
            $PerUserStatus = $User.PerUser
            $CAProtected = if ($User.CoveredByCA -like 'Enforced*') { '✅ Yes' } else { '❌ No' }
            $AcctType = if ($User.IsAdmin -eq $true) { '🔑 Admin' } else { 'User' }
            $Licensed = if ($User.isLicensed -eq $true) { 'Yes' } else { 'No' }
            $Result += "| $Name | $PerUserStatus | $CAProtected | $AcctType | $Licensed |`n"
        }

        $Result += "`n### Recommended Migration Steps`n`n"
        $Result += "1. **Create a Conditional Access policy** that requires MFA for all users (or start with admins)`n"
        $Result += "2. **Verify** the Conditional Access policy is working correctly for affected users`n"
        $Result += "3. **Disable Per-User MFA** for each account listed above once confirmed`n"
        $Result += "4. **Test sign-in** to confirm users can still authenticate properly`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest008' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Legacy Per-User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest008: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest008' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Legacy Per-User MFA Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest008.ps1' 71
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest009.ps1' -1

function Invoke-CippTestGenericTest009 {
    <#
    .SYNOPSIS
    Secure Score Report — 14-day trend of Microsoft Secure Score
    #>
    param($Tenant)

    try {
        $SecureScoreData = Get-CIPPTestData -TenantFilter $Tenant -Type 'SecureScore'

        if (-not $SecureScoreData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest009' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No Secure Score data found in the reporting database. Please sync the Secure Score cache first.' -Risk 'Informational' -Name 'Secure Score Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $Scores = @($SecureScoreData | Where-Object { $_.currentScore -ne $null })
        if ($Scores.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest009' -TestType 'Identity' -Status 'Informational' -ResultMarkdown 'Secure Score data was found but contained no score records.' -Risk 'Informational' -Name 'Secure Score Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        # Sort by date ascending for trend display
        $SortedScores = $Scores | Sort-Object { if ($_.createdDateTime) { [datetime]$_.createdDateTime } else { [datetime]::MinValue } }

        $Latest = $SortedScores | Select-Object -Last 1
        $Oldest = $SortedScores | Select-Object -First 1
        $CurrentScore = [math]::Round([double]$Latest.currentScore, 1)
        $MaxScore = [math]::Round([double]$Latest.maxScore, 1)
        $ScorePct = if ($MaxScore -gt 0) { [math]::Round(($CurrentScore / $MaxScore) * 100, 1) } else { 0 }

        $OldestScore = [math]::Round([double]$Oldest.currentScore, 1)
        $ScoreChange = [math]::Round($CurrentScore - $OldestScore, 1)
        $TrendIcon = if ($ScoreChange -gt 0) { "📈 +$ScoreChange" } elseif ($ScoreChange -lt 0) { "📉 $ScoreChange" } else { '➡️ No change' }

        $Result = "### Current Score`n`n"
        $Result += "| Metric | Value |`n"
        $Result += "|--------|-------|`n"
        $Result += "| Current Score | **$CurrentScore** out of $MaxScore ($ScorePct%) |`n"
        $Result += "| 14-Day Trend | $TrendIcon |`n"
        $Result += "| Data Points | $($SortedScores.Count) days |`n`n"

        if ($ScorePct -ge 80) {
            $Result += "**✅ Strong security posture.** Your score is in the top tier. Keep monitoring to maintain this level.`n`n"
        } elseif ($ScorePct -ge 50) {
            $Result += "**🟡 Moderate security posture.** There's room for improvement. Review the recommended actions in your Microsoft 365 Security portal.`n`n"
        } else {
            $Result += "**🔴 Low security posture.** Significant improvements are recommended. Focus on the high-impact actions first.`n`n"
        }

        $Result += "### 14-Day Score Trend`n`n"
        $Result += "| Date | Score | Max Score | Percentage |`n"
        $Result += "|------|-------|-----------|------------|`n"

        foreach ($Score in $SortedScores) {
            $DateStr = if ($Score.createdDateTime) { ([datetime]$Score.createdDateTime).ToString('yyyy-MM-dd') } else { 'Unknown' }
            $DayScore = [math]::Round([double]$Score.currentScore, 1)
            $DayMax = [math]::Round([double]$Score.maxScore, 1)
            $DayPct = if ($DayMax -gt 0) { [math]::Round(($DayScore / $DayMax) * 100, 1) } else { 0 }
            $Result += "| $DateStr | $DayScore | $DayMax | $DayPct% |`n"
        }

        # Show top improvable controls if available
        if ($Latest.controlScores) {
            $Controls = if ($Latest.controlScores -is [string]) {
                try { $Latest.controlScores | ConvertFrom-Json } catch { @() }
            } else { $Latest.controlScores }

            $ImprovableControls = @($Controls | Where-Object { $_.score -ne $null } | ForEach-Object {
                $MaxControlScore = if ($_.maxScore) { [double]$_.maxScore } else { 0 }
                $CurrentControlScore = [double]$_.score
                $Gap = $MaxControlScore - $CurrentControlScore
                [PSCustomObject]@{
                    Name        = $_.controlName -replace '([a-z])([A-Z])', '$1 $2'
                    Score       = $CurrentControlScore
                    MaxScore    = $MaxControlScore
                    Gap         = $Gap
                    Description = $_.description
                }
            } | Where-Object { $_.Gap -gt 0 } | Sort-Object Gap -Descending | Select-Object -First 10)

            if ($ImprovableControls.Count -gt 0) {
                $Result += "`n### Top Improvement Opportunities`n`n"
                $Result += "| Control | Current | Max | Points Available |`n"
                $Result += "|---------|---------|-----|-----------------|`n"

                foreach ($Control in $ImprovableControls) {
                    $Result += "| $($Control.Name) | $($Control.Score) | $($Control.MaxScore) | +$($Control.Gap) |`n"
                }
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest009' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Secure Score Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest009: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest009' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Secure Score Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest009.ps1' 100
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest010.ps1' -1

function Invoke-CippTestGenericTest010 {
    <#
    .SYNOPSIS
    Tenant Capabilities Report — list of all service plans and features available in the tenant
    #>
    param($Tenant)

    try {
        # Try to get capabilities from cache first, fall back to live query
        $Capabilities = Get-CIPPTenantCapabilities -TenantFilter $Tenant

        if (-not $Capabilities) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest010' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No tenant capability data could be retrieved. The tenant may not be accessible or licenses may not be synced.' -Risk 'Informational' -Name 'Tenant Capabilities Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        $CapabilityProperties = $Capabilities.PSObject.Properties | Where-Object { $_.Value -eq $true }

        if (-not $CapabilityProperties -or $CapabilityProperties.Count -eq 0) {
            $Result = "No active service plans were found for this tenant. This is unusual and may indicate a licensing issue."
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest010' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Tenant Capabilities Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        # Load the ConversionTable for friendly names
        $FriendlyNameMap = @{}
        $ConvertTable = [System.IO.File]::ReadAllText((Join-Path $env:CIPPRootPath 'Config\ConversionTable.csv')) | ConvertFrom-Csv
        foreach ($Row in $ConvertTable) {
            if ($Row.Service_Plan_Name -and $Row.Service_Plans_Included_Friendly_Names) {
                if (-not $FriendlyNameMap.ContainsKey($Row.Service_Plan_Name)) {
                    $FriendlyNameMap[$Row.Service_Plan_Name] = $Row.Service_Plans_Included_Friendly_Names
                }
            }
        }

        $Result = "**Total Active Capabilities:** $($CapabilityProperties.Count)`n`n"

        # Categorize capabilities into logical groups
        $Categories = [ordered]@{
            'Email & Communication'     = @('EXCHANGE_S_ENTERPRISE', 'EXCHANGE_S_STANDARD', 'EXCHANGE_S_FOUNDATION', 'MCOSTANDARD', 'MCOEV', 'TEAMS1', 'MICROSOFTBOOKINGS', 'YAMMER_ENTERPRISE')
            'Office & Productivity'     = @('OFFICESUBSCRIPTION', 'SHAREPOINTENTERPRISE', 'SHAREPOINTWAC', 'SWAY', 'FORMS_PLAN_E5', 'FORMS_PLAN_E3', 'PROJECTWORKMANAGEMENT', 'MICROSOFT_LOOP', 'CLIPCHAMP', 'MESH_IMMERSIVE_FOR_TEAMS', 'MESH_AVATARS_FOR_TEAMS', 'MESH_AVATARS_ADDITIONAL_FOR_TEAMS', 'WHITEBOARD_PLAN3', 'BPOS_S_TODO_3')
            'Power Platform'            = @('POWERAPPS_O365_P3', 'POWERAPPS_O365_P2', 'FLOW_O365_P3', 'FLOW_O365_P2', 'BI_AZURE_P2', 'BI_AZURE_P1', 'POWER_VIRTUAL_AGENTS_O365_P3', 'CDS_O365_P3', 'DYN365_CDS_O365_P3', 'PROJECT_O365_P3')
            'Security & Identity'       = @('AAD_PREMIUM', 'AAD_PREMIUM_P2', 'MFA_PREMIUM', 'RMS_S_ENTERPRISE', 'RMS_S_PREMIUM', 'RMS_S_PREMIUM2', 'ATA', 'ADALLOM_S_STANDALONE', 'ADALLOM_S_O365', 'MTP', 'ATP_ENTERPRISE', 'THREAT_INTELLIGENCE', 'SAFEDOCS', 'COMMON_DEFENDER_PLATFORM_FOR_OFFICE')
            'Compliance & Governance'   = @('MIP_S_CLP1', 'MIP_S_CLP2', 'MIP_S_Exchange', 'LOCKBOX_ENTERPRISE', 'CustomerLockboxA_Enterprise', 'CUSTOMER_KEY', 'RECORDS_MANAGEMENT', 'INFO_GOVERNANCE', 'ML_CLASSIFICATION', 'EQUIVIO_ANALYTICS', 'INSIDER_RISK', 'INSIDER_RISK_MANAGEMENT', 'COMMUNICATIONS_COMPLIANCE', 'COMMUNICATIONS_DLP', 'MICROSOFT_COMMUNICATION_COMPLIANCE', 'DATA_INVESTIGATIONS', 'M365_ADVANCED_AUDITING', 'M365_AUDIT_PLATFORM', 'PAM_ENTERPRISE', 'Content_Explorer', 'PURVIEW_DISCOVERY')
            'Device Management'         = @('INTUNE_A', 'INTUNE_O365')
            'Analytics & Insights'      = @('EXCHANGE_ANALYTICS', 'MICROSOFT_MYANALYTICS_FULL', 'INSIGHTS_BY_MYANALYTICS', 'VIVA_LEARNING_SEEDED', 'PEOPLE_SKILLS_FOUNDATION', 'MICROSOFT_SEARCH', 'Bing_Chat_Enterprise', 'GRAPH_CONNECTORS_SEARCH_INDEX')
            'Collaboration & Storage'   = @('STREAM_O365_E5', 'Nucleus', 'Deskless', 'EXCEL_PREMIUM', 'PLACES_CORE', 'M365_LIGHTHOUSE_CUSTOMER_PLAN1')
        }

        $CategorizedPlanNames = $Categories.Values | ForEach-Object { $_ }
        $AllPlanNames = @($CapabilityProperties | Select-Object -ExpandProperty Name)

        foreach ($CategoryName in $Categories.Keys) {
            $CategoryPlans = @($AllPlanNames | Where-Object { $_ -in $Categories[$CategoryName] })
            if ($CategoryPlans.Count -eq 0) { continue }

            $Result += "### $CategoryName`n`n"
            $Result += "| Capability | Service Plan |`n"
            $Result += "|------------|-------------|`n"

            foreach ($Plan in ($CategoryPlans | Sort-Object)) {
                $FriendlyName = if ($FriendlyNameMap.ContainsKey($Plan)) {
                    $FriendlyNameMap[$Plan]
                } else {
                    # Convert raw plan name to readable format
                    $Plan -replace '_', ' ' -replace '([a-z])([A-Z])', '$1 $2' -replace ' S ', ' ' -replace ' O365 ', ' ' -replace ' P\d$', '' -replace ' ENTERPRISE', '' -replace ' PREMIUM', ' Premium' -replace ' STANDARD', ''
                }
                $Result += "| $FriendlyName | $Plan |`n"
            }
            $Result += "`n"
        }

        # Any uncategorized plans
        $Uncategorized = @($AllPlanNames | Where-Object { $_ -notin $CategorizedPlanNames })
        if ($Uncategorized.Count -gt 0) {
            $Result += "### Other Capabilities`n`n"
            $Result += "| Capability | Service Plan |`n"
            $Result += "|------------|-------------|`n"

            foreach ($Plan in ($Uncategorized | Sort-Object)) {
                $FriendlyName = if ($FriendlyNameMap.ContainsKey($Plan)) {
                    $FriendlyNameMap[$Plan]
                } else {
                    $Plan -replace '_', ' ' -replace '([a-z])([A-Z])', '$1 $2' -replace ' S ', ' ' -replace ' O365 ', ' ' -replace ' P\d$', '' -replace ' ENTERPRISE', '' -replace ' PREMIUM', ' Premium' -replace ' STANDARD', ''
                }
                $Result += "| $FriendlyName | $Plan |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest010' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Tenant Capabilities Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest010: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest010' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Tenant Capabilities Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest010.ps1' 98
#Region './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest011.ps1' -1

function Invoke-CippTestGenericTest011 {
    <#
    .SYNOPSIS
    Standard Alignment Report — compliance status of applied standards templates
    #>
    param($Tenant)

    try {
        $AlignmentData = Get-CIPPTenantAlignment -TenantFilter $Tenant

        if (-not $AlignmentData) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest011' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No standards alignment data found for this tenant. Ensure at least one standards template is assigned and data collection has run.' -Risk 'Informational' -Name 'Standard Alignment Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
            return
        }

        # Load standards.json for friendly name resolution
        $StandardsLabelMap = @{}
        $StandardsJsonPath = Join-Path $env:CIPPRootPath 'Config\standards.json'
        if (Test-Path $StandardsJsonPath) {
            $StandardsJson = Get-Content $StandardsJsonPath -Raw | ConvertFrom-Json
            foreach ($Std in $StandardsJson) {
                if ($Std.name -and $Std.label) {
                    $StandardsLabelMap[$Std.name] = $Std.label
                }
            }
        }

        # Load Intune templates from table storage for display name resolution
        $TemplateTable = Get-CippTable -tablename 'templates'
        $AllIntuneTemplates = @()
        $AllCATemplates = @()
        try {
            $RawIntuneTemplates = Get-CIPPAzDataTableEntity @TemplateTable -Filter "PartitionKey eq 'IntuneTemplate'"
            $AllIntuneTemplates = @($RawIntuneTemplates | ForEach-Object {
                $JSONData = $_.JSON | ConvertFrom-Json -Depth 10
                $data = $JSONData.RAWJson | ConvertFrom-Json -Depth 10
                $data | Add-Member -NotePropertyName 'displayName' -NotePropertyValue $JSONData.Displayname -Force
                $data | Add-Member -NotePropertyName 'GUID' -NotePropertyValue $_.RowKey -Force
                $data
            })
        } catch { $AllIntuneTemplates = @() }

        # Load Conditional Access templates
        try {
            $RawCATemplates = Get-CIPPAzDataTableEntity @TemplateTable -Filter "PartitionKey eq 'CATemplate'"
            $AllCATemplates = @($RawCATemplates | ForEach-Object {
                $data = $_.JSON | ConvertFrom-Json -Depth 100
                $data | Add-Member -NotePropertyName 'GUID' -NotePropertyValue $_.RowKey -Force
                $data
            })
        } catch { $AllCATemplates = @() }

        $AlignmentItems = @($AlignmentData)
        $Result = ''

        # Helper: resolve a standard name to a friendly display name
        # Mirrors the resolution chain from Get-CIPPDrift.ps1 and the frontend drift.js
        $ResolveDisplayName = {
            param($StandardName, $TemplateSettings)

            # 1. Regular standards — look up in standards.json
            if ($StandardsLabelMap.ContainsKey($StandardName)) {
                return $StandardsLabelMap[$StandardName]
            }

            # 2. IntuneTemplate — extract GUID, look up in template table, fall back to standardSettings
            if ($StandardName -like '*IntuneTemplate*') {
                $Parts = $StandardName.Split('.')
                $TemplateGuid = $Parts | Where-Object {
                    $_ -match '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
                } | Select-Object -First 1

                if ($TemplateGuid) {
                    # Try template table first
                    $MatchedTemplate = $AllIntuneTemplates | Where-Object { $_.GUID -match "$TemplateGuid" }
                    if ($MatchedTemplate -and $MatchedTemplate.displayName) {
                        return "Intune - $($MatchedTemplate.displayName)"
                    }
                    # Fall back to standardSettings TemplateList.label
                    if ($TemplateSettings -and $TemplateSettings.IntuneTemplate) {
                        $IntuneTemplates = @($TemplateSettings.IntuneTemplate)
                        $Match = $IntuneTemplates | Where-Object { $_.TemplateList.value -eq $TemplateGuid }
                        if ($Match -and $Match.TemplateList.label) {
                            return "Intune - $($Match.TemplateList.label)"
                        }
                    }
                }
                return $null
            }

            # 3. ConditionalAccessTemplate — extract GUID, look up in template table
            if ($StandardName -like '*ConditionalAccessTemplate*') {
                $Parts = $StandardName.Split('.')
                $TemplateGuid = $Parts | Where-Object {
                    $_ -match '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
                } | Select-Object -First 1

                if ($TemplateGuid) {
                    $MatchedTemplate = $AllCATemplates | Where-Object { $_.GUID -match "$TemplateGuid" }
                    if ($MatchedTemplate -and $MatchedTemplate.displayName) {
                        return "Conditional Access - $($MatchedTemplate.displayName)"
                    }
                    if ($TemplateSettings -and $TemplateSettings.ConditionalAccessTemplate) {
                        $CATemplates = @($TemplateSettings.ConditionalAccessTemplate)
                        $Match = $CATemplates | Where-Object { $_.TemplateList.value -eq $TemplateGuid }
                        if ($Match -and $Match.TemplateList.label) {
                            return "Conditional Access - $($Match.TemplateList.label)"
                        }
                    }
                }
                return $null
            }

            # 4. QuarantineTemplate — hex decode the policy display name
            if ($StandardName -like 'standards.QuarantineTemplate.*') {
                $HexEncodedName = $StandardName.Substring('standards.QuarantineTemplate.'.Length)
                if ($HexEncodedName) {
                    $Chars = [System.Collections.Generic.List[char]]::new()
                    for ($i = 0; $i -lt $HexEncodedName.Length; $i += 2) {
                        $Chars.Add([char][Convert]::ToInt32($HexEncodedName.Substring($i, 2), 16))
                    }
                    return "Quarantine Policy - $(-join $Chars)"
                }
                return $null
            }

            # 5. Not found in any source
            return $null
        }

        foreach ($Template in $AlignmentItems) {
            $TemplateName = $Template.StandardName
            $Score = $Template.AlignmentScore
            $Compliant = $Template.CompliantStandards
            $NonCompliant = $Template.NonCompliantStandards
            $LicenseMissing = $Template.LicenseMissingStandards
            $Total = $Template.TotalStandards
            $ReportingDisabled = $Template.ReportingDisabledCount

            $ScoreIcon = if ($Score -ge 80) { '✅' } elseif ($Score -ge 50) { '🟡' } else { '🔴' }

            $Result += "### $TemplateName`n`n"
            $Result += "**Alignment Score:** $ScoreIcon $Score% | **Compliant:** $Compliant / $Total"
            if ($LicenseMissing -gt 0) { $Result += " | **License Missing:** $LicenseMissing" }
            if ($ReportingDisabled -gt 0) { $Result += " | **Reporting Disabled:** $ReportingDisabled" }
            if ($Template.LatestDataCollection) {
                $CollectionDate = ([datetime]$Template.LatestDataCollection).ToString('yyyy-MM-dd HH:mm')
                $Result += " | **Last Checked:** $CollectionDate"
            }
            $Result += "`n`n"

            $Details = $Template.ComparisonDetails
            if (-not $Details) {
                $Result += "No comparison details available for this template.`n`n"
                continue
            }

            # Split into categories
            $CompliantItems = @($Details | Where-Object { $_.ComplianceStatus -eq 'Compliant' })
            $NonCompliantItems = @($Details | Where-Object { $_.ComplianceStatus -eq 'Non-Compliant' })
            $LicenseMissingItems = @($Details | Where-Object { $_.ComplianceStatus -eq 'License Missing' })
            $ReportingDisabledItems = @($Details | Where-Object { $_.ComplianceStatus -eq 'Reporting Disabled' })

            # Helper to resolve and skip unresolvable template items
            $TemplateSettings = $Template.standardSettings

            # Compliant items
            if ($CompliantItems.Count -gt 0) {
                $Result += "| Standard | Status |`n"
                $Result += "|----------|--------|`n"
                foreach ($Item in $CompliantItems) {
                    $FriendlyName = & $ResolveDisplayName $Item.StandardName $TemplateSettings
                    if (-not $FriendlyName) { continue }
                    $Result += "| $FriendlyName | ✅ Compliant |`n"
                }
                $Result += "`n"
            }

            # Non-compliant items
            if ($NonCompliantItems.Count -gt 0) {
                $Result += "| Standard | Status |`n"
                $Result += "|----------|--------|`n"
                foreach ($Item in $NonCompliantItems) {
                    $FriendlyName = & $ResolveDisplayName $Item.StandardName $TemplateSettings
                    if (-not $FriendlyName) { continue }
                    $Result += "| $FriendlyName | ❌ Non-Compliant |`n"
                }
                $Result += "`n"
            }

            # License missing items
            if ($LicenseMissingItems.Count -gt 0) {
                $Result += "#### Standards Not Applied Due to Missing Licenses`n`n"
                $Result += "These items are part of this baseline, but your environment does not meet the minimum required licenses for them to be applied.`n`n"
                $Result += "| Standard | Status |`n"
                $Result += "|----------|--------|`n"
                foreach ($Item in $LicenseMissingItems) {
                    $FriendlyName = & $ResolveDisplayName $Item.StandardName $TemplateSettings
                    if (-not $FriendlyName) { continue }
                    $Result += "| $FriendlyName | ⚠️ License Missing |`n"
                }
                $Result += "`n"
            }

            # Reporting disabled items
            if ($ReportingDisabledItems.Count -gt 0) {
                $Result += "#### Standards With Reporting Disabled`n`n"
                $Result += "| Standard | Status |`n"
                $Result += "|----------|--------|`n"
                foreach ($Item in $ReportingDisabledItems) {
                    $FriendlyName = & $ResolveDisplayName $Item.StandardName $TemplateSettings
                    if (-not $FriendlyName) { continue }
                    $Result += "| $FriendlyName | ⏸️ Reporting Disabled |`n"
                }
                $Result += "`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest011' -TestType 'Identity' -Status 'Informational' -ResultMarkdown $Result -Risk 'Informational' -Name 'Standard Alignment Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test GenericTest011: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'GenericTest011' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Informational' -Name 'Standard Alignment Report' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant Overview'
    }
}
#EndRegion './Public/Tests/GenericTests/Identity/Invoke-CippTestGenericTest011.ps1' 227
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA100.ps1' -1

function Invoke-CippTestORCA100 {
    <#
    .SYNOPSIS
    Bulk Complaint Level threshold is between 4 and 6
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA100' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Bulk Complaint Level threshold is between 4 and 6' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            # Check if BulkThreshold is between 4 and 6 (inclusive)
            if ($Policy.BulkThreshold -ge 4 -and $Policy.BulkThreshold -le 6) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have appropriate Bulk Complaint Level (BCL) thresholds set between 4 and 6.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies have BCL thresholds outside the recommended range (4-6).`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Current BCL Threshold |`n"
            $Result += "|------------|----------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.BulkThreshold) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA100' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Bulk Complaint Level threshold is between 4 and 6' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA100' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Bulk Complaint Level threshold is between 4 and 6' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA100.ps1' 51
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA101.ps1' -1

function Invoke-CippTestORCA101 {
    <#
    .SYNOPSIS
    Bulk is marked as spam
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA101' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Bulk is marked as spam' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.MarkAsSpamBulkMail -eq 'On') {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies are configured to mark bulk mail as spam.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)`n`n"
            if ($PassedPolicies.Count -gt 0) {
                $Result += "| Policy Name | Mark As Spam Bulk Mail |`n"
                $Result += "|------------|------------------------|`n"
                foreach ($Policy in $PassedPolicies) {
                    $Result += "| $($Policy.Identity) | $($Policy.MarkAsSpamBulkMail) |`n"
                }
            }
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies are not configured to mark bulk mail as spam.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Mark As Spam Bulk Mail |`n"
            $Result += "|------------|------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.MarkAsSpamBulkMail) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA101' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Bulk is marked as spam' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA101' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Bulk is marked as spam' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA101.ps1' 57
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA102.ps1' -1

function Invoke-CippTestORCA102 {
    <#
    .SYNOPSIS
    Advanced Spam filter options are turned off
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA102' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Advanced Spam filter options are turned off' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            $ASFSettings = @(
                $Policy.IncreaseScoreWithImageLinks,
                $Policy.IncreaseScoreWithNumericIps,
                $Policy.IncreaseScoreWithRedirectToOtherPort,
                $Policy.IncreaseScoreWithBizOrInfoUrls,
                $Policy.MarkAsSpamEmptyMessages,
                $Policy.MarkAsSpamJavaScriptInHtml,
                $Policy.MarkAsSpamFramesInHtml,
                $Policy.MarkAsSpamObjectTagsInHtml,
                $Policy.MarkAsSpamEmbedTagsInHtml,
                $Policy.MarkAsSpamFormTagsInHtml,
                $Policy.MarkAsSpamWebBugsInHtml,
                $Policy.MarkAsSpamSensitiveWordList,
                $Policy.MarkAsSpamFromAddressAuthFail,
                $Policy.MarkAsSpamNdrBackscatter,
                $Policy.MarkAsSpamSpfRecordHardFail
            )

            $EnabledASF = $ASFSettings | Where-Object { $_ -eq 'On' }

            if ($EnabledASF.Count -eq 0) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have Advanced Spam Filter (ASF) options turned off.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies have Advanced Spam Filter (ASF) options enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enabled ASF Options |`n"
            $Result += "|------------|---------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $EnabledOptions = [System.Collections.Generic.List[string]]::new()
                if ($Policy.IncreaseScoreWithImageLinks -eq 'On') { $EnabledOptions.Add('ImageLinks') | Out-Null }
                if ($Policy.IncreaseScoreWithNumericIps -eq 'On') { $EnabledOptions.Add('NumericIPs') | Out-Null }
                if ($Policy.MarkAsSpamEmptyMessages -eq 'On') { $EnabledOptions.Add('EmptyMessages') | Out-Null }
                if ($Policy.MarkAsSpamJavaScriptInHtml -eq 'On') { $EnabledOptions.Add('JavaScript') | Out-Null }
                $Result += "| $($Policy.Identity) | $($EnabledOptions -join ', ') |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA102' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Advanced Spam filter options are turned off' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA102' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Advanced Spam filter options are turned off' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA102.ps1' 75
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA103.ps1' -1

function Invoke-CippTestORCA103 {
    <#
    .SYNOPSIS
    Outbound spam filter policy settings configured
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedOutboundSpamFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA103' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Outbound spam filter policy settings configured' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            $IsCompliant = $true
            $Issues = [System.Collections.Generic.List[string]]::new()

            if ($Policy.RecipientLimitExternalPerHour -ne 500) {
                $IsCompliant = $false
                $Issues.Add("RecipientLimitExternalPerHour: $($Policy.RecipientLimitExternalPerHour) (should be 500)") | Out-Null
            }
            if ($Policy.RecipientLimitInternalPerHour -ne 1000) {
                $IsCompliant = $false
                $Issues.Add("RecipientLimitInternalPerHour: $($Policy.RecipientLimitInternalPerHour) (should be 1000)") | Out-Null
            }
            if ($Policy.ActionWhenThresholdReached -ne 'BlockUserForToday') {
                $IsCompliant = $false
                $Issues.Add("ActionWhenThresholdReached: $($Policy.ActionWhenThresholdReached) (should be BlockUserForToday)") | Out-Null
            }

            if ($IsCompliant) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add([PSCustomObject]@{
                        Policy = $Policy
                        Issues = $Issues
                    }) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All outbound spam filter policies are configured correctly.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) outbound spam filter policies are not configured correctly.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Issues |`n"
            $Result += "|------------|--------|`n"
            foreach ($Failed in $FailedPolicies) {
                $Result += "| $($Failed.Policy.Identity) | $($Failed.Issues -join '<br/>') |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA103' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Outbound spam filter policy settings configured' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'

        } catch {
            $ErrorMessage = Get-CippException -Exception $_
            Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA103' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Outbound spam filter policy settings configured' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'
        }
    }
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA103.ps1' 69
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA104.ps1' -1

function Invoke-CippTestORCA104 {
    <#
    .SYNOPSIS
    High Confidence Phish action set to Quarantine message
    #>
    param($Tenant)

    try {
        $AntiPhishPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $AntiPhishPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA104' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'High Confidence Phish action set to Quarantine message' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = @()
        $PassedPolicies = @()

        foreach ($Policy in $AntiPhishPolicies) {
            # Check if HighConfidencePhishAction is set to Quarantine
            if ($Policy.HighConfidencePhishAction -eq 'Quarantine') {
                $PassedPolicies += $Policy
            } else {
                $FailedPolicies += $Policy
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have High Confidence Phish action set to Quarantine.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)`n`n"
            if ($PassedPolicies.Count -gt 0) {
                $Result += "| Policy Name | Action |`n"
                $Result += "|------------|--------|`n"
                foreach ($Policy in $PassedPolicies) {
                    $Result += "| $($Policy.Identity) | $($Policy.HighConfidencePhishAction) |`n"
                }
            }
        } else {
            $Status = 'Failed'
            $Result = "Some anti-phishing policies do not have High Confidence Phish action set to Quarantine.`n`n"
            $Result += "**Failed Policies:** $($FailedPolicies.Count) | **Passed Policies:** $($PassedPolicies.Count)`n`n"
            $Result += "### Non-Compliant Policies`n`n"
            $Result += "| Policy Name | Current Action | Recommended Action |`n"
            $Result += "|------------|----------------|-------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.HighConfidencePhishAction) | Quarantine |`n"
            }
            $Result += "`n**Remediation:** Update the HighConfidencePhishAction to 'Quarantine' for enhanced security."
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA104' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'High Confidence Phish action set to Quarantine message' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA104' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'High Confidence Phish action set to Quarantine message' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA104.ps1' 59
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA105.ps1' -1

function Invoke-CippTestORCA105 {
    <#
    .SYNOPSIS
    Safe Links Synchronous URL detonation is enabled
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA105' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Safe Links Synchronous URL detonation is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.DeliverMessageAfterScan -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All Safe Links policies have synchronous URL detonation enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) Safe Links policies do not have synchronous URL detonation enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Deliver Message After Scan |`n"
            $Result += "|------------|---------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.DeliverMessageAfterScan) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA105' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Safe Links Synchronous URL detonation is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA105' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Safe Links Synchronous URL detonation is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA105.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA106.ps1' -1

function Invoke-CippTestORCA106 {
    <#
    .SYNOPSIS
    Quarantine retention period is 30 days
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA106' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Quarantine retention period is 30 days' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.QuarantineRetentionPeriod -gt 15) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have quarantine retention period set to 30 days.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies do not have quarantine retention period set to 30 days.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Quarantine Retention Period |`n"
            $Result += "|------------|----------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.QuarantineRetentionPeriod) days |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA106' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Quarantine retention period is 30 days' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA106' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Quarantine retention period is 30 days' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA106.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA107.ps1' -1

function Invoke-CippTestORCA107 {
    <#
    .SYNOPSIS
    End-user spam notification is enabled
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoQuarantinePolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA107' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'End-user spam notification is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Quarantine'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EndUserSpamNotificationFrequency -gt 0) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0 -and $PassedPolicies.Count -gt 0) {
            $Status = 'Passed'
            $Result = "All quarantine policies have end-user spam notifications enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)`n`n"
            $Result += "| Policy Name | Notification Frequency (days) |`n"
            $Result += "|------------|-------------------------------|`n"
            foreach ($Policy in $PassedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EndUserSpamNotificationFrequency) |`n"
            }
        } elseif ($PassedPolicies.Count -eq 0) {
            $Status = 'Failed'
            $Result = "No quarantine policies have end-user spam notifications enabled.`n`n"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) quarantine policies do not have end-user spam notifications enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Notification Frequency |`n"
            $Result += "|------------|----------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | Disabled |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA107' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'End-user spam notification is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Quarantine'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA107' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'End-user spam notification is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Quarantine'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA107.ps1' 58
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA108_1.ps1' -1

function Invoke-CippTestORCA108_1 {
    <#
    .SYNOPSIS
    DNS Records have been set up to support DKIM
    #>
    param($Tenant)

    try {
        $DkimConfig = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoDkimSigningConfig'
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'

        if (-not $DkimConfig -or -not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA108_1' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'DNS Records have been set up to support DKIM' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'DKIM'
            return
        }

        $FailedDomains = [System.Collections.Generic.List[object]]::new()
        $PassedDomains = [System.Collections.Generic.List[object]]::new()
        $CustomDomains = $AcceptedDomains | Where-Object { $_.DomainName -notlike '*onmicrosoft.com' }

        foreach ($Domain in $CustomDomains) {
            $DkimRecord = $DkimConfig | Where-Object { $_.Domain -eq $Domain.DomainName }

            if ($DkimRecord -and $DkimRecord.Selector1CNAME -and $DkimRecord.Selector2CNAME) {
                $PassedDomains.Add($Domain) | Out-Null
            } else {
                $FailedDomains.Add($Domain) | Out-Null
            }
        }

        if ($FailedDomains.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All custom domains have DKIM DNS records configured.`n`n"
            $Result += "**Compliant Domains:** $($PassedDomains.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedDomains.Count) custom domains do not have DKIM DNS records configured.`n`n"
            $Result += "**Non-Compliant Domains:** $($FailedDomains.Count)`n`n"
            $Result += "| Domain Name |`n"
            $Result += "|------------|`n"
            foreach ($Domain in $FailedDomains) {
                $Result += "| $($Domain.DomainName) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA108_1' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'DNS Records have been set up to support DKIM' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'DKIM'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA108_1' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'DNS Records have been set up to support DKIM' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'DKIM'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA108_1.ps1' 54
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA108.ps1' -1

function Invoke-CippTestORCA108 {
    <#
    .SYNOPSIS
    DKIM signing is set up for all your custom domains
    #>
    param($Tenant)

    try {
        $DkimConfig = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoDkimSigningConfig'
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'

        if (-not $DkimConfig -or -not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA108' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'DKIM signing is set up for all your custom domains' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'DKIM'
            return
        }

        # Get custom domains (exclude default .onmicrosoft.com domains)
        $CustomDomains = $AcceptedDomains | Where-Object {
            $_.DomainName -notlike '*.onmicrosoft.com' -and
            $_.DomainName -notlike '*.mail.onmicrosoft.com'
        }

        if ($CustomDomains.Count -eq 0) {
            $Status = 'Passed'
            $Result = 'No custom domains configured. DKIM check not applicable for default domains only.'
        } else {
            $DomainsWithoutDkim = @()
            $DomainsWithDkim = @()

            foreach ($Domain in $CustomDomains) {
                $DkimForDomain = $DkimConfig | Where-Object { $_.Domain -eq $Domain.DomainName }

                if ($DkimForDomain -and $DkimForDomain.Enabled -eq $true) {
                    $DomainsWithDkim += $Domain.DomainName
                } else {
                    $DomainsWithoutDkim += $Domain.DomainName
                }
            }

            if ($DomainsWithoutDkim.Count -eq 0) {
                $Status = 'Passed'
                $Result = "DKIM signing is enabled for all custom domains ($($DomainsWithDkim.Count) domains).`n`n"
                $Result += "**Domains with DKIM enabled:**`n"
                $Result += ($DomainsWithDkim | ForEach-Object { "- $_" }) -join "`n"
            } else {
                $Status = 'Failed'
                $Result = "DKIM signing is not configured for all custom domains.`n`n"
                $Result += "**Missing DKIM:** $($DomainsWithoutDkim.Count) | **Configured:** $($DomainsWithDkim.Count)`n`n"
                $Result += "### Domains without DKIM:`n"
                $Result += ($DomainsWithoutDkim | ForEach-Object { "- $_" }) -join "`n"
                $Result += "`n`n**Remediation:** Enable DKIM signing for all custom domains to prevent email spoofing."
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA108' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'DKIM signing is set up for all your custom domains' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'DKIM'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA108' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'DKIM signing is set up for all your custom domains' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'DKIM'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA108.ps1' 62
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA109.ps1' -1

function Invoke-CippTestORCA109 {
    <#
    .SYNOPSIS
    Senders are not being allow listed in an unsafe manner
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA109' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Senders are not being allow listed in an unsafe manner' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            $HasAllowedSenders = ($Policy.AllowedSenders -and $Policy.AllowedSenders.Count -gt 0) -or
            ($Policy.AllowedSenderDomains -and $Policy.AllowedSenderDomains.Count -gt 0)

            if (-not $HasAllowedSenders) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No anti-spam policies have sender allow lists configured.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies have sender allow lists configured.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Allowed Senders | Allowed Sender Domains |`n"
            $Result += "|------------|----------------|----------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $SenderCount = if ($Policy.AllowedSenders) { $Policy.AllowedSenders.Count } else { 0 }
                $DomainCount = if ($Policy.AllowedSenderDomains) { $Policy.AllowedSenderDomains.Count } else { 0 }
                $Result += "| $($Policy.Identity) | $SenderCount | $DomainCount |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA109' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Senders are not being allow listed in an unsafe manner' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA109' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Senders are not being allow listed in an unsafe manner' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA109.ps1' 55
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA110.ps1' -1

function Invoke-CippTestORCA110 {
    <#
    .SYNOPSIS
    Internal Sender notifications are disabled
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA110' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Internal Sender notifications are disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.InlineSafetyTipsEnabled -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have internal sender notifications disabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies have internal sender notifications enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Inline Safety Tips Enabled |`n"
            $Result += "|------------|---------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.InlineSafetyTipsEnabled) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA110' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Internal Sender notifications are disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA110' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Internal Sender notifications are disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA110.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA111.ps1' -1

function Invoke-CippTestORCA111 {
    <#
    .SYNOPSIS
    Anti-phishing policy exists and EnableUnauthenticatedSender is true
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA111' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Unauthenticated Sender tagging enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableUnauthenticatedSender -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have unauthenticated sender tagging enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have unauthenticated sender tagging enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable Unauthenticated Sender |`n"
            $Result += "|------------|------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableUnauthenticatedSender) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA111' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Unauthenticated Sender tagging enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA111' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Unauthenticated Sender tagging enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA111.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA112.ps1' -1

function Invoke-CippTestORCA112 {
    <#
    .SYNOPSIS
    Anti-spoofing protection action is configured to Move message to Junk Email folders
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA112' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Anti-spoofing protection action configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.AuthenticationFailAction -eq 'MoveToJmf') {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have anti-spoofing action set to Move to Junk Email folder.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have anti-spoofing action set to Move to Junk Email folder.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Authentication Fail Action |`n"
            $Result += "|------------|---------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.AuthenticationFailAction) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA112' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Anti-spoofing protection action configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA112' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Anti-spoofing protection action configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA112.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA113.ps1' -1

function Invoke-CippTestORCA113 {
    <#
    .SYNOPSIS
    AllowClickThrough is disabled in Safe Links policies
    #>
    param($Tenant)

    try {
        $SafeLinksPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $SafeLinksPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA113' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'AllowClickThrough is disabled in Safe Links policies' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
            return
        }

        $FailedPolicies = @()
        $PassedPolicies = @()

        foreach ($Policy in $SafeLinksPolicies) {
            # Check if DoNotAllowClickThrough is set to true (which means AllowClickThrough is disabled)
            if ($Policy.DoNotAllowClickThrough -eq $true) {
                $PassedPolicies += $Policy
            } else {
                $FailedPolicies += $Policy
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All Safe Links policies have click-through disabled (DoNotAllowClickThrough = true).`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)`n`n"
            if ($PassedPolicies.Count -gt 0) {
                $Result += "| Policy Name | DoNotAllowClickThrough |`n"
                $Result += "|------------|----------------------|`n"
                foreach ($Policy in $PassedPolicies) {
                    $Result += "| $($Policy.Identity) | $($Policy.DoNotAllowClickThrough) |`n"
                }
            }
        } else {
            $Status = 'Failed'
            $Result = "Some Safe Links policies allow click-through, which reduces protection.`n`n"
            $Result += "**Failed Policies:** $($FailedPolicies.Count) | **Passed Policies:** $($PassedPolicies.Count)`n`n"
            $Result += "### Non-Compliant Policies`n`n"
            $Result += "| Policy Name | DoNotAllowClickThrough | Recommended |`n"
            $Result += "|------------|----------------------|-------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.DoNotAllowClickThrough) | true |`n"
            }
            $Result += "`n**Remediation:** Disable click-through (set DoNotAllowClickThrough to true) to prevent users from bypassing Safe Links protection."
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA113' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'AllowClickThrough is disabled in Safe Links policies' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA113' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'AllowClickThrough is disabled in Safe Links policies' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA113.ps1' 59
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA114.ps1' -1

function Invoke-CippTestORCA114 {
    <#
    .SYNOPSIS
    No IP Allow Lists have been configured
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA114' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'No IP Allow Lists have been configured' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

$FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            $HasIPAllowList = ($Policy.IPAllowList -and $Policy.IPAllowList.Count -gt 0)

            if (-not $HasIPAllowList) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No anti-spam policies have IP allow lists configured.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies have IP allow lists configured.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | IP Allow List Count |`n"
            $Result += "|------------|-------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $IPCount = if ($Policy.IPAllowList) { $Policy.IPAllowList.Count } else { 0 }
                $Result += "| $($Policy.Identity) | $IPCount |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA114' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'No IP Allow Lists have been configured' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA114' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'No IP Allow Lists have been configured' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA114.ps1' 53
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA115.ps1' -1

function Invoke-CippTestORCA115 {
    <#
    .SYNOPSIS
    Mailbox intelligence based impersonation protection is enabled
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA115' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Mailbox intelligence based impersonation protection is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableMailboxIntelligenceProtection -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have mailbox intelligence based impersonation protection enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have mailbox intelligence based impersonation protection enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable Mailbox Intelligence Protection |`n"
            $Result += "|------------|---------------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableMailboxIntelligenceProtection) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA115' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Mailbox intelligence based impersonation protection is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA115' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Mailbox intelligence based impersonation protection is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA115.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA116.ps1' -1

function Invoke-CippTestORCA116 {
    <#
    .SYNOPSIS
    Mailbox intelligence based impersonation protection action set to move message to junk mail folder
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA116' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Mailbox intelligence impersonation protection action configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.MailboxIntelligenceProtectionAction -eq 'MoveToJmf') {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have mailbox intelligence impersonation protection action set to Move to Junk Email folder.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have mailbox intelligence impersonation protection action set to Move to Junk Email folder.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Mailbox Intelligence Protection Action |`n"
            $Result += "|------------|---------------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.MailboxIntelligenceProtectionAction) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA116' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Mailbox intelligence impersonation protection action configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA116' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Mailbox intelligence impersonation protection action configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA116.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA118_1.ps1' -1

function Invoke-CippTestORCA118_1 {
    <#
    .SYNOPSIS
    Domains not allow listed in Anti-Spam
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_1' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Domains not allow listed in Anti-Spam' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            $HasAllowedDomains = ($Policy.AllowedSenderDomains -and $Policy.AllowedSenderDomains.Count -gt 0)

            if (-not $HasAllowedDomains) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No anti-spam policies have allowed sender domains configured.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies have allowed sender domains configured.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Allowed Sender Domains Count |`n"
            $Result += "|------------|------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Count = if ($Policy.AllowedSenderDomains) { $Policy.AllowedSenderDomains.Count } else { 0 }
                $Result += "| $($Policy.Identity) | $Count |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_1' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Domains not allow listed in Anti-Spam' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_1' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Domains not allow listed in Anti-Spam' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA118_1.ps1' 53
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA118_2.ps1' -1

function Invoke-CippTestORCA118_2 {
    <#
    .SYNOPSIS
    Domains not allow listed in Transport Rules
    #>
    param($Tenant)

    try {
        $TransportRules = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoTransportRules'

        if (-not $TransportRules) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_2' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Domains not allow listed in Transport Rules' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Transport Rules'
            return
        }

        $FailedRules = [System.Collections.Generic.List[object]]::new()

        foreach ($Rule in $TransportRules) {
            # Check if rule sets SCL to -1 (bypass spam filtering) based on sender domain
            if ($Rule.SetSCL -eq -1 -and $Rule.SenderDomainIs) {
                $FailedRules.Add($Rule) | Out-Null
            }
        }

        if ($FailedRules.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No transport rules allow list domains by setting SCL to -1.`n`n"
            $Result += "**Total Transport Rules Checked:** $($TransportRules.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedRules.Count) transport rules allow list domains by setting SCL to -1.`n`n"
            $Result += "**Non-Compliant Rules:** $($FailedRules.Count)`n`n"
            $Result += "| Rule Name | Sender Domains |`n"
            $Result += "|-----------|---------------|`n"
            foreach ($Rule in $FailedRules) {
                $Domains = if ($Rule.SenderDomainIs) { ($Rule.SenderDomainIs -join ', ') } else { 'N/A' }
                $Result += "| $($Rule.Name) | $Domains |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_2' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Domains not allow listed in Transport Rules' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Transport Rules'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_2' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Domains not allow listed in Transport Rules' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Transport Rules'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA118_2.ps1' 49
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA118_3.ps1' -1

function Invoke-CippTestORCA118_3 {
    <#
    .SYNOPSIS
    Own domains not allow listed in Anti-Spam
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_3' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Own domains not allow listed in Anti-Spam' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        if (-not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_3' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No accepted domains found in database.' -Risk 'High' -Name 'Own domains not allow listed in Anti-Spam' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $OwnDomains = $AcceptedDomains | Select-Object -ExpandProperty DomainName
        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            $HasOwnDomainInAllowList = $false

            if ($Policy.AllowedSenderDomains) {
                foreach ($AllowedDomain in $Policy.AllowedSenderDomains) {
                    if ($OwnDomains -contains $AllowedDomain) {
                        $HasOwnDomainInAllowList = $true
                        break
                    }
                }
            }

            if ($HasOwnDomainInAllowList) {
                $FailedPolicies.Add($Policy) | Out-Null
            } else {
                $PassedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No anti-spam policies have own domains in the allow list.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies have own domains in the allow list.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Own Domains in Allow List |`n"
            $Result += "|------------|---------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $OwnDomainsInList = $Policy.AllowedSenderDomains | Where-Object { $OwnDomains -contains $_ }
                $Result += "| $($Policy.Identity) | $($OwnDomainsInList -join ', ') |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_3' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Own domains not allow listed in Anti-Spam' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_3' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Own domains not allow listed in Anti-Spam' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA118_3.ps1' 69
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA118_4.ps1' -1

function Invoke-CippTestORCA118_4 {
    <#
    .SYNOPSIS
    Own domains not allow listed in Transport Rules
    #>
    param($Tenant)

    try {
        $TransportRules = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoTransportRules'
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'

        if (-not $TransportRules) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_4' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Own domains not allow listed in Transport Rules' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Transport Rules'
            return
        }

        if (-not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_4' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No accepted domains found in database.' -Risk 'High' -Name 'Own domains not allow listed in Transport Rules' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Transport Rules'
            return
        }

        $OwnDomains = $AcceptedDomains | Select-Object -ExpandProperty DomainName
        $FailedRules = [System.Collections.Generic.List[object]]::new()

        foreach ($Rule in $TransportRules) {
            # Check if rule sets SCL to -1 (bypass spam filtering) based on sender domain
            if ($Rule.SetSCL -eq -1 -and $Rule.SenderDomainIs) {
                $HasOwnDomain = $false
                foreach ($SenderDomain in $Rule.SenderDomainIs) {
                    if ($OwnDomains -contains $SenderDomain) {
                        $HasOwnDomain = $true
                        break
                    }
                }

                if ($HasOwnDomain) {
                    $FailedRules.Add($Rule) | Out-Null
                }
            }
        }

        if ($FailedRules.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No transport rules allow list own domains by setting SCL to -1.`n`n"
            $Result += "**Total Transport Rules Checked:** $($TransportRules.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedRules.Count) transport rules allow list own domains by setting SCL to -1.`n`n"
            $Result += "**Non-Compliant Rules:** $($FailedRules.Count)`n`n"
            $Result += "| Rule Name | Own Domains in Rule |`n"
            $Result += "|-----------|-------------------|`n"
            foreach ($Rule in $FailedRules) {
                $OwnDomainsInRule = $Rule.SenderDomainIs | Where-Object { $OwnDomains -contains $_ }
                $Result += "| $($Rule.Name) | $($OwnDomainsInRule -join ', ') |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_4' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Own domains not allow listed in Transport Rules' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Transport Rules'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA118_4' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Own domains not allow listed in Transport Rules' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Transport Rules'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA118_4.ps1' 66
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA119.ps1' -1

function Invoke-CippTestORCA119 {
    <#
    .SYNOPSIS
    Similar Domains Safety Tips is enabled
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA119' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Similar Domains Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableSimilarDomainsSafetyTips -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have Similar Domains Safety Tips enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have Similar Domains Safety Tips enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable Similar Domains Safety Tips |`n"
            $Result += "|------------|-----------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableSimilarDomainsSafetyTips) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA119' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Similar Domains Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA119' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Similar Domains Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA119.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA120_malware.ps1' -1

function Invoke-CippTestORCA120_malware {
    <#
    .SYNOPSIS
    Zero Hour Autopurge Enabled for Malware
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoMalwareFilterPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA120_malware' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Zero Hour Autopurge Enabled for Malware' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Malware'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.ZapEnabled -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All malware filter policies have Zero Hour Autopurge enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) malware filter policies do not have Zero Hour Autopurge enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | ZAP Enabled |`n"
            $Result += "|------------|------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.ZapEnabled) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA120_malware' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Zero Hour Autopurge Enabled for Malware' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Malware'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA120_malware' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Zero Hour Autopurge Enabled for Malware' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Malware'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA120_malware.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA120_phish.ps1' -1

function Invoke-CippTestORCA120_phish {
    <#
    .SYNOPSIS
    Zero Hour Autopurge Enabled for Phish
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA120_phish' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Zero Hour Autopurge Enabled for Phish' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.PhishZapEnabled -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have Zero Hour Autopurge for Phish enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies do not have Zero Hour Autopurge for Phish enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Phish ZAP Enabled |`n"
            $Result += "|------------|------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.PhishZapEnabled) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA120_phish' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Zero Hour Autopurge Enabled for Phish' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA120_phish' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Zero Hour Autopurge Enabled for Phish' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA120_phish.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA120_spam.ps1' -1

function Invoke-CippTestORCA120_spam {
    <#
    .SYNOPSIS
    Zero Hour Autopurge Enabled for Spam
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA120_spam' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Zero Hour Autopurge Enabled for Spam' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.SpamZapEnabled -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have Zero Hour Autopurge for Spam enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies do not have Zero Hour Autopurge for Spam enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Spam ZAP Enabled |`n"
            $Result += "|------------|-----------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.SpamZapEnabled) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA120_spam' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Zero Hour Autopurge Enabled for Spam' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA120_spam' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Zero Hour Autopurge Enabled for Spam' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA120_spam.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA121.ps1' -1

function Invoke-CippTestORCA121 {
    <#
    .SYNOPSIS
    Supported filter policy action used
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoQuarantinePolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA121' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Supported filter policy action used' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Quarantine'
            return
        }

        $Status = 'Passed'
        $Result = "Quarantine policies are configured to support Zero Hour Auto Purge.`n`n"
        $Result += "**Total Policies:** $($Policies.Count)"

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA121' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Supported filter policy action used' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Quarantine'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA121' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Supported filter policy action used' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Quarantine'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA121.ps1' 28
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA123.ps1' -1

function Invoke-CippTestORCA123 {
    <#
    .SYNOPSIS
    Unusual Characters Safety Tips is enabled
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA123' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Unusual Characters Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableUnusualCharactersSafetyTips -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have Unusual Characters Safety Tips enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have Unusual Characters Safety Tips enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable Unusual Characters Safety Tips |`n"
            $Result += "|------------|---------------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableUnusualCharactersSafetyTips) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA123' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Unusual Characters Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA123' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Unusual Characters Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA123.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA124.ps1' -1

function Invoke-CippTestORCA124 {
    <#
    .SYNOPSIS
    Safe attachments unknown malware response set to block messages
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeAttachmentPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA124' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Safe attachments unknown malware response set to block messages' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Safe Attachments'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.Action -in @('Block', 'Quarantine')) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All Safe Attachments policies have unknown malware response set to Block.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) Safe Attachments policies do not have unknown malware response set to Block.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Action |`n"
            $Result += "|------------|--------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.Action) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA124' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Safe attachments unknown malware response set to block messages' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Safe Attachments'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA124' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Safe attachments unknown malware response set to block messages' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Safe Attachments'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA124.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA139.ps1' -1

function Invoke-CippTestORCA139 {
    <#
    .SYNOPSIS
    Spam action set to move message to junk mail folder or quarantine
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA139' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Spam action set to move message to junk mail folder or quarantine' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.SpamAction -in @('MoveToJmf', 'Quarantine')) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have Spam action set to move to Junk Email folder or Quarantine.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies do not have Spam action set appropriately.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Spam Action |`n"
            $Result += "|------------|------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.SpamAction) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA139' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Spam action set to move message to junk mail folder or quarantine' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA139' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Spam action set to move message to junk mail folder or quarantine' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA139.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA140.ps1' -1

function Invoke-CippTestORCA140 {
    <#
    .SYNOPSIS
    High Confidence Spam action set to Quarantine message
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA140' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'High Confidence Spam action set to Quarantine message' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.HighConfidenceSpamAction -eq 'Quarantine') {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have High Confidence Spam action set to Quarantine.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies do not have High Confidence Spam action set to Quarantine.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | High Confidence Spam Action |`n"
            $Result += "|------------|---------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.HighConfidenceSpamAction) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA140' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'High Confidence Spam action set to Quarantine message' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA140' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'High Confidence Spam action set to Quarantine message' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA140.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA141.ps1' -1

function Invoke-CippTestORCA141 {
    <#
    .SYNOPSIS
    Bulk action set to Move message to Junk Email Folder
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA141' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Bulk action set to Move message to Junk Email Folder' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.BulkSpamAction -in @('MoveToJmf', 'Quarantine')) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have Bulk action set to Move to Junk Email folder.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies do not have Bulk action set to Move to Junk Email folder.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Bulk Spam Action |`n"
            $Result += "|------------|-----------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.BulkSpamAction) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA141' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Bulk action set to Move message to Junk Email Folder' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA141' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Bulk action set to Move message to Junk Email Folder' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA141.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA142.ps1' -1

function Invoke-CippTestORCA142 {
    <#
    .SYNOPSIS
    Phish action set to Quarantine message
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA142' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Phish action set to Quarantine message' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.PhishSpamAction -eq 'Quarantine') {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have Phish action set to Quarantine.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies do not have Phish action set to Quarantine.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Phish Spam Action |`n"
            $Result += "|------------|------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.PhishSpamAction) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA142' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Phish action set to Quarantine message' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA142' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Phish action set to Quarantine message' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA142.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA143.ps1' -1

function Invoke-CippTestORCA143 {
    <#
    .SYNOPSIS
    Safety Tips are enabled
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA143' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Safety Tips are enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.InlineSafetyTipsEnabled -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies have Safety Tips enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies do not have Safety Tips enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Inline Safety Tips Enabled |`n"
            $Result += "|------------|---------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.InlineSafetyTipsEnabled) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA143' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Safety Tips are enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA143' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Safety Tips are enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA143.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA156.ps1' -1

function Invoke-CippTestORCA156 {
    <#
    .SYNOPSIS
    Safe Links Policies are tracking when user clicks on safe links
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA156' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Safe Links Policies are tracking user clicks' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.TrackClicks -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All Safe Links policies are tracking user clicks.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) Safe Links policies are not tracking user clicks.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Track Clicks |`n"
            $Result += "|------------|-------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.TrackClicks) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA156' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Low' -Name 'Safe Links Policies are tracking user clicks' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA156' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Safe Links Policies are tracking user clicks' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA156.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA158.ps1' -1

function Invoke-CippTestORCA158 {
    <#
    .SYNOPSIS
    Safe Attachments is enabled for SharePoint and Teams
    #>
    param($Tenant)

    try {
        $AtpPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAtpPolicyForO365'

        if (-not $AtpPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA158' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Safe Attachments enabled for SharePoint and Teams' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Safe Attachments'
            return
        }

        $Policy = $AtpPolicy | Select-Object -First 1

        if ($Policy.EnableATPForSPOTeamsODB -eq $true) {
            $Status = 'Passed'
            $Result = "Safe Attachments is enabled for SharePoint, OneDrive, and Teams.`n`n"
            $Result += "**EnableATPForSPOTeamsODB:** $($Policy.EnableATPForSPOTeamsODB)"
        } else {
            $Status = 'Failed'
            $Result = "Safe Attachments is NOT enabled for SharePoint, OneDrive, and Teams.`n`n"
            $Result += "**EnableATPForSPOTeamsODB:** $($Policy.EnableATPForSPOTeamsODB)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA158' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Safe Attachments enabled for SharePoint and Teams' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Safe Attachments'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA158' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Safe Attachments enabled for SharePoint and Teams' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Safe Attachments'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA158.ps1' 36
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA179.ps1' -1

function Invoke-CippTestORCA179 {
    <#
    .SYNOPSIS
    Safe Links is enabled intra-organization
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA179' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Safe Links is enabled intra-organization' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableForInternalSenders -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All Safe Links policies are enabled for internal senders.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) Safe Links policies are not enabled for internal senders.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable For Internal Senders |`n"
            $Result += "|------------|----------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableForInternalSenders) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA179' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Safe Links is enabled intra-organization' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA179' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Safe Links is enabled intra-organization' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA179.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA180.ps1' -1

function Invoke-CippTestORCA180 {
    <#
    .SYNOPSIS
    Anti-phishing policy exists and EnableSpoofIntelligence is true
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA180' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Spoof Intelligence is enabled' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableSpoofIntelligence -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have Spoof Intelligence enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have Spoof Intelligence enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable Spoof Intelligence |`n"
            $Result += "|------------|--------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableSpoofIntelligence) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA180' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Spoof Intelligence is enabled' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA180' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Spoof Intelligence is enabled' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA180.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA189_2.ps1' -1

function Invoke-CippTestORCA189_2 {
    <#
    .SYNOPSIS
    Safe Links is not bypassed
    #>
    param($Tenant)
    
    try {
        $Rules = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoTransportRules'
        
        if (-not $Rules) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA189_2' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Safe Links is not bypassed' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Safe Links'
            return
        }

        $BypassRules = [System.Collections.Generic.List[object]]::new()
        foreach ($Rule in $Rules) {
            if ($Rule.SetHeaderName -eq 'X-MS-Exchange-Organization-SkipSafeLinksProcessing' -and $Rule.SetHeaderValue -eq '1') {
                $BypassRules.Add($Rule) | Out-Null
            }
        }

        if ($BypassRules.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No transport rules are bypassing Safe Links processing."
        } else {
            $Status = 'Failed'
            $Result = "$($BypassRules.Count) transport rules are bypassing Safe Links processing.`n`n"
            $Result += "| Rule Name | Priority |`n"
            $Result += "|-----------|----------|`n"
            foreach ($Rule in $BypassRules) {
                $Result += "| $($Rule.Name) | $($Rule.Priority) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA189_2' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Safe Links is not bypassed' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Safe Links'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA189_2' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Safe Links is not bypassed' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Safe Links'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA189_2.ps1' 44
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA189.ps1' -1

function Invoke-CippTestORCA189 {
    <#
    .SYNOPSIS
    Safe Attachments is not bypassed
    #>
    param($Tenant)
    
    try {
        $Rules = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoTransportRules'
        
        if (-not $Rules) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA189' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Safe Attachments is not bypassed' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Safe Attachments'
            return
        }

        $BypassRules = [System.Collections.Generic.List[object]]::new()
        foreach ($Rule in $Rules) {
            if ($Rule.SetHeaderName -eq 'X-MS-Exchange-Organization-SkipSafeAttachmentProcessing' -and $Rule.SetHeaderValue -eq '1') {
                $BypassRules.Add($Rule) | Out-Null
            }
        }

        if ($BypassRules.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No transport rules are bypassing Safe Attachments processing."
        } else {
            $Status = 'Failed'
            $Result = "$($BypassRules.Count) transport rules are bypassing Safe Attachments processing.`n`n"
            $Result += "| Rule Name | Priority |`n"
            $Result += "|-----------|----------|`n"
            foreach ($Rule in $BypassRules) {
                $Result += "| $($Rule.Name) | $($Rule.Priority) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA189' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Safe Attachments is not bypassed' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Safe Attachments'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA189' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Safe Attachments is not bypassed' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Safe Attachments'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA189.ps1' 44
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA205.ps1' -1

function Invoke-CippTestORCA205 {
    <#
    .SYNOPSIS
    Common attachment type filter is enabled
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoMalwareFilterPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA205' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Common attachment type filter is enabled' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Malware'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableFileFilter -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All malware filter policies have common attachment type filter enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) malware filter policies do not have common attachment type filter enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable File Filter |`n"
            $Result += "|------------|-------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableFileFilter) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA205' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Common attachment type filter is enabled' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Malware'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA205' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Common attachment type filter is enabled' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Malware'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA205.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA220.ps1' -1

function Invoke-CippTestORCA220 {
    <#
    .SYNOPSIS
    Advanced Phish filter Threshold level is adequate
    #>
    param($Tenant)
    
    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'
        
        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA220' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Advanced Phish filter Threshold level is adequate' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            # PhishThresholdLevel: 1=Standard, 2=Aggressive, 3=More Aggressive, 4=Most Aggressive
            if ($Policy.PhishThresholdLevel -ge 2) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have adequate phishing threshold levels (2 or higher).`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies have inadequate phishing threshold levels.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Phish Threshold Level |`n"
            $Result += "|------------|----------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.PhishThresholdLevel) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA220' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Advanced Phish filter Threshold level is adequate' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA220' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Advanced Phish filter Threshold level is adequate' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA220.ps1' 51
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA221.ps1' -1

function Invoke-CippTestORCA221 {
    <#
    .SYNOPSIS
    Mailbox intelligence is enabled in anti-phishing policies
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA221' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Mailbox intelligence is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableMailboxIntelligence -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have mailbox intelligence enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have mailbox intelligence enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable Mailbox Intelligence |`n"
            $Result += "|------------|----------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableMailboxIntelligence) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA221' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Mailbox intelligence is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA221' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Mailbox intelligence is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA221.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA222.ps1' -1

function Invoke-CippTestORCA222 {
    <#
    .SYNOPSIS
    Domain Impersonation action is set to move to Quarantine
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA222' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Domain Impersonation action set to Quarantine' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.TargetedDomainProtectionAction -eq 'Quarantine') {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have Domain Impersonation action set to Quarantine.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have Domain Impersonation action set to Quarantine.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Targeted Domain Protection Action |`n"
            $Result += "|------------|----------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.TargetedDomainProtectionAction) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA222' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Domain Impersonation action set to Quarantine' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA222' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Domain Impersonation action set to Quarantine' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA222.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA223.ps1' -1

function Invoke-CippTestORCA223 {
    <#
    .SYNOPSIS
    User impersonation action is set to move to Quarantine
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA223' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'User impersonation action set to Quarantine' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.TargetedUserProtectionAction -eq 'Quarantine') {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have User Impersonation action set to Quarantine.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have User Impersonation action set to Quarantine.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Targeted User Protection Action |`n"
            $Result += "|------------|--------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.TargetedUserProtectionAction) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA223' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'User impersonation action set to Quarantine' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA223' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'User impersonation action set to Quarantine' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA223.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA224.ps1' -1

function Invoke-CippTestORCA224 {
    <#
    .SYNOPSIS
    Similar Users Safety Tips is enabled
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA224' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Similar Users Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableSimilarUsersSafetyTips -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have Similar Users Safety Tips enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have Similar Users Safety Tips enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable Similar Users Safety Tips |`n"
            $Result += "|------------|----------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableSimilarUsersSafetyTips) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA224' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Similar Users Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA224' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Similar Users Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA224.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA225.ps1' -1

function Invoke-CippTestORCA225 {
    <#
    .SYNOPSIS
    Safe Documents is enabled for Office clients
    #>
    param($Tenant)

    try {
        $AtpPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAtpPolicyForO365'

        if (-not $AtpPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA225' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Safe Documents is enabled for Office clients' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Attachments'
            return
        }

        $Policy = $AtpPolicy | Select-Object -First 1

        if ($Policy.EnableSafeDocs -eq $true) {
            $Status = 'Passed'
            $Result = "Safe Documents is enabled for Office clients.`n`n"
            $Result += "**EnableSafeDocs:** $($Policy.EnableSafeDocs)"
        } else {
            $Status = 'Failed'
            $Result = "Safe Documents is NOT enabled for Office clients.`n`n"
            $Result += "**EnableSafeDocs:** $($Policy.EnableSafeDocs)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA225' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Safe Documents is enabled for Office clients' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Attachments'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA225' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Safe Documents is enabled for Office clients' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Attachments'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA225.ps1' 36
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA226.ps1' -1

function Invoke-CippTestORCA226 {
    <#
    .SYNOPSIS
    Each domain has a Safe Links policy
    #>
    param($Tenant)

    try {
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'
        $SafeLinksPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA226' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No accepted domains found in database.' -Risk 'High' -Name 'Each domain has a Safe Links policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Safe Links'
            return
        }

        if (-not $SafeLinksPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA226' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'No Safe Links policies found. Each domain should have a Safe Links policy.' -Risk 'High' -Name 'Each domain has a Safe Links policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Safe Links'
            return
        }

        # Get all recipient domains from policies
        $CoveredDomains = [System.Collections.Generic.List[string]]::new()
        foreach ($Policy in $SafeLinksPolicies) {
            if ($Policy.RecipientDomainIs) {
                foreach ($Domain in $Policy.RecipientDomainIs) {
                    $CoveredDomains.Add($Domain) | Out-Null
                }
            }
        }

        $DomainsWithoutPolicy = [System.Collections.Generic.List[string]]::new()
        foreach ($Domain in $AcceptedDomains) {
            if ($CoveredDomains -notcontains $Domain.DomainName) {
                $DomainsWithoutPolicy.Add($Domain.DomainName) | Out-Null
            }
        }

        if ($DomainsWithoutPolicy.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All accepted domains are covered by Safe Links policies.`n`n"
            $Result += "**Total Accepted Domains:** $($AcceptedDomains.Count)`n"
            $Result += "**Total Safe Links Policies:** $($SafeLinksPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($DomainsWithoutPolicy.Count) domains do not have a Safe Links policy.`n`n"
            $Result += "**Domains Without Policy:**`n`n"
            foreach ($Domain in $DomainsWithoutPolicy) {
                $Result += "- $Domain`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA226' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Each domain has a Safe Links policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Safe Links'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA226' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Each domain has a Safe Links policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Safe Links'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA226.ps1' 61
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA227.ps1' -1

function Invoke-CippTestORCA227 {
    <#
    .SYNOPSIS
    Each domain has a Safe Attachments policy
    #>
    param($Tenant)

    try {
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'
        $SafeAttachmentPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeAttachmentPolicies'

        if (-not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA227' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No accepted domains found in database.' -Risk 'High' -Name 'Each domain has a Safe Attachments policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Safe Attachments'
            return
        }

        if (-not $SafeAttachmentPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA227' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'No Safe Attachments policies found. Each domain should have a Safe Attachments policy.' -Risk 'High' -Name 'Each domain has a Safe Attachments policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Safe Attachments'
            return
        }

        # Get all recipient domains from policies
        $CoveredDomains = [System.Collections.Generic.List[string]]::new()
        foreach ($Policy in $SafeAttachmentPolicies) {
            if ($Policy.RecipientDomainIs) {
                foreach ($Domain in $Policy.RecipientDomainIs) {
                    $CoveredDomains.Add($Domain) | Out-Null
                }
            }
        }

        $DomainsWithoutPolicy = [System.Collections.Generic.List[string]]::new()
        foreach ($Domain in $AcceptedDomains) {
            if ($CoveredDomains -notcontains $Domain.DomainName) {
                $DomainsWithoutPolicy.Add($Domain.DomainName) | Out-Null
            }
        }

        if ($DomainsWithoutPolicy.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All accepted domains are covered by Safe Attachments policies.`n`n"
            $Result += "**Total Accepted Domains:** $($AcceptedDomains.Count)`n"
            $Result += "**Total Safe Attachments Policies:** $($SafeAttachmentPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($DomainsWithoutPolicy.Count) domains do not have a Safe Attachments policy.`n`n"
            $Result += "**Domains Without Policy:**`n`n"
            foreach ($Domain in $DomainsWithoutPolicy) {
                $Result += "- $Domain`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA227' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Each domain has a Safe Attachments policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Safe Attachments'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA227' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Each domain has a Safe Attachments policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Safe Attachments'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA227.ps1' 61
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA228.ps1' -1

function Invoke-CippTestORCA228 {
    <#
    .SYNOPSIS
    No trusted senders in Anti-phishing policy
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA228' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'No trusted senders in Anti-phishing policy' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            $HasTrustedSenders = ($Policy.ExcludedSenders -and $Policy.ExcludedSenders.Count -gt 0)

            if (-not $HasTrustedSenders) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No anti-phishing policies have trusted senders configured.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies have trusted senders configured.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Excluded Senders Count |`n"
            $Result += "|------------|----------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Count = if ($Policy.ExcludedSenders) { $Policy.ExcludedSenders.Count } else { 0 }
                $Result += "| $($Policy.Identity) | $Count |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA228' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'No trusted senders in Anti-phishing policy' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA228' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'No trusted senders in Anti-phishing policy' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA228.ps1' 53
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA229.ps1' -1

function Invoke-CippTestORCA229 {
    <#
    .SYNOPSIS
    No trusted domains in Anti-phishing policy
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA229' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'No trusted domains in Anti-phishing policy' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            $HasTrustedDomains = ($Policy.ExcludedDomains -and $Policy.ExcludedDomains.Count -gt 0)

            if (-not $HasTrustedDomains) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No anti-phishing policies have trusted domains configured.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies have trusted domains configured.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Excluded Domains Count |`n"
            $Result += "|------------|----------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Count = if ($Policy.ExcludedDomains) { $Policy.ExcludedDomains.Count } else { 0 }
                $Result += "| $($Policy.Identity) | $Count |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA229' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'No trusted domains in Anti-phishing policy' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA229' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'No trusted domains in Anti-phishing policy' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA229.ps1' 53
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA230.ps1' -1

function Invoke-CippTestORCA230 {
    <#
    .SYNOPSIS
    Each domain has an Anti-phishing policy
    #>
    param($Tenant)

    try {
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'
        $AntiPhishPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA230' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No accepted domains found in database.' -Risk 'High' -Name 'Each domain has an Anti-phishing policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Anti-Phish'
            return
        }

        if (-not $AntiPhishPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA230' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'No Anti-phishing policies found. Each domain should have an Anti-phishing policy.' -Risk 'High' -Name 'Each domain has an Anti-phishing policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Anti-Phish'
            return
        }

        # Get all recipient domains from policies
        $CoveredDomains = [System.Collections.Generic.List[string]]::new()
        foreach ($Policy in $AntiPhishPolicies) {
            if ($Policy.RecipientDomainIs) {
                foreach ($Domain in $Policy.RecipientDomainIs) {
                    $CoveredDomains.Add($Domain) | Out-Null
                }
            }
        }

        $DomainsWithoutPolicy = [System.Collections.Generic.List[string]]::new()
        foreach ($Domain in $AcceptedDomains) {
            if ($CoveredDomains -notcontains $Domain.DomainName) {
                $DomainsWithoutPolicy.Add($Domain.DomainName) | Out-Null
            }
        }

        if ($DomainsWithoutPolicy.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All accepted domains are covered by Anti-phishing policies.`n`n"
            $Result += "**Total Accepted Domains:** $($AcceptedDomains.Count)`n"
            $Result += "**Total Anti-phishing Policies:** $($AntiPhishPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($DomainsWithoutPolicy.Count) domains do not have an Anti-phishing policy.`n`n"
            $Result += "**Domains Without Policy:**`n`n"
            foreach ($Domain in $DomainsWithoutPolicy) {
                $Result += "- $Domain`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA230' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Each domain has an Anti-phishing policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA230' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Each domain has an Anti-phishing policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA230.ps1' 61
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA231.ps1' -1

function Invoke-CippTestORCA231 {
    <#
    .SYNOPSIS
    Each domain has an anti-spam policy
    #>
    param($Tenant)

    try {
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'
        $ContentFilterPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA231' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No accepted domains found in database.' -Risk 'High' -Name 'Each domain has an anti-spam policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Anti-Spam'
            return
        }

        if (-not $ContentFilterPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA231' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'No anti-spam policies found. Each domain should have an anti-spam policy.' -Risk 'High' -Name 'Each domain has an anti-spam policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Anti-Spam'
            return
        }

        # Get all recipient domains from policies
        $CoveredDomains = [System.Collections.Generic.List[string]]::new()
        foreach ($Policy in $ContentFilterPolicies) {
            if ($Policy.RecipientDomainIs) {
                foreach ($Domain in $Policy.RecipientDomainIs) {
                    $CoveredDomains.Add($Domain) | Out-Null
                }
            }
        }

        $DomainsWithoutPolicy = [System.Collections.Generic.List[string]]::new()
        foreach ($Domain in $AcceptedDomains) {
            if ($CoveredDomains -notcontains $Domain.DomainName) {
                $DomainsWithoutPolicy.Add($Domain.DomainName) | Out-Null
            }
        }

        if ($DomainsWithoutPolicy.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All accepted domains are covered by anti-spam policies.`n`n"
            $Result += "**Total Accepted Domains:** $($AcceptedDomains.Count)`n"
            $Result += "**Total Anti-spam Policies:** $($ContentFilterPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($DomainsWithoutPolicy.Count) domains do not have an anti-spam policy.`n`n"
            $Result += "**Domains Without Policy:**`n`n"
            foreach ($Domain in $DomainsWithoutPolicy) {
                $Result += "- $Domain`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA231' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Each domain has an anti-spam policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA231' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Each domain has an anti-spam policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA231.ps1' 61
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA232.ps1' -1

function Invoke-CippTestORCA232 {
    <#
    .SYNOPSIS
    Each domain has a malware filter policy
    #>
    param($Tenant)

    try {
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'
        $MalwarePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoMalwareFilterPolicies'

        if (-not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA232' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No accepted domains found in database.' -Risk 'High' -Name 'Each domain has a malware filter policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Malware'
            return
        }

        if (-not $MalwarePolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA232' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'No malware filter policies found. Each domain should have a malware filter policy.' -Risk 'High' -Name 'Each domain has a malware filter policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Malware'
            return
        }

        # Get all recipient domains from policies
        $CoveredDomains = [System.Collections.Generic.List[string]]::new()
        foreach ($Policy in $MalwarePolicies) {
            if ($Policy.RecipientDomainIs) {
                foreach ($Domain in $Policy.RecipientDomainIs) {
                    $CoveredDomains.Add($Domain) | Out-Null
                }
            }
        }

        $DomainsWithoutPolicy = [System.Collections.Generic.List[string]]::new()
        foreach ($Domain in $AcceptedDomains) {
            if ($CoveredDomains -notcontains $Domain.DomainName) {
                $DomainsWithoutPolicy.Add($Domain.DomainName) | Out-Null
            }
        }

        if ($DomainsWithoutPolicy.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All accepted domains are covered by malware filter policies.`n`n"
            $Result += "**Total Accepted Domains:** $($AcceptedDomains.Count)`n"
            $Result += "**Total Malware Filter Policies:** $($MalwarePolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($DomainsWithoutPolicy.Count) domains do not have a malware filter policy.`n`n"
            $Result += "**Domains Without Policy:**`n`n"
            foreach ($Domain in $DomainsWithoutPolicy) {
                $Result += "- $Domain`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA232' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Each domain has a malware filter policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Malware'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA232' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Each domain has a malware filter policy' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Malware'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA232.ps1' 61
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA233_1.ps1' -1

function Invoke-CippTestORCA233_1 {
    <#
    .SYNOPSIS
    Enhanced filtering on default connectors
    #>
    param($Tenant)

    try {
        $OrgConfig = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoOrganizationConfig'

        if (-not $OrgConfig) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA233_1' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No organization config found in database.' -Risk 'Medium' -Name 'Enhanced filtering on default connectors' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Configuration'
            return
        }

        $Config = $OrgConfig | Select-Object -First 1

        # Check if enhanced filtering is enabled
        # This property may vary depending on Exchange Online version
        $EnhancedFilteringEnabled = $false

        # Check various properties that indicate enhanced filtering
        if ($Config.PSObject.Properties.Name -contains 'SkipListedFromForging') {
            $EnhancedFilteringEnabled = $Config.SkipListedFromForging -eq $false
        }

        if ($EnhancedFilteringEnabled) {
            $Status = 'Passed'
            $Result = "Enhanced filtering appears to be properly configured.`n`n"
            $Result += "**Configuration:** Reviewed"
        } else {
            $Status = 'Informational'
            $Result = "Unable to fully determine enhanced filtering status. Manual review recommended.`n`n"
            $Result += "**Action Required:** Review inbound connectors for enhanced filtering configuration"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA233_1' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Enhanced filtering on default connectors' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Configuration'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA233_1' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Enhanced filtering on default connectors' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Configuration'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA233_1.ps1' 45
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA233.ps1' -1

function Invoke-CippTestORCA233 {
    <#
    .SYNOPSIS
    Domains pointed at EOP or enhanced filtering used
    #>
    param($Tenant)

    try {
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'

        if (-not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA233' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No accepted domains found in database.' -Risk 'High' -Name 'Domains pointed at EOP or enhanced filtering used' -UserImpact 'High' -ImplementationEffort 'High' -Category 'Configuration'
            return
        }

        # This test requires checking MX records and inbound connectors which may not be available
        # We'll check if domains are authoritative (pointed at EOP) or use external mail flow
        $NonCompliantDomains = [System.Collections.Generic.List[string]]::new()
        $CompliantDomains = [System.Collections.Generic.List[string]]::new()

        foreach ($Domain in $AcceptedDomains) {
            # Authoritative domains point MX to EOP
            # InternalRelay/ExternalRelay domains use inbound connectors with enhanced filtering
            if ($Domain.DomainType -eq 'Authoritative') {
                $CompliantDomains.Add($Domain.DomainName) | Out-Null
            } elseif ($Domain.DomainType -in @('InternalRelay', 'ExternalRelay')) {
                # These should have enhanced filtering configured on inbound connectors
                # For now, we'll mark these as compliant if they exist
                $CompliantDomains.Add($Domain.DomainName) | Out-Null
            } else {
                $NonCompliantDomains.Add($Domain.DomainName) | Out-Null
            }
        }

        if ($NonCompliantDomains.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All domains are properly configured for mail flow.`n`n"
            $Result += "**Compliant Domains:** $($CompliantDomains.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($NonCompliantDomains.Count) domains may not be properly configured for mail flow.`n`n"
            $Result += "**Domains Needing Review:**`n`n"
            foreach ($Domain in $NonCompliantDomains) {
                $Result += "- $Domain`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA233' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Domains pointed at EOP or enhanced filtering used' -UserImpact 'High' -ImplementationEffort 'High' -Category 'Configuration'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA233' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Domains pointed at EOP or enhanced filtering used' -UserImpact 'High' -ImplementationEffort 'High' -Category 'Configuration'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA233.ps1' 56
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA234.ps1' -1

function Invoke-CippTestORCA234 {
    <#
    .SYNOPSIS
    Click through is disabled for Safe Documents
    #>
    param($Tenant)

    try {
        $AtpPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAtpPolicyForO365'

        if (-not $AtpPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA234' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Click through is disabled for Safe Documents' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Attachments'
            return
        }

        $Policy = $AtpPolicy | Select-Object -First 1

        if ($Policy.AllowSafeDocsOpen -eq $false) {
            $Status = 'Passed'
            $Result = "Click through is disabled for Safe Documents.`n`n"
            $Result += "**AllowSafeDocsOpen:** $($Policy.AllowSafeDocsOpen)"
        } else {
            $Status = 'Failed'
            $Result = "Click through is enabled for Safe Documents.`n`n"
            $Result += "**AllowSafeDocsOpen:** $($Policy.AllowSafeDocsOpen)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA234' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Click through is disabled for Safe Documents' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Attachments'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA234' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Click through is disabled for Safe Documents' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Attachments'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA234.ps1' 36
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA235.ps1' -1

function Invoke-CippTestORCA235 {
    <#
    .SYNOPSIS
    SPF records setup for custom domains
    #>
    param($Tenant)

    try {
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'

        if (-not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA235' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No accepted domains found in database.' -Risk 'High' -Name 'SPF records setup for custom domains' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Configuration'
            return
        }

        # Note: This test would ideally check DNS SPF records
        # Since we don't have DNS query capability here, we'll provide informational guidance

        $CustomDomains = $AcceptedDomains | Where-Object { $_.DomainName -notlike '*.onmicrosoft.com' }

        if ($CustomDomains.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No custom domains found. Only using onmicrosoft.com domain.`n`n"
            $Result += "**Total Domains:** $($AcceptedDomains.Count)"
        } else {
            $Status = 'Informational'
            $Result = "Found $($CustomDomains.Count) custom domains that should have SPF records configured.`n`n"
            $Result += "**Custom Domains:**`n`n"
            foreach ($Domain in $CustomDomains) {
                $Result += "- $($Domain.DomainName)`n"
            }
            $Result += "`n**Action Required:** Verify that each custom domain has an SPF record including Microsoft 365:`n"
            $Result += "``v=spf1 include:spf.protection.outlook.com -all``"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA235' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'SPF records setup for custom domains' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Configuration'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA235' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'SPF records setup for custom domains' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Configuration'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA235.ps1' 44
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA236.ps1' -1

function Invoke-CippTestORCA236 {
    <#
    .SYNOPSIS
    Safe Links is enabled for emails
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA236' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Safe Links is enabled for emails' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableSafeLinksForEmail -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All Safe Links policies have email protection enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) Safe Links policies do not have email protection enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable Safe Links For Email |`n"
            $Result += "|------------|----------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableSafeLinksForEmail) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA236' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Safe Links is enabled for emails' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA236' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Safe Links is enabled for emails' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA236.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA237.ps1' -1

function Invoke-CippTestORCA237 {
    <#
    .SYNOPSIS
    Safe Links is enabled for Teams
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA237' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Safe Links is enabled for Teams' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableSafeLinksForTeams -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All Safe Links policies have Teams protection enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) Safe Links policies do not have Teams protection enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable Safe Links For Teams |`n"
            $Result += "|------------|----------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableSafeLinksForTeams) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA237' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Safe Links is enabled for Teams' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA237' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Safe Links is enabled for Teams' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA237.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA238.ps1' -1

function Invoke-CippTestORCA238 {
    <#
    .SYNOPSIS
    Safe Links is enabled for Office documents
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoSafeLinksPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA238' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Safe Links is enabled for Office documents' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableSafeLinksForOffice -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All Safe Links policies have Office document protection enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) Safe Links policies do not have Office document protection enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable Safe Links For Office |`n"
            $Result += "|------------|------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableSafeLinksForOffice) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA238' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Safe Links is enabled for Office documents' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA238' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Safe Links is enabled for Office documents' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Safe Links'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA238.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA239.ps1' -1

function Invoke-CippTestORCA239 {
    <#
    .SYNOPSIS
    No exclusions for built-in protection
    #>
    param($Tenant)

    try {
        $AntiPhishPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'
        $ContentFilterPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $AntiPhishPolicies -and -not $ContentFilterPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA239' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No policies found in database.' -Risk 'High' -Name 'No exclusions for built-in protection' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Configuration'
            return
        }

        $FailedPolicies = @()
        $Issues = @()

        # Check Anti-Phish policies for exclusions
        if ($AntiPhishPolicies) {
            foreach ($Policy in $AntiPhishPolicies) {
                $HasExclusions = $false
                $ExclusionDetails = @()

                if ($Policy.ExcludedSenders -and $Policy.ExcludedSenders.Count -gt 0) {
                    $HasExclusions = $true
                    $ExclusionDetails += "ExcludedSenders: $($Policy.ExcludedSenders.Count)"
                }

                if ($Policy.ExcludedDomains -and $Policy.ExcludedDomains.Count -gt 0) {
                    $HasExclusions = $true
                    $ExclusionDetails += "ExcludedDomains: $($Policy.ExcludedDomains.Count)"
                }

                if ($HasExclusions) {
                    $Issues += "Anti-Phish Policy '$($Policy.Identity)': $($ExclusionDetails -join ', ')"
                }
            }
        }

        # Check Content Filter policies for exclusions
        if ($ContentFilterPolicies) {
            foreach ($Policy in $ContentFilterPolicies) {
                $HasExclusions = $false
                $ExclusionDetails = @()

                if ($Policy.AllowedSenders -and $Policy.AllowedSenders.Count -gt 0) {
                    $HasExclusions = $true
                    $ExclusionDetails += "AllowedSenders: $($Policy.AllowedSenders.Count)"
                }

                if ($Policy.AllowedSenderDomains -and $Policy.AllowedSenderDomains.Count -gt 0) {
                    $HasExclusions = $true
                    $ExclusionDetails += "AllowedSenderDomains: $($Policy.AllowedSenderDomains.Count)"
                }

                if ($HasExclusions) {
                    $Issues += "Anti-Spam Policy '$($Policy.Identity)': $($ExclusionDetails -join ', ')"
                }
            }
        }

        if ($Issues.Count -eq 0) {
            $Status = 'Passed'
            $Result = "No exclusions found in built-in protection policies."
        } else {
            $Status = 'Failed'
            $Result = "Found $($Issues.Count) policies with exclusions that bypass built-in protection.`n`n"
            $Result += "**Issues Found:**`n`n"
            foreach ($Issue in $Issues) {
                $Result += "- $Issue`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA239' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'No exclusions for built-in protection' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Configuration'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA239' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'No exclusions for built-in protection' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Configuration'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA239.ps1' 84
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA240.ps1' -1

function Invoke-CippTestORCA240 {
    <#
    .SYNOPSIS
    Outlook external tags are configured
    #>
    param($Tenant)

    try {
        $OrgConfig = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoOrganizationConfig'

        if (-not $OrgConfig) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA240' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Outlook external tags are configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Configuration'
            return
        }

        $Config = $OrgConfig | Select-Object -First 1

        if ($Config.ExternalInOutlook -ne 'Disabled') {
            $Status = 'Passed'
            $Result = "Outlook external tags are configured.`n`n"
            $Result += "**ExternalInOutlook:** $($Config.ExternalInOutlook)"
        } else {
            $Status = 'Failed'
            $Result = "Outlook external tags are NOT configured.`n`n"
            $Result += "**ExternalInOutlook:** $($Config.ExternalInOutlook)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA240' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Outlook external tags are configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Configuration'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA240' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Outlook external tags are configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Configuration'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA240.ps1' 36
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA241.ps1' -1

function Invoke-CippTestORCA241 {
    <#
    .SYNOPSIS
    First Contact Safety Tips is enabled
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAntiPhishPolicies'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA241' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'First Contact Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.EnableFirstContactSafetyTips -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-phishing policies have First Contact Safety Tips enabled.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-phishing policies do not have First Contact Safety Tips enabled.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Enable First Contact Safety Tips |`n"
            $Result += "|------------|----------------------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.EnableFirstContactSafetyTips) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA241' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'First Contact Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA241' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'First Contact Safety Tips is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Phish'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA241.ps1' 50
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA242.ps1' -1

function Invoke-CippTestORCA242 {
    <#
    .SYNOPSIS
    Important protection alerts enabled
    #>
    param($Tenant)

    try {
        # This test would check for alert policies related to ATP/Defender for Office 365
        # Since we don't have an alert policy cache, we'll provide informational guidance

        $Status = 'Informational'
        $Result = "Alert policies for protection features should be enabled and monitored.`n`n"
        $Result += "**Recommended Alert Policies:**`n`n"
        $Result += "- Messages reported by users as malware or phish`n"
        $Result += "- Email sending limit exceeded`n"
        $Result += "- Suspicious email forwarding activity`n"
        $Result += "- Malware campaign detected`n"
        $Result += "- Suspicious connector activity`n"
        $Result += "- Unusual external user file activity`n"
        $Result += "`n**Action Required:** Verify alert policies are configured in Microsoft 365 Security & Compliance Center"

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA242' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Important protection alerts enabled' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Configuration'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA242' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Important protection alerts enabled' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Configuration'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA242.ps1' 31
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA243.ps1' -1

function Invoke-CippTestORCA243 {
    <#
    .SYNOPSIS
    Authenticated Receive Chain for non-EOP domains
    #>
    param($Tenant)

    try {
        $AcceptedDomains = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoAcceptedDomains'

        if (-not $AcceptedDomains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA243' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No accepted domains found in database.' -Risk 'Medium' -Name 'Authenticated Receive Chain for non-EOP domains' -UserImpact 'Medium' -ImplementationEffort 'High' -Category 'Configuration'
            return
        }

        # Check for non-authoritative domains that would need inbound connectors
        $NonAuthDomains = $AcceptedDomains | Where-Object { $_.DomainType -in @('InternalRelay', 'ExternalRelay') }

        if ($NonAuthDomains.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All domains are authoritative. No inbound connectors needed.`n`n"
            $Result += "**Total Domains:** $($AcceptedDomains.Count)"
        } else {
            $Status = 'Informational'
            $Result = "Found $($NonAuthDomains.Count) non-authoritative domains.`n`n"
            $Result += "**Domains Requiring Inbound Connectors:**`n`n"
            foreach ($Domain in $NonAuthDomains) {
                $Result += "- $($Domain.DomainName) (Type: $($Domain.DomainType))`n"
            }
            $Result += "`n**Action Required:** Verify inbound connectors are configured with proper authentication for these domains"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA243' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Authenticated Receive Chain for non-EOP domains' -UserImpact 'Medium' -ImplementationEffort 'High' -Category 'Configuration'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA243' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Authenticated Receive Chain for non-EOP domains' -UserImpact 'Medium' -ImplementationEffort 'High' -Category 'Configuration'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA243.ps1' 41
#Region './Public/Tests/ORCA/Identity/Invoke-CippTestORCA244.ps1' -1

function Invoke-CippTestORCA244 {
    <#
    .SYNOPSIS
    Policies honor sending domain DMARC
    #>
    param($Tenant)

    try {
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ExoHostedContentFilterPolicy'

        if (-not $Policies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA244' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Policies honor sending domain DMARC' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
            return
        }

        $FailedPolicies = [System.Collections.Generic.List[object]]::new()
        $PassedPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $Policies) {
            if ($Policy.HonorDMARCPolicy -eq $true) {
                $PassedPolicies.Add($Policy) | Out-Null
            } else {
                $FailedPolicies.Add($Policy) | Out-Null
            }
        }

        if ($FailedPolicies.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All anti-spam policies honor sending domain DMARC.`n`n"
            $Result += "**Compliant Policies:** $($PassedPolicies.Count)"
        } else {
            $Status = 'Failed'
            $Result = "$($FailedPolicies.Count) anti-spam policies do not honor sending domain DMARC.`n`n"
            $Result += "**Non-Compliant Policies:** $($FailedPolicies.Count)`n`n"
            $Result += "| Policy Name | Honor DMARC Policy |`n"
            $Result += "|------------|--------------------|`n"
            foreach ($Policy in $FailedPolicies) {
                $Result += "| $($Policy.Identity) | $($Policy.HonorDMARCPolicy) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA244' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Policies honor sending domain DMARC' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ORCA244' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Policies honor sending domain DMARC' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Anti-Spam'
    }
}
#EndRegion './Public/Tests/ORCA/Identity/Invoke-CippTestORCA244.ps1' 50
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24540.ps1' -1

function Invoke-CippTestZTNA24540 {
    <#
    .SYNOPSIS
    Windows Firewall policies protect against unauthorized network access
    #>
    param($Tenant)
    #Tested - Device
    try {
        $ConfigurationPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneConfigurationPolicies'
        if (-not $ConfigurationPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24540' -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Windows Firewall policies protect against unauthorized network access' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $FirewallPolicies = $ConfigurationPolicies | Where-Object {
            $_.templateReference -and $_.templateReference.templateFamily -eq 'endpointSecurityFirewall'
        }

        if ($FirewallPolicies.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24540' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No Windows Firewall configuration policies found' -Risk 'High' -Name 'Windows Firewall policies protect against unauthorized network access' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $AssignedPolicies = $FirewallPolicies | Where-Object {
            $_.assignments -and $_.assignments.Count -gt 0
        }

        if ($AssignedPolicies.Count -gt 0) {
            $Status = 'Passed'
            $ResultLines = @(
                'At least one Windows Firewall policy is created and assigned to a group.'
                ''
                '**Windows Firewall Configuration Policies:**'
                ''
                '| Policy Name | Status | Assignment Count |'
                '| :---------- | :----- | :--------------- |'
            )

            foreach ($Policy in $FirewallPolicies) {
                $PolicyStatus = if ($Policy.assignments -and $Policy.assignments.Count -gt 0) {
                    '✅ Assigned'
                } else {
                    '❌ Not assigned'
                }
                $AssignmentCount = if ($Policy.assignments) { $Policy.assignments.Count } else { 0 }
                $ResultLines += "| $($Policy.name) | $PolicyStatus | $AssignmentCount |"
            }

            $Result = $ResultLines -join "`n"
        } else {
            $Status = 'Failed'
            $ResultLines = @(
                'There are no firewall policies assigned to any groups.'
                ''
                '**Windows Firewall Configuration Policies (Unassigned):**'
                ''
            )

            foreach ($Policy in $FirewallPolicies) {
                $ResultLines += "- $($Policy.name)"
            }

            $Result = $ResultLines -join "`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24540' -TestType 'Devices' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Windows Firewall policies protect against unauthorized network access' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Device'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24540' -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Windows Firewall policies protect against unauthorized network access' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Device'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24540.ps1' 73
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24541.ps1' -1

function Invoke-CippTestZTNA24541 {
    <#
    .SYNOPSIS
    Compliance policies protect Windows devices
    #>
    param($Tenant)

    $TestId = 'ZTNA24541'
    #Tested - Device
    try {
        $IntunePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceCompliancePolicies'

        if (-not $IntunePolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Compliance policies protect Windows devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
            return
        }

        $WindowsPolicies = @($IntunePolicies | Where-Object {
                $_.'@odata.type' -in @('#microsoft.graph.windows10CompliancePolicy', '#microsoft.graph.windows11CompliancePolicy')
            })

        $AssignedPolicies = @($WindowsPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedPolicies.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one Windows compliance policy exists and is assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No Windows compliance policy exists or none are assigned.`n`n"
        }

        $ResultMarkdown += "## Windows Compliance Policies`n`n"
        $ResultMarkdown += "| Policy Name | Assigned |`n"
        $ResultMarkdown += "| :---------- | :------- |`n"

        foreach ($policy in $WindowsPolicies) {
            $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
            $ResultMarkdown += "| $($policy.displayName) | $assigned |`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Compliance policies protect Windows devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Compliance policies protect Windows devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24541.ps1' 49
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24542.ps1' -1

function Invoke-CippTestZTNA24542 {
    <#
    .SYNOPSIS
    Compliance policies protect macOS devices
    #>
    param($Tenant)

    $TestId = 'ZTNA24542'
    #Tested - Device
    try {
        $IntunePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceCompliancePolicies'

        if (-not $IntunePolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Compliance policies protect macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
            return
        }

        $MacOSPolicies = @($IntunePolicies | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.macOSCompliancePolicy' })
        $AssignedPolicies = @($MacOSPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedPolicies.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one macOS compliance policy exists and is assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No macOS compliance policy exists or none are assigned.`n`n"
        }

        $ResultMarkdown += "## macOS Compliance Policies`n`n"
        $ResultMarkdown += "| Policy Name | Assigned |`n"
        $ResultMarkdown += "| :---------- | :------- |`n"

        foreach ($policy in $MacOSPolicies) {
            $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
            $ResultMarkdown += "| $($policy.displayName) | $assigned |`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Compliance policies protect macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Compliance policies protect macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24542.ps1' 46
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24543.ps1' -1

function Invoke-CippTestZTNA24543 {
    <#
    .SYNOPSIS
    Compliance policies protect iOS/iPadOS devices
    #>
    param($Tenant)

    $TestId = 'ZTNA24543'
    #Tested - Device

    try {
        $IntunePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceCompliancePolicies'

        if (-not $IntunePolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Compliance policies protect iOS/iPadOS devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
            return
        }

        $iOSPolicies = @($IntunePolicies | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.iosCompliancePolicy' })
        $AssignedPolicies = @($iOSPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedPolicies.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one iOS/iPadOS compliance policy exists and is assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No iOS/iPadOS compliance policy exists or none are assigned.`n`n"
        }

        $ResultMarkdown += "## iOS/iPadOS Compliance Policies`n`n"
        $ResultMarkdown += "| Policy Name | Assigned |`n"
        $ResultMarkdown += "| :---------- | :------- |`n"

        foreach ($policy in $iOSPolicies) {
            $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
            $ResultMarkdown += "| $($policy.displayName) | $assigned |`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Compliance policies protect iOS/iPadOS devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Compliance policies protect iOS/iPadOS devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24543.ps1' 47
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24545.ps1' -1

function Invoke-CippTestZTNA24545 {
    <#
    .SYNOPSIS
    Compliance policies protect fully managed and corporate-owned Android devices
    #>
    param($Tenant)

    $TestId = 'ZTNA24545'
    #Tested - Device

    try {
        $IntunePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceCompliancePolicies'

        if (-not $IntunePolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Compliance policies protect fully managed and corporate-owned Android devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
            return
        }

        $AndroidPolicies = @($IntunePolicies | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.androidDeviceOwnerCompliancePolicy' })
        $AssignedPolicies = @($AndroidPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })

        $Passed = $AssignedPolicies.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one compliance policy for Android Enterprise Fully managed devices exists and is assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No compliance policy for Android Enterprise exists or none are assigned.`n`n"
        }

        $ResultMarkdown += "## Android Device Owner Compliance Policies`n`n"
        $ResultMarkdown += "| Policy Name | Assigned |`n"
        $ResultMarkdown += "| :---------- | :------- |`n"

        foreach ($policy in $AndroidPolicies) {
            $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
            $ResultMarkdown += "| $($policy.displayName) | $assigned |`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Compliance policies protect fully managed and corporate-owned Android devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Compliance policies protect fully managed and corporate-owned Android devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24545.ps1' 48
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24547.ps1' -1

function Invoke-CippTestZTNA24547 {
    <#
    .SYNOPSIS
    Compliance policies protect personally owned Android devices
    #>
    param($Tenant)

    $TestId = 'ZTNA24547'
    #Tested - Device

    try {
        $IntunePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceCompliancePolicies'

        if (-not $IntunePolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Compliance policies protect personally owned Android devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
            return
        }

        $AndroidPolicies = @($IntunePolicies | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.androidWorkProfileCompliancePolicy' })
        $AssignedPolicies = @($AndroidPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })

        $Passed = $AssignedPolicies.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one compliance policy for Android Work Profile devices exists and is assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No compliance policy for Android Work Profile exists or none are assigned.`n`n"
        }

        $ResultMarkdown += "## Android Work Profile Compliance Policies`n`n"
        $ResultMarkdown += "| Policy Name | Assigned |`n"
        $ResultMarkdown += "| :---------- | :------- |`n"

        foreach ($policy in $AndroidPolicies) {
            $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
            $ResultMarkdown += "| $($policy.displayName) | $assigned |`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Compliance policies protect personally owned Android devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Compliance policies protect personally owned Android devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24547.ps1' 48
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24548.ps1' -1

function Invoke-CippTestZTNA24548 {
    <#
    .SYNOPSIS
    Data on iOS/iPadOS is protected by app protection policies
    #>
    param($Tenant)

    $TestId = 'ZTNA24548'
    #Tested - Device

    try {
        $IosPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneIosAppProtectionPolicies'

        if (-not $IosPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Data on iOS/iPadOS is protected by app protection policies' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant'
            return
        }

        $AssignedPolicies = @($IosPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedPolicies.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one iOS app protection policy exists and is assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No iOS app protection policy exists or none are assigned.`n`n"
        }

        $ResultMarkdown += "## iOS App Protection Policies`n`n"
        $ResultMarkdown += "| Policy Name | Assigned |`n"
        $ResultMarkdown += "| :---------- | :------- |`n"

        foreach ($policy in $IosPolicies) {
            $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
            $ResultMarkdown += "| $($policy.displayName) | $assigned |`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Data on iOS/iPadOS is protected by app protection policies' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Data on iOS/iPadOS is protected by app protection policies' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24548.ps1' 46
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24549.ps1' -1

function Invoke-CippTestZTNA24549 {
    <#
    .SYNOPSIS
    Data on Android is protected by app protection policies
    #>
    param($Tenant)

    $TestId = 'ZTNA24549'
    #Tested - Device

    try {
        $AndroidPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneAndroidAppProtectionPolicies'

        if (-not $AndroidPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Data on Android is protected by app protection policies' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant'
            return
        }

        $AssignedPolicies = @($AndroidPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedPolicies.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one Android app protection policy exists and is assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No Android app protection policy exists or none are assigned.`n`n"
        }

        $ResultMarkdown += "## Android App Protection Policies`n`n"
        $ResultMarkdown += "| Policy Name | Assigned |`n"
        $ResultMarkdown += "| :---------- | :------- |`n"

        foreach ($policy in $AndroidPolicies) {
            $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
            $ResultMarkdown += "| $($policy.displayName) | $assigned |`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Data on Android is protected by app protection policies' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Data on Android is protected by app protection policies' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24549.ps1' 46
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24550.ps1' -1

function Invoke-CippTestZTNA24550 {
    <#
    .SYNOPSIS
    Data on Windows is protected by BitLocker encryption
    #>
    param($Tenant)
    #Tested - Device

    try {
        $ConfigurationPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneConfigurationPolicies'
        if (-not $ConfigurationPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24550' -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Data on Windows is protected by BitLocker encryption' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $WindowsPolicies = $ConfigurationPolicies | Where-Object {
            $_.platforms -match 'windows10'
        }

        $WindowsBitLockerPolicies = @()
        foreach ($WindowsPolicy in $WindowsPolicies) {
            $ValidSettingValues = @('device_vendor_msft_bitlocker_requiredeviceencryption_1')

            if ($WindowsPolicy.settings.settinginstance.choicesettingvalue.value) {
                $PolicySettingValues = $WindowsPolicy.settings.settinginstance.choicesettingvalue.value
                if ($PolicySettingValues -isnot [array]) {
                    $PolicySettingValues = @($PolicySettingValues)
                }

                $HasValidSetting = $false
                foreach ($SettingValue in $PolicySettingValues) {
                    if ($ValidSettingValues -contains $SettingValue) {
                        $HasValidSetting = $true
                        break
                    }
                }

                if ($HasValidSetting) {
                    $WindowsBitLockerPolicies += $WindowsPolicy
                }
            }
        }

        $AssignedPolicies = $WindowsBitLockerPolicies | Where-Object {
            $_.assignments -and $_.assignments.Count -gt 0
        }

        if ($AssignedPolicies.Count -gt 0) {
            $Status = 'Passed'
            $ResultLines = @(
                'At least one Windows BitLocker policy is configured and assigned.'
                ''
                '**Windows BitLocker Policies:**'
                ''
                '| Policy Name | Status | Assignment Count |'
                '| :---------- | :----- | :--------------- |'
            )

            foreach ($Policy in $WindowsBitLockerPolicies) {
                $PolicyStatus = if ($Policy.assignments -and $Policy.assignments.Count -gt 0) {
                    '✅ Assigned'
                } else {
                    '❌ Not assigned'
                }
                $AssignmentCount = if ($Policy.assignments) { $Policy.assignments.Count } else { 0 }
                $ResultLines += "| $($Policy.name) | $PolicyStatus | $AssignmentCount |"
            }

            $Result = $ResultLines -join "`n"
        } else {
            $Status = 'Failed'
            if ($WindowsBitLockerPolicies.Count -gt 0) {
                $ResultLines = @(
                    'Windows BitLocker policies exist but none are assigned.'
                    ''
                    '**Unassigned BitLocker Policies:**'
                    ''
                )
                foreach ($Policy in $WindowsBitLockerPolicies) {
                    $ResultLines += "- $($Policy.name)"
                }
            } else {
                $ResultLines = @('No Windows BitLocker policy is configured or assigned.')
            }
            $Result = $ResultLines -join "`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24550' -TestType 'Devices' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Data on Windows is protected by BitLocker encryption' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24550' -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Data on Windows is protected by BitLocker encryption' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24550.ps1' 95
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24552.ps1' -1

function Invoke-CippTestZTNA24552 {
    <#
    .SYNOPSIS
    Data on macOS is protected by firewall
    #>
    param($Tenant)
    #Tested - Device

    try {
        $ConfigurationPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneConfigurationPolicies'
        if (-not $ConfigurationPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24552' -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Data on macOS is protected by firewall' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $MacOSPolicies = $ConfigurationPolicies | Where-Object {
            $_.platforms -match 'macOS'
        }

        $MacOSFirewallPolicies = @()
        foreach ($MacOSPolicy in $MacOSPolicies) {
            $ValidSettingValues = @('com.apple.security.firewall_enablefirewall_true')

            if ($MacOSPolicy.settings.settinginstance.choicesettingvalue.value) {
                $PolicySettingValues = $MacOSPolicy.settings.settinginstance.choicesettingvalue.value
                if ($PolicySettingValues -isnot [array]) {
                    $PolicySettingValues = @($PolicySettingValues)
                }

                $HasValidSetting = $false
                foreach ($SettingValue in $PolicySettingValues) {
                    if ($ValidSettingValues -contains $SettingValue) {
                        $HasValidSetting = $true
                        break
                    }
                }

                if ($HasValidSetting) {
                    $MacOSFirewallPolicies += $MacOSPolicy
                }
            }
        }

        $AssignedPolicies = $MacOSFirewallPolicies | Where-Object {
            $_.assignments -and $_.assignments.Count -gt 0
        }

        if ($AssignedPolicies.Count -gt 0) {
            $Status = 'Passed'
            $ResultLines = @(
                'At least one macOS Firewall policy is configured and assigned.'
                ''
                '**macOS Firewall Policies:**'
                ''
                '| Policy Name | Status | Assignment Count |'
                '| :---------- | :----- | :--------------- |'
            )

            foreach ($Policy in $MacOSFirewallPolicies) {
                $PolicyStatus = if ($Policy.assignments -and $Policy.assignments.Count -gt 0) {
                    '✅ Assigned'
                } else {
                    '❌ Not assigned'
                }
                $AssignmentCount = if ($Policy.assignments) { $Policy.assignments.Count } else { 0 }
                $ResultLines += "| $($Policy.name) | $PolicyStatus | $AssignmentCount |"
            }

            $Result = $ResultLines -join "`n"
        } else {
            $Status = 'Failed'
            if ($MacOSFirewallPolicies.Count -gt 0) {
                $ResultLines = @(
                    'macOS Firewall policies exist but none are assigned.'
                    ''
                    '**Unassigned Firewall Policies:**'
                    ''
                )
                foreach ($Policy in $MacOSFirewallPolicies) {
                    $ResultLines += "- $($Policy.name)"
                }
            } else {
                $ResultLines = @('No macOS Firewall policy is configured or assigned.')
            }
            $Result = $ResultLines -join "`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24552' -TestType 'Devices' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Data on macOS is protected by firewall' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24552' -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Data on macOS is protected by firewall' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24552.ps1' 95
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24553.ps1' -1

function Invoke-CippTestZTNA24553 {
    <#
    .SYNOPSIS
    Windows Update policies are enforced to reduce risk from unpatched vulnerabilities
    #>
    param($Tenant)
    #Tested - Device

    $TestId = 'ZTNA24553'

    try {
        $IntunePolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceCompliancePolicies'

        if (-not $IntunePolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Windows Update policies are enforced to reduce risk from unpatched vulnerabilities' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
            return
        }

        $UpdatePolicies = @($IntunePolicies | Where-Object {
                $_.'@odata.type' -in @(
                    '#microsoft.graph.windowsUpdateForBusinessConfiguration',
                    '#microsoft.graph.windows10CompliancePolicy'
                )
            })

        $AssignedPolicies = @($UpdatePolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedPolicies.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ Windows Update policies are configured and assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No Windows Update policies are configured or assigned.`n`n"
        }

        $ResultMarkdown += "## Windows Update Policies`n`n"
        $ResultMarkdown += "| Policy Name | Type | Assigned |`n"
        $ResultMarkdown += "| :---------- | :--- | :------- |`n"

        foreach ($policy in $UpdatePolicies) {
            $type = if ($policy.'@odata.type' -eq '#microsoft.graph.windowsUpdateForBusinessConfiguration') { 'Update' } else { 'Compliance' }
            $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
            $ResultMarkdown += "| $($policy.displayName) | $type | $assigned |`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Windows Update policies are enforced to reduce risk from unpatched vulnerabilities' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Windows Update policies are enforced to reduce risk from unpatched vulnerabilities' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24553.ps1' 54
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24560.ps1' -1

function Invoke-CippTestZTNA24560 {
    <#
    .SYNOPSIS
    Local administrator credentials on Windows are protected by Windows LAPS
    #>
    param($Tenant)
    #Tested - Device

    try {
        $ConfigPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneConfigurationPolicies'
        if (-not $ConfigPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24560' -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Local administrator credentials on Windows are protected by Windows LAPS' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $WindowsPolicies = $ConfigPolicies | Where-Object {
            $_.templateReference.templateFamily -eq 'endpointSecurityAccountProtection' -and
            $_.platforms -like '*windows10*'
        }

        if (-not $WindowsPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24560' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No Windows LAPS policies found' -Risk 'High' -Name 'Local administrator credentials on Windows are protected by Windows LAPS' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $LapsPolicies = $WindowsPolicies | Where-Object {
            $settingIds = $_.settings.settingInstance.settingDefinitionId
            $settingIds -contains 'device_vendor_msft_laps_policies_backupdirectory' -or
            $settingIds -contains 'device_vendor_msft_laps_policies_automaticaccountmanagementenabled'
        }

        if (-not $LapsPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24560' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No LAPS policies configured' -Risk 'High' -Name 'Local administrator credentials on Windows are protected by Windows LAPS' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $CompliantPolicies = $LapsPolicies | Where-Object {
            $settingIds = $_.settings.settingInstance.settingDefinitionId
            $choiceValues = $_.settings.settingInstance.choiceSettingValue.value

            $hasBackupDir = $settingIds -contains 'device_vendor_msft_laps_policies_backupdirectory'
            $hasEntraBackup = $choiceValues -contains 'device_vendor_msft_laps_policies_backupdirectory_1'
            $hasAdBackup = $choiceValues -contains 'device_vendor_msft_laps_policies_backupdirectory_2'
            $hasAutoMgmt = $choiceValues -contains 'device_vendor_msft_laps_policies_automaticaccountmanagementenabled_true'

            ($hasBackupDir -and ($hasEntraBackup -or $hasAdBackup) -and $hasAutoMgmt)
        }

        $AssignedCompliantPolicies = $CompliantPolicies | Where-Object {
            $_.assignments -and $_.assignments.Count -gt 0
        }

        if ($AssignedCompliantPolicies) {
            $Status = 'Passed'
            $Result = "Cloud LAPS policy is assigned and enforced. Found $($AssignedCompliantPolicies.Count) compliant and assigned policy/policies"
        } else {
            $Status = 'Failed'
            if ($CompliantPolicies) {
                $Result = "Cloud LAPS policy exists but is not assigned. Found $($CompliantPolicies.Count) compliant but unassigned policy/policies"
            } else {
                $Result = 'Cloud LAPS policy is not configured correctly or not enforced'
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24560' -TestType 'Devices' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Local administrator credentials on Windows are protected by Windows LAPS' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24560' -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Local administrator credentials on Windows are protected by Windows LAPS' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24560.ps1' 72
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24564.ps1' -1

function Invoke-CippTestZTNA24564 {
    <#
    .SYNOPSIS
    Local account usage on Windows is restricted to reduce unauthorized access
    #>
    param($Tenant)
    #Tested - Device

    try {
        $ConfigPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneConfigurationPolicies'
        if (-not $ConfigPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24564' -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Local account usage on Windows is restricted to reduce unauthorized access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $WindowsPolicies = $ConfigPolicies | Where-Object {
            $_.platforms -like '*windows10*'
        }

        if (-not $WindowsPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24564' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No Windows policies found' -Risk 'High' -Name 'Local account usage on Windows is restricted to reduce unauthorized access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $LocalUsersGroupsPolicies = $WindowsPolicies | Where-Object {
            $settingIds = $_.settings.settingInstance.settingDefinitionId
            if ($settingIds -is [string]) {
                $settingIds -eq 'device_vendor_msft_policy_config_localusersandgroups_configure'
            } else {
                $settingIds -contains 'device_vendor_msft_policy_config_localusersandgroups_configure'
            }
        }

        if (-not $LocalUsersGroupsPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24564' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No Local Users and Groups policy configured' -Risk 'High' -Name 'Local account usage on Windows is restricted to reduce unauthorized access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $AssignedPolicies = $LocalUsersGroupsPolicies | Where-Object {
            $_.assignments -and $_.assignments.Count -gt 0
        }

        if ($AssignedPolicies) {
            $Status = 'Passed'
            $Result = "At least one Local Users and Groups policy is configured and assigned. Found $($AssignedPolicies.Count) assigned policy/policies"
        } else {
            $Status = 'Failed'
            $Result = "Local Users and Groups policy exists but is not assigned. Found $($LocalUsersGroupsPolicies.Count) unassigned policy/policies"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24564' -TestType 'Devices' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Local account usage on Windows is restricted to reduce unauthorized access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24564' -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Local account usage on Windows is restricted to reduce unauthorized access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24564.ps1' 58
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24568.ps1' -1

function Invoke-CippTestZTNA24568 {
    <#
    .SYNOPSIS
    Platform SSO is configured to strengthen authentication on macOS devices
    #>
    param($Tenant)
    #Tested - Device

    try {
        $ConfigPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneConfigurationPolicies'
        if (-not $ConfigPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24568' -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Platform SSO is configured to strengthen authentication on macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Tenant'
            return
        }

        $MacOSPolicies = $ConfigPolicies | Where-Object {
            $_.platforms -like '*macOS*' -and
            $_.technologies -like '*mdm*' -and
            $_.technologies -like '*appleRemoteManagement*'
        }

        if (-not $MacOSPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24568' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No macOS policies found' -Risk 'Medium' -Name 'Platform SSO is configured to strengthen authentication on macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Tenant'
            return
        }

        $SSOPolicies = $MacOSPolicies | Where-Object {
            $children = $_.settings.settingInstance.groupSettingCollectionValue.children
            $extensionIdSetting = $children | Where-Object {
                $_.settingDefinitionId -eq 'com.apple.extensiblesso_extensionidentifier'
            }
            $extensionValue = $extensionIdSetting.simpleSettingValue.value
            $extensionValue -eq 'com.microsoft.CompanyPortalMac.ssoextension'
        }

        if (-not $SSOPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24568' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No macOS SSO policies configured with Microsoft Company Portal extension' -Risk 'Medium' -Name 'Platform SSO is configured to strengthen authentication on macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Tenant'
            return
        }

        $AssignedSSOPolicies = $SSOPolicies | Where-Object {
            $_.assignments -and $_.assignments.Count -gt 0
        }

        if ($AssignedSSOPolicies) {
            $Status = 'Passed'
            $Result = "macOS SSO policies are configured and assigned. Found $($AssignedSSOPolicies.Count) assigned policy/policies"
        } else {
            $Status = 'Failed'
            $Result = "macOS SSO policy exists but is not assigned. Found $($SSOPolicies.Count) unassigned policy/policies"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24568' -TestType 'Devices' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Platform SSO is configured to strengthen authentication on macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Tenant'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24568' -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Platform SSO is configured to strengthen authentication on macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24568.ps1' 60
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24569.ps1' -1

function Invoke-CippTestZTNA24569 {
    <#
    .SYNOPSIS
    FileVault encryption protects data on macOS devices
    #>
    param($Tenant)

    $TestId = 'ZTNA24569'
    #Tested - Device

    try {
        $DeviceConfigs = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceConfigurations'

        if (-not $DeviceConfigs) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'FileVault encryption protects data on macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $MacOSEndpointProtectionPolicies = @($DeviceConfigs | Where-Object {
                $_.'@odata.type' -eq '#microsoft.graph.macOSEndpointProtectionConfiguration'
            })

        $FileVaultEnabledPolicies = @($MacOSEndpointProtectionPolicies | Where-Object { $_.fileVaultEnabled -eq $true })
        $AssignedFileVaultPolicies = @($FileVaultEnabledPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedFileVaultPolicies.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ macOS FileVault encryption policies are configured and assigned in Intune.`n`n"
        } else {
            $ResultMarkdown = "❌ No relevant macOS FileVault encryption policies are configured or assigned.`n`n"
        }

        if ($FileVaultEnabledPolicies.Count -gt 0) {
            $ResultMarkdown += "## macOS FileVault Policies`n`n"
            $ResultMarkdown += "| Policy Name | FileVault Enabled | Assigned |`n"
            $ResultMarkdown += "| :---------- | :---------------- | :------- |`n"

            foreach ($policy in $FileVaultEnabledPolicies) {
                $fileVault = if ($policy.fileVaultEnabled -eq $true) { '✅ Yes' } else { '❌ No' }
                $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
                $ResultMarkdown += "| $($policy.displayName) | $fileVault | $assigned |`n"
            }
        } else {
            $ResultMarkdown += "No macOS Endpoint Protection policies with FileVault settings found.`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'FileVault encryption protects data on macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Device'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'FileVault encryption protects data on macOS devices' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Device'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24569.ps1' 56
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24574.ps1' -1

function Invoke-CippTestZTNA24574 {
    <#
    .SYNOPSIS
    Attack Surface Reduction rules are applied to Windows devices to prevent exploitation of vulnerable system components
    #>
    param($Tenant)
    #Tested - Device

    try {
        $ConfigPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneConfigurationPolicies'
        if (-not $ConfigPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24574' -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Attack Surface Reduction rules are applied to Windows devices to prevent exploitation of vulnerable system components' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Device'
            return
        }

        $Win10MdmSensePolicies = $ConfigPolicies | Where-Object {
            $_.platforms -like '*windows10*' -and
            $_.technologies -like '*mdm*' -and
            $_.technologies -like '*microsoftSense*'
        }

        if (-not $Win10MdmSensePolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24574' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No Windows ASR policies found' -Risk 'High' -Name 'Attack Surface Reduction rules are applied to Windows devices to prevent exploitation of vulnerable system components' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Device'
            return
        }

        $ASRPolicies = $Win10MdmSensePolicies | Where-Object {
            $settingIds = $_.settings.settingInstance.settingDefinitionId
            $settingIds -contains 'device_vendor_msft_policy_config_defender_attacksurfacereductionrules'
        }

        if (-not $ASRPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24574' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No Attack Surface Reduction policies found' -Risk 'High' -Name 'Attack Surface Reduction rules are applied to Windows devices to prevent exploitation of vulnerable system components' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Device'
            return
        }

        $ObfuscatedScriptPolicies = $ASRPolicies | Where-Object {
            $children = $_.settings.settingInstance.groupSettingCollectionValue.children
            $settingId = 'device_vendor_msft_policy_config_defender_attacksurfacereductionrules_blockexecutionofpotentiallyobfuscatedscripts'
            $matchingSetting = $children | Where-Object { $_.settingDefinitionId -eq $settingId }
            $value = $matchingSetting.choiceSettingValue.value
            $value -like '*_block' -or $value -like '*_warn'
        }

        $Win32MacroPolicies = $ASRPolicies | Where-Object {
            $children = $_.settings.settingInstance.groupSettingCollectionValue.children
            $settingId = 'device_vendor_msft_policy_config_defender_attacksurfacereductionrules_blockwin32apicallsfromofficemacros'
            $matchingSetting = $children | Where-Object { $_.settingDefinitionId -eq $settingId }
            $value = $matchingSetting.choiceSettingValue.value
            $value -like '*_block' -or $value -like '*_warn'
        }

        $AssignedObfuscated = $ObfuscatedScriptPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 }
        $AssignedWin32Macro = $Win32MacroPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 }

        if ($AssignedObfuscated -and $AssignedWin32Macro) {
            $Status = 'Passed'
            $Result = 'ASR policies are configured and assigned with required rules (obfuscated scripts and Win32 API calls from macros)'
        } elseif ($AssignedObfuscated -or $AssignedWin32Macro) {
            $Status = 'Failed'
            $Result = "ASR policies partially configured. Missing: $(if (-not $AssignedObfuscated) { 'obfuscated scripts rule ' })$(if (-not $AssignedWin32Macro) { 'Win32 API calls rule' })"
        } else {
            $Status = 'Failed'
            $Result = 'ASR policies found but not properly configured or assigned for required rules'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24574' -TestType 'Devices' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Attack Surface Reduction rules are applied to Windows devices to prevent exploitation of vulnerable system components' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Device'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24574' -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Attack Surface Reduction rules are applied to Windows devices to prevent exploitation of vulnerable system components' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Device'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24574.ps1' 74
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24575.ps1' -1

function Invoke-CippTestZTNA24575 {
    <#
    .SYNOPSIS
    Defender Antivirus policies protect Windows devices from malware
    #>
    param($Tenant)
    #Tested - Device

    try {
        $ConfigPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneConfigurationPolicies'
        if (-not $ConfigPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24575' -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Defender Antivirus policies protect Windows devices from malware' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Device'
            return
        }

        $MdmSensePolicies = $ConfigPolicies | Where-Object {
            $_.platforms -like '*windows10*' -and
            $_.technologies -like '*mdm*' -and
            $_.technologies -like '*microsoftSense*'
        }

        if (-not $MdmSensePolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24575' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No Windows Defender policies found' -Risk 'High' -Name 'Defender Antivirus policies protect Windows devices from malware' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Device'
            return
        }

        $AVPolicies = $MdmSensePolicies | Where-Object {
            $_.templateReference.templateFamily -eq 'endpointSecurityAntivirus'
        }

        if (-not $AVPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24575' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No Windows Defender Antivirus policies found' -Risk 'High' -Name 'Defender Antivirus policies protect Windows devices from malware' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Device'
            return
        }

        $AssignedPolicies = $AVPolicies | Where-Object {
            $_.assignments -and $_.assignments.Count -gt 0
        }

        if ($AssignedPolicies) {
            $Status = 'Passed'
            $Result = "Windows Defender Antivirus policies are configured and assigned. Found $($AssignedPolicies.Count) assigned policy/policies"
        } else {
            $Status = 'Failed'
            $Result = "Windows Defender Antivirus policies exist but are not assigned. Found $($AVPolicies.Count) unassigned policy/policies"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24575' -TestType 'Devices' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Defender Antivirus policies protect Windows devices from malware' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Device'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24575' -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Defender Antivirus policies protect Windows devices from malware' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Device'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24575.ps1' 55
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24576.ps1' -1

function Invoke-CippTestZTNA24576 {
    <#
    .SYNOPSIS
    Endpoint Analytics is enabled to help identify risks on Windows devices
    #>
    param($Tenant)

    $TestId = 'ZTNA24576'
    #Tested - Device

    try {
        $DeviceConfigs = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceConfigurations'

        if (-not $DeviceConfigs) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Endpoint Analytics is enabled to help identify risks on Windows devices' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant'
            return
        }

        $WindowsHealthMonitoringPolicies = @($DeviceConfigs | Where-Object {
                $_.'@odata.type' -eq '#microsoft.graph.windowsHealthMonitoringConfiguration'
            })

        $AssignedPolicies = @($WindowsHealthMonitoringPolicies | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedPolicies.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ An Endpoint analytics policy is created and assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ Endpoint analytics policy is not created or not assigned.`n`n"
        }

        if ($WindowsHealthMonitoringPolicies.Count -gt 0) {
            $ResultMarkdown += "## Endpoint Analytics Policies`n`n"
            $ResultMarkdown += "| Policy Name | Assigned |`n"
            $ResultMarkdown += "| :---------- | :------- |`n"

            foreach ($policy in $WindowsHealthMonitoringPolicies) {
                $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
                $ResultMarkdown += "| $($policy.displayName) | $assigned |`n"
            }
        } else {
            $ResultMarkdown += "No Endpoint Analytics policies found in this tenant.`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'Low' -Name 'Endpoint Analytics is enabled to help identify risks on Windows devices' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Endpoint Analytics is enabled to help identify risks on Windows devices' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24576.ps1' 54
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24784.ps1' -1

function Invoke-CippTestZTNA24784 {
    <#
    .SYNOPSIS
    Defender Antivirus policies protect macOS devices from malware
    #>
    param($Tenant)
    #Tested - Device

    try {
        $ConfigPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneConfigurationPolicies'
        if (-not $ConfigPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24784' -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Defender Antivirus policies protect macOS devices from malware' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $MdmMacOSSensePolicies = $ConfigPolicies | Where-Object {
            $_.platforms -like '*macOS*' -and
            $_.technologies -like '*mdm*' -and
            $_.technologies -like '*microsoftSense*'
        }

        if (-not $MdmMacOSSensePolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24784' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No macOS Defender policies found' -Risk 'High' -Name 'Defender Antivirus policies protect macOS devices from malware' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $AVPolicies = $MdmMacOSSensePolicies | Where-Object {
            $_.templateReference.templateFamily -eq 'endpointSecurityAntivirus'
        }

        if (-not $AVPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24784' -TestType 'Devices' -Status 'Failed' -ResultMarkdown 'No Defender Antivirus policies for macOS found' -Risk 'High' -Name 'Defender Antivirus policies protect macOS devices from malware' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
            return
        }

        $AssignedPolicies = $AVPolicies | Where-Object {
            $_.assignments -and $_.assignments.Count -gt 0
        }

        if ($AssignedPolicies) {
            $Status = 'Passed'
            $Result = "Defender Antivirus policies for macOS are configured and assigned. Found $($AssignedPolicies.Count) assigned policy/policies"
        } else {
            $Status = 'Failed'
            $Result = "Defender Antivirus policies for macOS exist but are not assigned. Found $($AVPolicies.Count) unassigned policy/policies"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24784' -TestType 'Devices' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Defender Antivirus policies protect macOS devices from malware' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA24784' -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Defender Antivirus policies protect macOS devices from malware' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Device'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24784.ps1' 55
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24839.ps1' -1

function Invoke-CippTestZTNA24839 {
    <#
    .SYNOPSIS
    Secure Wi-Fi profiles protect iOS devices from unauthorized network access
    #>
    param($Tenant)
    #Tested - Device

    $TestId = 'ZTNA24839'

    try {
        $DeviceConfigs = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceConfigurations'

        if (-not $DeviceConfigs) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Secure Wi-Fi profiles protect iOS devices from unauthorized network access' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Data'
            return
        }

        $iOSWifiConfProfiles = @($DeviceConfigs | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.iosWiFiConfiguration' })
        $CompliantIosWifiConfProfiles = @($iOSWifiConfProfiles | Where-Object { $_.wiFiSecurityType -in @('wpa2Enterprise', 'wpaEnterprise') })
        $AssignedCompliantProfiles = @($CompliantIosWifiConfProfiles | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedCompliantProfiles.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one Enterprise Wi-Fi profile for iOS exists and is assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No Enterprise Wi-Fi profile for iOS exists or none are assigned.`n`n"
        }

        if ($iOSWifiConfProfiles.Count -gt 0) {
            $ResultMarkdown += "## iOS WiFi Configuration Profiles`n`n"
            $ResultMarkdown += "| Policy Name | Wi-Fi Security Type | Assigned |`n"
            $ResultMarkdown += "| :---------- | :------------------ | :------- |`n"

            foreach ($policy in $iOSWifiConfProfiles) {
                $securityType = if ($policy.wiFiSecurityType) { $policy.wiFiSecurityType } else { 'Unknown' }
                $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
                $ResultMarkdown += "| $($policy.displayName) | $securityType | $assigned |`n"
            }
        } else {
            $ResultMarkdown += "No iOS WiFi configuration profiles found.`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Secure Wi-Fi profiles protect iOS devices from unauthorized network access' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Data'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Secure Wi-Fi profiles protect iOS devices from unauthorized network access' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Data'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24839.ps1' 53
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24840.ps1' -1

function Invoke-CippTestZTNA24840 {
    <#
    .SYNOPSIS
    Secure Wi-Fi profiles protect Android devices from unauthorized network access
    #>
    param($Tenant)

    $TestId = 'ZTNA24840'

    #Tested - Device

    try {
        $DeviceConfigs = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceConfigurations'

        if (-not $DeviceConfigs) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Secure Wi-Fi profiles protect Android devices from unauthorized network access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data'
            return
        }

        $AndroidWifiConfProfiles = @($DeviceConfigs | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.androidDeviceOwnerEnterpriseWiFiConfiguration' })
        $CompliantAndroidWifiConfProfiles = @($AndroidWifiConfProfiles | Where-Object { $_.wiFiSecurityType -eq 'wpaEnterprise' })
        $AssignedCompliantProfiles = @($CompliantAndroidWifiConfProfiles | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedCompliantProfiles.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one Enterprise Wi-Fi profile for android exists and is assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No Enterprise Wi-Fi profile for android exists or none are assigned.`n`n"
        }

        if ($CompliantAndroidWifiConfProfiles.Count -gt 0) {
            $ResultMarkdown += "## Android Wi-Fi Configuration Profiles`n`n"
            $ResultMarkdown += "| Policy Name | Wi-Fi Security Type | Assigned |`n"
            $ResultMarkdown += "| :---------- | :------------------ | :------- |`n"

            foreach ($policy in $CompliantAndroidWifiConfProfiles) {
                $securityType = if ($policy.wiFiSecurityType) { $policy.wiFiSecurityType } else { 'Unknown' }
                $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
                $ResultMarkdown += "| $($policy.displayName) | $securityType | $assigned |`n"
            }
        } else {
            $ResultMarkdown += "No compliant Android Enterprise WiFi configuration profiles found.`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Secure Wi-Fi profiles protect Android devices from unauthorized network access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Secure Wi-Fi profiles protect Android devices from unauthorized network access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24840.ps1' 54
#Region './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24870.ps1' -1

function Invoke-CippTestZTNA24870 {
    <#
    .SYNOPSIS
    Secure Wi-Fi profiles protect macOS devices from unauthorized network access
    #>
    param($Tenant)

    $TestId = 'ZTNA24870'
    #Tested - Device

    try {
        $DeviceConfigs = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceConfigurations'

        if (-not $DeviceConfigs) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Secure Wi-Fi profiles protect macOS devices from unauthorized network access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data'
            return
        }

        $MacOSWifiConfProfiles = @($DeviceConfigs | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.macOSWiFiConfiguration' })
        $CompliantMacOSWifiConfProfiles = @($MacOSWifiConfProfiles | Where-Object { $_.wiFiSecurityType -eq 'wpaEnterprise' })
        $AssignedCompliantProfiles = @($CompliantMacOSWifiConfProfiles | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedCompliantProfiles.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one Enterprise Wi-Fi profile for macOS exists and is assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No Enterprise Wi-Fi profile for macOS exists or none are assigned.`n`n"
        }

        if ($CompliantMacOSWifiConfProfiles.Count -gt 0) {
            $ResultMarkdown += "## macOS WiFi Configuration Profiles`n`n"
            $ResultMarkdown += "| Policy Name | Wi-Fi Security Type | Assigned |`n"
            $ResultMarkdown += "| :---------- | :------------------ | :------- |`n"

            foreach ($policy in $CompliantMacOSWifiConfProfiles) {
                $securityType = if ($policy.wiFiSecurityType) { $policy.wiFiSecurityType } else { 'Unknown' }
                $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
                $ResultMarkdown += "| $($policy.displayName) | $securityType | $assigned |`n"
            }
        } else {
            $ResultMarkdown += "No compliant macOS Enterprise WiFi configuration profiles found.`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Secure Wi-Fi profiles protect macOS devices from unauthorized network access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Devices' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Secure Wi-Fi profiles protect macOS devices from unauthorized network access' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Data'
    }
}
#EndRegion './Public/Tests/ZTNA/Devices/Invoke-CippTestZTNA24870.ps1' 53
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21772.ps1' -1

function Invoke-CippTestZTNA21772 {
    <#
    .SYNOPSIS
    Applications do not have client secrets configured
    #>
    param($Tenant)
    #tested
    try {
        $Apps = Get-CIPPTestData -TenantFilter $Tenant -Type 'Apps'
        $ServicePrincipals = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipals'

        if (-not $Apps -and -not $ServicePrincipals) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21772' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Applications do not have client secrets configured' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
            return
        }

        $AppsWithSecrets = @()
        $SPsWithSecrets = @()

        if ($Apps) {
            $AppsWithSecrets = $Apps | Where-Object {
                $_.passwordCredentials -and
                $_.passwordCredentials.Count -gt 0 -and
                $_.passwordCredentials -ne '[]'
            }
        }

        if ($ServicePrincipals) {
            $SPsWithSecrets = $ServicePrincipals | Where-Object {
                $_.passwordCredentials -and
                $_.passwordCredentials.Count -gt 0 -and
                $_.passwordCredentials -ne '[]'
            }
        }

        $TotalWithSecrets = $AppsWithSecrets.Count + $SPsWithSecrets.Count

        if ($TotalWithSecrets -eq 0) {
            $Status = 'Passed'
            $Result = 'Applications in your tenant do not use client secrets'
        } else {
            $Status = 'Failed'
            $Result = @"
Found $($AppsWithSecrets.Count) applications and $($SPsWithSecrets.Count) service principals with client secrets configured
## Apps with client secrets:
$(($AppsWithSecrets | ForEach-Object { "- $($_.displayName) (AppId: $($_.appId))" }) -join "`n")
## Service principals with client secrets:
$(($SPsWithSecrets | ForEach-Object { "- $($_.displayName) (AppId: $($_.appId))" }) -join "`n")
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21772' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Applications do not have client secrets configured' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21772' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Applications do not have client secrets configured' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21772.ps1' 59
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21773.ps1' -1

function Invoke-CippTestZTNA21773 {
    <#
    .SYNOPSIS
    Applications do not have certificates with expiration longer than 180 days
    #>
    param($Tenant)
    #tested
    try {
        $Apps = Get-CIPPTestData -TenantFilter $Tenant -Type 'Apps'
        $ServicePrincipals = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipals'

        if (-not $Apps -and -not $ServicePrincipals) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21773' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Applications do not have certificates with expiration longer than 180 days' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
            return
        }

        $MaxDate = (Get-Date).AddDays(180)
        $AppsWithLongCerts = @()
        $SPsWithLongCerts = @()

        if ($Apps) {
            $AppsWithLongCerts = $Apps | Where-Object {
                if ($_.keyCredentials -and $_.keyCredentials.Count -gt 0 -and $_.keyCredentials -ne '[]') {
                    $HasLongCert = $false
                    foreach ($Cred in $_.keyCredentials) {
                        if ($Cred.endDateTime) {
                            $EndDate = [datetime]$Cred.endDateTime
                            if ($EndDate -gt $MaxDate) {
                                $HasLongCert = $true
                                break
                            }
                        }
                    }
                    $HasLongCert
                } else {
                    $false
                }
            }
        }

        if ($ServicePrincipals) {
            $SPsWithLongCerts = $ServicePrincipals | Where-Object {
                if ($_.keyCredentials -and $_.keyCredentials.Count -gt 0 -and $_.keyCredentials -ne '[]') {
                    $HasLongCert = $false
                    foreach ($Cred in $_.keyCredentials) {
                        if ($Cred.endDateTime) {
                            $EndDate = [datetime]$Cred.endDateTime
                            if ($EndDate -gt $MaxDate) {
                                $HasLongCert = $true
                                break
                            }
                        }
                    }
                    $HasLongCert
                } else {
                    $false
                }
            }
        }

        $TotalWithLongCerts = $AppsWithLongCerts.Count + $SPsWithLongCerts.Count

        if ($TotalWithLongCerts -eq 0) {
            $Status = 'Passed'
            $Result = 'Applications in your tenant do not have certificates valid for more than 180 days'
        } else {
            $Status = 'Failed'
            $Result = "Found $($AppsWithLongCerts.Count) applications and $($SPsWithLongCerts.Count) service principals with certificates longer than 180 days`n`n"

            if ($AppsWithLongCerts.Count -gt 0) {
                $Result += "## Apps with long-lived certificates:`n`n"
                $Result += ($AppsWithLongCerts | ForEach-Object { "- $($_.displayName) (AppId: $($_.appId))" }) -join "`n"
                $Result += "`n`n"
            }

            if ($SPsWithLongCerts.Count -gt 0) {
                $Result += "## Service principals with long-lived certificates:`n`n"
                $Result += ($SPsWithLongCerts | ForEach-Object { "- $($_.displayName) (AppId: $($_.appId))" }) -join "`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21773' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Applications do not have certificates with expiration longer than 180 days' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21773' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Applications do not have certificates with expiration longer than 180 days' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21773.ps1' 89
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21774.ps1' -1

function Invoke-CippTestZTNA21774 {
    <#
    .SYNOPSIS
    Microsoft services applications do not have credentials configured
    #>
    param($Tenant)

    try {
        $ServicePrincipals = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipals'
        #tested
        if (-not $ServicePrincipals) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21774' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Microsoft services applications do not have credentials configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application Management'
            return
        }

        $MicrosoftTenantId = 'f8cdef31-a31e-4b4a-93e4-5f571e91255a'

        $MicrosoftSPs = $ServicePrincipals | Where-Object {
            $_.appOwnerOrganizationId -eq $MicrosoftTenantId
        }

        $SPsWithPasswordCreds = @()
        $SPsWithKeyCreds = @()

        if ($MicrosoftSPs) {
            $SPsWithPasswordCreds = $MicrosoftSPs | Where-Object {
                $_.passwordCredentials -and
                $_.passwordCredentials.Count -gt 0 -and
                $_.passwordCredentials -ne '[]'
            }

            $SPsWithKeyCreds = $MicrosoftSPs | Where-Object {
                $_.keyCredentials -and
                $_.keyCredentials.Count -gt 0 -and
                $_.keyCredentials -ne '[]'
            }
        }

        $TotalWithCreds = $SPsWithPasswordCreds.Count + $SPsWithKeyCreds.Count

        if ($TotalWithCreds -eq 0) {
            $Status = 'Passed'
            $Result = 'No Microsoft services applications have credentials configured in the tenant'
        } else {
            $Status = 'Investigate'
            $Result = @"
Found Microsoft services applications with credentials configured: $($SPsWithPasswordCreds.Count) with password credentials, $($SPsWithKeyCreds.Count) with key credentials
## Service principals with password credentials:
$(($SPsWithPasswordCreds | ForEach-Object { "- $($_.displayName) (AppId: $($_.appId))" }) -join "`n")
## Service principals with key credentials:
$(($SPsWithKeyCreds | ForEach-Object { "- $($_.displayName) (AppId: $($_.appId))" }) -join "`n")
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21774' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Microsoft services applications do not have credentials configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21774' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Microsoft services applications do not have credentials configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21774.ps1' 62
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21776.ps1' -1

function Invoke-CippTestZTNA21776 {
    <#
    .SYNOPSIS
    User consent settings are restricted
    #>
    param($Tenant)
    #tested
    try {
        $AuthPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'
        if (-not $AuthPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21776' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'User consent settings are restricted' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Application Management'
            return
        }

        $Matched = $AuthPolicy | Where-Object { $_.defaultUserRolePermissions.permissionGrantPoliciesAssigned -match '^ManagePermissionGrantsForSelf' }
        $NoMatch = $Matched.Count -eq 0
        $LowImpact = $Matched.defaultUserRolePermissions.permissionGrantPoliciesAssigned -contains 'managePermissionGrantsForSelf.microsoft-user-default-low'

        if ($NoMatch -or $LowImpact) {
            $Status = 'Passed'
            $Result = if ($NoMatch) { 'User consent is disabled' } else { 'User consent restricted to verified publishers and low-impact permissions' }
        } else {
            $Status = 'Failed'
            $Result = 'Users can consent to any application'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21776' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'User consent settings are restricted' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Application Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21776' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'User consent settings are restricted' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21776.ps1' 34
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21780.ps1' -1

function Invoke-CippTestZTNA21780 {
    <#
    .SYNOPSIS
    No usage of ADAL in the tenant
    #>
    param($Tenant)
    #tested
    try {
        $Recommendations = Get-CIPPTestData -TenantFilter $Tenant -Type 'DirectoryRecommendations'

        if (-not $Recommendations) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21780' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'No usage of ADAL in the tenant' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application Management'
            return
        }

        $AdalRecommendations = $Recommendations | Where-Object {
            $_.recommendationType -eq 'adalToMsalMigration'
        }

        if ($AdalRecommendations.Count -eq 0) {
            $Status = 'Passed'
            $Result = 'No ADAL applications found in the tenant'
        } else {
            $Status = 'Failed'
            $Result = @"
            Found $($AdalRecommendations.Count) ADAL applications in the tenant that need migration to MSAL.
            ADAL Applications:
            $(($AdalRecommendations | ForEach-Object { "- $($_.applicationDisplayName) (AppId: $($_.applicationId))" }) -join "`n")
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21780' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'No usage of ADAL in the tenant' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21780' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'No usage of ADAL in the tenant' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21780.ps1' 39
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21782.ps1' -1

function Invoke-CippTestZTNA21782 {
    <#
    .SYNOPSIS
    Privileged accounts have phishing-resistant methods registered
    #>
    param($Tenant)

    try {
        $UserRegistrationDetails = Get-CIPPTestData -TenantFilter $Tenant -Type 'UserRegistrationDetails'
        $RoleAssignments = Get-CIPPTestData -TenantFilter $Tenant -Type 'RoleAssignments'

        if (-not $UserRegistrationDetails -or -not $RoleAssignments) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21782' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Privileged accounts have phishing-resistant methods registered' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged Access'
            return
        }

        $PhishResistantMethods = @('passKeyDeviceBound', 'passKeyDeviceBoundAuthenticator', 'windowsHelloForBusiness')

        # Join user registration details with role assignments
        $results = $UserRegistrationDetails | Where-Object {
            $userId = $_.id
            $RoleAssignments | Where-Object { $_.principalId -eq $userId }
        } | ForEach-Object {
            $user = $_
            $userRoles = $RoleAssignments | Where-Object { $_.principalId -eq $user.id }
            $hasPhishResistant = $false

            if ($user.methodsRegistered) {
                foreach ($method in $PhishResistantMethods) {
                    if ($user.methodsRegistered -contains $method) {
                        $hasPhishResistant = $true
                        break
                    }
                }
            }

            [PSCustomObject]@{
                id                       = $user.id
                userDisplayName          = $user.userDisplayName
                roleDisplayName          = ($userRoles.roleDefinitionName -join ', ')
                methodsRegistered        = $user.methodsRegistered
                phishResistantAuthMethod = $hasPhishResistant
            }
        }

        $totalUserCount = $results.Length
        $phishResistantPrivUsers = $results | Where-Object { $_.phishResistantAuthMethod }
        $phishablePrivUsers = $results | Where-Object { !$_.phishResistantAuthMethod }

        $phishResistantPrivUserCount = $phishResistantPrivUsers.Length

        $passed = $totalUserCount -eq $phishResistantPrivUserCount

        $testResultMarkdown = if ($passed) {
            "Validated that all privileged users have registered phishing resistant authentication methods.`n`n%TestResult%"
        } else {
            "Found privileged users that have not yet registered phishing resistant authentication methods`n`n%TestResult%"
        }

        $mdInfo = "## Privileged users`n`n"

        if ($passed) {
            $mdInfo = "All privileged users have registered phishing resistant authentication methods.`n`n"
        } else {
            $mdInfo = "Found privileged users that have not registered phishing resistant authentication methods.`n`n"
        }

        $mdInfo = $mdInfo + "| User | Role Name | Phishing resistant method registered |`n"
        $mdInfo = $mdInfo + "| :--- | :--- | :---: |`n"

        $userLinkFormat = 'https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/UserAuthMethods/userId/{0}/hidePreviewBanner~/true'

        $mdLines = @($phishablePrivUsers | Sort-Object userDisplayName | ForEach-Object {
                $userLink = $userLinkFormat -f $_.id
                "|[$($_.userDisplayName)]($userLink)| $($_.roleDisplayName) | ❌ |`n"
            })
        $mdInfo = $mdInfo + ($mdLines -join '')

        $mdLines = @($phishResistantPrivUsers | Sort-Object userDisplayName | ForEach-Object {
                $userLink = $userLinkFormat -f $_.id
                "|[$($_.userDisplayName)]($userLink)| $($_.roleDisplayName) | ✅ |`n"
            })
        $mdInfo = $mdInfo + ($mdLines -join '')

        $testResultMarkdown = $testResultMarkdown -replace '%TestResult%', $mdInfo

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21782' -TestType 'Identity' -Status $(if ($passed) { 'Passed' } else { 'Failed' }) -ResultMarkdown $testResultMarkdown -Risk 'High' -Name 'Privileged accounts have phishing-resistant methods registered' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged Access'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21782' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Privileged accounts have phishing-resistant methods registered' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged Access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21782.ps1' 95
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21783.ps1' -1

function Invoke-CippTestZTNA21783 {
    <#
    .SYNOPSIS
    Privileged Microsoft Entra built-in roles are targeted with Conditional Access policies to enforce phishing-resistant methods
    #>
    param($Tenant)
    #tested
    try {
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'
        $Roles = Get-CIPPTestData -TenantFilter $Tenant -Type 'Roles'

        if (-not $CAPolicies -or -not $Roles) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21783' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Privileged Microsoft Entra built-in roles are targeted with Conditional Access policies to enforce phishing-resistant methods' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access Control'
            return
        }

        $PrivilegedRoles = $Roles | Where-Object { $_.isPrivileged -and $_.isBuiltIn }

        if (-not $PrivilegedRoles) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21783' -TestType 'Identity' -Status 'Passed' -ResultMarkdown 'No privileged built-in roles found in tenant' -Risk 'High' -Name 'Privileged Microsoft Entra built-in roles are targeted with Conditional Access policies to enforce phishing-resistant methods' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access Control'
            return
        }

        $PhishResistantMethods = @('windowsHelloForBusiness', 'fido2', 'x509CertificateMultiFactor')

        $PhishResistantPolicies = $CAPolicies | Where-Object {
            $_.state -eq 'enabled' -and
            $_.grantControls.authenticationStrength -and
            $_.conditions.users.includeRoles
        }

        $CoveredRoleIds = $PhishResistantPolicies.conditions.users.includeRoles | Select-Object -Unique

        $UnprotectedRoles = $PrivilegedRoles | Where-Object { $_.id -notin $CoveredRoleIds }

        if ($UnprotectedRoles.Count -eq 0) {
            $Status = 'Passed'
            $Result = "All $($PrivilegedRoles.Count) privileged built-in roles are protected by Conditional Access policies enforcing phishing-resistant authentication"
        } else {
            $Status = 'Failed'
            $UnprotectedCount = $UnprotectedRoles.Count
            $ProtectedCount = $PrivilegedRoles.Count - $UnprotectedCount
            $Result = @"
Found $UnprotectedCount unprotected privileged roles out of $($PrivilegedRoles.Count) total ($ProtectedCount protected)
## Unprotected privileged roles:
$(($UnprotectedRoles | ForEach-Object { "- $($_.displayName)" }) -join "`n")
"@
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21783' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Privileged Microsoft Entra built-in roles are targeted with Conditional Access policies to enforce phishing-resistant methods' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access Control'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21783' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Privileged Microsoft Entra built-in roles are targeted with Conditional Access policies to enforce phishing-resistant methods' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access Control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21783.ps1' 57
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21784.ps1' -1

function Invoke-CippTestZTNA21784 {
    <#
    .SYNOPSIS
    All user sign in activity uses phishing-resistant authentication methods
    #>
    param($Tenant)
    #tested
    try {
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $CAPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21784' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'All user sign in activity uses phishing-resistant authentication methods' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access Control'
            return
        }

        # Get authentication strength policies from cache
        $AuthStrengthPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationStrengths'

        # Define phishing-resistant methods
        $PhishingResistantMethods = @(
            'windowsHelloForBusiness',
            'fido2',
            'x509CertificateMultiFactor',
            'certificateBasedAuthenticationPki'
        )

        # Find authentication strength policies with phishing-resistant methods
        $PhishingResistantPolicies = $AuthStrengthPolicies | Where-Object {
            $_.allowedCombinations | Where-Object { $PhishingResistantMethods -contains $_ }
        }

        if (-not $PhishingResistantPolicies) {
            $Status = 'Failed'
            $Result = 'No phishing-resistant authentication strength policies found in tenant'
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21784' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'All user sign in activity uses phishing-resistant authentication methods' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access Control'
            return
        }

        $EnabledPolicies = $CAPolicies | Where-Object { $_.state -eq 'enabled' }

        # Find policies that apply to all users with phishing-resistant auth strength
        $RelevantPolicies = $EnabledPolicies | Where-Object {
            ($_.conditions.users.includeUsers -contains 'All') -and
            ($_.grantControls.authenticationStrength.id -in $PhishingResistantPolicies.id)
        }

        if (-not $RelevantPolicies) {
            $Status = 'Failed'
            $Result = 'No Conditional Access policies found requiring phishing-resistant authentication for all users'
        } else {
            # Check for user exclusions that create coverage gaps
            $PoliciesWithExclusions = $RelevantPolicies | Where-Object {
                $_.conditions.users.excludeUsers.Count -gt 0
            }

            if ($PoliciesWithExclusions.Count -gt 0) {
                $Status = 'Failed'
                $Result = "Found $($RelevantPolicies.Count) policies requiring phishing-resistant authentication, but $($PoliciesWithExclusions.Count) have user exclusions creating coverage gaps:`n`n"
                $Result += ($PoliciesWithExclusions | ForEach-Object { "- $($_.displayName) (Excludes $($_.conditions.users.excludeUsers.Count) users)" }) -join "`n"
            } else {
                $Status = 'Passed'
                $Result = "All users are protected by $($RelevantPolicies.Count) Conditional Access policies requiring phishing-resistant authentication:`n`n"
                $Result += ($RelevantPolicies | ForEach-Object { "- $($_.displayName)" }) -join "`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21784' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'All user sign in activity uses phishing-resistant authentication methods' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access Control'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21784' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'All user sign in activity uses phishing-resistant authentication methods' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access Control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21784.ps1' 74
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21786.ps1' -1

function Invoke-CippTestZTNA21786 {
    <#
    .SYNOPSIS
    User sign-in activity uses token protection
    #>
    param($Tenant)
    #tested
    try {
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $CAPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21786' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'User sign-in activity uses token protection' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access Control'
            return
        }

        $TokenProtectionPolicies = $CAPolicies | Where-Object {
            $_.state -eq 'enabled' -and
            $_.conditions.clientAppTypes.Count -eq 1 -and
            $_.conditions.clientAppTypes[0] -eq 'mobileAppsAndDesktopClients' -and
            $_.conditions.applications.includeApplications -contains '00000002-0000-0ff1-ce00-000000000000' -and
            $_.conditions.applications.includeApplications -contains '00000003-0000-0ff1-ce00-000000000000' -and
            $_.conditions.platforms.includePlatforms.Count -eq 1 -and
            $_.conditions.platforms.includePlatforms -eq 'windows' -and
            $_.sessionControls.secureSignInSession.isEnabled -eq $true
        }

        if ($TokenProtectionPolicies.Count -gt 0) {
            $Status = 'Passed'
            $Result = "Found $($TokenProtectionPolicies.Count) token protection policies properly configured"
        } else {
            $Status = 'Failed'
            $Result = 'No properly configured token protection policies found'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21786' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'User sign-in activity uses token protection' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access Control'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21786' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'User sign-in activity uses token protection' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access Control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21786.ps1' 42
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21787.ps1' -1

function Invoke-CippTestZTNA21787 {
    <#
    .SYNOPSIS
    Permissions to create new tenants are limited to the Tenant Creator role
    #>
    param($Tenant)
    #tested
    try {
        $AuthPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21787' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Permissions to create new tenants are limited to the Tenant Creator role' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Privileged Access'
            return
        }

        $CanCreateTenants = $AuthPolicy.defaultUserRolePermissions.allowedToCreateTenants

        if ($CanCreateTenants -eq $false) {
            $Status = 'Passed'
            $Result = 'Non-privileged users are restricted from creating tenants'
        } else {
            $Status = 'Failed'
            $Result = 'Non-privileged users are allowed to create tenants'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21787' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Permissions to create new tenants are limited to the Tenant Creator role' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Privileged Access'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21787' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Permissions to create new tenants are limited to the Tenant Creator role' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Privileged Access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21787.ps1' 33
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21790.ps1' -1

function Invoke-CippTestZTNA21790 {
    <#
    .SYNOPSIS
    Outbound cross-tenant access settings are configured
    #>
    param($Tenant)
    #tested
    try {
        $CrossTenantPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'CrossTenantAccessPolicy'

        if (-not $CrossTenantPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21790' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Outbound cross-tenant access settings are configured' -UserImpact 'Medium' -ImplementationEffort 'High' -Category 'Application Management'
            return
        }

        $B2BCollabOutbound = $CrossTenantPolicy.b2bCollaborationOutbound.usersAndGroups.accessType -eq 'blocked' -and
        $CrossTenantPolicy.b2bCollaborationOutbound.usersAndGroups.targets[0].target -eq 'AllUsers' -and
        $CrossTenantPolicy.b2bCollaborationOutbound.applications.accessType -eq 'blocked' -and
        $CrossTenantPolicy.b2bCollaborationOutbound.applications.targets[0].target -eq 'AllApplications'

        $B2BDirectOutbound = $CrossTenantPolicy.b2bDirectConnectOutbound.usersAndGroups.accessType -eq 'blocked' -and
        $CrossTenantPolicy.b2bDirectConnectOutbound.usersAndGroups.targets[0].target -eq 'AllUsers' -and
        $CrossTenantPolicy.b2bDirectConnectOutbound.applications.accessType -eq 'blocked' -and
        $CrossTenantPolicy.b2bDirectConnectOutbound.applications.targets[0].target -eq 'AllApplications'

        if ($B2BCollabOutbound -and $B2BDirectOutbound) {
            $Status = 'Passed'
            $Result = 'Default cross-tenant access outbound policy blocks all access'
        } else {
            $Status = 'Failed'
            $Result = 'Default cross-tenant access outbound policy has unrestricted access'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21790' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Outbound cross-tenant access settings are configured' -UserImpact 'Medium' -ImplementationEffort 'High' -Category 'Application Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21790' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Outbound cross-tenant access settings are configured' -UserImpact 'Medium' -ImplementationEffort 'High' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21790.ps1' 41
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21791.ps1' -1

function Invoke-CippTestZTNA21791 {
    <#
    .SYNOPSIS
    Guests cannot invite other guests
    #>
    param($Tenant)
    #tested
    try {
        $AuthPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21791' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Guests cannot invite other guests' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'External Collaboration'
            return
        }

        $AllowInvitesFrom = $AuthPolicy.allowInvitesFrom

        if ($AllowInvitesFrom -ne 'everyone') {
            $Status = 'Passed'
            $Result = "Tenant restricts who can invite guests (Set to: $AllowInvitesFrom)"
        } else {
            $Status = 'Failed'
            $Result = 'Tenant allows any user including guests to invite other guests'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21791' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Guests cannot invite other guests' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'External Collaboration'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21791' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Guests cannot invite other guests' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'External Collaboration'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21791.ps1' 33
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21792.ps1' -1

function Invoke-CippTestZTNA21792 {
    <#
    .SYNOPSIS
    Guests have restricted access to directory objects
    #>
    param($Tenant)
    #tested
    try {
        $AuthPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21792' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Guests have restricted access to directory objects' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'External Collaboration'
            return
        }

        $GuestRestrictedRoleId = '2af84b1e-32c8-42b7-82bc-daa82404023b'
        $GuestRoleId = $AuthPolicy.guestUserRoleId

        if ($GuestRoleId -eq $GuestRestrictedRoleId) {
            $Status = 'Passed'
            $Result = 'Guest user access is properly restricted'
        } else {
            $Status = 'Failed'
            $Result = 'Guest user access is not restricted'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21792' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Guests have restricted access to directory objects' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'External Collaboration'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21792' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Guests have restricted access to directory objects' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'External Collaboration'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21792.ps1' 34
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21793.ps1' -1

function Invoke-CippTestZTNA21793 {
    <#
    .SYNOPSIS
    Tenant restrictions v2 policy is configured
    #>
    param($Tenant)
    #tested
    try {
        $CrossTenantPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'CrossTenantAccessPolicy'

        if (-not $CrossTenantPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21793' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Tenant restrictions v2 policy is configured' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
            return
        }

        $TenantRestrictions = $CrossTenantPolicy.tenantRestrictions

        if (-not $TenantRestrictions) {
            $Status = 'Failed'
            $Result = 'Tenant Restrictions v2 policy is not configured'
        } else {
            $UsersBlocked = $TenantRestrictions.usersAndGroups.accessType -eq 'blocked' -and
            $TenantRestrictions.usersAndGroups.targets[0].target -eq 'AllUsers'

            $AppsBlocked = $TenantRestrictions.applications.accessType -eq 'blocked' -and
            $TenantRestrictions.applications.targets[0].target -eq 'AllApplications'

            if ($UsersBlocked -and $AppsBlocked) {
                $Status = 'Passed'
                $Result = 'Tenant Restrictions v2 policy is properly configured'
            } else {
                $Status = 'Failed'
                $Result = 'Tenant Restrictions v2 policy is configured but not properly restricting all users and applications'
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21793' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Tenant restrictions v2 policy is configured' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21793' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Tenant restrictions v2 policy is configured' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21793.ps1' 44
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21796.ps1' -1

function Invoke-CippTestZTNA21796 {
    <#
    .SYNOPSIS
    Block legacy authentication policy is configured
    #>
    param($Tenant)
    #tested
    try {
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $CAPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21796' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Block legacy authentication policy is configured' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Access Control'
            return
        }

        $BlockPolicies = $CAPolicies | Where-Object {
            $_.grantControls.builtInControls -contains 'block' -and
            $_.conditions.clientAppTypes -contains 'exchangeActiveSync' -and
            $_.conditions.clientAppTypes -contains 'other'
        }

        $EnabledBlockPolicies = $BlockPolicies | Where-Object {
            $_.conditions.users.includeUsers -contains 'All' -and
            $_.state -eq 'enabled'
        }

        if ($EnabledBlockPolicies.Count -ge 1) {
            $Status = 'Passed'
            $Result = "Found $($EnabledBlockPolicies.Count) properly configured policies blocking legacy authentication:`n $($EnabledBlockPolicies | ForEach-Object { "- $($_.displayName)" } | Out-String) "
        } elseif ($BlockPolicies.Count -ge 1) {
            $Status = 'Failed'
            $Result = "Policies to block legacy authentication found but not properly configured or enabled: `n $($BlockPolicies | ForEach-Object { "- $($_.displayName)" } | Out-String) "
        } else {
            $Status = 'Failed'
            $Result = 'No conditional access policies to block legacy authentication found'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21796' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Block legacy authentication policy is configured' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Access Control'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21796' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Block legacy authentication policy is configured' -UserImpact 'High' -ImplementationEffort 'Low' -Category 'Access Control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21796.ps1' 45
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21797.ps1' -1

function Invoke-CippTestZTNA21797 {
    <#
    .SYNOPSIS
    Restrict access to high risk users
    #>
    param($Tenant)
    #tested
    try {
        $allCAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'
        $authMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $allCAPolicies -or -not $authMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21797' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Restrict access to high risk users' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Conditional Access'
            return
        }

        $caPasswordChangePolicies = $allCAPolicies | Where-Object {
            $_.conditions.userRiskLevels -contains 'high' -and
            $_.grantControls.builtInControls -contains 'passwordChange' -and
            $_.state -eq 'enabled'
        }

        $caBlockPolicies = $allCAPolicies | Where-Object {
            $_.conditions.userRiskLevels -contains 'high' -and
            $_.grantControls.builtInControls -contains 'block' -and
            $_.state -eq 'enabled'
        }

        $inactiveCAPolicies = $allCAPolicies | Where-Object {
            $_.conditions.userRiskLevels -contains 'high' -and
            ($_.grantControls.builtInControls -contains 'passwordChange' -or $_.grantControls.builtInControls -contains 'block') -and
            $_.state -ne 'enabled'
        }

        $passwordlessEnabled = $false
        $passwordlessAuthMethods = @()

        if ($authMethodsPolicy.authenticationMethodConfigurations) {
            foreach ($method in $authMethodsPolicy.authenticationMethodConfigurations) {
                $isPasswordless = $false
                $methodName = $method.id
                $methodState = $method.state
                $additionalInfo = ''

                if ($method.id -in @('fido2')) {
                    $isPasswordless = ($method.state -eq 'enabled')
                }

                if ($method.id -eq 'x509Certificate') {
                    if ($method.state -eq 'enabled' -and $method.x509CertificateAuthenticationDefaultMode -eq 'x509CertificateMultiFactor') {
                        $isPasswordless = $true
                        $additionalInfo = ' (Mode: x509CertificateMultiFactor)'
                    }
                }

                if ($isPasswordless) {
                    $passwordlessEnabled = $true
                    $passwordlessAuthMethods += [PSCustomObject]@{
                        Name           = $methodName
                        State          = $methodState
                        AdditionalInfo = $additionalInfo
                    }
                }
            }
        }

        $result = $false
        if ((-not $passwordlessEnabled -and ($caPasswordChangePolicies.Count + $caBlockPolicies.Count -gt 0)) -or
            ($passwordlessEnabled -and $caBlockPolicies.Count -gt 0)) {
            $result = $true
        }

        $testResultMarkdown = ''

        if ($result) {
            $testResultMarkdown = 'Policies to restrict access for high risk users are properly implemented.'
        } else {
            if ($passwordlessEnabled -and $caBlockPolicies.Count -eq 0) {
                $testResultMarkdown = 'Passwordless authentication is enabled, but no policies to block high risk users are configured.'
            } else {
                $testResultMarkdown = 'No policies found to protect against high risk users.'
            }
        }

        $mdInfo = "`n## Passwordless Authentication Methods allowed in tenant`n`n"

        if ($passwordlessAuthMethods.Count -gt 0) {
            $mdInfo += "| Authentication Method Name | State | Additional Info |`n"
            $mdInfo += "| :------------------------ | :---- | :-------------- |`n"
            foreach ($method in $passwordlessAuthMethods) {
                $mdInfo += "| $($method.Name) | $($method.State) | $($method.AdditionalInfo) |`n"
            }
        } else {
            $mdInfo += "No passwordless authentication methods are enabled.`n"
        }

        $mdInfo += "`n## Conditional Access Policies targeting high risk users`n`n"

        $allEnabledHighRiskPolicies = @($caPasswordChangePolicies) + @($caBlockPolicies)

        if ($allEnabledHighRiskPolicies.Count -gt 0) {
            $mdInfo += "| Conditional Access Policy Name | Status | Conditions |`n"
            $mdInfo += "| :--------------------- | :----- | :--------- |`n"

            foreach ($policy in $allEnabledHighRiskPolicies) {
                $conditions = 'User Risk Level: High'
                if ($policy.grantControls.builtInControls -contains 'passwordChange') {
                    $conditions += ', Control: Password Change'
                }
                if ($policy.grantControls.builtInControls -contains 'block') {
                    $conditions += ', Control: Block'
                }
                $mdInfo += "| $($policy.displayName) | Enabled | $conditions |`n"
            }
        }

        if ($inactiveCAPolicies.Count -gt 0) {
            if ($allEnabledHighRiskPolicies.Count -eq 0) {
                $mdInfo += "No conditional access policies targeting high risk users found.`n`n"
                $mdInfo += "### Inactive policies targeting high risk users (not contributing to security posture):`n`n"
                $mdInfo += "| Conditional Access Policy Name | Status | Conditions |`n"
                $mdInfo += "| :--------------------- | :----- | :--------- |`n"
            }

            foreach ($policy in $inactiveCAPolicies) {
                $conditions = 'User Risk Level: High'
                if ($policy.grantControls.builtInControls -contains 'passwordChange') {
                    $conditions += ', Control: Password Change'
                }
                if ($policy.grantControls.builtInControls -contains 'block') {
                    $conditions += ', Control: Block'
                }
                $status = if ($policy.state -eq 'enabledForReportingButNotEnforced') { 'Report-only' } else { 'Disabled' }
                $mdInfo += "| $($policy.displayName) | $status | $conditions |`n"
            }
        } elseif ($allEnabledHighRiskPolicies.Count -eq 0) {
            $mdInfo += "No conditional access policies targeting high risk users found.`n"
        }

        $testResultMarkdown = $testResultMarkdown + $mdInfo

        $Status = if ($result) { 'Passed' } else { 'Failed' }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21797' -TestType 'Identity' -Status $Status -ResultMarkdown $testResultMarkdown -Risk 'High' -Name 'Restrict access to high risk users' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Conditional Access'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21797' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Restrict access to high risk users' -UserImpact 'High' -ImplementationEffort 'Medium' -Category 'Conditional Access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21797.ps1' 151
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21799.ps1' -1

function Invoke-CippTestZTNA21799 {
    <#
    .SYNOPSIS
    Restrict high risk sign-ins
    #>
    param($Tenant)
    #tested
    try {
        $authMethodPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'
        $allCAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $allCAPolicies -or -not $authMethodPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21799' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Restrict high risk sign-ins' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Conditional Access'
            return
        }

        $matchedPolicies = $null

        if (($authMethodPolicy.authenticationMethodConfigurations.state -eq 'enabled').count -gt 0) {
            $matchedPolicies = $allCAPolicies | Where-Object {
                $_.conditions.signInRiskLevels -eq 'high' -and
                ($_.conditions.users.includeUsers -contains 'All') -and
                ($_.grantControls.builtInControls -contains 'block' -or $_.grantControls.builtInControls -contains 'mfa' -or $null -ne $_.grantControls.authenticationStrength) -and
                ($_.state -eq 'enabled')
            }
        } else {
            $matchedPolicies = $allCAPolicies | Where-Object {
                $_.conditions.signInRiskLevels -eq 'high' -and
                ($_.conditions.users.includeUsers -contains 'All') -and
                ($_.grantControls.builtInControls -contains 'block') -and
                ($_.state -eq 'enabled')
            }
        }

        $testResultMarkdown = ''

        if ($matchedPolicies.Count -gt 0) {
            $passed = 'Passed'
            $testResultMarkdown = 'All high-risk sign-in attempts are mitigated by Conditional Access policies enforcing appropriate controls.'
        } else {
            $passed = 'Failed'
            $testResultMarkdown = 'Some high-risk sign-in attempts are not adequately mitigated by Conditional Access policies.'
        }

        $reportTitle = 'Conditional Access Policies targeting high-risk sign-in attempts'
        $tableRows = ''

        if ($matchedPolicies.Count -gt 0) {
            $mdInfo = "`n## $reportTitle`n`n"
            $mdInfo += "| Policy Name | Grant Controls | Target Users |`n"
            $mdInfo += "| :---------- | :------------- | :----------- |`n"

            foreach ($policy in $matchedPolicies) {
                $grantControls = switch ($policy.grantControls) {
                    { $_.builtInControls -contains 'block' } {
                        'Block Access'
                    }
                    { $_.builtInControls -contains 'mfa' } {
                        'Require Multi-Factor Authentication'
                    }
                    { $null -ne $_.authenticationStrength } {
                        'Require Authentication Strength'
                    }
                }

                $targetUsers = if ($policy.conditions.users.includeUsers -contains 'All') {
                    'All Users'
                } else {
                    $policy.conditions.users.includeUsers -join ', '
                }

                $mdInfo += "| $($policy.displayName) | $grantControls | $targetUsers |`n"
            }
        }
        $testResultMarkdown = $testResultMarkdown + $mdInfo

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21799' -TestType 'Identity' -Status $passed -ResultMarkdown $testResultMarkdown -Risk 'High' -Name 'Block high risk sign-ins' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Conditional Access'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21799' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Restrict high risk sign-ins' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Conditional Access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21799.ps1' 84
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21801.ps1' -1

function Invoke-CippTestZTNA21801 {
    <#
    .SYNOPSIS
    Users have strong authentication methods configured
    #>
    param($Tenant)

    try {
        $UserRegistrationDetails = Get-CIPPTestData -TenantFilter $Tenant -Type 'UserRegistrationDetails'
        $Users = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        if (-not $UserRegistrationDetails -or -not $Users) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21801' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Users have strong authentication methods configured' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Credential Management'
            return
        }

        $PhishResistantMethods = @('passKeyDeviceBound', 'passKeyDeviceBoundAuthenticator', 'windowsHelloForBusiness')

        # Create hashtable for O(1) user lookup instead of O(n) Where-Object searches
        $UserLookup = @{}
        foreach ($user in $Users) {
            if ($user.accountEnabled) {
                $UserLookup[$user.id] = $user
            }
        }

        $results = foreach ($regDetail in $UserRegistrationDetails) {
            # Fast O(1) lookup instead of Where-Object
            if (-not $UserLookup.ContainsKey($regDetail.id)) {
                continue
            }

            $matchingUser = $UserLookup[$regDetail.id]
            $hasPhishResistant = $false

            if ($regDetail.methodsRegistered) {
                foreach ($method in $PhishResistantMethods) {
                    if ($regDetail.methodsRegistered -contains $method) {
                        $hasPhishResistant = $true
                        break
                    }
                }
            }

            [PSCustomObject]@{
                id                           = $regDetail.id
                displayName                  = $regDetail.userDisplayName
                phishResistantAuthMethod     = $hasPhishResistant
                lastSuccessfulSignInDateTime = $matchingUser.signInActivity.lastSuccessfulSignInDateTime
            }
        }

        $totalUserCount = $results.Count
        $phishResistantUsers = $results | Where-Object { $_.phishResistantAuthMethod }
        $phishableUsers = $results | Where-Object { !$_.phishResistantAuthMethod }

        $phishResistantUserCount = $phishResistantUsers.Count

        $passed = $totalUserCount -eq $phishResistantUserCount

        $testResultMarkdown = if ($passed) {
            "Validated that all users have registered phishing resistant authentication methods.`n`n%TestResult%"
        } else {
            "Found users that have not yet registered phishing resistant authentication methods`n`n%TestResult%"
        }

        $mdInfo = "## Users strong authentication methods`n`n"

        if ($passed) {
            $mdInfo = "All users have registered phishing resistant authentication methods.`n`n"
        } else {
            $mdInfo = "Found users that have not registered phishing resistant authentication methods.`n`n"
        }

        # Limit output to prevent performance issues with large user sets
        $maxUsersToDisplay = 500

        $mdInfo = $mdInfo + "| User | Last sign in | Phishing resistant method registered |`n"
        $mdInfo = $mdInfo + "| :--- | :--- | :---: |`n"

        $userLinkFormat = 'https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/UserAuthMethods/userId/{0}/hidePreviewBanner~/true'

        # Show phishable users first (up to limit)
        $phishableUsersToShow = $phishableUsers | Sort-Object displayName | Select-Object -First $maxUsersToDisplay
        $mdLines = @($phishableUsersToShow | ForEach-Object {
                $userLink = $userLinkFormat -f $_.id
                $lastSignInDate = if ($_.lastSuccessfulSignInDateTime) { (Get-Date $_.lastSuccessfulSignInDateTime -Format 'yyyy-MM-dd') } else { 'Never' }
                "|[$($_.displayName)]($userLink)| $lastSignInDate | ❌ |`n"
            })
        $mdInfo = $mdInfo + ($mdLines -join '')

        if ($phishableUsers.Count -gt $maxUsersToDisplay) {
            $mdInfo = $mdInfo + "|... and $($phishableUsers.Count - $maxUsersToDisplay) more users without phish-resistant methods|||`n"
        }

        # Show phish-resistant users (up to remaining limit)
        $remainingSlots = $maxUsersToDisplay - [Math]::Min($phishableUsers.Count, $maxUsersToDisplay)
        if ($remainingSlots -gt 0) {
            $phishResistantUsersToShow = $phishResistantUsers | Sort-Object displayName | Select-Object -First $remainingSlots
            $mdLines = @($phishResistantUsersToShow | ForEach-Object {
                    $userLink = $userLinkFormat -f $_.id
                    $lastSignInDate = if ($_.lastSuccessfulSignInDateTime) { (Get-Date $_.lastSuccessfulSignInDateTime -Format 'yyyy-MM-dd') } else { 'Never' }
                    "|[$($_.displayName)]($userLink)| $lastSignInDate | ✅ |`n"
                })
            $mdInfo = $mdInfo + ($mdLines -join '')

            if ($phishResistantUsers.Count -gt $remainingSlots) {
                $mdInfo = $mdInfo + "|... and $($phishResistantUsers.Count - $remainingSlots) more users with phish-resistant methods|||`n"
            }
        }

        $testResultMarkdown = $testResultMarkdown -replace '%TestResult%', $mdInfo

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21801' -TestType 'Identity' -Status $(if ($passed) { 'Passed' } else { 'Failed' }) -ResultMarkdown $testResultMarkdown -Risk 'Medium' -Name 'Users have strong authentication methods configured' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Credential Management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21801' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Users have strong authentication methods configured' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Credential Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21801.ps1' 122
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21802.ps1' -1

function Invoke-CippTestZTNA21802 {
    <#
    .SYNOPSIS
    Microsoft Authenticator app shows sign-in context
    #>
    param($Tenant)
    #tested
    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21802' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Microsoft Authenticator app shows sign-in context' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access Control'
            return
        }

        $AuthenticatorConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'MicrosoftAuthenticator' }

        if (-not $AuthenticatorConfig) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21802' -TestType 'Identity' -Status 'Failed' -ResultMarkdown 'Microsoft Authenticator configuration not found in authentication methods policy' -Risk 'Medium' -Name 'Microsoft Authenticator app shows sign-in context' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access Control'
            return
        }

        $AppInfoEnabled = $AuthenticatorConfig.featureSettings.displayAppInformationRequiredState.state -eq 'enabled'
        $LocationInfoEnabled = $AuthenticatorConfig.featureSettings.displayLocationInformationRequiredState.state -eq 'enabled'

        if ($AppInfoEnabled -and $LocationInfoEnabled) {
            $Status = 'Passed'
            $Result = 'Microsoft Authenticator shows application name and geographic location in push notifications'
        } else {
            $Status = 'Failed'
            $Result = "Microsoft Authenticator sign-in context incomplete - App info: $AppInfoEnabled, Location info: $LocationInfoEnabled"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21802' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Microsoft Authenticator app shows sign-in context' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access Control'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21802' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Microsoft Authenticator app shows sign-in context' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access Control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21802.ps1' 41
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21803.ps1' -1

function Invoke-CippTestZTNA21803 {
    <#
    .SYNOPSIS
    Migrate from legacy MFA and SSPR policies
    #>
    param($Tenant)
    #Tested
    try {
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21803' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Migrate from legacy MFA and SSPR policies' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Credential Management'
            return
        }

        $PolicyMigrationState = $AuthMethodsPolicy.policyMigrationState

        if ($PolicyMigrationState -eq 'migrationComplete') {
            $Status = 'Passed'
            $Result = 'Tenant has migrated from legacy MFA and SSPR policies to authentication methods policy'
        } elseif ($PolicyMigrationState -eq 'migrationInProgress') {
            $Status = 'Investigate'
            $Result = 'Tenant migration from legacy MFA and SSPR policies is in progress'
        } else {
            $Status = 'Failed'
            $Result = "Tenant has not migrated from legacy MFA and SSPR policies (state: $PolicyMigrationState)"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21803' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Migrate from legacy MFA and SSPR policies' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Credential Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21803' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Migrate from legacy MFA and SSPR policies' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Credential Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21803.ps1' 36
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21804.ps1' -1

function Invoke-CippTestZTNA21804 {
    <#
    .SYNOPSIS
    SMS and Voice Call authentication methods are disabled
    #>
    param($Tenant)
    #Tested
    try {
        $authMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $authMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21804' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'SMS and Voice Call authentication methods are disabled' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Credential Management'
            return
        }

        $matchedMethods = $authMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Sms' -or $_.id -eq 'Voice' }

        $testResultMarkdown = ''

        if ($matchedMethods.state -contains 'enabled') {
            $passed = 'Failed'
            $testResultMarkdown = 'Found weak authentication methods that are still enabled.'
        } else {
            $passed = 'Passed'
            $testResultMarkdown = 'SMS and voice calls authentication methods are disabled in the tenant.'
        }

        $reportTitle = 'Weak authentication methods'

        $mdInfo = "`n## $reportTitle`n`n"
        $mdInfo += "| Method ID | Is method weak? | State |`n"
        $mdInfo += "| :-------- | :-------------- | :---- |`n"

        foreach ($method in $matchedMethods) {
            $mdInfo += "| $($method.id) | Yes | $($method.state) |`n"
        }

        $testResultMarkdown = $testResultMarkdown + $mdInfo

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21804' -TestType 'Identity' -Status $passed -ResultMarkdown $testResultMarkdown -Risk 'High' -Name 'Weak authentication methods are disabled' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Conditional Access'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21804' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'SMS and Voice Call authentication methods are disabled' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Credential Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21804.ps1' 47
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21806.ps1' -1

function Invoke-CippTestZTNA21806 {
    <#
    .SYNOPSIS
    Secure the MFA registration (My Security Info) page
    #>
    param($Tenant)
    #tested
    try {
        $allCAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $allCAPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21806' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Secure the MFA registration (My Security Info) page' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Conditional Access'
            return
        }

        $matchedPolicies = $allCAPolicies | Where-Object {
            ($_.conditions.applications.includeUserActions -contains 'urn:user:registersecurityinfo') -and
            ($_.conditions.users.includeUsers -contains 'All') -and
            $_.state -eq 'enabled'
        }

        $testResultMarkdown = ''

        if ($matchedPolicies.Count -gt 0) {
            $passed = 'Passed'
            $testResultMarkdown = 'Security information registration is protected by Conditional Access policies.'
        } else {
            $passed = 'Failed'
            $testResultMarkdown = 'Security information registration is not protected by Conditional Access policies.'
        }

        $reportTitle = 'Conditional Access Policies targeting security information registration'
        $tableRows = ''

        if ($matchedPolicies.Count -gt 0) {
            $mdInfo = "`n## $reportTitle`n`n"
            $mdInfo += "| Policy Name | User Actions Targeted | Grant Controls Applied |`n"
            $mdInfo += "| :---------- | :-------------------- | :--------------------- |`n"

            foreach ($policy in $matchedPolicies) {
                $mdInfo += "| $($policy.displayName) | $($policy.conditions.applications.includeUserActions) | $($policy.grantControls.builtInControls -join ', ') |`n"
            }
        } else {
            $mdInfo = 'No Conditional Access policies targeting security information registration.'
        }

        $testResultMarkdown = $testResultMarkdown + $mdInfo

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21806' -TestType 'Identity' -Status $passed -ResultMarkdown $testResultMarkdown -Risk 'High' -Name 'Secure the MFA registration (My Security Info) page' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Conditional Access'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21806' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Secure the MFA registration (My Security Info) page' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Conditional Access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21806.ps1' 56
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21807.ps1' -1

function Invoke-CippTestZTNA21807 {
    <#
    .SYNOPSIS
    Creating new applications and service principals is restricted to privileged users
    #>
    param($Tenant)
    #Tested
    try {
        $AuthPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21807' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Creating new applications and service principals is restricted to privileged users' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application Management'
            return
        }

        $CanCreateApps = $AuthPolicy.defaultUserRolePermissions.allowedToCreateApps

        if ($CanCreateApps -eq $false) {
            $Status = 'Passed'
            $Result = 'Tenant is configured to prevent users from registering applications'
        } else {
            $Status = 'Failed'
            $Result = 'Tenant allows all non-privileged users to register applications'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21807' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Creating new applications and service principals is restricted to privileged users' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21807' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Creating new applications and service principals is restricted to privileged users' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21807.ps1' 33
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21808.ps1' -1

function Invoke-CippTestZTNA21808 {
    <#
    .SYNOPSIS
    Restrict device code flow
    #>
    param($Tenant)
    #Tested
    try {
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'
        if (-not $CAPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21808' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Restrict device code flow' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Access Control'
            return
        }

        $Enabled = $CAPolicies | Where-Object { $_.state -eq 'enabled' }
        $DeviceCodePolicies = $Enabled | Where-Object {
            if ($_.conditions.authenticationFlows.transferMethods) {
                $Methods = $_.conditions.authenticationFlows.transferMethods -split ','
                $Methods -contains 'deviceCodeFlow'
            } else {
                $false
            }
        }

        $BlockPolicies = $DeviceCodePolicies | Where-Object { $_.grantControls.builtInControls -contains 'block' }

        if ($BlockPolicies.Count -gt 0) {
            $Status = 'Passed'
            $Result = "Device code flow is properly restricted with $($BlockPolicies.Count) blocking policy/policies"
        } elseif ($DeviceCodePolicies.Count -eq 0) {
            $Status = 'Failed'
            $Result = 'No Conditional Access policies found targeting device code flow'
            #Add table with existing policies?
        } else {
            $Status = 'Failed'
            $Result = 'Device code flow policies exist but none are configured to block'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21808' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Restrict device code flow' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Access Control'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21808' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Restrict device code flow' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Access Control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21808.ps1' 46
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21809.ps1' -1

function Invoke-CippTestZTNA21809 {
    <#
    .SYNOPSIS
    Admin consent workflow is enabled
    #>
    param($Tenant)
    #Tested
    try {
        $result = Get-CIPPTestData -TenantFilter $Tenant -Type 'AdminConsentRequestPolicy'

        if (-not $result) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21809' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Admin consent workflow is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application Management'
            return
        }

        $passed = if ($result.isEnabled) { 'Passed' } else { 'Failed' }

        if ($result.isEnabled) {
            $testResultMarkdown = 'Admin consent workflow is enabled.'
        } else {
            $testResultMarkdown = "Admin consent workflow is disabled.`n`nThe adminConsentRequestPolicy.isEnabled property is set to false."
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21809' -TestType 'Identity' -Status $passed -ResultMarkdown $testResultMarkdown -Risk 'High' -Name 'Admin consent workflow is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21809' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Admin consent workflow is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21809.ps1' 31
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21810.ps1' -1

function Invoke-CippTestZTNA21810 {
    <#
    .SYNOPSIS
    Resource-specific consent is restricted
    #>
    param($Tenant)
    #Tested
    try {
        $authPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $authPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21810' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Resource-specific consent is restricted' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application Management'
            return
        }

        $teamPermission = 'managepermissiongrantsforownedresource.microsoft-dynamically-managed-permissions-for-team'
        $hasTeamPermission = $authPolicy.permissionGrantPolicyIdsAssignedToDefaultUserRole -contains $teamPermission

        if (-not $hasTeamPermission) {
            $state = 'DisabledForAllApps'
        } else {
            $state = 'EnabledForAllApps'
        }

        if ($state -eq 'DisabledForAllApps') {
            $passed = 'Passed'
            $testResultMarkdown = "Resource-Specific Consent is restricted.`n`nThe current state is $state."
        } else {
            $passed = 'Failed'
            $testResultMarkdown = "Resource-Specific Consent is not restricted.`n`nThe current state is $state."
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21810' -TestType 'Identity' -Status $passed -ResultMarkdown $testResultMarkdown -Risk 'Medium' -Name 'Resource-specific consent is restricted' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21810' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Resource-specific consent is restricted' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21810.ps1' 40
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21811.ps1' -1

function Invoke-CippTestZTNA21811 {
    <#
    .SYNOPSIS
    Password expiration is disabled
    #>
    param($Tenant)
    #Tested
    try {
        $domains = Get-CIPPTestData -TenantFilter $Tenant -Type 'Domains'

        if (-not $domains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21811' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Password expiration is disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential Management'
            return
        }

        $misconfiguredDomains = $domains | Where-Object { $_.passwordValidityPeriodInDays -ne 2147483647 }

        $users = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        $misconfiguredUsers = @()
        if ($users) {
            $misconfiguredUsers = foreach ($user in $users) {
                $userDomain = $user.userPrincipalName.Split('@')[-1]
                $domainPolicy = $misconfiguredDomains | Where-Object { $_.id -eq $userDomain }
                if (($user.passwordPolicies -notlike '*DisablePasswordExpiration*') -and ($domainPolicy)) {
                    [PSCustomObject]@{
                        id                     = $user.id
                        displayName            = $user.displayName
                        userPrincipalName      = $user.userPrincipalName
                        passwordPolicies       = $user.passwordPolicies
                        DomainPasswordValidity = $domainPolicy.passwordValidityPeriodInDays
                    }
                }
            }
        }

        if ($misconfiguredDomains -or $misconfiguredUsers) {
            $passed = 'Failed'
            $testResultMarkdown = 'Found domains or users with password expiration still enabled.'
        } else {
            $passed = 'Passed'
            $testResultMarkdown = 'Password expiration is properly disabled across all domains and users.'
        }

        if ($misconfiguredDomains) {
            $reportTitle1 = 'Domains with password expiration enabled'
            $mdInfo1 = "`n## $reportTitle1`n`n"
            $mdInfo1 += "| Domain Name | Password Validity Interval |`n"
            $mdInfo1 += "| :---------- | :------------------------- |`n"

            foreach ($domain in $misconfiguredDomains) {
                $mdInfo1 += "| $($domain.id) | $($domain.passwordValidityPeriodInDays) |`n"
            }

            $testResultMarkdown = $testResultMarkdown + $mdInfo1
        }

        if ($misconfiguredUsers) {
            $reportTitle2 = 'Users with password expiration enabled'
            $mdInfo2 = "`n## $reportTitle2`n`n"
            $mdInfo2 += "| Display Name | User Principal Name | User Password Expiration setting | Domain Password Expiration setting |`n"
            $mdInfo2 += "| :----------- | :------------------ | :------------------------------- | :--------------------------------- |`n"

            foreach ($misconfiguredUser in $misconfiguredUsers) {
                $displayName = $misconfiguredUser.displayName
                $userPrincipalName = $misconfiguredUser.userPrincipalName
                $userPasswordExpiration = $misconfiguredUser.passwordPolicies
                $domainPasswordExpiration = $misconfiguredUser.DomainPasswordValidity
                $mdInfo2 += "| $displayName | $userPrincipalName | $userPasswordExpiration | $domainPasswordExpiration |`n"
            }

            $testResultMarkdown = $testResultMarkdown + $mdInfo2
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21811' -TestType 'Identity' -Status $passed -ResultMarkdown $testResultMarkdown -Risk 'Medium' -Name 'Password expiration is disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential Management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21811' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Password expiration is disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21811.ps1' 82
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21812.ps1' -1

function Invoke-CippTestZTNA21812 {
    <#
    .SYNOPSIS
    Maximum number of Global Administrators doesn't exceed five users
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    $TestId = 'ZTNA21812'

    try {
        $AllGlobalAdmins = Get-CippDbRoleMembers -TenantFilter $Tenant -RoleTemplateId '62e90394-69f5-4237-9190-012177145e10'

        $GlobalAdmins = @($AllGlobalAdmins | Where-Object { $_.'@odata.type' -in @('#microsoft.graph.user', '#microsoft.graph.servicePrincipal') })

        $Passed = $GlobalAdmins.Count -le 5

        if ($Passed) {
            $ResultMarkdown = "Maximum number of Global Administrators doesn't exceed five users/service principals.`n`n"
        } else {
            $ResultMarkdown = "Maximum number of Global Administrators exceeds five users/service principals.`n`n"
        }

        if ($GlobalAdmins.Count -gt 0) {
            $ResultMarkdown += "## Global Administrators`n`n"
            $ResultMarkdown += "### Total number of Global Administrators: $($GlobalAdmins.Count)`n`n"
            $ResultMarkdown += "| Display Name | Object Type | User Principal Name |`n"
            $ResultMarkdown += "| :----------- | :---------- | :------------------ |`n"

            foreach ($GlobalAdmin in $GlobalAdmins) {
                $DisplayName = $GlobalAdmin.displayName
                $ObjectType = switch ($GlobalAdmin.'@odata.type') {
                    '#microsoft.graph.user' { 'User' }
                    '#microsoft.graph.servicePrincipal' { 'Service Principal' }
                    default { 'Unknown' }
                }
                $UserPrincipalName = if ($GlobalAdmin.userPrincipalName) { $GlobalAdmin.userPrincipalName } else { 'N/A' }

                $PortalLink = switch ($ObjectType) {
                    'User' { "https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/AdministrativeRole/userId/$($GlobalAdmin.id)" }
                    'Service Principal' { "https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationMenuBlade/~/Overview/appId/$($GlobalAdmin.id)" }
                    default { 'https://entra.microsoft.com' }
                }

                $ResultMarkdown += "| [$DisplayName]($PortalLink) | $ObjectType | $UserPrincipalName |`n"
            }
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'Low' -Name "Maximum number of Global Administrators doesn't exceed five users" -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Privileged access'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name "Maximum number of Global Administrators doesn't exceed five users" -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Privileged access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21812.ps1' 61
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21813.ps1' -1

function Invoke-CippTestZTNA21813 {
    <#
    .SYNOPSIS
    High Global Administrator to privileged user ratio
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    $TestId = 'ZTNA21813'

    try {
        $GlobalAdminRoleId = '62e90394-69f5-4237-9190-012177145e10'

        $PrivilegedRoles = Get-CippDbRole -TenantFilter $Tenant -IncludePrivilegedRoles
        $RoleAssignmentScheduleInstances = Get-CIPPTestData -TenantFilter $Tenant -Type 'RoleAssignmentScheduleInstances'
        $RoleEligibilitySchedules = Get-CIPPTestData -TenantFilter $Tenant -Type 'RoleEligibilitySchedules'
        $Users = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        $AllGAUsers = @{}
        $AllPrivilegedUsers = @{}
        $UserRoleMap = @{}

        foreach ($Role in $PrivilegedRoles) {
            $ActiveAssignments = $RoleAssignmentScheduleInstances | Where-Object {
                $_.roleDefinitionId -eq $Role.templateId -and $_.assignmentType -eq 'Assigned'
            }
            $EligibleAssignments = $RoleEligibilitySchedules | Where-Object {
                $_.roleDefinitionId -eq $Role.templateId
            }

            $AllAssignments = @($ActiveAssignments) + @($EligibleAssignments)

            foreach ($Assignment in $AllAssignments) {
                $User = $Users | Where-Object { $_.id -eq $Assignment.principalId } | Select-Object -First 1
                if (-not $User) { continue }

                $UserId = $User.id
                $IsGARole = $Role.templateId -eq $GlobalAdminRoleId

                if ($IsGARole) {
                    $AllGAUsers[$UserId] = $User
                }

                if (-not $IsGARole) {
                    $AllPrivilegedUsers[$UserId] = $User
                }

                if (-not $UserRoleMap.ContainsKey($UserId)) {
                    $UserRoleMap[$UserId] = @{
                        User  = $User
                        Roles = [System.Collections.ArrayList]@()
                        IsGA  = $false
                    }
                }

                if ($Role.displayName -notin $UserRoleMap[$UserId].Roles) {
                    [void]$UserRoleMap[$UserId].Roles.Add($Role.displayName)
                }

                if ($IsGARole) {
                    $UserRoleMap[$UserId].IsGA = $true
                }
            }
        }

        $GARoleAssignmentCount = $AllGAUsers.Count
        $PrivilegedRoleAssignmentCount = $AllPrivilegedUsers.Count
        $TotalPrivilegedRoleAssignmentCount = $GARoleAssignmentCount + $PrivilegedRoleAssignmentCount

        if ($TotalPrivilegedRoleAssignmentCount -gt 0) {
            $GAPercentage = [math]::Round(($GARoleAssignmentCount / $TotalPrivilegedRoleAssignmentCount) * 100, 2)
            $OtherPercentage = [math]::Round(($PrivilegedRoleAssignmentCount / $TotalPrivilegedRoleAssignmentCount) * 100, 2)
        } else {
            $GAPercentage = 0
            $OtherPercentage = 0
        }

        $HasHealthyRatio = $false
        $HasModerateRatio = $false
        $HasHighRatio = $false
        $CustomStatus = $null

        if ($GAPercentage -lt 30) {
            $StatusIndicator = '✅ Passed'
            $HasHealthyRatio = $true
        } elseif ($GAPercentage -ge 30 -and $GAPercentage -lt 50) {
            $StatusIndicator = '⚠️ Investigate'
            $HasModerateRatio = $true
        } else {
            $StatusIndicator = '❌ Failed'
            $HasHighRatio = $true
        }

        $MdInfo = "`n## Privileged role assignment summary`n`n"
        $MdInfo += "**Global administrator role count:** $GARoleAssignmentCount ($GAPercentage%) - $StatusIndicator`n`n"
        $MdInfo += "**Other privileged role count:** $PrivilegedRoleAssignmentCount ($OtherPercentage%)`n`n"

        $MdInfo += "## User privileged role assignments`n`n"
        $MdInfo += "| User | Global administrator | Other Privileged Role(s) |`n"
        $MdInfo += "| :--- | :------------------- | :------ |`n"

        $SortedUsers = $UserRoleMap.Values | Sort-Object @{Expression = { -not $_.IsGA } }, @{Expression = { $_.User.displayName } }

        foreach ($UserEntry in $SortedUsers) {
            $User = $UserEntry.User
            $IsGA = if ($UserEntry.IsGA) { 'Yes' } else { 'No' }

            $OtherRoles = $UserEntry.Roles | Where-Object { $_ -ne 'Global Administrator' } | Sort-Object
            $RolesList = if ($OtherRoles.Count -gt 0) { ($OtherRoles -join ', ') } else { '-' }

            $UserLink = "https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/AdministrativeRole/userId/$($User.id)/hidePreviewBanner~/true"
            $MdInfo += "| [$($User.displayName)]($UserLink) | $IsGA | $RolesList |`n"
        }

        if ($UserRoleMap.Count -eq 0) {
            $MdInfo += "| No privileged users found | - | - |`n"
        }

        if ($TotalPrivilegedRoleAssignmentCount -eq 0) {
            $Passed = $true
            $ResultMarkdown = "No privileged role assignments found in the tenant.$MdInfo"
        } elseif ($HasHealthyRatio) {
            $Passed = $true
            $ResultMarkdown = "Less than 30% of privileged role assignments in the tenant are Global Administrator.$MdInfo"
        } elseif ($HasModerateRatio) {
            $Passed = $false
            $CustomStatus = 'Investigate'
            $ResultMarkdown = "Between 30-50% of privileged role assignments in the tenant are Global Administrator.$MdInfo"
        } else {
            $Passed = $false
            $ResultMarkdown = "More than 50% of privileged role assignments in the tenant are Global Administrator.$MdInfo"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'High Global Administrator to privileged user ratio' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged access'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'High Global Administrator to privileged user ratio' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21813.ps1' 146
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21814.ps1' -1

function Invoke-CippTestZTNA21814 {
    <#
    .SYNOPSIS
    Privileged accounts are cloud native identities
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )

    $TestId = 'ZTNA21814'

    try {
        $PrivilegedRoles = Get-CippDbRole -TenantFilter $Tenant -IncludePrivilegedRoles
        $Users = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        $RoleData = [System.Collections.Generic.List[object]]::new()

        foreach ($Role in $PrivilegedRoles) {
            $RoleMembers = Get-CippDbRoleMembers -TenantFilter $Tenant -RoleTemplateId $Role.RoletemplateId
            $RoleUsers = $RoleMembers | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.user' }

            foreach ($RoleMember in $RoleUsers) {
                $UserDetail = $Users | Where-Object { $_.id -eq $RoleMember.id } | Select-Object -First 1

                if ($UserDetail) {
                    $RoleData.Add([PSCustomObject]@{
                            RoleName              = $Role.displayName
                            UserId                = $UserDetail.id
                            UserDisplayName       = $UserDetail.displayName
                            UserPrincipalName     = $UserDetail.userPrincipalName
                            OnPremisesSyncEnabled = $UserDetail.onPremisesSyncEnabled
                        })
                }
            }
        }

        $SyncedUsers = $RoleData | Where-Object { $_.OnPremisesSyncEnabled -eq $true }
        $Passed = $SyncedUsers.Count -eq 0

        if ($Passed) {
            $ResultMarkdown = "Validated that standing or eligible privileged accounts are cloud only accounts.`n`n"
        } else {
            $ResultMarkdown = "This tenant has $($SyncedUsers.Count) privileged users that are synced from on-premise.`n`n"
        }

        if ($RoleData.Count -gt 0) {
            $ResultMarkdown += "## Privileged Roles`n`n"
            $ResultMarkdown += "| Role Name | User | Source | Status |`n"
            $ResultMarkdown += "| :--- | :--- | :--- | :---: |`n"

            foreach ($RoleUser in ($RoleData | Sort-Object RoleName, UserDisplayName)) {
                if ($RoleUser.OnPremisesSyncEnabled) {
                    $Type = 'Synced from on-premise'
                    $Status = '❌'
                } else {
                    $Type = 'Cloud native identity'
                    $Status = '✅'
                }

                $UserLink = "https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/AdministrativeRole/userId/$($RoleUser.UserId)"
                $ResultMarkdown += "| $($RoleUser.RoleName) | [$($RoleUser.UserDisplayName)]($UserLink) | $Type | $Status |`n"
            }
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Privileged accounts are cloud native identities' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged access'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Privileged accounts are cloud native identities' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21814.ps1' 76
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21815.ps1' -1

function Invoke-CippTestZTNA21815 {
    <#
    .SYNOPSIS
    All privileged role assignments are activated just in time and not permanently active
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #tested
    $TestId = 'ZTNA21815'

    try {
        $PrivilegedRoles = Get-CippDbRole -TenantFilter $Tenant -IncludePrivilegedRoles
        $RoleAssignmentScheduleInstances = Get-CIPPTestData -TenantFilter $Tenant -Type 'RoleAssignmentScheduleInstances'
        $Users = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        $PermanentAssignments = [System.Collections.Generic.List[object]]::new()

        foreach ($Role in $PrivilegedRoles) {
            $ActiveAssignments = $RoleAssignmentScheduleInstances | Where-Object {
                $_.roleDefinitionId -eq $Role.RoletemplateId -and
                $_.assignmentType -eq 'Assigned' -and
                $null -eq $_.endDateTime
            }

            foreach ($Assignment in $ActiveAssignments) {
                $User = $Users | Where-Object { $_.id -eq $Assignment.principalId } | Select-Object -First 1
                if (-not $User) { continue }

                $PermanentAssignments.Add([PSCustomObject]@{
                        PrincipalDisplayName = $User.displayName
                        UserPrincipalName    = $User.userPrincipalName
                        PrincipalId          = $User.id
                        RoleDisplayName      = $Role.displayName
                        PrivilegeType        = 'Permanent'
                    })
            }
        }

        if ($PermanentAssignments.Count -eq 0) {
            $Passed = $true
            $ResultMarkdown = 'No privileged users have permanent role assignments.'
        } else {
            $Passed = $false
            $ResultMarkdown = "Privileged users with permanent role assignments were found.`n`n"
            $ResultMarkdown += "## Privileged users with permanent role assignments`n`n"
            $ResultMarkdown += "| User | UPN | Role Name | Assignment Type |`n"
            $ResultMarkdown += "| :--- | :-- | :-------- | :-------------- |`n"

            foreach ($Result in $PermanentAssignments) {
                $PortalLink = "https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/AdministrativeRole/userId/$($Result.PrincipalId)/hidePreviewBanner~/true"
                $ResultMarkdown += "| [$($Result.PrincipalDisplayName)]($PortalLink) | $($Result.UserPrincipalName) | $($Result.RoleDisplayName) | $($Result.PrivilegeType) |`n"
            }
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'All privileged role assignments are activated just in time and not permanently active' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Privileged access'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'All privileged role assignments are activated just in time and not permanently active' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Privileged access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21815.ps1' 67
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21816.ps1' -1

function Invoke-CippTestZTNA21816 {
    <#
    .SYNOPSIS
    All Microsoft Entra privileged role assignments are managed with PIM
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    $TestId = 'ZTNA21816'

    try {
        $GlobalAdminRoleId = '62e90394-69f5-4237-9190-012177145e10'
        $PermanentGAUserList = [System.Collections.Generic.List[object]]::new()
        $PermanentGAGroupList = [System.Collections.Generic.List[object]]::new()
        $NonPIMPrivilegedUsers = [System.Collections.Generic.List[object]]::new()
        $NonPIMPrivilegedGroups = [System.Collections.Generic.List[object]]::new()

        $PrivilegedRoles = Get-CippDbRole -TenantFilter $Tenant -IncludePrivilegedRoles
        $RoleEligibilitySchedules = Get-CIPPTestData -TenantFilter $Tenant -Type 'RoleEligibilitySchedules'
        $RoleAssignmentScheduleInstances = Get-CIPPTestData -TenantFilter $Tenant -Type 'RoleAssignmentScheduleInstances'
        $Users = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'
        $Groups = Get-CIPPTestData -TenantFilter $Tenant -Type 'Groups'

        $EligibleGAs = $RoleEligibilitySchedules | Where-Object { $_.roleDefinitionId -eq $GlobalAdminRoleId }
        $EligibleGAUsers = 0

        foreach ($EligibleGA in $EligibleGAs) {
            $Principal = $Users | Where-Object { $_.id -eq $EligibleGA.principalId } | Select-Object -First 1
            if ($Principal) {
                $EligibleGAUsers++
            } else {
                $GroupPrincipal = $Groups | Where-Object { $_.id -eq $EligibleGA.principalId } | Select-Object -First 1
                if ($GroupPrincipal) {
                    $GroupMembers = $Users | Where-Object { $_.id -in $GroupPrincipal.members }
                    $EligibleGAUsers = $EligibleGAUsers + $GroupMembers.Count
                }
            }
        }

        foreach ($Role in $PrivilegedRoles) {
            if ($Role.templateId -eq $GlobalAdminRoleId) { continue }

            $RoleMembers = Get-CippDbRoleMembers -TenantFilter $Tenant -RoleTemplateId $Role.RoletemplateId

            foreach ($Member in $RoleMembers) {
                $Assignment = $RoleAssignmentScheduleInstances | Where-Object {
                    $_.principalId -eq $Member.id -and $_.roleDefinitionId -eq $Role.RoletemplateId
                } | Select-Object -First 1

                if (-not $Assignment -or ($Assignment.assignmentType -eq 'Assigned' -and $null -eq $Assignment.endDateTime)) {
                    $MemberInfo = [PSCustomObject]@{
                        displayName       = $Member.displayName
                        userPrincipalName = $Member.userPrincipalName
                        id                = $Member.id
                        roleTemplateId    = $Role.RoletemplateId
                        roleName          = $Role.displayName
                        assignmentType    = if ($Assignment) { $Assignment.assignmentType } else { 'Not in PIM' }
                    }

                    if ($Member.'@odata.type' -eq '#microsoft.graph.user') {
                        $NonPIMPrivilegedUsers.Add($MemberInfo)
                    } else {
                        $NonPIMPrivilegedGroups.Add($MemberInfo)
                    }
                }
            }
        }

        $GAMembers = Get-CippDbRoleMembers -TenantFilter $Tenant -RoleTemplateId $GlobalAdminRoleId

        foreach ($Member in $GAMembers) {
            $Assignment = $RoleAssignmentScheduleInstances | Where-Object {
                $_.principalId -eq $Member.id -and $_.roleDefinitionId -eq $GlobalAdminRoleId
            } | Select-Object -First 1

            if (-not $Assignment -or ($Assignment.assignmentType -eq 'Assigned' -and $null -eq $Assignment.endDateTime)) {
                $MemberInfo = [PSCustomObject]@{
                    displayName           = $Member.displayName
                    userPrincipalName     = $Member.userPrincipalName
                    id                    = $Member.id
                    roleTemplateId        = $GlobalAdminRoleId
                    roleName              = 'Global Administrator'
                    assignmentType        = if ($Assignment) { $Assignment.assignmentType } else { 'Not in PIM' }
                    onPremisesSyncEnabled = $null
                }

                if ($Member.'@odata.type' -eq '#microsoft.graph.user') {
                    $UserDetail = $Users | Where-Object { $_.id -eq $Member.id } | Select-Object -First 1
                    if ($UserDetail) {
                        $MemberInfo.onPremisesSyncEnabled = $UserDetail.onPremisesSyncEnabled
                    }
                    $PermanentGAUserList.Add($MemberInfo)
                } elseif ($Member.'@odata.type' -eq '#microsoft.graph.group') {
                    $PermanentGAGroupList.Add($MemberInfo)

                    $Group = $Groups | Where-Object { $_.id -eq $Member.id } | Select-Object -First 1
                    if ($Group) {
                        $GroupMembers = $Users | Where-Object { $_.id -in $Group.members }
                        foreach ($GroupMember in $GroupMembers) {
                            $GroupMemberInfo = [PSCustomObject]@{
                                displayName           = $GroupMember.displayName
                                userPrincipalName     = $GroupMember.userPrincipalName
                                id                    = $GroupMember.id
                                roleTemplateId        = $GlobalAdminRoleId
                                roleName              = 'Global Administrator (via group)'
                                assignmentType        = 'Via Group'
                                onPremisesSyncEnabled = $GroupMember.onPremisesSyncEnabled
                            }
                            $PermanentGAUserList.Add($GroupMemberInfo)
                        }
                    }
                }
            }
        }

        $HasPIMUsage = $EligibleGAUsers -gt 0
        $HasNonPIMPrivileged = ($NonPIMPrivilegedUsers.Count + $NonPIMPrivilegedGroups.Count) -gt 0
        $PermanentGACount = $PermanentGAUserList.Count
        $CustomStatus = $null

        if (-not $HasPIMUsage) {
            $Passed = $false
            $ResultMarkdown = 'No eligible Global Administrator assignments found. PIM usage cannot be confirmed.'
        } elseif ($HasNonPIMPrivileged) {
            $Passed = $false
            $ResultMarkdown = 'Found Microsoft Entra privileged role assignments that are not managed with PIM.'
        } elseif ($PermanentGACount -gt 2) {
            $Passed = $false
            $CustomStatus = 'Investigate'
            $ResultMarkdown = 'Three or more accounts are permanently assigned the Global Administrator role. Review to determine whether these are emergency access accounts.'
        } else {
            $Passed = $true
            $ResultMarkdown = 'All Microsoft Entra privileged role assignments are managed with PIM with the exception of up to two standing Global Administrator accounts.'
        }

        $ResultMarkdown += "`n`n## Assessment summary`n`n"
        $ResultMarkdown += "| Metric | Count |`n"
        $ResultMarkdown += "| :----- | :---- |`n"
        $ResultMarkdown += "| Privileged roles found | $($PrivilegedRoles.Count) |`n"
        $ResultMarkdown += "| Eligible Global Administrators | $EligibleGAUsers |`n"
        $ResultMarkdown += "| Non-PIM privileged users | $($NonPIMPrivilegedUsers.Count) |`n"
        $ResultMarkdown += "| Non-PIM privileged groups | $($NonPIMPrivilegedGroups.Count) |`n"
        $ResultMarkdown += "| Permanent Global Administrator users | $($PermanentGAUserList.Count) |`n"

        if ($NonPIMPrivilegedUsers.Count -gt 0 -or $NonPIMPrivilegedGroups.Count -gt 0) {
            $ResultMarkdown += "`n## Non-PIM managed privileged role assignments`n`n"
            $ResultMarkdown += "| Display name | User principal name | Role name | Assignment type |`n"
            $ResultMarkdown += "| :----------- | :------------------ | :-------- | :-------------- |`n"

            foreach ($User in $NonPIMPrivilegedUsers) {
                $UserLink = "https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/AdministrativeRole/userId/$($User.id)/hidePreviewBanner~/true"
                $ResultMarkdown += "| [$($User.displayName)]($UserLink) | $($User.userPrincipalName) | $($User.roleName) | $($User.assignmentType) |`n"
            }

            foreach ($Group in $NonPIMPrivilegedGroups) {
                $GroupLink = "https://entra.microsoft.com/#view/Microsoft_AAD_IAM/GroupDetailsMenuBlade/~/RolesAndAdministrators/groupId/$($Group.id)/menuId/"
                $ResultMarkdown += "| [$($Group.displayName)]($GroupLink) | N/A (Group) | $($Group.roleName) | $($Group.assignmentType) |`n"
            }
        }

        if ($PermanentGAUserList.Count -gt 0) {
            $ResultMarkdown += "`n## Permanent Global Administrator assignments`n`n"
            $ResultMarkdown += "| Display name | User principal name | Assignment type | On-Premises synced |`n"
            $ResultMarkdown += "| :----------- | :------------------ | :-------------- | :----------------- |`n"

            foreach ($User in $PermanentGAUserList) {
                $SyncStatus = if ($null -ne $User.onPremisesSyncEnabled) { $User.onPremisesSyncEnabled } else { 'N/A' }
                $UserLink = "https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/AdministrativeRole/userId/$($User.id)/hidePreviewBanner~/true"
                $ResultMarkdown += "| [$($User.displayName)]($UserLink) | $($User.userPrincipalName) | $($User.assignmentType) | $SyncStatus |`n"
            }
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'All Microsoft Entra privileged role assignments are managed with PIM' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Identity'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'All Microsoft Entra privileged role assignments are managed with PIM' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Identity'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21816.ps1' 185
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21817.ps1' -1

function Invoke-CippTestZTNA21817 {
    <#
    .SYNOPSIS
    Global Administrator role activation triggers an approval workflow
    #>
    param($Tenant)

    try {
        $RoleManagementPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'RoleManagementPolicies'

        if (-not $RoleManagementPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21817' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Global Administrator role activation triggers an approval workflow' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
            return
        }

        $globalAdminRoleId = '62e90394-69f5-4237-9190-012177145e10'

        $globalAdminPolicy = $RoleManagementPolicies | Where-Object {
            $_.scopeId -eq '/' -and
            $_.scopeType -eq 'DirectoryRole' -and
            $_.roleDefinitionId -eq $globalAdminRoleId
        }

        $tableRows = ''
        $result = $false

        if ($globalAdminPolicy) {
            $approvalRule = $globalAdminPolicy.rules | Where-Object { $_.id -like '*Approval_EndUser_Assignment*' }

            if ($approvalRule -and $approvalRule.setting.isApprovalRequired -eq $true) {
                $approverCount = 0
                foreach ($stage in $approvalRule.setting.approvalStages) {
                    $approverCount = $approverCount + ($stage.primaryApprovers | Measure-Object).Count
                }

                if ($approverCount -gt 0) {
                    $result = $true
                    $testResultMarkdown = "✅ **Pass**: Approval required with $approverCount primary approver(s) configured.`n`n%TestResult%"
                    $primaryApprovers = ($approvalRule.setting.approvalStages[0].primaryApprovers.description -join ', ')
                    $escalationApprovers = ($approvalRule.setting.approvalStages[0].escalationApprovers.description -join ', ')
                    $tableRows = "| Yes | $primaryApprovers | $escalationApprovers |`n"
                } else {
                    $testResultMarkdown = "❌ **Fail**: Approval required but no approvers configured.`n`n%TestResult%"
                    $tableRows = "| Yes | None | None |`n"
                }
            } else {
                $testResultMarkdown = "❌ **Fail**: Approval not required for Global Administrator role activation.`n`n%TestResult%"
                $tableRows = "| No | N/A | N/A |`n"
            }
        } else {
            $testResultMarkdown = "❌ **Fail**: No PIM policy found for Global Administrator role.`n`n%TestResult%"
            $tableRows = "| N/A | N/A | N/A |`n"
        }

        $passed = $result

        $reportTitle = 'Global Administrator role activation and approval workflow'

        $formatTemplate = @'

## {0}


| Approval Required | Primary Approvers | Escalation Approvers |
| :---------------- | :---------------- | :------------------- |
{1}

'@

        $mdInfo = $formatTemplate -f $reportTitle, $tableRows
        $testResultMarkdown = $testResultMarkdown -replace '%TestResult%', $mdInfo

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21817' -TestType 'Identity' -Status $(if ($passed) { 'Passed' } else { 'Failed' }) -ResultMarkdown $testResultMarkdown -Risk 'High' -Name 'Global Administrator role activation triggers an approval workflow' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21817' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Global Administrator role activation triggers an approval workflow' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application Management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21817.ps1' 81
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21818.ps1' -1

function Invoke-CippTestZTNA21818 {
    <#
    .SYNOPSIS
    Privileged role activations have monitoring and alerting configured
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    $TestId = 'ZTNA21818'

    try {
        $PrivilegedRoles = Get-CippDbRole -TenantFilter $Tenant -IncludePrivilegedRoles
        $RoleManagementPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'RoleManagementPolicies'

        $Notifications = @(
            [PSCustomObject]@{
                NotificationScenario = 'Send notifications when members are assigned as eligible to this role'
                NotificationType     = 'Role assignment alert'
                RuleId               = 'Notification_Admin_Admin_Eligibility'
            }
            [PSCustomObject]@{
                NotificationScenario = 'Send notifications when members are assigned as eligible to this role'
                NotificationType     = 'Notification to the assigned user (assignee)'
                RuleId               = 'Notification_Requestor_Admin_Eligibility'
            }
            [PSCustomObject]@{
                NotificationScenario = 'Send notifications when members are assigned as eligible to this role'
                NotificationType     = 'Request to approve a role assignment renewal/extension'
                RuleId               = 'Notification_Approver_Admin_Eligibility'
            }
            [PSCustomObject]@{
                NotificationScenario = 'Send notifications when members are assigned as active to this role'
                NotificationType     = 'Role assignment alert'
                RuleId               = 'Notification_Admin_Admin_Assignment'
            }
            [PSCustomObject]@{
                NotificationScenario = 'Send notifications when members are assigned as active to this role'
                NotificationType     = 'Notification to the assigned user (assignee)'
                RuleId               = 'Notification_Requestor_Admin_Assignment'
            }
            [PSCustomObject]@{
                NotificationScenario = 'Send notifications when members are assigned as active to this role'
                NotificationType     = 'Request to approve a role assignment renewal/extension'
                RuleId               = 'Notification_Approver_Admin_Assignment'
            }
            [PSCustomObject]@{
                NotificationScenario = 'Send notifications when eligible members activate this role'
                NotificationType     = 'Role activation alert'
                RuleId               = 'Notification_Admin_EndUser_Assignment'
            }
            [PSCustomObject]@{
                NotificationScenario = 'Send notifications when eligible members activate this role'
                NotificationType     = 'Notification to activated user (requestor)'
                RuleId               = 'Notification_Requestor_EndUser_Assignment'
            }
            [PSCustomObject]@{
                NotificationScenario = 'Send notifications when eligible members activate this role'
                NotificationType     = 'Request to approve an activation'
                RuleId               = 'Notification_Approver_EndUser_Assignment'
            }
        )

        $NotificationRules = [System.Collections.Generic.List[object]]::new()
        $Passed = $true
        $ExitLoop = $false

        foreach ($Role in $PrivilegedRoles) {
            $Policy = $RoleManagementPolicies | Where-Object {
                $_.scopeId -eq '/' -and $_.scopeType -eq 'DirectoryRole' -and $_.roleDefinitionId -eq $Role.id
            } | Select-Object -First 1

            if (-not $Policy) { continue }

            foreach ($NotificationRuleId in $Notifications.RuleId) {
                $Rule = $Policy.rules | Where-Object { $_.id -eq $NotificationRuleId } | Select-Object -First 1

                if ($Rule) {
                    $RuleWithRole = $Rule | Select-Object *, @{Name = 'RoleDisplayName'; Expression = { $Role.displayName } }
                    $NotificationRules.Add($RuleWithRole)

                    if ($Rule.isDefaultRecipientsEnabled -eq $true -and ($Rule.notificationRecipients.Count -eq 0 -or $null -eq $Rule.notificationRecipients)) {
                        $Passed = $false
                        $ExitLoop = $true
                        break
                    }
                }
            }

            if ($ExitLoop) { break }
        }

        if ($Passed) {
            $ResultMarkdown = "Role notifications are properly configured for privileged role.`n`n"
        } else {
            $ResultMarkdown = "Role notifications are not properly configured.`n`nNote: To save time, this check stops when it finds the first role that does not have notifications. After fixing this role and all other roles, we recommend running the check again to verify.`n`n"
        }

        $ResultMarkdown += "## Notifications for high privileged roles`n`n"
        $ResultMarkdown += "| Role Name | Notification Scenario | Notification Type | Default Recipients Enabled | Additional Recipients |`n"
        $ResultMarkdown += "| :-------- | :-------------------- | :---------------- | :------------------------- | :-------------------- |`n"

        foreach ($NotificationRule in $NotificationRules) {
            $MatchingNotification = $Notifications | Where-Object { $_.RuleId -eq $NotificationRule.id }
            $Recipients = if ($NotificationRule.notificationRecipients) { ($NotificationRule.notificationRecipients -join ', ') } else { '' }
            $ResultMarkdown += "| $($NotificationRule.roleDisplayName) | $($MatchingNotification.notificationScenario) | $($MatchingNotification.notificationType) | $($NotificationRule.isDefaultRecipientsEnabled) | $Recipients |`n"
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Privileged role activations have monitoring and alerting configured' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Monitoring'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Privileged role activations have monitoring and alerting configured' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Monitoring'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21818.ps1' 120
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21819.ps1' -1

function Invoke-CippTestZTNA21819 {
    <#
    .SYNOPSIS
    Activation alert for Global Administrator role assignment
    #>
    param($Tenant)
    #Tested
    $TestId = 'ZTNA21819'

    try {
        # Get Global Administrator role (template ID: 62e90394-69f5-4237-9190-012177145e10)
        $Roles = Get-CIPPTestData -TenantFilter $Tenant -Type 'Roles'
        $GlobalAdminRole = $Roles | Where-Object { $_.roleTemplateId -eq '62e90394-69f5-4237-9190-012177145e10' }

        if (-not $GlobalAdminRole) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Activation alert for Global Administrator role assignment' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged access'
            return
        }

        # Get role management policy for Global Admin
        $RoleManagementPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'RoleManagementPolicies'
        $GlobalAdminPolicy = $RoleManagementPolicies | Where-Object {
            $_.scopeId -eq '/' -and $_.scopeType -eq 'DirectoryRole' -and $_.effectiveRules.target.targetObjects.id -contains $GlobalAdminRole.id
        }

        $Passed = 'Failed'
        $IsDefaultRecipientsEnabled = 'N/A'
        $Recipients = 'N/A'

        if ($GlobalAdminPolicy) {
            # Find the notification rule for requestor end-user assignment
            $NotificationRule = $GlobalAdminPolicy.effectiveRules | Where-Object {
                $_.id -like '*Notification_Requestor_EndUser_Assignment*'
            }

            if ($NotificationRule) {
                $IsDefaultRecipientsEnabled = $NotificationRule.isDefaultRecipientsEnabled
                $NotificationRecipients = $NotificationRule.notificationRecipients

                if ($NotificationRecipients) {
                    $Recipients = ($NotificationRecipients -join ', ')
                }

                if ($NotificationRecipients -or $IsDefaultRecipientsEnabled) {
                    $Passed = 'Passed'
                }
            }
        }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = "Activation alerts are configured for Global Administrator role.`n`n"
        } else {
            $ResultMarkdown = "Activation alerts are missing or improperly configured for Global Administrator role.`n`n"
        }

        $ResultMarkdown += "| Role display name | Default recipients | Additional recipients |`n"
        $ResultMarkdown += "| :---------------- | :----------------- | :------------------- |`n"

        $RoleLink = 'https://entra.microsoft.com/#view/Microsoft_AAD_IAM/RolesManagementMenuBlade/~/AllRoles'
        $DisplayNameLink = "[$($GlobalAdminRole.displayName)]($RoleLink)"

        $DefaultRecipientsStatus = if ($IsDefaultRecipientsEnabled -eq $true) {
            '✅ Enabled'
        } elseif ($IsDefaultRecipientsEnabled -eq $false) {
            '❌ Disabled'
        } else {
            'N/A'
        }

        $RecipientsDisplay = if ([string]::IsNullOrEmpty($Recipients) -or $Recipients -eq 'N/A') {
            '-'
        } else {
            $Recipients
        }

        $ResultMarkdown += "| $DisplayNameLink | $DefaultRecipientsStatus | $RecipientsDisplay |`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Low' -Name 'Activation alert for Global Administrator role assignment' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged access'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Activation alert for Global Administrator role assignment' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21819.ps1' 86
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21820.ps1' -1

function Invoke-CippTestZTNA21820 {
    <#
    .SYNOPSIS
    Activation alert for all privileged role assignments
    #>
    param($Tenant)
    #Tested
    $TestId = 'ZTNA21820'

    try {
        # Get all privileged roles
        $PrivilegedRoles = Get-CippDbRole -TenantFilter $Tenant -IncludePrivilegedRoles

        if (-not $PrivilegedRoles -or $PrivilegedRoles.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Low' -Name 'Activation alert for all privileged role assignments' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged access'
            return
        }

        # Get all role management policies
        $RoleManagementPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'RoleManagementPolicies'

        # Build hashtable for quick policy lookup by role ID
        $PolicyByRoleId = @{}
        foreach ($Policy in $RoleManagementPolicies) {
            if ($Policy.scopeId -eq '/' -and $Policy.scopeType -eq 'DirectoryRole') {
                foreach ($RoleId in $Policy.effectiveRules.target.targetObjects.id) {
                    if ($RoleId) {
                        $PolicyByRoleId[$RoleId] = $Policy
                    }
                }
            }
        }

        $RolesWithIssues = [System.Collections.Generic.List[object]]::new()
        $Passed = 'Passed'

        foreach ($Role in $PrivilegedRoles) {
            $Policy = $PolicyByRoleId[$Role.id]

            if (-not $Policy) {
                $RolesWithIssues.Add(@{
                        Role                       = $Role
                        Issue                      = 'No PIM policy assignment found'
                        IsDefaultRecipientsEnabled = 'N/A'
                        NotificationRecipients     = 'N/A'
                    })
                continue
            }

            # Find notification rule for requestor end-user assignment
            $NotificationRule = $Policy.effectiveRules | Where-Object {
                $_.id -like '*Notification_Requestor_EndUser_Assignment*'
            }

            if ($NotificationRule) {
                $IsDefaultRecipientsEnabled = $NotificationRule.isDefaultRecipientsEnabled
                $NotificationRecipients = $NotificationRule.notificationRecipients

                # Check if alert is properly configured
                if ($IsDefaultRecipientsEnabled -eq $true -and ((-not $NotificationRecipients) -or $NotificationRecipients.Count -eq 0)) {
                    $Passed = 'Failed'
                    $RolesWithIssues.Add(@{
                            Role                       = $Role
                            IsDefaultRecipientsEnabled = $IsDefaultRecipientsEnabled
                            NotificationRecipients     = 'N/A'
                        })
                    # Exit early on first issue for performance
                    break
                }
            }
        }

        if ($RolesWithIssues.Count -eq 0) {
            $ResultMarkdown = 'Activation alerts are configured for privileged role assignments.'
        } else {
            $ResultMarkdown = 'Activation alerts are missing or improperly configured for privileged roles.'
        }

        if ($RolesWithIssues.Count -gt 0) {
            $ResultMarkdown += "`n`n## Roles with missing or misconfigured alerts`n`n"
            $ResultMarkdown += "| Role display name | Default recipients | Additional recipients |`n"
            $ResultMarkdown += "| :---------------- | :----------------- | :------------------- |`n"

            foreach ($RoleIssue in $RolesWithIssues) {
                $Role = $RoleIssue.Role
                $RoleLink = 'https://entra.microsoft.com/#view/Microsoft_AAD_IAM/RolesManagementMenuBlade/~/AllRoles'
                $DisplayNameLink = "[$($Role.displayName)]($RoleLink)"

                $DefaultRecipientsStatus = if ($RoleIssue.IsDefaultRecipientsEnabled -eq $true) {
                    'Enabled'
                } else {
                    'Disabled'
                }
                $Recipients = $RoleIssue.NotificationRecipients

                $ResultMarkdown += "| $DisplayNameLink | $DefaultRecipientsStatus | $Recipients |`n"
            }
            $ResultMarkdown += "`n`n*Not all misconfigured roles may be listed. For performance reasons, this assessment stops at the first detected issue.*`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Low' -Name 'Activation alert for all privileged role assignments' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged access'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Low' -Name 'Activation alert for all privileged role assignments' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Privileged access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21820.ps1' 109
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21822.ps1' -1

function Invoke-CippTestZTNA21822 {
    <#
    .SYNOPSIS
    Guest access is limited to approved tenants
    #>
    param($Tenant)
    #Tested
    $TestId = 'ZTNA21822'

    try {
        # Get B2B management policy from cache
        $B2BManagementPolicyObject = Get-CIPPTestData -TenantFilter $Tenant -Type 'B2BManagementPolicy'

        $Passed = 'Failed'
        $AllowedDomains = @()
        $BlockedDomains = @()

        if ($B2BManagementPolicyObject -and $B2BManagementPolicyObject.definition) {
            $B2BManagementPolicy = ($B2BManagementPolicyObject.definition | ConvertFrom-Json).B2BManagementPolicy
            $AllowedDomains = $B2BManagementPolicy.InvitationsAllowedAndBlockedDomainsPolicy.AllowedDomains
            $BlockedDomains = $B2BManagementPolicy.InvitationsAllowedAndBlockedDomainsPolicy.BlockedDomains

            if ($AllowedDomains -and $AllowedDomains.Count -gt 0) {
                $Passed = 'Passed'
            }
        }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = "Guest access is limited to approved tenants.`n"
        } else {
            $ResultMarkdown = "Guest access is not limited to approved tenants.`n"
        }

        $ResultMarkdown += "`n`n## [Collaboration restrictions](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/CompanyRelationshipsMenuBlade/~/Settings/menuId/)`n`n"
        $ResultMarkdown += 'The tenant is configured to: '

        if ($Passed -eq 'Passed') {
            $ResultMarkdown += "**Allow invitations only to the specified domains (most restrictive)** ✅`n"
        } else {
            if ($BlockedDomains -and $BlockedDomains.Count -gt 0) {
                $ResultMarkdown += "**Deny invitations to the specified domains** ❌`n"
            } else {
                $ResultMarkdown += "**Allow invitations to be sent to any domain (most inclusive)** ❌`n"
            }
        }

        if (($AllowedDomains -and $AllowedDomains.Count -gt 0) -or ($BlockedDomains -and $BlockedDomains.Count -gt 0)) {
            $ResultMarkdown += "| Domain | Status |`n"
            $ResultMarkdown += "| :--- | :--- |`n"

            foreach ($Domain in $AllowedDomains) {
                $ResultMarkdown += "| $Domain | ✅ Allowed |`n"
            }

            foreach ($Domain in $BlockedDomains) {
                $ResultMarkdown += "| $Domain | ❌ Blocked |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Guest access is limited to approved tenants' -UserImpact 'Medium' -ImplementationEffort 'High' -Category 'Access control'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Guest access is limited to approved tenants' -UserImpact 'Medium' -ImplementationEffort 'High' -Category 'Access control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21822.ps1' 68
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21823.ps1' -1

function Invoke-CippTestZTNA21823 {
    <#
    .SYNOPSIS
    Guest self-service sign-up via user flow is disabled
    #>
    param($Tenant)

    $TestId = 'ZTNA21823'
    #Tested
    try {
        # Get authentication flows policy from cache
        $AuthFlowPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationFlowsPolicy'

        if (-not $AuthFlowPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Guest self-service sign-up via user flow is disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'External collaboration'
            return
        }

        $Passed = if ($AuthFlowPolicy.selfServiceSignUp.isEnabled -eq $false) { 'Passed' } else { 'Failed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = "[Guest self-service sign up via user flow](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/CompanyRelationshipsMenuBlade/~/Settings/menuId/ExternalIdentitiesGettingStarted) is disabled.`n"
        } else {
            $ResultMarkdown = "[Guest self-service sign up via user flow](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/CompanyRelationshipsMenuBlade/~/Settings/menuId/ExternalIdentitiesGettingStarted) is enabled.`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Guest self-service sign-up via user flow is disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'External collaboration'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Guest self-service sign-up via user flow is disabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'External collaboration'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21823.ps1' 35
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21824.ps1' -1

function Invoke-CippTestZTNA21824 {
    <#
    .SYNOPSIS
    Guests don't have long lived sign-in sessions
    #>
    param($Tenant)
    #Tested
    try {
        $allCAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $allCAPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21824' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name "Guests don't have long lived sign-in sessions" -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Conditional Access'
            return
        }

        $filteredCAPolicies = $allCAPolicies | Where-Object {
            ($null -ne $_.conditions.users.includeGuestsOrExternalUsers) -and
            ($_.state -in @('enabled', 'enabledForReportingButNotEnforced')) -and
            ($null -eq $_.grantControls.termsOfUse -or $_.grantControls.termsOfUse.Count -eq 0)
        }

        $matchedPolicies = $filteredCAPolicies | Where-Object {
            $signInFrequency = $_.sessionControls.signInFrequency
            if ($signInFrequency -and $signInFrequency.isEnabled) {
                ($signInFrequency.type -eq 'hours' -and $signInFrequency.value -le 24) -or
                ($signInFrequency.type -eq 'days' -and $signInFrequency.value -eq 1) -or
                ($null -eq $signInFrequency.type -and $signInFrequency.frequencyInterval -eq 'everyTime')
            } else {
                $false
            }
        }

        $passed = if ($filteredCAPolicies.Count -eq $matchedPolicies.Count) { 'Passed' } else { 'Failed' }

        if ($passed -eq 'Passed') {
            $testResultMarkdown = "Guests don't have long lived sign-in sessions."
        } else {
            $testResultMarkdown = 'Guests do have long lived sign-in sessions.'
        }

        $reportTitle = 'Sign-in frequency policies'

        if ($filteredCAPolicies -and $filteredCAPolicies.Count -gt 0) {
            $mdInfo = "`n## $reportTitle`n`n"
            $mdInfo += "| Policy Name | Sign-in Frequency | Status |`n"
            $mdInfo += "| :---------- | :---------------- | :----- |`n"

            foreach ($filteredCAPolicy in $filteredCAPolicies) {
                $policyName = $filteredCAPolicy.DisplayName

                $signInFrequency = $filteredCAPolicy.sessionControls.signInFrequency
                switch ($signInFrequency.type) {
                    'hours' {
                        $signInFreqValue = "$($signInFrequency.value) hours"
                    }
                    'days' {
                        $signInFreqValue = "$($signInFrequency.value) days"
                    }
                    default {
                        if ($signInFrequency.frequencyInterval -eq 'everyTime') {
                            $signInFreqValue = 'Every time'
                        } else {
                            $signInFreqValue = 'Not configured'
                        }
                    }
                }

                $status = if ($matchedPolicies -and $matchedPolicies.Id -contains $filteredCAPolicy.Id) {
                    '✅'
                } else {
                    '❌'
                }

                $mdInfo += "| $policyName | $signInFreqValue | $status |`n"
            }

            $testResultMarkdown = $testResultMarkdown + $mdInfo
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21824' -TestType 'Identity' -Status $passed -ResultMarkdown $testResultMarkdown -Risk 'Medium' -Name "Guests don't have long lived sign-in sessions" -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Conditional Access'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21824' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name "Guests don't have long lived sign-in sessions" -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Conditional Access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21824.ps1' 87
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21825.ps1' -1

function Invoke-CippTestZTNA21825 {
    <#
    .SYNOPSIS
    Privileged users have short-lived sign-in sessions
    #>
    param($Tenant)

    $TestId = 'ZTNA21825'
    #Tested
    try {
        # Get privileged roles
        $PrivilegedRoles = Get-CippDbRole -TenantFilter $Tenant -IncludePrivilegedRoles

        if (-not $PrivilegedRoles -or $PrivilegedRoles.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Privileged users have short-lived sign-in sessions' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Access control'
            return
        }

        # Get Conditional Access policies
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        # Filter to policies targeting roles
        $RoleScopedPolicies = $CAPolicies | Where-Object {
            $_.conditions.users.includeRoles -and $_.conditions.users.includeRoles.Count -gt 0
        }

        # Recommended: Sign-in frequency should be 4 hours or less for privileged users
        $RecommendedMaxHours = 4

        $ResultMarkdown = "## Privileged User Sign-In Sessions`n`n"
        $ResultMarkdown += "**Total Privileged Roles Found:** $($PrivilegedRoles.Count)`n`n"
        $ResultMarkdown += "**CA Policies Targeting Roles:** $($RoleScopedPolicies.Count)`n`n"
        $ResultMarkdown += "**Recommended Sign In Session Hours:** $RecommendedMaxHours`n`n"
        $ResultMarkdown += "### Conditional Access Policies by Privileged Role`n`n"

        $AllRolesCovered = $true

        foreach ($Role in $PrivilegedRoles) {
            $ResultMarkdown += "#### $($Role.displayName)`n`n"

            # Get CA policies assigned to this role
            $AssignedPolicies = $CAPolicies | Where-Object { $_.conditions.users.includeRoles -contains $Role.id }
            $EnabledPolicies = $AssignedPolicies | Where-Object { $_.state -eq 'enabled' }

            if ($EnabledPolicies.Count -gt 0) {
                # Check if at least one compliant enabled policy covers this role
                $CompliantForRole = $EnabledPolicies | Where-Object {
                    $_.sessionControls.signInFrequency -and
                    $_.sessionControls.signInFrequency.type -eq 'hours' -and
                    $_.sessionControls.signInFrequency.value -le $RecommendedMaxHours
                }

                $RoleStatus = if ($CompliantForRole.Count -gt 0) {
                    '✅ Covered'
                } else {
                    '❌ Not Covered'; $AllRolesCovered = $false
                }
                $ResultMarkdown += "**Status:** $RoleStatus`n`n"

                $ResultMarkdown += "| Policy Name | Sign-In Frequency | Compliant |`n"
                $ResultMarkdown += "| :--- | :--- | :--- |`n"

                foreach ($Policy in $EnabledPolicies) {
                    $FreqValue = 'Not Configured'
                    $IsCompliant = '❌'

                    if ($Policy.sessionControls.signInFrequency) {
                        $Freq = $Policy.sessionControls.signInFrequency
                        $FreqValue = "$($Freq.value) $($Freq.type)"

                        if ($Freq.type -eq 'hours' -and $Freq.value -le $RecommendedMaxHours) {
                            $IsCompliant = '✅'
                        } elseif ($Freq.type -eq 'hours') {
                            $IsCompliant = "⚠️ ($($Freq.value)h > $($RecommendedMaxHours)h)"
                        } else {
                            $IsCompliant = '❌ (Days not recommended)'
                        }
                    }

                    $PolicyLink = "https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/PolicyBlade/policyId/$($Policy.id)"
                    $ResultMarkdown += "| [$($Policy.displayName)]($PolicyLink) | $FreqValue | $IsCompliant |`n"
                }
                $ResultMarkdown += "`n"
            } else {
                $ResultMarkdown += "**Status:** ❌ No CA policies assigned`n`n"
                $ResultMarkdown += "*No Conditional Access policies target this privileged role.*`n`n"
                $AllRolesCovered = $false
            }
        }

        $Passed = if ($AllRolesCovered -and $PrivilegedRoles.Count -gt 0) { 'Passed' } else { 'Failed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown += "✅ **All privileged roles are covered by enabled policies enforcing short-lived sessions (≤$RecommendedMaxHours hours).**`n"
        } else {
            $ResultMarkdown += "❌ **Not all privileged roles are covered by compliant sign-in frequency controls.**`n"
            $ResultMarkdown += "`n**Recommendation:** Configure Conditional Access policies to enforce sign-in frequency of $RecommendedMaxHours hours or less for ALL privileged roles.`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Privileged users have short-lived sign-in sessions' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Access control'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Privileged users have short-lived sign-in sessions' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Access control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21825.ps1' 108
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21828.ps1' -1

function Invoke-CippTestZTNA21828 {
    <#
    .SYNOPSIS
    Authentication transfer is blocked
    #>
    param($Tenant)
    #Tested
    try {
        $allCAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $allCAPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21828' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Authentication transfer is blocked' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Conditional Access'
            return
        }

        $matchedPolicies = $allCAPolicies | Where-Object {
            $_.conditions.authenticationFlows.transferMethods -match 'authenticationTransfer' -and
            $_.grantControls.builtInControls -contains 'block' -and
            $_.conditions.users.includeUsers -eq 'all' -and
            $_.conditions.applications.includeApplications -eq 'all' -and
            $_.state -eq 'enabled'
        }

        if ($matchedPolicies.Count -gt 0) {
            $passed = 'Passed'
            $testResultMarkdown = 'Authentication transfer is blocked by Conditional Access Policy(s).'
        } else {
            $passed = 'Failed'
            $testResultMarkdown = 'Authentication transfer is not blocked.'
        }

        $reportTitle = 'Conditional Access Policies targeting Authentication Transfer'

        if ($matchedPolicies.Count -gt 0) {
            $mdInfo = "`n## $reportTitle`n`n"
            $mdInfo += "| Policy Name | Policy ID | State | Created | Modified |`n"
            $mdInfo += "| :---------- | :-------- | :---- | :------ | :------- |`n"

            foreach ($policy in $matchedPolicies) {
                $created = if ($policy.createdDateTime) { $policy.createdDateTime } else { 'N/A' }
                $modified = if ($policy.modifiedDateTime) { $policy.modifiedDateTime } else { 'N/A' }
                $mdInfo += "| $($policy.displayName) | $($policy.id) | $($policy.state) | $created | $modified |`n"
            }

            $testResultMarkdown = $testResultMarkdown + $mdInfo
        } else {
            $testResultMarkdown = $testResultMarkdown + "`n`nNo Conditional Access policies targeting authentication transfer."
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21828' -TestType 'Identity' -Status $passed -ResultMarkdown $testResultMarkdown -Risk 'High' -Name 'Authentication transfer is blocked' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Conditional Access'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21828' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Authentication transfer is blocked' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Conditional Access'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21828.ps1' 57
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21829.ps1' -1

function Invoke-CippTestZTNA21829 {
    <#
    .SYNOPSIS
    Use cloud authentication
    #>
    param($Tenant)
    #Tested
    $TestId = 'ZTNA21829'

    try {
        # Get domains
        $Domains = Get-CIPPTestData -TenantFilter $Tenant -Type 'Domains'

        if (-not $Domains) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Use cloud authentication' -UserImpact 'High' -ImplementationEffort 'High' -Category 'Access control'
            return
        }

        $FederatedDomains = $Domains | Where-Object { $_.authenticationType -eq 'Federated' }
        $Passed = if ($FederatedDomains.Count -eq 0) { 'Passed' } else { 'Failed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = "All domains are using cloud authentication.`n`n"
        } else {
            $ResultMarkdown = "Federated authentication is in use.`n`n"

            $ResultMarkdown += "`n## List of federated domains`n`n"
            $ResultMarkdown += "| Domain Name |`n"
            $ResultMarkdown += "| :--- |`n"
            foreach ($Domain in $FederatedDomains) {
                $ResultMarkdown += "| $($Domain.id) |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Use cloud authentication' -UserImpact 'High' -ImplementationEffort 'High' -Category 'Access control'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Use cloud authentication' -UserImpact 'High' -ImplementationEffort 'High' -Category 'Access control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21829.ps1' 43
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21830.ps1' -1

function Invoke-CippTestZTNA21830 {
    <#
    .SYNOPSIS
    Conditional Access policies for Privileged Access Workstations are configured
    #>
    param($Tenant)

    $TestId = 'ZTNA21830'
    #Tested
    try {
        # Get Conditional Access policies
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'
        $EnabledCAPolicies = $CAPolicies | Where-Object { $_.state -eq 'enabled' }

        # Get privileged roles
        $PrivilegedRoles = Get-CippDbRole -TenantFilter $Tenant -IncludePrivilegedRoles

        if (-not $PrivilegedRoles) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Conditional Access policies for Privileged Access Workstations are configured' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application management'
            return
        }

        $CompliantDevicePolicies = [System.Collections.Generic.List[object]]::new()
        $DeviceFilterPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($Policy in $EnabledCAPolicies) {
            # Check if policy targets privileged roles
            $TargetsPrivilegedRoles = $false
            if ($Policy.conditions.users.includeRoles) {
                foreach ($RoleId in $Policy.conditions.users.includeRoles) {
                    if ($PrivilegedRoles.id -contains $RoleId) {
                        $TargetsPrivilegedRoles = $true
                        break
                    }
                }
            }

            if ($TargetsPrivilegedRoles) {
                # Check for compliant device control
                if ($Policy.grantControls.builtInControls -contains 'compliantDevice') {
                    $CompliantDevicePolicies.Add($Policy)
                }

                # Check for device filter exclude + block
                $HasDeviceFilterExclude = $Policy.conditions.devices.deviceFilter -and
                $Policy.conditions.devices.deviceFilter.mode -eq 'exclude'
                $BlocksAccess = (-not $Policy.grantControls.builtInControls) -or
                ($Policy.grantControls.builtInControls -contains 'block')

                if ($HasDeviceFilterExclude -and $BlocksAccess) {
                    $DeviceFilterPolicies.Add($Policy)
                }
            }
        }

        $Passed = if ($CompliantDevicePolicies.Count -eq 0 -or $DeviceFilterPolicies.Count -eq 0) { 'Failed' } else { 'Passed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = 'Conditional Access policies restrict privileged role access to PAW devices.'
        } else {
            $ResultMarkdown = 'No Conditional Access policies found that restrict privileged roles to PAW device.'
        }

        $CompliantDeviceMarkdown = if ($CompliantDevicePolicies.Count -gt 0) { '✅' } else { '❌' }
        $DeviceFilterMarkdown = if ($DeviceFilterPolicies.Count -gt 0) { '✅' } else { '❌' }

        $ResultMarkdown += "`n`n**$CompliantDeviceMarkdown Found $($CompliantDevicePolicies.Count) policy(s) with compliant device control targeting all privileged roles**`n"
        foreach ($Policy in $CompliantDevicePolicies) {
            $PortalLink = "https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/PolicyBlade/policyId/$($Policy.id)"
            $ResultMarkdown += "- **Policy:** [$($Policy.displayName)]($PortalLink)`n"
        }

        $ResultMarkdown += "`n`n**$DeviceFilterMarkdown Found $($DeviceFilterPolicies.Count) policy(s) with PAW/SAW device filter targeting all privileged roles**`n"
        foreach ($Policy in $DeviceFilterPolicies) {
            $PortalLink = "https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/PolicyBlade/policyId/$($Policy.id)"
            $ResultMarkdown += "- **Policy:** [$($Policy.displayName)]($PortalLink)`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Conditional Access policies for Privileged Access Workstations are configured' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Conditional Access policies for Privileged Access Workstations are configured' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21830.ps1' 87
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21835.ps1' -1

function Invoke-CippTestZTNA21835 {
    <#
    .SYNOPSIS
    Emergency access accounts are configured appropriately
    #>
    param($Tenant)
    #Untested
    $TestId = 'ZTNA21835'

    try {
        # Get Global Administrator role (template ID: 62e90394-69f5-4237-9190-012177145e10)
        $Roles = Get-CIPPTestData -TenantFilter $Tenant -Type 'Roles'
        $GlobalAdminRole = $Roles | Where-Object { $_.roleTemplateId -eq '62e90394-69f5-4237-9190-012177145e10' }

        if (-not $GlobalAdminRole) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Emergency access accounts are configured appropriately' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application management'
            return
        }

        # Get permanent Global Administrator members
        $PermanentGAMembers = Get-CippDbRoleMembers -TenantFilter $Tenant -RoleTemplateId '62e90394-69f5-4237-9190-012177145e10' | Where-Object {
            $_.AssignmentType -eq 'Permanent' -and $_.'@odata.type' -eq '#microsoft.graph.user'
        }

        # Get Users data to check sync status
        $Users = Get-CIPPTestData -TenantFilter $Tenant -Type 'Users'

        $EmergencyAccountCandidates = [System.Collections.Generic.List[object]]::new()

        foreach ($Member in $PermanentGAMembers) {
            $User = $Users | Where-Object { $_.id -eq $Member.principalId }

            # Only process cloud-only accounts
            if ($User -and $User.onPremisesSyncEnabled -ne $true) {
                # Note: Individual user authentication methods require per-user API calls not available in cache
                # Add all cloud-only permanent GAs as candidates (cannot verify auth methods from cache)
                $EmergencyAccountCandidates.Add([PSCustomObject]@{
                        Id                    = $User.id
                        UserPrincipalName     = $User.userPrincipalName
                        DisplayName           = $User.displayName
                        OnPremisesSyncEnabled = $User.onPremisesSyncEnabled
                        AuthenticationMethods = @('Unknown - requires per-user API call')
                        CAPoliciesTargeting   = 0
                        ExcludedFromAllCA     = $false
                    })
            }
        }

        # Get CA policies
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'
        $EnabledCAPolicies = $CAPolicies | Where-Object { $_.state -eq 'enabled' }

        $EmergencyAccessAccounts = [System.Collections.Generic.List[object]]::new()

        foreach ($Candidate in $EmergencyAccountCandidates) {
            # Note: Transitive group and role memberships require per-user API calls not available in cache
            # Simplified check: only verify direct includes/excludes in CA policies
            $UserGroupIds = @()
            $UserRoles = @()
            $UserRoleIds = @()

            $PoliciesTargetingUser = 0
            $ExcludedFromAll = $true

            foreach ($Policy in $EnabledCAPolicies) {
                $IsTargeted = $false

                # Check user includes/excludes
                $IncludeUsers = @($Policy.conditions.users.includeUsers)
                $ExcludeUsers = @($Policy.conditions.users.excludeUsers)

                if ($IncludeUsers -contains 'All' -or $IncludeUsers -contains $Candidate.Id) {
                    $IsTargeted = $true
                }

                if ($ExcludeUsers -contains $Candidate.Id) {
                    $IsTargeted = $false
                }

                # Check group includes/excludes
                if (-not $IsTargeted -and $UserGroupIds.Count -gt 0) {
                    $IncludeGroups = @($Policy.conditions.users.includeGroups)
                    $ExcludeGroups = @($Policy.conditions.users.excludeGroups)

                    foreach ($GroupId in $UserGroupIds) {
                        if ($IncludeGroups -contains $GroupId) {
                            $IsTargeted = $true
                        }
                        if ($ExcludeGroups -contains $GroupId) {
                            $IsTargeted = $false
                            break
                        }
                    }
                }

                # Check role includes/excludes
                $IncludeRoles = @($Policy.conditions.users.includeRoles)
                $ExcludeRoles = @($Policy.conditions.users.excludeRoles)

                foreach ($RoleId in $UserRoleIds) {
                    $Role = $UserRoles | Where-Object { $_.id -eq $RoleId }
                    if ($Role -and $IncludeRoles -contains $Role.roleTemplateId) {
                        $IsTargeted = $true
                    }
                    if ($Role -and $ExcludeRoles -contains $Role.roleTemplateId) {
                        $IsTargeted = $false
                        break
                    }
                }

                if ($IsTargeted) {
                    $PoliciesTargetingUser++
                    $ExcludedFromAll = $false
                }
            }

            $Candidate.CAPoliciesTargeting = $PoliciesTargetingUser
            $Candidate.ExcludedFromAllCA = $ExcludedFromAll

            if ($ExcludedFromAll) {
                $EmergencyAccessAccounts.Add($Candidate)
            }
        }

        $AccountCount = $EmergencyAccessAccounts.Count
        $Passed = 'Failed'
        $ResultMarkdown = ''

        if ($AccountCount -lt 2) {
            $ResultMarkdown = "Fewer than two emergency access accounts were identified based on cloud-only state, registered phishing-resistant credentials and Conditional Access policy exclusions.`n`n"
        } elseif ($AccountCount -ge 2 -and $AccountCount -le 4) {
            $Passed = 'Passed'
            $ResultMarkdown = "Emergency access accounts appear to be configured as per Microsoft guidance based on cloud-only state, registered phishing-resistant credentials and Conditional Access policy exclusions.`n`n"
        } else {
            $ResultMarkdown = "$AccountCount emergency access accounts appear to be configured based on cloud-only state, registered phishing-resistant credentials and Conditional Access policy exclusions. Review these accounts to determine whether this volume is excessive for your organization.`n`n"
        }

        $ResultMarkdown += "**Summary:**`n"
        $ResultMarkdown += "- Total permanent Global Administrators: $($PermanentGAMembers.Count)`n"
        $ResultMarkdown += "- Cloud-only GAs with phishing-resistant auth: $($EmergencyAccountCandidates.Count)`n"
        $ResultMarkdown += "- Emergency access accounts (excluded from all CA): $AccountCount`n"
        $ResultMarkdown += "- Enabled Conditional Access policies: $($EnabledCAPolicies.Count)`n`n"

        if ($EmergencyAccessAccounts.Count -gt 0) {
            $ResultMarkdown += "## Emergency access accounts`n`n"
            $ResultMarkdown += "| Display name | UPN | Synced from on-premises | Authentication methods |`n"
            $ResultMarkdown += "| :----------- | :-- | :---------------------- | :--------------------- |`n"

            foreach ($Account in $EmergencyAccessAccounts) {
                $SyncStatus = if ($Account.OnPremisesSyncEnabled -ne $true) { 'No' } else { 'Yes' }
                $AuthMethodDisplay = ($Account.AuthenticationMethods | ForEach-Object {
                        $_ -replace '#microsoft.graph.', '' -replace 'AuthenticationMethod', ''
                    }) -join ', '

                $PortalLink = "https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/overview/userId/$($Account.Id)"
                $ResultMarkdown += "| $($Account.DisplayName) | [$($Account.UserPrincipalName)]($PortalLink) | $SyncStatus | $AuthMethodDisplay |`n"
            }
            $ResultMarkdown += "`n"
        }

        if ($PermanentGAMembers.Count -gt 0) {
            $ResultMarkdown += "## All permanent Global Administrators`n`n"
            $ResultMarkdown += "| Display name | UPN | Cloud only | All CA excluded | Phishing resistant auth |`n"
            $ResultMarkdown += "| :----------- | :-- | :--------: | :---------: | :---------------------: |`n"

            $UserSummary = [System.Collections.Generic.List[object]]::new()
            foreach ($Member in $PermanentGAMembers) {
                $User = $Users | Where-Object { $_.id -eq $Member.principalId }
                if (-not $User) { continue }

                $PortalLink = "https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/overview/userId/$($User.id)"
                $IsCloudOnly = ($User.onPremisesSyncEnabled -ne $true)
                $CloudOnlyEmoji = if ($IsCloudOnly) { '✅' } else { '❌' }

                $EmergencyAccount = $EmergencyAccessAccounts | Where-Object { $_.Id -eq $User.id }
                $CAExcludedEmoji = if ($EmergencyAccount) { '✅' } else { '❌' }

                $Candidate = $EmergencyAccountCandidates | Where-Object { $_.Id -eq $User.id }
                $PhishingResistantEmoji = if ($Candidate) { '✅' } else { '❌' }

                $UserSummary.Add([PSCustomObject]@{
                        DisplayName       = $User.displayName
                        UserPrincipalName = $User.userPrincipalName
                        PortalLink        = $PortalLink
                        CloudOnly         = $CloudOnlyEmoji
                        CAExcluded        = $CAExcludedEmoji
                        PhishingResistant = $PhishingResistantEmoji
                    })
            }

            foreach ($UserSum in $UserSummary) {
                $ResultMarkdown += "| $($UserSum.DisplayName) | [$($UserSum.UserPrincipalName)]($($UserSum.PortalLink)) | $($UserSum.CloudOnly) | $($UserSum.CAExcluded) | $($UserSum.PhishingResistant) |`n"
            }

            $ResultMarkdown += "`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Emergency access accounts are configured appropriately' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Emergency access accounts are configured appropriately' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21835.ps1' 206
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21836.ps1' -1

function Invoke-CippTestZTNA21836 {
    <#
    .SYNOPSIS
    Workload Identities are not assigned privileged roles
    #>
    param($Tenant)
    #Untested
    $TestId = 'ZTNA21836'

    try {
        # Get privileged roles
        $PrivilegedRoles = Get-CippDbRole -TenantFilter $Tenant -IncludePrivilegedRoles

        if (-not $PrivilegedRoles) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Workload Identities are not assigned privileged roles' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application management'
            return
        }

        # Get workload identities (service principals) with privileged role assignments
        $WorkloadIdentitiesWithPrivilegedRoles = [System.Collections.Generic.List[object]]::new()

        foreach ($Role in $PrivilegedRoles) {
            $RoleMembers = Get-CippDbRoleMembers -TenantFilter $Tenant -RoleTemplateId $Role.id

            foreach ($Member in $RoleMembers) {
                if ($Member.'@odata.type' -eq '#microsoft.graph.servicePrincipal') {
                    $WorkloadIdentitiesWithPrivilegedRoles.Add([PSCustomObject]@{
                            PrincipalId          = $Member.principalId
                            PrincipalDisplayName = $Member.principalDisplayName
                            AppId                = $Member.appId
                            RoleDisplayName      = $Role.displayName
                            RoleDefinitionId     = $Role.id
                            AssignmentType       = $Member.AssignmentType
                        })
                }
            }
        }

        $Passed = 'Passed'
        $ResultMarkdown = ''

        if ($WorkloadIdentitiesWithPrivilegedRoles.Count -gt 0) {
            $Passed = 'Failed'
            $ResultMarkdown = "**Found workload identities assigned to privileged roles.**`n"
            $ResultMarkdown += "| Service Principal Name | Privileged Role | Assignment Type |`n"
            $ResultMarkdown += "| :--- | :--- | :--- |`n"

            $SortedAssignments = $WorkloadIdentitiesWithPrivilegedRoles | Sort-Object -Property PrincipalDisplayName

            foreach ($Assignment in $SortedAssignments) {
                $SPLink = "https://entra.microsoft.com/#view/Microsoft_AAD_IAM/ManagedAppMenuBlade/~/Overview/objectId/$($Assignment.PrincipalId)/appId/$($Assignment.AppId)/preferredSingleSignOnMode~/null/servicePrincipalType/Application/fromNav/"
                $ResultMarkdown += "| [$($Assignment.PrincipalDisplayName)]($SPLink) | $($Assignment.RoleDisplayName) | $($Assignment.AssignmentType) |`n"
            }
            $ResultMarkdown += "`n"
            $ResultMarkdown += "`n**Recommendation:** Review and remove privileged role assignments from workload identities unless absolutely necessary. Use least-privilege principles and consider alternative approaches like managed identities with specific API permissions instead of directory roles.`n"
        } else {
            $ResultMarkdown = "✅ **No workload identities found with privileged role assignments.**`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Workload Identities are not assigned privileged roles' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Workload Identities are not assigned privileged roles' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21836.ps1' 68
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21837.ps1' -1

function Invoke-CippTestZTNA21837 {
    <#
    .SYNOPSIS
    Limit the maximum number of devices per user to 10
    #>
    param($Tenant)

    $TestId = 'ZTNA21837'
    #Tested
    try {
        # Get device registration policy
        $DeviceSettings = Get-CIPPTestData -TenantFilter $Tenant -Type 'DeviceRegistrationPolicy'

        if (-not $DeviceSettings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Limit the maximum number of devices per user to 10' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Devices'
            return
        }

        $UserQuota = $DeviceSettings.userDeviceQuota
        $EntraDeviceSettingsLink = 'https://entra.microsoft.com/#view/Microsoft_AAD_Devices/DevicesMenuBlade/~/DeviceSettings/menuId/Overview'

        $Passed = 'Failed'
        $CustomStatus = $null

        if ($null -eq $UserQuota -or $UserQuota -le 10) {
            $Passed = 'Passed'
            $ResultMarkdown = "[Maximum number of devices per user]($EntraDeviceSettingsLink) is set to $UserQuota"
        } elseif ($UserQuota -gt 10 -and $UserQuota -le 20) {
            $CustomStatus = 'Investigate'
            $ResultMarkdown = "[Maximum number of devices per user]($EntraDeviceSettingsLink) is set to $UserQuota. Consider reducing to 10 or fewer."
        } else {
            $ResultMarkdown = "[Maximum number of devices per user]($EntraDeviceSettingsLink) is set to $UserQuota. Consider reducing to 10 or fewer."
        }

        if ($CustomStatus) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $CustomStatus -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Limit the maximum number of devices per user to 10' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Devices'
        } else {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Limit the maximum number of devices per user to 10' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Devices'
        }

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Limit the maximum number of devices per user to 10' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Devices'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21837.ps1' 47
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21838.ps1' -1

function Invoke-CippTestZTNA21838 {
    <#
    .SYNOPSIS
    Security key authentication method enabled
    #>
    param($Tenant)

    $TestId = 'ZTNA21838'
    #Tested
    try {
        # Get FIDO2 authentication method policy
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Security key authentication method enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access control'
            return
        }

        $Fido2Config = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Fido2' }

        if (-not $Fido2Config) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Security key authentication method enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access control'
            return
        }

        $Fido2Enabled = $Fido2Config.state -eq 'enabled'
        $Passed = if ($Fido2Enabled) { 'Passed' } else { 'Failed' }
        $StatusEmoji = if ($Fido2Enabled) { '✅' } else { '❌' }

        if ($Fido2Enabled) {
            $ResultMarkdown = "Security key authentication method is enabled for your tenant, providing hardware-backed phishing-resistant authentication.`n`n"
        } else {
            $ResultMarkdown = "Security key authentication method is not enabled; users cannot register FIDO2 security keys for strong authentication.`n`n"
        }

        $ResultMarkdown += "## FIDO2 security key authentication settings`n`n"
        $ResultMarkdown += "$StatusEmoji **FIDO2 authentication method**`n"
        $ResultMarkdown += "- Status: $($Fido2Config.state)`n"

        $IncludeTargetsDisplay = if ($Fido2Config.includeTargets -and $Fido2Config.includeTargets.Count -gt 0) {
            ($Fido2Config.includeTargets | ForEach-Object { if ($_.id -eq 'all_users') { 'All users' } else { $_.id } }) -join ', '
        } else {
            'None'
        }
        $ResultMarkdown += "- Include targets: $IncludeTargetsDisplay`n"

        $ExcludeTargetsDisplay = if ($Fido2Config.excludeTargets -and $Fido2Config.excludeTargets.Count -gt 0) {
            ($Fido2Config.excludeTargets | ForEach-Object { $_.id }) -join ', '
        } else {
            'None'
        }
        $ResultMarkdown += "- Exclude targets: $ExcludeTargetsDisplay`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Security key authentication method enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access control'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Security key authentication method enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21838.ps1' 62
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21839.ps1' -1

function Invoke-CippTestZTNA21839 {
    <#
    .SYNOPSIS
    Passkey authentication method enabled
    #>
    param($Tenant)

    $TestId = 'ZTNA21839'
    #Tested
    try {
        # Get FIDO2 authentication method policy
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Passkey authentication method enabled' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Credential management'
            return
        }

        $Fido2Config = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Fido2' }

        if (-not $Fido2Config) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Passkey authentication method enabled' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Credential management'
            return
        }

        $State = $Fido2Config.state
        $IncludeTargets = $Fido2Config.includeTargets
        $IsAttestationEnforced = $Fido2Config.isAttestationEnforced
        $KeyRestrictions = $Fido2Config.keyRestrictions

        $Fido2Enabled = $State -eq 'enabled'
        $HasIncludeTargets = $IncludeTargets -and $IncludeTargets.Count -gt 0

        $PortalLink = 'https://entra.microsoft.com/#view/Microsoft_AAD_IAM/AuthenticationMethodsMenuBlade/~/AdminAuthMethods'

        $ResultMarkdown = "`n## [Passkey authentication method details]($PortalLink)`n"

        $StatusDisplay = if ($Fido2Enabled) { 'Enabled ✅' } else { 'Disabled ❌' }
        $ResultMarkdown += "- **Status** : $StatusDisplay`n"

        if ($Fido2Enabled) {
            $ResultMarkdown += '- **Include targets** : '
            if ($IncludeTargets) {
                $TargetsDisplay = ($IncludeTargets | ForEach-Object {
                        if ($_.id -eq 'all_users') { 'All users' } else { $_.id }
                    }) -join ', '
                $ResultMarkdown += "$TargetsDisplay`n"
            } else {
                $ResultMarkdown += "None`n"
            }

            $ResultMarkdown += "- **Enforce attestation** : $IsAttestationEnforced`n"

            if ($KeyRestrictions) {
                $ResultMarkdown += "- **Key restriction policy** :`n"
                if ($null -ne $KeyRestrictions.isEnforced) {
                    $ResultMarkdown += "  - **Enforce key restrictions** : $($KeyRestrictions.isEnforced)`n"
                } else {
                    $ResultMarkdown += "  - **Enforce key restrictions** : Not configured`n"
                }
                if ($KeyRestrictions.enforcementType) {
                    $ResultMarkdown += "  - **Restrict specific keys** : $($KeyRestrictions.enforcementType)`n"
                } else {
                    $ResultMarkdown += "  - **Restrict specific keys** : Not configured`n"
                }
            }
        }

        $Passed = if ($Fido2Enabled -and $HasIncludeTargets) { 'Passed' } else { 'Failed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = "Passkey authentication method is enabled and configured for users in your tenant.$ResultMarkdown"
        } else {
            $ResultMarkdown = "Passkey authentication method is not enabled or not configured for any users in your tenant.$ResultMarkdown"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Passkey authentication method enabled' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Credential management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Passkey authentication method enabled' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Credential management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21839.ps1' 85
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21840.ps1' -1

function Invoke-CippTestZTNA21840 {
    <#
    .SYNOPSIS
    Security key attestation is enforced
    #>
    param($Tenant)
    #Tested
    $TestId = 'ZTNA21840'

    try {
        # Get FIDO2 authentication method policy
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Security key attestation is enforced' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
            return
        }

        $Fido2Config = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'Fido2' }

        if (-not $Fido2Config) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Security key attestation is enforced' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
            return
        }

        $IsAttestationEnforced = $Fido2Config.isAttestationEnforced
        $KeyRestrictions = $Fido2Config.keyRestrictions

        $PortalLink = 'https://entra.microsoft.com/#view/Microsoft_AAD_IAM/AuthenticationMethodsMenuBlade/~/AdminAuthMethods'

        $ResultMarkdown = "`n## [Security key attestation policy details]($PortalLink)`n"

        $AttestationStatus = if ($IsAttestationEnforced -eq $true) { 'True ✅' } else { 'False ❌' }
        $ResultMarkdown += "- **Enforce attestation** : $AttestationStatus`n"

        if ($KeyRestrictions) {
            $ResultMarkdown += "- **Key restriction policy** :`n"
            if ($null -ne $KeyRestrictions.isEnforced) {
                $ResultMarkdown += "  - **Enforce key restrictions** : $($KeyRestrictions.isEnforced)`n"
            } else {
                $ResultMarkdown += "  - **Enforce key restrictions** : Not configured`n"
            }
            if ($KeyRestrictions.enforcementType) {
                $ResultMarkdown += "  - **Restrict specific keys** : $($KeyRestrictions.enforcementType)`n"
            } else {
                $ResultMarkdown += "  - **Restrict specific keys** : Not configured`n"
            }

            if ($KeyRestrictions.aaGuids -and $KeyRestrictions.aaGuids.Count -gt 0) {
                $ResultMarkdown += "  - **AAGUID** :`n"
                foreach ($Guid in $KeyRestrictions.aaGuids) {
                    $ResultMarkdown += "    - $Guid`n"
                }
            }
        }

        $Passed = if ($IsAttestationEnforced -eq $true) { 'Passed' } else { 'Failed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = "Security key attestation is properly enforced, ensuring only verified hardware authenticators can be registered.$ResultMarkdown"
        } else {
            $ResultMarkdown = "Security key attestation is not enforced, allowing unverified or potentially compromised security keys to be registered.$ResultMarkdown"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Security key attestation is enforced' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Security key attestation is enforced' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21840.ps1' 73
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21841.ps1' -1

function Invoke-CippTestZTNA21841 {
    <#
    .SYNOPSIS
    Microsoft Authenticator app report suspicious activity setting is enabled
    #>
    param($Tenant)
    #Tested
    $TestId = 'ZTNA21841'

    try {
        # Get authentication methods policy
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Microsoft Authenticator app report suspicious activity setting is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
            return
        }

        $Passed = 'Failed'
        $PortalLink = 'https://entra.microsoft.com/#view/Microsoft_AAD_IAM/AuthenticationMethodsMenuBlade/~/AuthMethodsSettings'

        if ($AuthMethodsPolicy.reportSuspiciousActivitySettings) {
            $ReportSettings = $AuthMethodsPolicy.reportSuspiciousActivitySettings

            $StateEnabled = $ReportSettings.state -eq 'enabled'
            $TargetAllUsers = $false

            if ($ReportSettings.includeTarget) {
                $TargetAllUsers = $ReportSettings.includeTarget.id -eq 'all_users'
            }

            if ($StateEnabled -and $TargetAllUsers) {
                $Passed = 'Passed'
                $ResultMarkdown = "Authenticator app report suspicious activity is [enabled for all users]($PortalLink)."
            } else {
                if (-not $StateEnabled) {
                    $ResultMarkdown = "Authenticator app report suspicious activity is [not enabled]($PortalLink)."
                } elseif (-not $TargetAllUsers) {
                    $ResultMarkdown = "Authenticator app report suspicious activity is [not configured for all users]($PortalLink)."
                }
            }
        } else {
            $ResultMarkdown = "Authenticator app report suspicious activity is [not enabled]($PortalLink)."
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Microsoft Authenticator app report suspicious activity setting is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Microsoft Authenticator app report suspicious activity setting is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21841.ps1' 54
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21842.ps1' -1

function Invoke-CippTestZTNA21842 {
    <#
    .SYNOPSIS
    Block administrators from using SSPR
    #>
    param($Tenant)

    $TestId = 'ZTNA21842'
    #Tested
    try {
        # Get authorization policy
        $AuthorizationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthorizationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Block administrators from using SSPR' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
            return
        }

        $AllowedToUseSspr = $AuthorizationPolicy.allowedToUseSspr
        $Passed = 'Failed'
        $UserMessage = ''

        if ($null -ne $AllowedToUseSspr -and $AllowedToUseSspr -eq $false) {
            $Passed = 'Passed'
            $UserMessage = '✅ Administrators are properly blocked from using Self-Service Password Reset, ensuring password changes go through controlled processes.'
        } else {
            $UserMessage = '❌ Administrators have access to Self-Service Password Reset, which bypasses security controls and administrative oversight.'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $UserMessage -Risk 'High' -Name 'Block administrators from using SSPR' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Block administrators from using SSPR' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21842.ps1' 38
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21844.ps1' -1

function Invoke-CippTestZTNA21844 {
    <#
    .SYNOPSIS
    Block legacy Azure AD PowerShell module
    #>
    param($Tenant)

    $TestId = 'ZTNA21844'
    #Tested
    try {
        # Azure AD PowerShell App ID
        $AzureADPowerShellAppId = '1b730954-1685-4b74-9bfd-dac224a7b894'

        # Query for the Azure AD PowerShell service principal
        $ServicePrincipals = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipals'
        $ServicePrincipal = $ServicePrincipals | Where-Object { $_.appId -eq $AzureADPowerShellAppId }

        $InvestigateStatus = $false
        $AppName = 'Azure AD PowerShell'
        $Passed = 'Failed'

        if (-not $ServicePrincipal -or $ServicePrincipal.Count -eq 0) {
            $SummaryLines = @(
                'Summary',
                '',
                "- $AppName (Enterprise App not found in tenant)",
                '- Sign in disabled: N/A',
                '',
                "$AppName has not been blocked by the organization."
            )
        } else {
            $SP = $ServicePrincipal[0]
            $PortalLink = "https://entra.microsoft.com/#view/Microsoft_AAD_IAM/ManagedAppMenuBlade/~/Overview/objectId/$($SP.id)/appId/$($SP.appId)"
            $ServicePrincipalMarkdown = "[$AppName]($PortalLink)"

            if ($SP.accountEnabled -eq $false) {
                $Passed = 'Passed'
                $SummaryLines = @(
                    'Summary',
                    '',
                    "- $ServicePrincipalMarkdown",
                    '- Sign in disabled: Yes',
                    '',
                    "$AppName is blocked in the tenant by turning off user sign in to the Azure Active Directory PowerShell Enterprise Application."
                )
            } elseif ($SP.appRoleAssignmentRequired -eq $true) {
                $InvestigateStatus = $true
                $SummaryLines = @(
                    'Summary',
                    '',
                    "- $ServicePrincipalMarkdown",
                    '- Sign in disabled: No',
                    '- User assignment required: Yes',
                    '',
                    "App role assignment is required for $AppName. Review assignments and confirm that the app is inaccessible to users."
                )
            } else {
                $SummaryLines = @(
                    'Summary',
                    '',
                    "- $ServicePrincipalMarkdown",
                    '- Sign in disabled: No',
                    '',
                    "$AppName has not been blocked by the organization."
                )
            }
        }

        $ResultMarkdown = $SummaryLines -join "`n"

        if ($InvestigateStatus) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Block legacy Azure AD PowerShell module' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access control'
        } else {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Block legacy Azure AD PowerShell module' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access control'
        }

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Block legacy Azure AD PowerShell module' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Access control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21844.ps1' 83
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21845.ps1' -1

function Invoke-CippTestZTNA21845 {
    <#
    .SYNOPSIS
    Temporary access pass is enabled
    #>
    param($Tenant)

    $TestId = 'ZTNA21845'
    #Tested
    try {
        # Get Temporary Access Pass configuration
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'
        $TAPConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'TemporaryAccessPass' }

        if (-not $TAPConfig) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Temporary access pass is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
            return
        }

        # Check if TAP is disabled
        if ($TAPConfig.state -ne 'enabled') {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown '❌ Temporary Access Pass is disabled in the tenant.' -Risk 'Medium' -Name 'Temporary access pass is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
            return
        }

        # Get conditional access policies
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'
        $SecurityInfoPolicies = $CAPolicies | Where-Object {
            $_.state -eq 'enabled' -and
            $_.conditions.applications.includeUserActions -contains 'urn:user:registersecurityinfo' -and
            $_.grantControls.authenticationStrength -ne $null
        }

        $TAPEnabled = $TAPConfig.state -eq 'enabled'
        $TargetsAllUsers = $TAPConfig.includeTargets | Where-Object { $_.id -eq 'all_users' }
        $HasConditionalAccessEnforcement = $SecurityInfoPolicies.Count -gt 0

        # Note: Authentication strength policy validation requires additional API calls not available in cache
        # Simplified check: verify TAP is enabled, targets all users, and CA policies exist
        $TAPSupportedInAuthStrength = $HasConditionalAccessEnforcement

        # Determine pass/fail status
        $Passed = 'Failed'
        if ($TAPEnabled -and $TargetsAllUsers -and $HasConditionalAccessEnforcement -and $TAPSupportedInAuthStrength) {
            $Passed = 'Passed'
            $ResultMarkdown = 'Temporary Access Pass is enabled, targeting all users, and enforced with conditional access policies.'
        } elseif ($TAPEnabled -and $TargetsAllUsers -and $HasConditionalAccessEnforcement -and -not $TAPSupportedInAuthStrength) {
            $ResultMarkdown = "Temporary Access Pass is enabled but authentication strength policies don't include TAP methods."
        } elseif ($TAPEnabled -and $TargetsAllUsers -and -not $HasConditionalAccessEnforcement) {
            $ResultMarkdown = 'Temporary Access Pass is enabled but no conditional access enforcement for security info registration found. Consider adding conditional access policies for stronger security.'
        } else {
            $ResultMarkdown = 'Temporary Access Pass is not properly configured or does not target all users.'
        }

        $ResultMarkdown += "`n`n**Configuration summary**`n`n"

        $TAPStatus = if ($TAPConfig.state -eq 'enabled') { 'Enabled ✅' } else { 'Disabled ❌' }
        $ResultMarkdown += "[Temporary Access Pass](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/AuthenticationMethodsMenuBlade/~/AdminAuthMethods/fromNav/Identity): $TAPStatus`n`n"

        $CAStatus = if ($HasConditionalAccessEnforcement) { 'Enabled ✅' } else { 'Not enabled ❌' }
        $ResultMarkdown += "[Conditional Access policy for Security info registration](https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/ConditionalAccessBlade/~/Policies/fromNav/Identity): $CAStatus`n`n"

        $AuthStrengthStatus = if ($TAPSupportedInAuthStrength) { 'Enabled ✅' } else { 'Not enabled ❌' }
        $ResultMarkdown += "[Authentication strength policy for Temporary Access Pass](https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/AuthenticationStrength.ReactView/fromNav/Identity): $AuthStrengthStatus`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Temporary access pass is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Temporary access pass is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21845.ps1' 74
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21846.ps1' -1

function Invoke-CippTestZTNA21846 {
    <#
    .SYNOPSIS
    Restrict Temporary Access Pass to Single Use
    #>
    param($Tenant)

    $TestId = 'ZTNA21846'
    #Tested
    try {
        # Get Temporary Access Pass configuration
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'
        $TAPConfig = $AuthMethodsPolicy.authenticationMethodConfigurations | Where-Object { $_.id -eq 'TemporaryAccessPass' }

        if (-not $TAPConfig) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Restrict Temporary Access Pass to Single Use' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
            return
        }

        $Passed = if ($TAPConfig.isUsableOnce -eq $true) { 'Passed' } else { 'Failed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = "Temporary Access Pass is configured for one-time use only.`n`n"
        } else {
            $ResultMarkdown = "Temporary Access Pass allows multiple uses during validity period.`n`n"
        }

        $ResultMarkdown += "## Temporary Access Pass Configuration`n`n"
        $ResultMarkdown += "| Setting | Value | Status |`n"
        $ResultMarkdown += "| :------ | :---- | :----- |`n"

        $IsUsableOnceValue = if ($TAPConfig.isUsableOnce) { 'Enabled' } else { 'Disabled' }
        $StatusEmoji = if ($Passed -eq 'Passed') { '✅ Pass' } else { '❌ Fail' }

        $ResultMarkdown += "| [One-time use restriction](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/AuthenticationMethodsMenuBlade/~/AdminAuthMethods/fromNav/) | $IsUsableOnceValue | $StatusEmoji |`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Restrict Temporary Access Pass to Single Use' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Restrict Temporary Access Pass to Single Use' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21846.ps1' 45
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21847.ps1' -1

function Invoke-CippTestZTNA21847 {
    <#
    .SYNOPSIS
    Password protection for on-premises is enabled
    #>
    param($Tenant)

    $TestId = 'ZTNA21847'
    #Tested
    try {
        # Check if tenant has on-premises sync
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Organization'

        if (-not $Settings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Password protection for on-premises is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
            return
        }

        $Org = $Settings[0]

        if ($Org.onPremisesSyncEnabled -ne $true) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Passed' -ResultMarkdown '✅ **Pass**: This tenant is not synchronized to an on-premises environment.' -Risk 'High' -Name 'Password protection for on-premises is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
            return
        }

        # Note: Password protection settings require groupSettings API which is not cached
        # This test requires direct API access to check EnableBannedPasswordCheckOnPremises and BannedPasswordCheckOnPremisesMode
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Password protection for on-premises is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
        return

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Password protection for on-premises is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Password protection for on-premises is enabled' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21847.ps1' 39
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21848.ps1' -1

function Invoke-CippTestZTNA21848 {
    <#
    .SYNOPSIS
    Add organizational terms to the banned password list
    #>
    param($Tenant)

    $TestId = 'ZTNA21848'
    #Tested
    try {
        # Get password protection settings from Settings cache
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'
        $PasswordProtectionSettings = $Settings | Where-Object { $_.templateId -eq '5cf42378-d67d-4f36-ba46-e8b86229381d' }

        if (-not $PasswordProtectionSettings) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Add organizational terms to the banned password list' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
            return
        }

        $EnableBannedPasswordCheck = ($PasswordProtectionSettings.values | Where-Object { $_.name -eq 'EnableBannedPasswordCheck' }).value
        $BannedPasswordList = ($PasswordProtectionSettings.values | Where-Object { $_.name -eq 'BannedPasswordList' }).value

        if ([string]::IsNullOrEmpty($BannedPasswordList)) {
            $BannedPasswordList = $null
        }

        $Passed = if ($EnableBannedPasswordCheck -eq $true -and $null -ne $BannedPasswordList) { 'Passed' } else { 'Failed' }

        $PortalLink = 'https://entra.microsoft.com/#view/Microsoft_AAD_IAM/AuthenticationMethodsMenuBlade/~/PasswordProtection/fromNav/'

        $Enforced = if ($EnableBannedPasswordCheck -eq $true) { 'Yes' } else { 'No' }

        # Split on tab characters to handle tab-delimited banned password entries
        if ($BannedPasswordList) {
            $BannedPasswordArray = $BannedPasswordList -split '\t'
        } else {
            $BannedPasswordArray = @()
        }

        # Show up to 10 banned passwords, summarize if more exist
        $MaxDisplay = 10
        if ($BannedPasswordArray.Count -gt $MaxDisplay) {
            $DisplayList = $BannedPasswordArray[0..($MaxDisplay - 1)] + "...and $($BannedPasswordArray.Count - $MaxDisplay) more"
        } else {
            $DisplayList = $BannedPasswordArray
        }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = "✅ Custom banned passwords are properly configured with organization-specific terms.`n`n"
        } else {
            $ResultMarkdown = "❌ Custom banned passwords are not enabled or lack organization-specific terms.`n`n"
        }

        $ResultMarkdown += "## [Password protection settings]($PortalLink)`n`n"
        $ResultMarkdown += "| Enforce custom list | Custom banned password list | Number of terms |`n"
        $ResultMarkdown += "| :------------------ | :-------------------------- | :-------------- |`n"
        $ResultMarkdown += "| $Enforced | $($DisplayList -join ', ') | $($BannedPasswordArray.Count) |`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Add organizational terms to the banned password list' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Add organizational terms to the banned password list' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21848.ps1' 67
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21849.ps1' -1

function Invoke-CippTestZTNA21849 {
    <#
    .SYNOPSIS
    Smart lockout duration is set to a minimum of 60
    #>
    param($Tenant)

    $TestId = 'ZTNA21849'
    #Tested
    try {
        # Get password rule settings from Settings cache
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'
        $PasswordRuleSettings = $Settings | Where-Object { $_.displayName -eq 'Password Rule Settings' }

        $PortalLink = 'https://entra.microsoft.com/#view/Microsoft_AAD_IAM/AuthenticationMethodsMenuBlade/~/PasswordProtection/fromNav/'

        if ($null -eq $PasswordRuleSettings) {
            # Default is 60 seconds
            $Passed = 'Passed'
            $ResultMarkdown = "✅ Smart Lockout duration is configured to 60 seconds or higher (default).`n`n"
            $ResultMarkdown += "## [Smart Lockout Settings]($PortalLink)`n`n"
            $ResultMarkdown += "| Setting | Value |`n"
            $ResultMarkdown += "| :---- | :---- |`n"
            $ResultMarkdown += "| Lockout Duration (seconds) | 60 (Default) |`n"
        } else {
            $LockoutDurationSetting = $PasswordRuleSettings.values | Where-Object { $_.name -eq 'LockoutDurationInSeconds' }

            if ($null -eq $LockoutDurationSetting) {
                # Default is 60 seconds
                $Passed = 'Passed'
                $ResultMarkdown = "✅ Smart Lockout duration is configured to 60 seconds or higher (default).`n`n"
                $ResultMarkdown += "## [Smart Lockout Settings]($PortalLink)`n`n"
                $ResultMarkdown += "| Setting | Value |`n"
                $ResultMarkdown += "| :---- | :---- |`n"
                $ResultMarkdown += "| Lockout Duration (seconds) | 60 (Default) |`n"
            } else {
                $LockoutDuration = [int]$LockoutDurationSetting.value

                if ($LockoutDuration -ge 60) {
                    $Passed = 'Passed'
                    $ResultMarkdown = "✅ Smart Lockout duration is configured to 60 seconds or higher.`n`n"
                } else {
                    $Passed = 'Failed'
                    $ResultMarkdown = "❌ Smart Lockout duration is configured below 60 seconds.`n`n"
                }

                $ResultMarkdown += "## [Smart Lockout Settings]($PortalLink)`n`n"
                $ResultMarkdown += "| Setting | Value |`n"
                $ResultMarkdown += "| :---- | :---- |`n"
                $ResultMarkdown += "| Lockout Duration (seconds) | $LockoutDuration |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Smart lockout duration is set to a minimum of 60' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Smart lockout duration is set to a minimum of 60' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21849.ps1' 62
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21850.ps1' -1

function Invoke-CippTestZTNA21850 {
    <#
    .SYNOPSIS
    Smart lockout threshold set to 10 or less
    #>
    param($Tenant)

    $TestId = 'ZTNA21850'
    #Tested
    try {
        # Get password rule settings from Settings cache
        $Settings = Get-CIPPTestData -TenantFilter $Tenant -Type 'Settings'
        $PasswordRuleSettings = $Settings | Where-Object { $_.displayName -eq 'Password Rule Settings' }

        $PortalLink = 'https://entra.microsoft.com/#view/Microsoft_AAD_IAM/AuthenticationMethodsMenuBlade/~/PasswordProtection/fromNav/'

        if ($null -eq $PasswordRuleSettings) {
            $Passed = 'Failed'
            $ResultMarkdown = '❌ Password rule settings template not found.'
        } else {
            $LockoutThresholdSetting = $PasswordRuleSettings.values | Where-Object { $_.name -eq 'LockoutThreshold' }

            if ($null -eq $LockoutThresholdSetting) {
                $Passed = 'Failed'
                $ResultMarkdown = "❌ Lockout threshold setting not found in [password rule settings]($PortalLink)."
            } else {
                $LockoutThreshold = [int]$LockoutThresholdSetting.value

                if ($LockoutThreshold -le 10) {
                    $Passed = 'Passed'
                    $ResultMarkdown = "✅ Smart lockout threshold is set to 10 or below.`n`n"
                } else {
                    $Passed = 'Failed'
                    $ResultMarkdown = "❌ Smart lockout threshold is configured above 10.`n`n"
                }

                $ResultMarkdown += "## [Smart lockout configuration]($PortalLink)`n`n"
                $ResultMarkdown += "| Setting | Value |`n"
                $ResultMarkdown += "| :---- | :---- |`n"
                $ResultMarkdown += "| Lockout threshold | $LockoutThreshold attempts |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Smart lockout threshold set to 10 or less' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Smart lockout threshold set to 10 or less' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Credential management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21850.ps1' 52
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21858.ps1' -1

function Invoke-CippTestZTNA21858 {
    <#
    .SYNOPSIS
    Inactive guest identities are disabled or removed from the tenant
    #>
    param($Tenant)
    #Tested
    try {
        $Guests = Get-CIPPTestData -TenantFilter $Tenant -Type 'Guests'
        if (-not $Guests) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21858' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Inactive guest identities are disabled or removed from the tenant' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'External collaboration'
            return
        }

        $InactivityThresholdDays = 90
        $Today = Get-Date
        $EnabledGuests = $Guests | Where-Object { $_.AccountEnabled -eq $true }

        if (-not $EnabledGuests) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21858' -TestType 'Identity' -Status 'Passed' -ResultMarkdown 'No guest users found in the tenant' -Risk 'Medium' -Name 'Inactive guest identities are disabled or removed from the tenant' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'External collaboration'
            return
        }

        $InactiveGuests = @()
        foreach ($Guest in $EnabledGuests) {
            $DaysSinceLastActivity = $null

            if ($Guest.signInActivity.lastSuccessfulSignInDateTime) {
                $LastSignIn = [DateTime]$Guest.signInActivity.lastSuccessfulSignInDateTime
                $DaysSinceLastActivity = ($Today - $LastSignIn).Days
            } elseif ($Guest.createdDateTime) {
                $Created = [DateTime]$Guest.createdDateTime
                $DaysSinceLastActivity = ($Today - $Created).Days
            }

            if ($null -ne $DaysSinceLastActivity -and $DaysSinceLastActivity -gt $InactivityThresholdDays) {
                $InactiveGuests += $Guest
            }
        }

        if ($InactiveGuests.Count -gt 0) {
            $Status = 'Failed'

            $ResultLines = @(
                "Found $($InactiveGuests.Count) inactive guest user(s) with no sign-in activity in the last $InactivityThresholdDays days."
                ''
                "**Total enabled guests:** $($EnabledGuests.Count)"
                "**Inactive guests:** $($InactiveGuests.Count)"
                "**Inactivity threshold:** $InactivityThresholdDays days"
                ''
                '**Top 10 inactive guest users:**'
            )

            $Top10Guests = $InactiveGuests | Sort-Object {
                if ($_.signInActivity.lastSuccessfulSignInDateTime) {
                    [DateTime]$_.signInActivity.lastSuccessfulSignInDateTime
                } else {
                    [DateTime]$_.createdDateTime
                }
            } | Select-Object -First 10

            foreach ($Guest in $Top10Guests) {
                if ($Guest.signInActivity.lastSuccessfulSignInDateTime) {
                    $LastActivity = [DateTime]$Guest.signInActivity.lastSuccessfulSignInDateTime
                    $DaysInactive = [Math]::Round(($Today - $LastActivity).TotalDays, 0)
                    $ResultLines += "- $($Guest.displayName) ($($Guest.userPrincipalName)) - Last sign-in: $DaysInactive days ago"
                } else {
                    $Created = [DateTime]$Guest.createdDateTime
                    $DaysSinceCreated = [Math]::Round(($Today - $Created).TotalDays, 0)
                    $ResultLines += "- $($Guest.displayName) ($($Guest.userPrincipalName)) - Never signed in (Created $DaysSinceCreated days ago)"
                }
            }

            if ($InactiveGuests.Count -gt 10) {
                $ResultLines += "- ... and $($InactiveGuests.Count - 10) more inactive guest(s)"
            }

            $ResultLines += ''
            $ResultLines += '**Recommendation:** Review and remove or disable inactive guest accounts to reduce security risks.'

            $Result = $ResultLines -join "`n"
        } else {
            $Status = 'Passed'
            $Result = "All enabled guest users have been active within the last $InactivityThresholdDays days"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21858' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Inactive guest identities are disabled or removed from the tenant' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'External collaboration'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21858' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Inactive guest identities are disabled or removed from the tenant' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'External collaboration'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21858.ps1' 94
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21861.ps1' -1

function Invoke-CippTestZTNA21861 {
    <#
    .SYNOPSIS
    All high-risk users are triaged
    #>
    param($Tenant)

    $TestId = 'ZTNA21861'
    #Tested
    try {
        # Get risky users from cache
        $RiskyUsers = Get-CIPPTestData -TenantFilter $Tenant -Type 'RiskyUsers'

        if (-not $RiskyUsers) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'All high-risk users are triaged' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'
            return
        }

        # Filter for untriaged high-risk users (atRisk state with High risk level)
        $UntriagedHighRiskUsers = $RiskyUsers | Where-Object { $_.riskState -eq 'atRisk' -and $_.riskLevel -eq 'high' }

        $Passed = if ($UntriagedHighRiskUsers.Count -eq 0) { 'Passed' } else { 'Failed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = '✅ All high-risk users are properly triaged in Entra ID Protection.'
        } else {
            $ResultMarkdown = "❌ Found **$($UntriagedHighRiskUsers.Count)** untriaged high-risk users in Entra ID Protection.`n`n"
            $ResultMarkdown += "## Untriaged High-Risk Users`n`n"
            $ResultMarkdown += "| User | Risk level | Last updated | Risk detail |`n"
            $ResultMarkdown += "| :--- | :--- | :--- | :--- |`n"

            foreach ($User in $UntriagedHighRiskUsers) {
                $UserPrincipalName = if ($User.userPrincipalName) { $User.userPrincipalName } else { $User.id }
                $RiskLevel = switch ($User.riskLevel) {
                    'high' { '🔴 High' }
                    'medium' { '🟡 Medium' }
                    'low' { '🟢 Low' }
                    default { $User.riskLevel }
                }
                $RiskDate = $User.riskLastUpdatedDateTime
                $RiskDetail = $User.riskDetail

                $PortalLink = "https://entra.microsoft.com/#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/overview/userId/$($User.id)"
                $ResultMarkdown += "| [$UserPrincipalName]($PortalLink) | $RiskLevel | $RiskDate | $RiskDetail |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'All high-risk users are triaged' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'All high-risk users are triaged' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21861.ps1' 56
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21862.ps1' -1

function Invoke-CippTestZTNA21862 {
    <#
    .SYNOPSIS
    All risky workload identities are triaged
    #>
    param($Tenant)

    $TestId = 'ZTNA21862'
    #Tested
    try {
        # Get risky service principals and risk detections from cache
        $UntriagedRiskyPrincipals = Get-CIPPTestData -TenantFilter $Tenant -Type 'RiskyServicePrincipals' | Where-Object { $_.riskState -eq 'atRisk' }
        $ServicePrincipalRiskDetections = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipalRiskDetections'
        $UntriagedRiskDetections = $ServicePrincipalRiskDetections | Where-Object { $_.riskState -eq 'atRisk' }

        if (-not $UntriagedRiskyPrincipals -and -not $ServicePrincipalRiskDetections) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'All risky workload identities are triaged' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'
            return
        }

        $Passed = if (($UntriagedRiskyPrincipals.Count -eq 0) -and ($UntriagedRiskDetections.Count -eq 0)) { 'Passed' } else { 'Failed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = '✅ All risky workload identities have been triaged'
        } else {
            $RiskySPCount = $UntriagedRiskyPrincipals.Count
            $RiskyDetectionCount = $UntriagedRiskDetections.Count
            $ResultMarkdown = "❌ Found $RiskySPCount untriaged risky service principals and $RiskyDetectionCount untriaged risk detections`n`n"

            if ($RiskySPCount -gt 0) {
                $ResultMarkdown += "## Untriaged Risky Service Principals`n`n"
                $ResultMarkdown += "| Service Principal | Type | Risk Level | Risk State | Risk Last Updated |`n"
                $ResultMarkdown += "| :--- | :--- | :--- | :--- | :--- |`n"
                foreach ($SP in $UntriagedRiskyPrincipals) {
                    $PortalLink = "https://entra.microsoft.com/#view/Microsoft_AAD_IAM/ManagedAppMenuBlade/~/SignOn/objectId/$($SP.id)/appId/$($SP.appId)"
                    $RiskLevel = switch ($SP.riskLevel) {
                        'high' { '🔴 High' }
                        'medium' { '🟡 Medium' }
                        'low' { '🟢 Low' }
                        default { $SP.riskLevel }
                    }
                    $RiskState = switch ($SP.riskState) {
                        'atRisk' { '⚠️ At Risk' }
                        'confirmedCompromised' { '🔴 Confirmed Compromised' }
                        'dismissed' { '✅ Dismissed' }
                        'remediated' { '✅ Remediated' }
                        default { $SP.riskState }
                    }
                    $ResultMarkdown += "| [$($SP.displayName)]($PortalLink) | $($SP.servicePrincipalType) | $RiskLevel | $RiskState | $($SP.riskLastUpdatedDateTime) |`n"
                }
            }

            if ($RiskyDetectionCount -gt 0) {
                $ResultMarkdown += "`n`n## Untriaged Risk Detection Events`n`n"
                $ResultMarkdown += "| Service Principal | Risk Level | Risk State | Risk Event Type | Risk Last Updated |`n"
                $ResultMarkdown += "| :--- | :--- | :--- | :--- | :--- |`n"
                foreach ($Detection in $UntriagedRiskDetections) {
                    $PortalLink = "https://entra.microsoft.com/#view/Microsoft_AAD_IAM/ManagedAppMenuBlade/~/SignOn/objectId/$($Detection.servicePrincipalId)/appId/$($Detection.appId)"
                    $RiskLevel = switch ($Detection.riskLevel) {
                        'high' { '🔴 High' }
                        'medium' { '🟡 Medium' }
                        'low' { '🟢 Low' }
                        default { $Detection.riskLevel }
                    }
                    $RiskState = switch ($Detection.riskState) {
                        'atRisk' { '⚠️ At Risk' }
                        'confirmedCompromised' { '🔴 Confirmed Compromised' }
                        'dismissed' { '✅ Dismissed' }
                        'remediated' { '✅ Remediated' }
                        default { $Detection.riskState }
                    }
                    $ResultMarkdown += "| [$($Detection.servicePrincipalDisplayName)]($PortalLink) | $RiskLevel | $RiskState | $($Detection.riskEventType) | $($Detection.detectedDateTime) |`n"
                }
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'All risky workload identities are triaged' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'All risky workload identities are triaged' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21862.ps1' 85
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21863.ps1' -1

function Invoke-CippTestZTNA21863 {
    <#
    .SYNOPSIS
    All high-risk sign-ins are triaged
    #>
    param($Tenant)

    $TestId = 'ZTNA21863'
    #Tested
    try {
        # Get risk detections from cache and filter for high-risk untriaged sign-ins
        $RiskDetections = Get-CIPPTestData -TenantFilter $Tenant -Type 'RiskDetections'

        if (-not $RiskDetections) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'All high-risk sign-ins are triaged' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'
            return
        }

        $UntriagedHighRiskSignIns = $RiskDetections | Where-Object { $_.riskState -eq 'atRisk' -and $_.riskLevel -eq 'high' }

        $Passed = if ($UntriagedHighRiskSignIns.Count -eq 0) { 'Passed' } else { 'Failed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = '✅ No untriaged risky sign ins in the tenant.'
        } else {
            $ResultMarkdown = "❌ Found **$($UntriagedHighRiskSignIns.Count)** untriaged high-risk sign ins.`n`n"
            $ResultMarkdown += "## Untriaged High-Risk Sign ins`n`n"
            $ResultMarkdown += "| Date | User Principal Name | Type | Risk Level |`n"
            $ResultMarkdown += "| :---- | :---- | :---- | :---- |`n"

            foreach ($Risk in $UntriagedHighRiskSignIns) {
                $UserPrincipalName = $Risk.userPrincipalName
                $RiskLevel = switch ($Risk.riskLevel) {
                    'high' { '🔴 High' }
                    'medium' { '🟡 Medium' }
                    'low' { '🟢 Low' }
                    default { $Risk.riskLevel }
                }
                $RiskEventType = $Risk.riskEventType
                $RiskDate = $Risk.detectedDateTime
                $ResultMarkdown += "| $RiskDate | $UserPrincipalName | $RiskEventType | $RiskLevel |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'All high-risk sign-ins are triaged' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'All high-risk sign-ins are triaged' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21863.ps1' 53
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21865.ps1' -1

function Invoke-CippTestZTNA21865 {
    <#
    .SYNOPSIS
    Named locations are configured
    #>
    param($Tenant)

    $TestId = 'ZTNA21865'
    #tested
    try {
        $NamedLocations = Get-CIPPTestData -TenantFilter $Tenant -Type 'NamedLocations'

        if (-not $NamedLocations) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Named locations are configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application management'
            return
        }

        $TrustedLocations = @($NamedLocations | Where-Object { $_.isTrusted -eq $true })
        $Passed = $TrustedLocations.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ Trusted named locations are configured.`n`n"
        } else {
            $ResultMarkdown = "❌ No trusted named locations configured.`n`n"
        }

        $ResultMarkdown += "## Named Locations`n`n"
        $ResultMarkdown += "$($NamedLocations.Count) named locations found.`n`n"

        if ($NamedLocations.Count -gt 0) {
            $ResultMarkdown += "| Name | Type | Trusted |`n"
            $ResultMarkdown += "| :--- | :--- | :------ |`n"

            foreach ($Location in $NamedLocations) {
                $Name = $Location.displayName
                $Type = if ($Location.'@odata.type' -eq '#microsoft.graph.ipNamedLocation') { 'IP-based' }
                elseif ($Location.'@odata.type' -eq '#microsoft.graph.countryNamedLocation') { 'Country-based' }
                else { 'Unknown' }
                $Trusted = if ($Location.isTrusted) { 'Yes' } else { 'No' }
                $ResultMarkdown += "| $Name | $Type | $Trusted |`n"
            }
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Named locations are configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application management'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Named locations are configured' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21865.ps1' 53
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21866.ps1' -1

function Invoke-CippTestZTNA21866 {
    <#
    .SYNOPSIS
    All Microsoft Entra recommendations are addressed
    #>
    param($Tenant)
    #Tested
    $TestId = 'ZTNA21866'

    try {
        # Get directory recommendations from cache
        $Recommendations = Get-CIPPTestData -TenantFilter $Tenant -Type 'DirectoryRecommendations'

        if (-not $Recommendations) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'All Microsoft Entra recommendations are addressed' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Monitoring'
            return
        }

        # Filter for unaddressed recommendations (active or postponed status)
        $UnaddressedRecommendations = $Recommendations | Where-Object { $_.status -in @('active', 'postponed') }

        $Passed = if ($UnaddressedRecommendations.Count -eq 0) { 'Passed' } else { 'Failed' }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = '✅ All Entra Recommendations are addressed.'
        } else {
            $ResultMarkdown = "❌ Found $($UnaddressedRecommendations.Count) unaddressed Entra recommendations.`n`n"
            $ResultMarkdown += "## Unaddressed Entra recommendations`n`n"
            $ResultMarkdown += "| Display Name | Status | Insights | Priority |`n"
            $ResultMarkdown += "| :--- | :--- | :--- | :--- |`n"

            foreach ($Item in $UnaddressedRecommendations) {
                $DisplayName = $Item.displayName
                $Status = $Item.status
                $Insights = $Item.insights
                $Priority = $Item.priority
                $ResultMarkdown += "| $DisplayName | $Status | $Insights | $Priority |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'All Microsoft Entra recommendations are addressed' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'All Microsoft Entra recommendations are addressed' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Monitoring'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21866.ps1' 49
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21868.ps1' -1

function Invoke-CippTestZTNA21868 {
    <#
    .SYNOPSIS
    Guests do not own apps in the tenant
    #>
    param($Tenant)

    try {
        $Guests = Get-CIPPTestData -TenantFilter $Tenant -Type 'Guests'
        $Apps = Get-CIPPTestData -TenantFilter $Tenant -Type 'Apps'
        $ServicePrincipals = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipals'

        if (-not $Guests -or -not $Apps -or -not $ServicePrincipals) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21868' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Guests do not own apps in the tenant' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'External collaboration'
            return
        }

        # Create a HashSet of guest user IDs for fast lookups
        $GuestUserIds = [System.Collections.Generic.HashSet[string]]::new()
        foreach ($guest in $Guests) {
            [void]$GuestUserIds.Add($guest.id)
        }

        # Initialize lists for guest owners
        $GuestAppOwners = [System.Collections.Generic.List[object]]::new()
        $GuestSpOwners = [System.Collections.Generic.List[object]]::new()

        # Check applications for guest owners
        foreach ($app in $Apps) {
            if ($app.owners -and $app.owners.Count -gt 0) {
                foreach ($owner in $app.owners) {
                    if ($GuestUserIds.Contains($owner.id)) {
                        $ownerInfo = [PSCustomObject]@{
                            id                = $owner.id
                            displayName       = $owner.displayName
                            userPrincipalName = $owner.userPrincipalName
                            appDisplayName    = $app.displayName
                            appObjectId       = $app.id
                            appId             = $app.appId
                        }
                        $GuestAppOwners.Add($ownerInfo)
                    }
                }
            }
        }

        # Check service principals for guest owners
        foreach ($sp in $ServicePrincipals) {
            if ($sp.owners -and $sp.owners.Count -gt 0) {
                foreach ($owner in $sp.owners) {
                    if ($GuestUserIds.Contains($owner.id)) {
                        $ownerInfo = [PSCustomObject]@{
                            id                = $owner.id
                            displayName       = $owner.displayName
                            userPrincipalName = $owner.userPrincipalName
                            spDisplayName     = $sp.displayName
                            spObjectId        = $sp.id
                            spAppId           = $sp.appId
                        }
                        $GuestSpOwners.Add($ownerInfo)
                    }
                }
            }
        }

        $HasGuestAppOwners = $GuestAppOwners.Count -gt 0
        $HasGuestSpOwners = $GuestSpOwners.Count -gt 0

        if ($HasGuestAppOwners -or $HasGuestSpOwners) {
            $Status = 'Failed'
            $Result = "Guest users own applications or service principals`n`n"

            if ($HasGuestAppOwners -and $HasGuestSpOwners) {
                $Result += "## Guest users own both applications and service principals`n`n"
                $Result += "### Applications owned by guest users`n`n"
                $Result += "| User Display Name | User Principal Name | Application |`n"
                $Result += "| :---------------- | :------------------ | :---------- |`n"
                $Result += ($GuestAppOwners | ForEach-Object { "| $($_.displayName) | $($_.userPrincipalName) | $($_.appDisplayName) |" }) -join "`n"
                $Result += "`n`n### Service principals owned by guest users`n`n"
                $Result += "| User Display Name | User Principal Name | Service Principal |`n"
                $Result += "| :---------------- | :------------------ | :---------------- |`n"
                $Result += ($GuestSpOwners | ForEach-Object { "| $($_.displayName) | $($_.userPrincipalName) | $($_.spDisplayName) |" }) -join "`n"
            } elseif ($HasGuestAppOwners) {
                $Result += "## Guest users own applications`n`n"
                $Result += "| User Display Name | User Principal Name | Application |`n"
                $Result += "| :---------------- | :------------------ | :---------- |`n"
                $Result += ($GuestAppOwners | ForEach-Object { "| $($_.displayName) | $($_.userPrincipalName) | $($_.appDisplayName) |" }) -join "`n"
            } elseif ($HasGuestSpOwners) {
                $Result += "## Guest users own service principals`n`n"
                $Result += "| User Display Name | User Principal Name | Service Principal |`n"
                $Result += "| :---------------- | :------------------ | :---------------- |`n"
                $Result += ($GuestSpOwners | ForEach-Object { "| $($_.displayName) | $($_.userPrincipalName) | $($_.spDisplayName) |" }) -join "`n"
            }
        } else {
            $Status = 'Passed'
            $Result = 'No guest users own any applications or service principals in the tenant'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21868' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Guests do not own apps in the tenant' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'External collaboration'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21868' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Guests do not own apps in the tenant' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'External collaboration'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21868.ps1' 106
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21869.ps1' -1

function Invoke-CippTestZTNA21869 {
    <#
    .SYNOPSIS
    Enterprise applications must require explicit assignment or scoped provisioning
    #>
    param($Tenant)
    #tenant
    try {
        $ServicePrincipals = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipals'
        if (-not $ServicePrincipals) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21869' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Enterprise applications must require explicit assignment or scoped provisioning' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application management'
            return
        }

        $AppsWithoutAssignment = $ServicePrincipals | Where-Object {
            $_.appRoleAssignmentRequired -eq $false -and
            $null -ne $_.preferredSingleSignOnMode -and
            $_.preferredSingleSignOnMode -in @('password', 'saml', 'oidc') -and
            $_.accountEnabled -eq $true
        }

        if (-not $AppsWithoutAssignment) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21869' -TestType 'Identity' -Status 'Passed' -ResultMarkdown 'All enterprise applications have explicit assignment requirements' -Risk 'Medium' -Name 'Enterprise applications must require explicit assignment or scoped provisioning' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application management'
            return
        }

        $Status = 'Investigate'

        $ResultLines = @(
            "Found $($AppsWithoutAssignment.Count) enterprise application(s) without assignment requirements."
            ''
            '**Applications without user assignment requirements:**'
        )

        $Top10Apps = $AppsWithoutAssignment | Select-Object -First 10
        foreach ($App in $Top10Apps) {
            $ResultLines += "- $($App.displayName) (SSO: $($App.preferredSingleSignOnMode))"
        }

        if ($AppsWithoutAssignment.Count -gt 10) {
            $ResultLines += "- ... and $($AppsWithoutAssignment.Count - 10) more application(s)"
        }

        $ResultLines += ''
        $ResultLines += '**Note:** Full provisioning scope validation requires Graph API synchronization endpoint not available in cache.'
        $ResultLines += ''
        $ResultLines += '**Recommendation:** Enable user assignment requirements or configure scoped provisioning to limit application access.'

        $Result = $ResultLines -join "`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21869' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Enterprise applications must require explicit assignment or scoped provisioning' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21869' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Enterprise applications must require explicit assignment or scoped provisioning' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21869.ps1' 58
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21872.ps1' -1

function Invoke-CippTestZTNA21872 {
    <#
    .SYNOPSIS
    Require multifactor authentication for device join and device registration using user action
    #>
    param($Tenant)

    $TestId = 'ZTNA21872'
    #Tested
    try {
        # Get conditional access policies and device registration policy from cache
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'
        $DeviceRegistrationPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'DeviceRegistrationPolicy'

        if (-not $CAPolicies) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Require multifactor authentication for device join and device registration using user action' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Access control'
            return
        }

        if (-not $DeviceRegistrationPolicy) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Require multifactor authentication for device join and device registration using user action' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Access control'
            return
        }

        $MfaRequiredInDeviceSettings = $DeviceRegistrationPolicy.multiFactorAuthConfiguration -eq 'required'

        # Filter for enabled device registration CA policies
        $DeviceRegistrationPolicies = $CAPolicies | Where-Object {
            ($_.state -eq 'enabled') -and
            ($_.conditions.applications.includeUserActions -eq 'urn:user:registerdevice')
        }

        # Check each policy to see if it properly requires MFA
        $ValidPolicies = [System.Collections.Generic.List[object]]::new()
        foreach ($Policy in $DeviceRegistrationPolicies) {
            $RequiresMfa = $false

            # Check if the policy directly requires MFA
            if ($Policy.grantControls.builtInControls -contains 'mfa') {
                $RequiresMfa = $true
            }

            # Check if the policy uses any authentication strength
            if ($null -ne $Policy.grantControls.authenticationStrength) {
                $RequiresMfa = $true
            }

            # If the policy requires MFA, add it to valid policies
            if ($RequiresMfa) {
                $ValidPolicies.Add($Policy)
            }
        }

        # Determine pass/fail conditions
        if ($MfaRequiredInDeviceSettings) {
            $Passed = 'Failed'
            $ResultMarkdown = "❌ **MFA is configured incorrectly.** Device Settings has 'Require Multi-Factor Authentication to register or join devices' set to Yes. According to best practices, this should be set to No, and MFA should be enforced through Conditional Access policies instead.`n`n"
        } elseif ($DeviceRegistrationPolicies.Count -eq 0) {
            $Passed = 'Failed'
            $ResultMarkdown = "❌ **No Conditional Access policies found** for device registration or device join. Create a policy that requires MFA for these user actions.`n`n"
        } elseif ($ValidPolicies.Count -eq 0) {
            $Passed = 'Failed'
            $ResultMarkdown = "❌ **Conditional Access policies found**, but they're not correctly configured. Policies should require MFA or appropriate authentication strength.`n`n"
        } else {
            $Passed = 'Passed'
            $ResultMarkdown = "✅ **Properly configured Conditional Access policies found** that require MFA for device registration/join actions.`n`n"
        }

        # Add device settings information
        $ResultMarkdown += "## Device Settings Configuration`n`n"
        $ResultMarkdown += "| Setting | Value | Recommended Value | Status |`n"
        $ResultMarkdown += "| :------ | :---- | :---------------- | :----- |`n"

        $DeviceSettingStatus = if ($MfaRequiredInDeviceSettings) { '❌ Should be set to No' } else { '✅ Correctly configured' }
        $DeviceSettingValue = if ($MfaRequiredInDeviceSettings) { 'Yes' } else { 'No' }
        $ResultMarkdown += "| Require Multi-Factor Authentication to register or join devices | $DeviceSettingValue | No | $DeviceSettingStatus |`n"

        # Add policies information if any found
        if ($DeviceRegistrationPolicies.Count -gt 0) {
            $ResultMarkdown += "`n## Device Registration/Join Conditional Access Policies`n`n"
            $ResultMarkdown += "| Policy Name | State | Requires MFA | Status |`n"
            $ResultMarkdown += "| :---------- | :---- | :----------- | :----- |`n"

            foreach ($Policy in $DeviceRegistrationPolicies) {
                $PolicyName = $Policy.displayName
                $PolicyState = $Policy.state
                $PolicyLink = "https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/PolicyBlade/policyId/$($Policy.id)"
                $PolicyNameLink = "[$PolicyName]($PolicyLink)"

                # Check if this policy is properly configured
                $IsValid = $Policy -in $ValidPolicies
                $RequiresMfaText = if ($IsValid) { 'Yes' } else { 'No' }
                $StatusText = if ($IsValid) { '✅ Properly configured' } else { '❌ Incorrectly configured' }

                $ResultMarkdown += "| $PolicyNameLink | $PolicyState | $RequiresMfaText | $StatusText |`n"
            }
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Require multifactor authentication for device join and device registration using user action' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Access control'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Require multifactor authentication for device join and device registration using user action' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Access control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21872.ps1' 107
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21874.ps1' -1

function Invoke-CippTestZTNA21874 {
    <#
    .SYNOPSIS
    Guest access is limited to approved tenants
    #>
    param($Tenant)

    $TestId = 'ZTNA21874'
    #Trusted
    try {
        # Get B2B Management Policy from cache
        $B2BManagementPolicyObject = Get-CIPPTestData -TenantFilter $Tenant -Type 'B2BManagementPolicy'

        if (-not $B2BManagementPolicyObject) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Guest access is limited to approved tenants' -UserImpact 'Medium' -ImplementationEffort 'High' -Category 'External collaboration'
            return
        }

        $Passed = 'Failed'
        $AllowedDomains = $null

        if ($B2BManagementPolicyObject.definition) {
            $B2BManagementPolicy = ($B2BManagementPolicyObject.definition | ConvertFrom-Json).B2BManagementPolicy
            $AllowedDomains = $B2BManagementPolicy.InvitationsAllowedAndBlockedDomainsPolicy.AllowedDomains

            if ($AllowedDomains -and $AllowedDomains.Count -gt 0) {
                $Passed = 'Passed'
            }
        }

        if ($Passed -eq 'Passed') {
            $ResultMarkdown = '✅ Allow/Deny lists of domains to restrict external collaboration are configured.'
        } else {
            $ResultMarkdown = '❌ Allow/Deny lists of domains to restrict external collaboration are not configured.'
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Passed -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Guest access is limited to approved tenants' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'External collaboration'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Guest access is limited to approved tenants' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'External collaboration'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21874.ps1' 45
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21877.ps1' -1

function Invoke-CippTestZTNA21877 {
    <#
    .SYNOPSIS
    All guests have a sponsor
    #>
    param($Tenant)
    #Tested
    try {
        $Guests = Get-CIPPTestData -TenantFilter $Tenant -Type 'Guests'
        if (-not $Guests) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21877' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'All guests have a sponsor' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application management'
            return
        }

        if ($Guests.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21877' -TestType 'Identity' -Status 'Passed' -ResultMarkdown 'No guest accounts found in the tenant' -Risk 'Medium' -Name 'All guests have a sponsor' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application management'
            return
        }

        $GuestsWithoutSponsors = $Guests | Where-Object { -not $_.sponsors -or $_.sponsors.Count -eq 0 }

        if ($GuestsWithoutSponsors.Count -eq 0) {
            $Status = 'Passed'
            $Result = 'All guest accounts in the tenant have an assigned sponsor'
        } else {
            $Status = 'Failed'

            $ResultLines = @(
                "Found $($GuestsWithoutSponsors.Count) guest user(s) without sponsors out of $($Guests.Count) total guests."
                ''
                "**Total guests:** $($Guests.Count)"
                "**Guests without sponsors:** $($GuestsWithoutSponsors.Count)"
                "**Guests with sponsors:** $($Guests.Count - $GuestsWithoutSponsors.Count)"
                ''
                '**Top 10 guests without sponsors:**'
            )

            $Top10Guests = $GuestsWithoutSponsors | Select-Object -First 10
            foreach ($Guest in $Top10Guests) {
                $ResultLines += "- $($Guest.displayName) ($($Guest.userPrincipalName))"
            }

            if ($GuestsWithoutSponsors.Count -gt 10) {
                $ResultLines += "- ... and $($GuestsWithoutSponsors.Count - 10) more guest(s)"
            }

            $ResultLines += ''
            $ResultLines += '**Recommendation:** Assign sponsors to all guest accounts for better accountability and lifecycle management.'

            $Result = $ResultLines -join "`n"
        }

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21877' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'All guests have a sponsor' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21877' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'All guests have a sponsor' -UserImpact 'Medium' -ImplementationEffort 'Medium' -Category 'Application management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21877.ps1' 60
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21883.ps1' -1

function Invoke-CippTestZTNA21883 {
    <#
    .SYNOPSIS
    Checks if workload identities are configured with risk-based policies

    .DESCRIPTION
    Verifies that Conditional Access policies exist that:
    - Block authentication based on service principal risk
    - Are enabled
    - Target service principals

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #tested
    try {
        # Get Conditional Access policies from cache
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $Policies) {
            $TestParams = @{
                TestId               = 'ZTNA21883'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'No Conditional Access policies found in cache.'
                Risk                 = 'Medium'
                Name                 = 'Workload identities configured with risk-based policies'
                UserImpact           = 'High'
                ImplementationEffort = 'Low'
                Category             = 'Access control'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Filter for policies that:
        # - Block authentication
        # - Include service principals
        # - Are enabled
        $MatchedPolicies = [System.Collections.Generic.List[object]]::new()
        foreach ($Policy in $Policies) {
            $blocksAuth = $false
            if ($Policy.grantControls.builtInControls) {
                foreach ($control in $Policy.grantControls.builtInControls) {
                    if ($control -eq 'block') {
                        $blocksAuth = $true
                        break
                    }
                }
            }

            $includesSP = $false
            if ($Policy.conditions.clientApplications.includeServicePrincipals) {
                $includesSP = $true
            }

            $isEnabled = $Policy.state -eq 'enabled'

            if ($blocksAuth -and $includesSP -and $isEnabled) {
                $MatchedPolicies.Add($Policy)
            }
        }

        # Determine pass/fail
        if ($MatchedPolicies.Count -ge 1) {
            $Status = 'Passed'
            $ResultMarkdown = "✅ **Pass**: Workload identities are protected by risk-based Conditional Access policies.`n`n"
            $ResultMarkdown += "## Matching policies`n`n"
            $ResultMarkdown += "| Policy name | State | Service principals | Grant controls |`n"
            $ResultMarkdown += "| :---------- | :---- | :----------------- | :------------- |`n"

            foreach ($Policy in $MatchedPolicies) {
                $policyLink = "https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/PolicyBlade/policyId/$($Policy.id)"
                $policyName = if ($Policy.displayName) { $Policy.displayName } else { 'Unnamed' }
                $spTargets = if ($Policy.conditions.clientApplications.includeServicePrincipals) {
                    ($Policy.conditions.clientApplications.includeServicePrincipals | Select-Object -First 3) -join ', '
                    if ($Policy.conditions.clientApplications.includeServicePrincipals.Count -gt 3) {
                        $spTargets += " (and $($Policy.conditions.clientApplications.includeServicePrincipals.Count - 3) more)"
                    }
                    $spTargets
                } else {
                    'None'
                }
                $grants = if ($Policy.grantControls.builtInControls) {
                    $Policy.grantControls.builtInControls -join ', '
                } else {
                    'None'
                }
                $ResultMarkdown += "| [$policyName]($policyLink) | $($Policy.state) | $spTargets | $grants |`n"
            }
        } else {
            $Status = 'Failed'
            $ResultMarkdown = "❌ **Fail**: No Conditional Access policies found that protect workload identities with risk-based controls.`n`n"
            $ResultMarkdown += 'Workload identities should be protected by policies that block authentication when service principal risk is detected.'
        }

        $TestParams = @{
            TestId               = 'ZTNA21883'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'Medium'
            Name                 = 'Workload identities configured with risk-based policies'
            UserImpact           = 'High'
            ImplementationEffort = 'Low'
            Category             = 'Access control'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA21883'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'Medium'
            Name                 = 'Workload identities configured with risk-based policies'
            UserImpact           = 'High'
            ImplementationEffort = 'Low'
            Category             = 'Access control'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA21883 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21883.ps1' 134
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21886.ps1' -1

function Invoke-CippTestZTNA21886 {
    <#
    .SYNOPSIS
    Applications are configured for automatic user provisioning
    #>
    param($Tenant)
    #Tested
    try {
        $ServicePrincipals = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipals'
        if (-not $ServicePrincipals) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21886' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Applications are configured for automatic user provisioning' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Applications management'
            return
        }

        $AppsWithSSO = $ServicePrincipals | Where-Object {
            $null -ne $_.preferredSingleSignOnMode -and
            $_.preferredSingleSignOnMode -in @('password', 'saml', 'oidc') -and
            $_.accountEnabled -eq $true
        }

        if (-not $AppsWithSSO) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21886' -TestType 'Identity' -Status 'Passed' -ResultMarkdown 'No applications configured for SSO found' -Risk 'Medium' -Name 'Applications are configured for automatic user provisioning' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Applications management'
            return
        }

        $Status = 'Investigate'

        $ResultLines = @(
            "Found $($AppsWithSSO.Count) application(s) configured for SSO."
            ''
            '**Applications with SSO enabled:**'
        )

        $SSOByType = $AppsWithSSO | Group-Object -Property preferredSingleSignOnMode
        foreach ($Group in $SSOByType) {
            $ResultLines += ''
            $ResultLines += "**$($Group.Name.ToUpper()) SSO** ($($Group.Count) app(s)):"
            $Top5 = $Group.Group | Select-Object -First 5
            foreach ($App in $Top5) {
                $ResultLines += "- $($App.displayName)"
            }
            if ($Group.Count -gt 5) {
                $ResultLines += "- ... and $($Group.Count - 5) more"
            }
        }

        $ResultLines += ''
        $ResultLines += '**Note:** Provisioning template and job validation requires Graph API synchronization endpoint not available in cache.'
        $ResultLines += ''
        $ResultLines += '**Recommendation:** Configure automatic user provisioning for applications that support it to ensure consistent access management.'

        $Result = $ResultLines -join "`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21886' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Applications are configured for automatic user provisioning' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Applications management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21886' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Applications are configured for automatic user provisioning' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Applications management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21886.ps1' 61
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21889.ps1' -1

function Invoke-CippTestZTNA21889 {
    <#
    .SYNOPSIS
    Checks if organization has reduced password surface area by enabling multiple passwordless authentication methods

    .DESCRIPTION
    Verifies that both FIDO2 Security Keys and Microsoft Authenticator are enabled with proper configuration
    to reduce reliance on passwords.

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #tested
    try {
        # Get authentication methods policy from cache
        $AuthMethodsPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationMethodsPolicy'

        if (-not $AuthMethodsPolicy) {
            $TestParams = @{
                TestId = 'ZTNA21889'
                TenantFilter = $Tenant
                TestType = 'Identity'
                Status = 'Skipped'
                ResultMarkdown = 'Unable to retrieve authentication methods policy from cache.'
                Risk = 'High'
                Name = 'Reduce the user-visible password surface area'
                UserImpact = 'Medium'
                ImplementationEffort = 'Medium'
                Category = 'Access control'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Extract FIDO2 and Microsoft Authenticator configurations
        $Fido2Config = $null
        $AuthenticatorConfig = $null

        if ($AuthMethodsPolicy.authenticationMethodConfigurations) {
            foreach ($config in $AuthMethodsPolicy.authenticationMethodConfigurations) {
                if ($config.id -eq 'Fido2') {
                    $Fido2Config = $config
                }
                if ($config.id -eq 'MicrosoftAuthenticator') {
                    $AuthenticatorConfig = $config
                }
            }
        }

        # Check FIDO2 configuration
        $Fido2Enabled = $Fido2Config.state -eq 'enabled'
        $Fido2HasTargets = $Fido2Config.includeTargets -and $Fido2Config.includeTargets.Count -gt 0
        $Fido2Valid = $Fido2Enabled -and $Fido2HasTargets

        # Check Microsoft Authenticator configuration
        $AuthEnabled = $AuthenticatorConfig.state -eq 'enabled'
        $AuthHasTargets = $AuthenticatorConfig.includeTargets -and $AuthenticatorConfig.includeTargets.Count -gt 0
        $AuthMode = $null
        if ($AuthenticatorConfig.includeTargets) {
            foreach ($target in $AuthenticatorConfig.includeTargets) {
                if ($target.authenticationMode) {
                    $AuthMode = $target.authenticationMode
                    break
                }
            }
        }

        if ([string]::IsNullOrEmpty($AuthMode)) {
            $AuthMode = 'Not configured'
            $AuthModeValid = $false
        } else {
            $AuthModeValid = ($AuthMode -eq 'any') -or ($AuthMode -eq 'deviceBasedPush')
        }
        $AuthValid = $AuthEnabled -and $AuthHasTargets -and $AuthModeValid

        # Determine pass/fail
        $Status = if ($Fido2Valid -and $AuthValid) { 'Passed' } else { 'Failed' }

        # Build result message
        if ($Status -eq 'Passed') {
            $ResultMarkdown = "✅ **Pass**: Your organization has implemented multiple passwordless authentication methods reducing password exposure.`n`n"
        } else {
            $ResultMarkdown = "❌ **Fail**: Your organization relies heavily on password-based authentication, creating security vulnerabilities.`n`n"
        }

        # Build detailed markdown table
        $ResultMarkdown += "## Passwordless authentication methods`n`n"
        $ResultMarkdown += "| Method | State | Include targets | Authentication mode | Status |`n"
        $ResultMarkdown += "| :----- | :---- | :-------------- | :------------------ | :----- |`n"

        # FIDO2 row
        $Fido2State = if ($Fido2Enabled) { '✅ Enabled' } else { '❌ Disabled' }
        $Fido2TargetsDisplay = if ($Fido2Config.includeTargets -and $Fido2Config.includeTargets.Count -gt 0) {
            "$($Fido2Config.includeTargets.Count) target(s)"
        } else {
            'None'
        }
        $Fido2Status = if ($Fido2Valid) { '✅ Pass' } else { '❌ Fail' }
        $ResultMarkdown += "| FIDO2 Security Keys | $Fido2State | $Fido2TargetsDisplay | N/A | $Fido2Status |`n"

        # Microsoft Authenticator row
        $AuthState = if ($AuthEnabled) { '✅ Enabled' } else { '❌ Disabled' }
        $AuthTargetsDisplay = if ($AuthenticatorConfig.includeTargets -and $AuthenticatorConfig.includeTargets.Count -gt 0) {
            "$($AuthenticatorConfig.includeTargets.Count) target(s)"
        } else {
            'None'
        }
        $AuthModeDisplay = if ($AuthModeValid) { "✅ $AuthMode" } else { "❌ $AuthMode" }
        $AuthStatus = if ($AuthValid) { '✅ Pass' } else { '❌ Fail' }
        $ResultMarkdown += "| Microsoft Authenticator | $AuthState | $AuthTargetsDisplay | $AuthModeDisplay | $AuthStatus |`n"

        $TestParams = @{
            TestId = 'ZTNA21889'
            TenantFilter = $Tenant
            TestType = 'Identity'
            Status = $Status
            ResultMarkdown = $ResultMarkdown
            Risk = 'High'
            Name = 'Reduce the user-visible password surface area'
            UserImpact = 'Medium'
            ImplementationEffort = 'Medium'
            Category = 'Access control'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId = 'ZTNA21889'
            TenantFilter = $Tenant
            TestType = 'Identity'
            Status = 'Failed'
            ResultMarkdown = "❌ **Error**: $($_.Exception.Message)"
            Risk = 'High'
            Name = 'Reduce the user-visible password surface area'
            UserImpact = 'Medium'
            ImplementationEffort = 'Medium'
            Category = 'Access control'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA21889 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21889.ps1' 148
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21892.ps1' -1

function Invoke-CippTestZTNA21892 {
    <#
    .SYNOPSIS
    Verifies that all sign-in activity is restricted to managed devices

    .DESCRIPTION
    Checks for Conditional Access policies that:
    - Apply to all users
    - Apply to all applications
    - Require compliant or hybrid joined devices
    - Are enabled

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #tested
    try {
        # Get Conditional Access policies from cache
        $Policies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $Policies) {
            $TestParams = @{
                TestId               = 'ZTNA21892'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'No Conditional Access policies found in cache.'
                Risk                 = 'High'
                Name                 = 'All sign-in activity comes from managed devices'
                UserImpact           = 'High'
                ImplementationEffort = 'High'
                Category             = 'Access control'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Find policies that require managed devices for all users and apps
        $MatchingPolicies = [System.Collections.Generic.List[object]]::new()
        foreach ($Policy in $Policies) {
            # Check if applies to all users
            $appliesToAllUsers = $false
            if ($Policy.conditions.users.includeUsers) {
                foreach ($user in $Policy.conditions.users.includeUsers) {
                    if ($user -eq 'All') {
                        $appliesToAllUsers = $true
                        break
                    }
                }
            }

            # Check if applies to all apps
            $appliesToAllApps = $false
            if ($Policy.conditions.applications.includeApplications) {
                foreach ($app in $Policy.conditions.applications.includeApplications) {
                    if ($app -eq 'All') {
                        $appliesToAllApps = $true
                        break
                    }
                }
            }

            # Check if requires compliant or hybrid joined device
            $requiresCompliantDevice = $false
            $requiresHybridJoined = $false
            if ($Policy.grantControls.builtInControls) {
                foreach ($control in $Policy.grantControls.builtInControls) {
                    if ($control -eq 'compliantDevice') {
                        $requiresCompliantDevice = $true
                    }
                    if ($control -eq 'domainJoinedDevice') {
                        $requiresHybridJoined = $true
                    }
                }
            }

            $isEnabled = $Policy.state -eq 'enabled'

            # Policy matches if enabled, applies to all users/apps, and requires managed device
            if ($isEnabled -and $appliesToAllUsers -and $appliesToAllApps -and ($requiresCompliantDevice -or $requiresHybridJoined)) {
                $MatchingPolicies.Add([PSCustomObject]@{
                        PolicyId           = $Policy.id
                        PolicyState        = $Policy.state
                        DisplayName        = $Policy.displayName
                        AllUsers           = $appliesToAllUsers
                        AllApps            = $appliesToAllApps
                        CompliantDevice    = $requiresCompliantDevice
                        HybridJoinedDevice = $requiresHybridJoined
                        IsFullyCompliant   = $isEnabled -and $appliesToAllUsers -and $appliesToAllApps -and ($requiresCompliantDevice -or $requiresHybridJoined)
                    })
            }
        }

        # Determine pass/fail
        if ($MatchingPolicies.Count -gt 0) {
            $Status = 'Passed'
            $ResultMarkdown = "✅ **Pass**: Conditional Access policies require managed devices for all sign-in activity.`n`n"
            $ResultMarkdown += "## Matching policies`n`n"
            $ResultMarkdown += "| Policy name | State | All users | All apps | Compliant device | Hybrid joined |`n"
            $ResultMarkdown += "| :---------- | :---- | :-------- | :------- | :--------------- | :------------ |`n"

            foreach ($Policy in $MatchingPolicies) {
                $policyLink = "https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/PolicyBlade/policyId/$($Policy.PolicyId)"
                $policyName = if ($Policy.DisplayName) { $Policy.DisplayName } else { 'Unnamed' }
                $allUsers = if ($Policy.AllUsers) { '✅' } else { '❌' }
                $allApps = if ($Policy.AllApps) { '✅' } else { '❌' }
                $compliant = if ($Policy.CompliantDevice) { '✅' } else { '❌' }
                $hybrid = if ($Policy.HybridJoinedDevice) { '✅' } else { '❌' }

                $ResultMarkdown += "| [$policyName]($policyLink) | $($Policy.PolicyState) | $allUsers | $allApps | $compliant | $hybrid |`n"
            }
        } else {
            $Status = 'Failed'
            $ResultMarkdown = "❌ **Fail**: No Conditional Access policies found that require managed devices for all sign-in activity.`n`n"
            $ResultMarkdown += 'Organizations should enforce that all sign-ins come from managed devices (compliant or hybrid Azure AD joined) to ensure security controls are applied.'
        }

        $TestParams = @{
            TestId               = 'ZTNA21892'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'High'
            Name                 = 'All sign-in activity comes from managed devices'
            UserImpact           = 'High'
            ImplementationEffort = 'High'
            Category             = 'Access control'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA21892'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'High'
            Name                 = 'All sign-in activity comes from managed devices'
            UserImpact           = 'High'
            ImplementationEffort = 'High'
            Category             = 'Access control'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA21892 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21892.ps1' 154
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21896.ps1' -1

function Invoke-CippTestZTNA21896 {
    <#
    .SYNOPSIS
    Service principals do not have certificates or credentials associated with them
    #>
    param($Tenant)
    #tested
    try {
        $ServicePrincipals = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipals'
        if (-not $ServicePrincipals) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21896' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Service principals do not have certificates or credentials associated with them' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application management'
            return
        }

        $MicrosoftOwnerId = 'f8cdef31-a31e-4b4a-93e4-5f571e91255a'
        $SPsWithPassCreds = $ServicePrincipals | Where-Object {
            $_.passwordCredentials -and $_.passwordCredentials.Count -gt 0 -and $_.appOwnerOrganizationId -ne $MicrosoftOwnerId
        }
        $SPsWithKeyCreds = $ServicePrincipals | Where-Object {
            $_.keyCredentials -and $_.keyCredentials.Count -gt 0 -and $_.appOwnerOrganizationId -ne $MicrosoftOwnerId
        }

        if (-not $SPsWithPassCreds -and -not $SPsWithKeyCreds) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21896' -TestType 'Identity' -Status 'Passed' -ResultMarkdown 'Service principals do not have credentials associated with them' -Risk 'Medium' -Name 'Service principals do not have certificates or credentials associated with them' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application management'
            return
        }

        $TotalWithCreds = $SPsWithPassCreds.Count + $SPsWithKeyCreds.Count
        $Status = 'Investigate'

        $ResultLines = @(
            "Found $TotalWithCreds service principal(s) with credentials configured in the tenant, which represents a security risk."
            ''
        )

        if ($SPsWithPassCreds.Count -gt 0) {
            $ResultLines += "**Service principals with password credentials:** $($SPsWithPassCreds.Count)"
            $ResultLines += ''
        }

        if ($SPsWithKeyCreds.Count -gt 0) {
            $ResultLines += "**Service principals with key credentials (certificates):** $($SPsWithKeyCreds.Count)"
            $ResultLines += ''
        }

        $ResultLines += '**Security implications:**'
        $ResultLines += '- Service principals with credentials can be compromised if not properly secured'
        $ResultLines += '- Password credentials are less secure than managed identities or certificate-based authentication'
        $ResultLines += '- Consider using managed identities where possible to eliminate credential management'

        $Result = $ResultLines -join "`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21896' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'Medium' -Name 'Service principals do not have certificates or credentials associated with them' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21896' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Service principals do not have certificates or credentials associated with them' -UserImpact 'Low' -ImplementationEffort 'Medium' -Category 'Application management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21896.ps1' 60
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21941.ps1' -1

function Invoke-CippTestZTNA21941 {
    <#
    .SYNOPSIS
    Checks if token protection policies are enforced for Windows platform

    .DESCRIPTION
    Verifies that Conditional Access policies with token protection (secureSignInSession) are
    configured for Windows devices, requiring Office 365 and Microsoft Graph access through
    protected sessions to prevent token theft.

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    try {
        # Get CA policies from cache
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $CAPolicies) {
            $TestParams = @{
                TestId               = 'ZTNA21941'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'Unable to retrieve Conditional Access policies from cache.'
                Risk                 = 'High'
                Name                 = 'Implement token protection policies'
                UserImpact           = 'Medium'
                ImplementationEffort = 'Medium'
                Category             = 'Access control'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Required Office 365 and Graph app IDs
        $RequiredAppIds = @(
            '00000002-0000-0ff1-ce00-000000000000',  # Office 365 Exchange Online
            '00000003-0000-0ff1-ce00-000000000000'   # Microsoft Graph
        )

        # Filter for policies with Windows platform and secureSignInSession control
        $TokenProtectionPolicies = [System.Collections.Generic.List[object]]::new()

        foreach ($policy in $CAPolicies) {
            # Check if policy has Windows platform
            $hasWindows = $false
            if ($policy.conditions.platforms.includePlatforms) {
                if ($policy.conditions.platforms.includePlatforms -contains 'windows' -or
                    $policy.conditions.platforms.includePlatforms -contains 'all') {
                    $hasWindows = $true
                }
            }

            # Check if policy has secureSignInSession control
            $hasTokenProtection = $false
            if ($policy.sessionControls -and $policy.sessionControls.signInFrequency) {
                if ($policy.sessionControls.signInFrequency.isEnabled -eq $true -and
                    $policy.sessionControls.signInFrequency.authenticationType -eq 'primaryAndSecondaryAuthentication') {
                    $hasTokenProtection = $true
                }
            }

            # Alternative check for newer API format
            if (-not $hasTokenProtection -and $policy.sessionControls) {
                foreach ($prop in $policy.sessionControls.PSObject.Properties) {
                    if ($prop.Name -like '*secureSignIn*' -or $prop.Name -like '*tokenProtection*') {
                        if ($prop.Value.isEnabled -eq $true) {
                            $hasTokenProtection = $true
                            break
                        }
                    }
                }
            }

            if ($hasWindows -and $hasTokenProtection -and $policy.state -eq 'enabled') {
                # Check if policy includes users
                $hasUsers = $false
                if ($policy.conditions.users.includeUsers -and $policy.conditions.users.includeUsers.Count -gt 0) {
                    $hasUsers = $true
                }

                # Check if policy includes required apps
                $hasRequiredApps = $false
                if ($policy.conditions.applications.includeApplications) {
                    $includeAll = $policy.conditions.applications.includeApplications -contains 'All'
                    if ($includeAll) {
                        $hasRequiredApps = $true
                    } else {
                        $foundApps = 0
                        foreach ($appId in $RequiredAppIds) {
                            if ($policy.conditions.applications.includeApplications -contains $appId) {
                                $foundApps++
                            }
                        }
                        if ($foundApps -eq $RequiredAppIds.Count) {
                            $hasRequiredApps = $true
                        }
                    }
                }

                $policyStatus = 'Unknown'
                if ($hasUsers -and $hasRequiredApps) {
                    $policyStatus = 'Pass'
                } elseif (-not $hasUsers) {
                    $policyStatus = 'No users targeted'
                } elseif (-not $hasRequiredApps) {
                    $policyStatus = 'Missing required apps'
                }

                $TokenProtectionPolicies.Add([PSCustomObject]@{
                        Name            = $policy.displayName
                        State           = $policy.state
                        HasUsers        = $hasUsers
                        HasRequiredApps = $hasRequiredApps
                        Status          = $policyStatus
                    })
            }
        }

        # Determine overall status
        $PassingPolicies = $TokenProtectionPolicies | Where-Object { $_.Status -eq 'Pass' }
        $Status = if ($PassingPolicies.Count -gt 0) { 'Passed' } else { 'Failed' }

        # Build result markdown
        if ($Status -eq 'Passed') {
            $ResultMarkdown = "✅ **Pass**: Token protection policies are properly configured for Windows devices.`n`n"
            $ResultMarkdown += "Token protection binds authentication tokens to devices, making stolen tokens unusable on other devices.`n`n"
        } else {
            if ($TokenProtectionPolicies.Count -eq 0) {
                $ResultMarkdown = "❌ **Fail**: No token protection policies found for Windows devices.`n`n"
                $ResultMarkdown += "Without token protection, authentication tokens can be stolen and replayed from other devices.`n`n"
                $ResultMarkdown += '[Create token protection policies](https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/ConditionalAccessBlade/~/Policies)'
            } else {
                $ResultMarkdown = "❌ **Fail**: Token protection policies exist but are not properly configured.`n`n"
                $ResultMarkdown += "Policies must target users and include both Office 365 and Microsoft Graph applications.`n`n"
            }
        }

        if ($TokenProtectionPolicies.Count -gt 0) {
            $ResultMarkdown += "## Token protection policies`n`n"
            $ResultMarkdown += "| Policy Name | State | Has Users | Has Required Apps | Status |`n"
            $ResultMarkdown += "| :---------- | :---- | :-------- | :---------------- | :----- |`n"

            foreach ($policy in $TokenProtectionPolicies) {
                $stateIcon = if ($policy.State -eq 'enabled') { '✅' } else { '❌' }
                $usersIcon = if ($policy.HasUsers) { '✅' } else { '❌' }
                $appsIcon = if ($policy.HasRequiredApps) { '✅' } else { '❌' }
                $statusIcon = if ($policy.Status -eq 'Pass') { '✅' } else { '❌' }

                $ResultMarkdown += "| $($policy.Name) | $stateIcon $($policy.State) | $usersIcon | $appsIcon | $statusIcon $($policy.Status) |`n"
            }

            $ResultMarkdown += "`n[Review policies](https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/ConditionalAccessBlade/~/Policies)"
        }

        $TestParams = @{
            TestId               = 'ZTNA21941'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'High'
            Name                 = 'Implement token protection policies'
            UserImpact           = 'Medium'
            ImplementationEffort = 'Medium'
            Category             = 'Access control'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA21941'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'High'
            Name                 = 'Implement token protection policies'
            UserImpact           = 'Medium'
            ImplementationEffort = 'Medium'
            Category             = 'Access control'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA21941 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21941.ps1' 193
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21953.ps1' -1

function Invoke-CippTestZTNA21953 {
    <#
    .SYNOPSIS
    Checks if Windows Local Administrator Password Solution (LAPS) is deployed in the tenant

    .DESCRIPTION
    Verifies that LAPS is enabled in the device registration policy to automatically manage
    and rotate local administrator passwords on Windows devices.

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested

    try {
        # Get device registration policy from cache
        $DeviceRegPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'DeviceRegistrationPolicy'

        if (-not $DeviceRegPolicy) {
            $TestParams = @{
                TestId               = 'ZTNA21953'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'Unable to retrieve device registration policy from cache.'
                Risk                 = 'High'
                Name                 = 'Deploy Windows Local Administrator Password Solution (LAPS)'
                UserImpact           = 'Low'
                ImplementationEffort = 'Low'
                Category             = 'Device security'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Check if LAPS is enabled
        $LapsEnabled = $DeviceRegPolicy.localAdminPassword.isEnabled -eq $true

        $Status = if ($LapsEnabled) { 'Passed' } else { 'Failed' }

        if ($Status -eq 'Passed') {
            $ResultMarkdown = "✅ **Pass**: LAPS is deployed. Your organization can automatically manage and rotate local administrator passwords on all Entra joined and hybrid Entra joined Windows devices.`n`n"
            $ResultMarkdown += '[Learn more](https://entra.microsoft.com/#view/Microsoft_AAD_Devices/DevicesMenuBlade/~/DeviceSettings/menuId/)'
        } else {
            $ResultMarkdown = "❌ **Fail**: LAPS is not deployed. Local administrator passwords may be weak, shared, or unchanged, increasing security risk.`n`n"
            $ResultMarkdown += '[Deploy LAPS](https://entra.microsoft.com/#view/Microsoft_AAD_Devices/DevicesMenuBlade/~/DeviceSettings/menuId/)'
        }

        $TestParams = @{
            TestId               = 'ZTNA21953'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'High'
            Name                 = 'Deploy Windows Local Administrator Password Solution (LAPS)'
            UserImpact           = 'Low'
            ImplementationEffort = 'Low'
            Category             = 'Device security'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA21953'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'High'
            Name                 = 'Deploy Windows Local Administrator Password Solution (LAPS)'
            UserImpact           = 'Low'
            ImplementationEffort = 'Low'
            Category             = 'Device security'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA21953 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21953.ps1' 85
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21954.ps1' -1

function Invoke-CippTestZTNA21954 {
    <#
    .SYNOPSIS
    Checks if non-admin users are restricted from reading BitLocker recovery keys

    .DESCRIPTION
    Verifies that the authorization policy restricts non-admin users from reading BitLocker
    recovery keys for their own devices, reducing the risk of unauthorized key access.

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    try {
        # Get authorization policy from cache
        $AuthPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthorizationPolicy'

        if (-not $AuthPolicy) {
            $TestParams = @{
                TestId               = 'ZTNA21954'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'Unable to retrieve authorization policy from cache.'
                Risk                 = 'Low'
                Name                 = 'Restrict non-admin users from reading BitLocker recovery keys'
                UserImpact           = 'Low'
                ImplementationEffort = 'Low'
                Category             = 'Device security'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Check if BitLocker key reading is restricted (should be false)
        $IsRestricted = $AuthPolicy.defaultUserRolePermissions.allowedToReadBitlockerKeysForOwnedDevice -eq $false

        $Status = if ($IsRestricted) { 'Passed' } else { 'Failed' }

        if ($Status -eq 'Passed') {
            $ResultMarkdown = "✅ **Pass**: Non-admin users cannot read BitLocker recovery keys, reducing the risk of unauthorized access.`n`n"
            $ResultMarkdown += '[Review settings](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/PoliciesTemplateBlade)'
        } else {
            $ResultMarkdown = "❌ **Fail**: Non-admin users can read BitLocker recovery keys for their own devices, which may allow unauthorized access.`n`n"
            $ResultMarkdown += '[Restrict access](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/PoliciesTemplateBlade)'
        }

        $TestParams = @{
            TestId               = 'ZTNA21954'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'Low'
            Name                 = 'Restrict non-admin users from reading BitLocker recovery keys'
            UserImpact           = 'Low'
            ImplementationEffort = 'Low'
            Category             = 'Device security'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA21954'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'Low'
            Name                 = 'Restrict non-admin users from reading BitLocker recovery keys'
            UserImpact           = 'Low'
            ImplementationEffort = 'Low'
            Category             = 'Device security'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA21954 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21954.ps1' 84
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21955.ps1' -1

function Invoke-CippTestZTNA21955 {
    <#
    .SYNOPSIS
    Checks if local administrator management is properly configured on Entra joined devices

    .DESCRIPTION
    Verifies that Global Administrators are automatically added as local administrators on
    Entra joined devices to enable emergency access and device management.

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    try {
        # Get device registration policy from cache
        $DeviceRegPolicy = Get-CIPPTestData -TenantFilter $Tenant -Type 'DeviceRegistrationPolicy'

        if (-not $DeviceRegPolicy) {
            $TestParams = @{
                TestId               = 'ZTNA21955'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'Unable to retrieve device registration policy from cache.'
                Risk                 = 'Medium'
                Name                 = 'Manage local admins on Entra joined devices'
                UserImpact           = 'Low'
                ImplementationEffort = 'Low'
                Category             = 'Device security'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Check if global admins are added as local admins
        $GlobalAdminsEnabled = $DeviceRegPolicy.azureADJoin.localAdmins.enableGlobalAdmins -eq $true

        $Status = if ($GlobalAdminsEnabled) { 'Passed' } else { 'Failed' }

        if ($Status -eq 'Passed') {
            $ResultMarkdown = "✅ **Pass**: Global Administrators are automatically added as local administrators on Entra joined devices.`n`n"
            $ResultMarkdown += '[Review settings](https://entra.microsoft.com/#view/Microsoft_AAD_Devices/DevicesMenuBlade/~/DeviceSettings/menuId/)'
        } else {
            $ResultMarkdown = "❌ **Fail**: Global Administrators are not automatically added as local administrators, which may limit emergency access capabilities.`n`n"
            $ResultMarkdown += '[Configure settings](https://entra.microsoft.com/#view/Microsoft_AAD_Devices/DevicesMenuBlade/~/DeviceSettings/menuId/)'
        }

        $TestParams = @{
            TestId               = 'ZTNA21955'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'Medium'
            Name                 = 'Manage local admins on Entra joined devices'
            UserImpact           = 'Low'
            ImplementationEffort = 'Low'
            Category             = 'Device security'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA21955'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'Medium'
            Name                 = 'Manage local admins on Entra joined devices'
            UserImpact           = 'Low'
            ImplementationEffort = 'Low'
            Category             = 'Device security'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA21955 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21955.ps1' 84
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21964.ps1' -1

function Invoke-CippTestZTNA21964 {
    <#
    .SYNOPSIS
    Enable protected actions to secure Conditional Access policy creation and changes
    #>
    param($Tenant)

    $TestId = 'ZTNA21964'
    #Tested
    try {
        $AuthStrengths = Get-CIPPTestData -TenantFilter $Tenant -Type 'AuthenticationStrengths'

        if (-not $AuthStrengths) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Enable protected actions to secure Conditional Access policy creation and changes' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access control'
            return
        }

        $BuiltInStrengths = @($AuthStrengths | Where-Object { $_.policyType -eq 'builtIn' })
        $CustomStrengths = @($AuthStrengths | Where-Object { $_.policyType -eq 'custom' })

        $ResultMarkdown = "## Authentication Strength Policies`n`n"
        $ResultMarkdown += "Found $($AuthStrengths.Count) authentication strength policies ($($BuiltInStrengths.Count) built-in, $($CustomStrengths.Count) custom).`n`n"

        if ($CustomStrengths.Count -gt 0) {
            $ResultMarkdown += "### Custom Authentication Strengths`n`n"
            $ResultMarkdown += "| Name | Combinations |`n"
            $ResultMarkdown += "| :--- | :---------- |`n"
            foreach ($strength in $CustomStrengths) {
                $combinations = if ($strength.allowedCombinations) { $strength.allowedCombinations.Count } else { 0 }
                $ResultMarkdown += "| $($strength.displayName) | $combinations methods |`n"
            }
        }

        $Status = 'Passed'
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'High' -Name 'Enable protected actions to secure Conditional Access policy creation and changes' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access control'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Enable protected actions to secure Conditional Access policy creation and changes' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Access control'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21964.ps1' 43
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21992.ps1' -1

function Invoke-CippTestZTNA21992 {
    <#
    .SYNOPSIS
    Application certificates must be rotated on a regular basis
    #>
    param($Tenant)

    try {
        $Apps = Get-CIPPTestData -TenantFilter $Tenant -Type 'Apps'
        $ServicePrincipals = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipals'
        #Tested
        if (-not $Apps -and -not $ServicePrincipals) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21992' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Application certificates must be rotated on a regular basis' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application management'
            return
        }

        $RotationThresholdDays = 180
        $ThresholdDate = (Get-Date).AddDays(-$RotationThresholdDays)

        $OldAppCerts = @()
        if ($Apps) {
            $OldAppCerts = $Apps | Where-Object {
                $_.keyCredentials -and $_.keyCredentials.Count -gt 0
            } | ForEach-Object {
                $App = $_
                $OldestCert = $App.keyCredentials | Where-Object { $_.startDateTime } | ForEach-Object {
                    [DateTime]$_.startDateTime
                } | Sort-Object | Select-Object -First 1

                if ($OldestCert -and $OldestCert -lt $ThresholdDate) {
                    [PSCustomObject]@{
                        Type           = 'Application'
                        DisplayName    = $App.displayName
                        AppId          = $App.appId
                        Id             = $App.id
                        OldestCertDate = $OldestCert
                    }
                }
            }
        }

        $OldSPCerts = @()
        if ($ServicePrincipals) {
            $OldSPCerts = $ServicePrincipals | Where-Object {
                $_.keyCredentials -and $_.keyCredentials.Count -gt 0
            } | ForEach-Object {
                $SP = $_
                $OldestCert = $SP.keyCredentials | Where-Object { $_.startDateTime } | ForEach-Object {
                    [DateTime]$_.startDateTime
                } | Sort-Object | Select-Object -First 1

                if ($OldestCert -and $OldestCert -lt $ThresholdDate) {
                    [PSCustomObject]@{
                        Type           = 'ServicePrincipal'
                        DisplayName    = $SP.displayName
                        AppId          = $SP.appId
                        Id             = $SP.id
                        OldestCertDate = $OldestCert
                    }
                }
            }
        }

        if ($OldAppCerts.Count -eq 0 -and $OldSPCerts.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21992' -TestType 'Identity' -Status 'Passed' -ResultMarkdown "Certificates for applications in your tenant have been issued within $RotationThresholdDays days" -Risk 'High' -Name 'Application certificates must be rotated on a regular basis' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application management'
            return
        }

        $Status = 'Failed'

        $ResultLines = @(
            "Found $($OldAppCerts.Count) application(s) and $($OldSPCerts.Count) service principal(s) with certificates not rotated within $RotationThresholdDays days."
            ''
            "**Certificate rotation threshold:** $RotationThresholdDays days"
            ''
        )

        if ($OldAppCerts.Count -gt 0) {
            $ResultLines += '**Applications with old certificates:**'
            $Top10Apps = $OldAppCerts | Select-Object -First 10
            foreach ($App in $Top10Apps) {
                $DaysOld = [Math]::Round(((Get-Date) - $App.OldestCertDate).TotalDays, 0)
                $ResultLines += "- $($App.DisplayName) (Certificate age: $DaysOld days)"
            }
            if ($OldAppCerts.Count -gt 10) {
                $ResultLines += "- ... and $($OldAppCerts.Count - 10) more application(s)"
            }
            $ResultLines += ''
        }

        if ($OldSPCerts.Count -gt 0) {
            $ResultLines += '**Service principals with old certificates:**'
            $Top10SPs = $OldSPCerts | Select-Object -First 10
            foreach ($SP in $Top10SPs) {
                $DaysOld = [Math]::Round(((Get-Date) - $SP.OldestCertDate).TotalDays, 0)
                $ResultLines += "- $($SP.DisplayName) (Certificate age: $DaysOld days)"
            }
            if ($OldSPCerts.Count -gt 10) {
                $ResultLines += "- ... and $($OldSPCerts.Count - 10) more service principal(s)"
            }
            $ResultLines += ''
        }

        $ResultLines += '**Recommendation:** Rotate certificates regularly to reduce the risk of credential compromise.'

        $Result = $ResultLines -join "`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21992' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Application certificates must be rotated on a regular basis' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA21992' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Application certificates must be rotated on a regular basis' -UserImpact 'Low' -ImplementationEffort 'High' -Category 'Application management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA21992.ps1' 115
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA22124.ps1' -1

function Invoke-CippTestZTNA22124 {
    <#
    .SYNOPSIS
    Checks if all high priority Entra recommendations have been addressed

    .DESCRIPTION
    Verifies that there are no active or postponed high priority recommendations in the tenant,
    ensuring critical security improvements have been implemented.

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    try {
        # Get directory recommendations from cache
        $Recommendations = Get-CIPPTestData -TenantFilter $Tenant -Type 'DirectoryRecommendations'

        if (-not $Recommendations) {
            $TestParams = @{
                TestId               = 'ZTNA22124'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'Unable to retrieve directory recommendations from cache.'
                Risk                 = 'High'
                Name                 = 'Address high priority Entra recommendations'
                UserImpact           = 'Medium'
                ImplementationEffort = 'Medium'
                Category             = 'Governance'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Filter for high priority recommendations that are active or postponed
        $HighPriorityIssues = [System.Collections.Generic.List[object]]::new()
        foreach ($rec in $Recommendations) {
            if ($rec.priority -eq 'high' -and ($rec.status -eq 'active' -or $rec.status -eq 'postponed')) {
                $HighPriorityIssues.Add($rec)
            }
        }

        $Status = if ($HighPriorityIssues.Count -eq 0) { 'Passed' } else { 'Failed' }

        if ($Status -eq 'Passed') {
            $ResultMarkdown = "✅ **Pass**: All high priority Entra recommendations have been addressed.`n`n"
            $ResultMarkdown += '[View recommendations](https://entra.microsoft.com/#view/Microsoft_Azure_SecureScore/OverviewBlade)'
        } else {
            $ResultMarkdown = "❌ **Fail**: There are $($HighPriorityIssues.Count) high priority recommendation(s) that have not been addressed.`n`n"
            $ResultMarkdown += "## Outstanding high priority recommendations`n`n"
            $ResultMarkdown += "| Display Name | Status | Insights |`n"
            $ResultMarkdown += "| :----------- | :----- | :------- |`n"

            foreach ($issue in $HighPriorityIssues) {
                $displayName = if ($issue.displayName) { $issue.displayName } else { 'N/A' }
                $status = if ($issue.status) { $issue.status } else { 'N/A' }
                $insights = if ($issue.insights) { $issue.insights } else { 'N/A' }
                $ResultMarkdown += "| $displayName | $status | $insights |`n"
            }

            $ResultMarkdown += "`n[Address recommendations](https://entra.microsoft.com/#view/Microsoft_Azure_SecureScore/OverviewBlade)"
        }

        $TestParams = @{
            TestId               = 'ZTNA22124'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'High'
            Name                 = 'Address high priority Entra recommendations'
            UserImpact           = 'Medium'
            ImplementationEffort = 'Medium'
            Category             = 'Governance'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA22124'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'High'
            Name                 = 'Address high priority Entra recommendations'
            UserImpact           = 'Medium'
            ImplementationEffort = 'Medium'
            Category             = 'Governance'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA22124 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA22124.ps1' 100
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA22128.ps1' -1

function Invoke-CippTestZTNA22128 {
    <#
    .SYNOPSIS
    Guests are not assigned high privileged directory roles
    #>
    param($Tenant)
    #Tested
    try {
        $Roles = Get-CIPPTestData -TenantFilter $Tenant -Type 'Roles'
        $Guests = Get-CIPPTestData -TenantFilter $Tenant -Type 'Guests'

        if (-not $Roles -or -not $Guests) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA22128' -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'High' -Name 'Guests are not assigned high privileged directory roles' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application management'
            return
        }

        if ($Guests.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA22128' -TestType 'Identity' -Status 'Passed' -ResultMarkdown 'No guest users found in tenant' -Risk 'High' -Name 'Guests are not assigned high privileged directory roles' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application management'
            return
        }

        $GuestIds = $Guests | ForEach-Object { $_.id }
        $GuestIdHash = @{}
        foreach ($Guest in $Guests) {
            $GuestIdHash[$Guest.id] = $Guest
        }

        $PrivilegedRoleTemplateIds = @(
            '62e90394-69f5-4237-9190-012177145e10'
            '194ae4cb-b126-40b2-bd5b-6091b380977d'
            'f28a1f50-f6e7-4571-818b-6a12f2af6b6c'
            '29232cdf-9323-42fd-ade2-1d097af3e4de'
            'b1be1c3e-b65d-4f19-8427-f6fa0d97feb9'
            '729827e3-9c14-49f7-bb1b-9608f156bbb8'
            'b0f54661-2d74-4c50-afa3-1ec803f12efe'
            'fe930be7-5e62-47db-91af-98c3a49a38b1'
        )

        $GuestsInPrivilegedRoles = @()
        foreach ($Role in $Roles) {
            if ($Role.roleTemplateId -in $PrivilegedRoleTemplateIds -and $Role.members) {
                foreach ($Member in $Role.members) {
                    if ($GuestIdHash.ContainsKey($Member.id)) {
                        $GuestsInPrivilegedRoles += [PSCustomObject]@{
                            RoleName               = $Role.displayName
                            GuestId                = $Member.id
                            GuestDisplayName       = $Member.displayName
                            GuestUserPrincipalName = $Member.userPrincipalName
                        }
                    }
                }
            }
        }

        if ($GuestsInPrivilegedRoles.Count -eq 0) {
            Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA22128' -TestType 'Identity' -Status 'Passed' -ResultMarkdown 'Guests with privileged roles were not found. All users with privileged roles are members of the tenant' -Risk 'High' -Name 'Guests are not assigned high privileged directory roles' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application management'
            return
        }

        $Status = 'Failed'

        $ResultLines = @(
            "Found $($GuestsInPrivilegedRoles.Count) guest user(s) with privileged role assignments."
            ''
            "**Total guests in tenant:** $($Guests.Count)"
            "**Guests with privileged roles:** $($GuestsInPrivilegedRoles.Count)"
            ''
            '**Guest users in privileged roles:**'
        )

        $RoleGroups = $GuestsInPrivilegedRoles | Group-Object -Property RoleName
        foreach ($RoleGroup in $RoleGroups) {
            $ResultLines += ''
            $ResultLines += "**$($RoleGroup.Name)** ($($RoleGroup.Count) guest(s)):"
            foreach ($Guest in $RoleGroup.Group) {
                $ResultLines += "- $($Guest.GuestDisplayName) ($($Guest.GuestUserPrincipalName))"
            }
        }

        $ResultLines += ''
        $ResultLines += '**Security concern:** Guest users should not have privileged directory roles. Consider using separate admin accounts for external administrators or removing privileged access.'

        $Result = $ResultLines -join "`n"

        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA22128' -TestType 'Identity' -Status $Status -ResultMarkdown $Result -Risk 'High' -Name 'Guests are not assigned high privileged directory roles' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application management'
    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId 'ZTNA22128' -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Test failed: $($ErrorMessage.NormalizedError)" -Risk 'High' -Name 'Guests are not assigned high privileged directory roles' -UserImpact 'Low' -ImplementationEffort 'Low' -Category 'Application management'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA22128.ps1' 92
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA22659.ps1' -1

function Invoke-CippTestZTNA22659 {
    <#
    .SYNOPSIS
    Checks if risky workload identity sign-ins have been triaged

    .DESCRIPTION
    Verifies that there are no active risky sign-in detections for service principals,
    ensuring that compromised workload identities are properly investigated and remediated.

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    try {
        # Get service principal risk detections from cache
        $RiskDetections = Get-CIPPTestData -TenantFilter $Tenant -Type 'ServicePrincipalRiskDetections'

        if (-not $RiskDetections) {
            $TestParams = @{
                TestId               = 'ZTNA22659'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'Unable to retrieve service principal risk detections from cache.'
                Risk                 = 'High'
                Name                 = 'Triage risky workload identity sign-ins'
                UserImpact           = 'High'
                ImplementationEffort = 'Low'
                Category             = 'Identity protection'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Filter for sign-in detections that are at risk
        $RiskySignIns = [System.Collections.Generic.List[object]]::new()
        foreach ($detection in $RiskDetections) {
            if ($detection.activity -eq 'signIn' -and $detection.riskState -eq 'atRisk') {
                $RiskySignIns.Add($detection)
            }
        }

        $Status = if ($RiskySignIns.Count -eq 0) { 'Passed' } else { 'Failed' }

        if ($Status -eq 'Passed') {
            $ResultMarkdown = "✅ **Pass**: No risky workload identity sign-ins detected or all have been triaged.`n`n"
            $ResultMarkdown += '[View identity protection](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/IdentityProtectionMenuBlade/~/RiskyServicePrincipals)'
        } else {
            $ResultMarkdown = "❌ **Fail**: There are $($RiskySignIns.Count) risky workload identity sign-in(s) that require investigation.`n`n"
            $ResultMarkdown += "## Risky service principal sign-ins`n`n"
            $ResultMarkdown += "| Service Principal | App ID | Risk State | Risk Level | Last Updated |`n"
            $ResultMarkdown += "| :---------------- | :----- | :--------- | :--------- | :----------- |`n"

            foreach ($signin in $RiskySignIns) {
                $spName = if ($signin.servicePrincipalDisplayName) { $signin.servicePrincipalDisplayName } else { 'N/A' }
                $appId = if ($signin.appId) { $signin.appId } else { 'N/A' }
                $riskState = if ($signin.riskState) { $signin.riskState } else { 'N/A' }
                $riskLevel = if ($signin.riskLevel) { $signin.riskLevel } else { 'N/A' }

                # Format last updated date
                $lastUpdated = 'N/A'
                if ($signin.lastUpdatedDateTime) {
                    try {
                        $date = [DateTime]::Parse($signin.lastUpdatedDateTime)
                        $lastUpdated = $date.ToString('yyyy-MM-dd HH:mm')
                    } catch {
                        $lastUpdated = $signin.lastUpdatedDateTime
                    }
                }

                $ResultMarkdown += "| $spName | $appId | $riskState | $riskLevel | $lastUpdated |`n"
            }

            $ResultMarkdown += "`n[Investigate and remediate](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/IdentityProtectionMenuBlade/~/RiskyServicePrincipals)"
        }

        $TestParams = @{
            TestId               = 'ZTNA22659'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'High'
            Name                 = 'Triage risky workload identity sign-ins'
            UserImpact           = 'High'
            ImplementationEffort = 'Low'
            Category             = 'Identity protection'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA22659'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'High'
            Name                 = 'Triage risky workload identity sign-ins'
            UserImpact           = 'High'
            ImplementationEffort = 'Low'
            Category             = 'Identity protection'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA22659 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA22659.ps1' 113
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA24570.ps1' -1

function Invoke-CippTestZTNA24570 {
    <#
    .SYNOPSIS
    Checks if Entra Connect uses a service principal instead of a user account

    .DESCRIPTION
    Verifies that if hybrid identity synchronization is enabled (Entra Connect), the
    Directory Synchronization Accounts role contains only service principals and not user accounts,
    reducing the risk of credential theft.

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    try {
        # Get organization info to check if hybrid identity is enabled
        $OrgInfo = Get-CIPPTestData -TenantFilter $Tenant -Type 'Organization'

        if (-not $OrgInfo) {
            $TestParams = @{
                TestId               = 'ZTNA24570'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'Unable to retrieve organization information from cache.'
                Risk                 = 'High'
                Name                 = 'Entra Connect uses a service principal'
                UserImpact           = 'Medium'
                ImplementationEffort = 'High'
                Category             = 'Access control'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Check if hybrid identity is enabled
        $HybridEnabled = $OrgInfo.onPremisesSyncEnabled -eq $true

        if (-not $HybridEnabled) {
            $TestParams = @{
                TestId               = 'ZTNA24570'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = '✅ **N/A**: Hybrid identity synchronization is not enabled in this tenant.'
                Risk                 = 'High'
                Name                 = 'Entra Connect uses a service principal'
                UserImpact           = 'Medium'
                ImplementationEffort = 'High'
                Category             = 'Access control'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Get roles to find Directory Synchronization Accounts role
        $Roles = Get-CIPPTestData -TenantFilter $Tenant -Type 'Roles'

        if (-not $Roles) {
            $TestParams = @{
                TestId               = 'ZTNA24570'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'Unable to retrieve roles from cache.'
                Risk                 = 'High'
                Name                 = 'Entra Connect uses a service principal'
                UserImpact           = 'Medium'
                ImplementationEffort = 'High'
                Category             = 'Access control'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Find Directory Synchronization Accounts role (roleTemplateId: d29b2b05-8046-44ba-8758-1e26182fcf32)
        $DirSyncRole = $null
        foreach ($role in $Roles) {
            if ($role.roleTemplateId -eq 'd29b2b05-8046-44ba-8758-1e26182fcf32') {
                $DirSyncRole = $role
                break
            }
        }

        if (-not $DirSyncRole) {
            $TestParams = @{
                TestId               = 'ZTNA24570'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Failed'
                ResultMarkdown       = '❌ **Error**: Unable to find Directory Synchronization Accounts role in cache.'
                Risk                 = 'High'
                Name                 = 'Entra Connect uses a service principal'
                UserImpact           = 'Medium'
                ImplementationEffort = 'High'
                Category             = 'Access control'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Check role members for enabled user accounts
        $EnabledUsers = [System.Collections.Generic.List[object]]::new()
        if ($DirSyncRole.members) {
            foreach ($member in $DirSyncRole.members) {
                # Check if it's a user (not a service principal) and if it's enabled
                if ($member.'@odata.type' -eq '#microsoft.graph.user') {
                    $isEnabled = $member.accountEnabled -eq $true
                    if ($isEnabled) {
                        $EnabledUsers.Add([PSCustomObject]@{
                                DisplayName       = $member.displayName
                                UserPrincipalName = $member.userPrincipalName
                                AccountEnabled    = $isEnabled
                            })
                    }
                }
            }
        }

        $Status = if ($EnabledUsers.Count -eq 0) { 'Passed' } else { 'Failed' }

        # Build result markdown
        $lastSyncDate = if ($OrgInfo.onPremisesLastSyncDateTime) {
            try {
                $date = [DateTime]::Parse($OrgInfo.onPremisesLastSyncDateTime)
                $date.ToString('yyyy-MM-dd HH:mm')
            } catch {
                $OrgInfo.onPremisesLastSyncDateTime
            }
        } else {
            'Never'
        }

        if ($Status -eq 'Passed') {
            $ResultMarkdown = "✅ **Pass**: Hybrid identity is enabled and using a service principal for synchronization.`n`n"
            $ResultMarkdown += "**Last Sync**: $lastSyncDate`n`n"
            $ResultMarkdown += '[Review configuration](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/RolesManagementMenuBlade/~/AllRoles)'
        } else {
            $ResultMarkdown = "❌ **Fail**: Hybrid identity is enabled but using $($EnabledUsers.Count) enabled user account(s) for synchronization.`n`n"
            $ResultMarkdown += "**Last Sync**: $lastSyncDate`n`n"
            $ResultMarkdown += "## Directory Synchronization Accounts role members`n`n"
            $ResultMarkdown += "| Display Name | User Principal Name | Enabled |`n"
            $ResultMarkdown += "| :----------- | :------------------ | :------ |`n"

            foreach ($user in $EnabledUsers) {
                $ResultMarkdown += "| $($user.DisplayName) | $($user.UserPrincipalName) | ✅ Yes |`n"
            }

            $ResultMarkdown += "`n[Migrate to service principal](https://entra.microsoft.com/#view/Microsoft_AAD_IAM/RolesManagementMenuBlade/~/AllRoles)"
        }

        $TestParams = @{
            TestId               = 'ZTNA24570'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'High'
            Name                 = 'Entra Connect uses a service principal'
            UserImpact           = 'Medium'
            ImplementationEffort = 'High'
            Category             = 'Access control'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA24570'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'High'
            Name                 = 'Entra Connect uses a service principal'
            UserImpact           = 'Medium'
            ImplementationEffort = 'High'
            Category             = 'Access control'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA24570 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA24570.ps1' 188
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA24572.ps1' -1

function Invoke-CippTestZTNA24572 {
    <#
    .SYNOPSIS
    Device enrollment notifications are enforced to ensure user awareness and secure onboarding
    #>
    param($Tenant)

    $TestId = 'ZTNA24572'
    #Tested
    try {
        $EnrollmentConfigs = Get-CIPPTestData -TenantFilter $Tenant -Type 'IntuneDeviceEnrollmentConfigurations'

        if (-not $EnrollmentConfigs) {
            Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Skipped' -ResultMarkdown 'No data found in database. This may be due to missing required licenses or data collection not yet completed.' -Risk 'Medium' -Name 'Device enrollment notifications are enforced to ensure user awareness and secure onboarding' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
            return
        }

        $EnrollmentNotifications = @($EnrollmentConfigs | Where-Object {
                $_.'@odata.type' -eq '#microsoft.graph.windowsEnrollmentStatusScreenSettings' -or
                $_.'deviceEnrollmentConfigurationType' -eq 'EnrollmentNotificationsConfiguration'
            })

        $AssignedNotifications = @($EnrollmentNotifications | Where-Object { $_.assignments -and $_.assignments.Count -gt 0 })
        $Passed = $AssignedNotifications.Count -gt 0

        if ($Passed) {
            $ResultMarkdown = "✅ At least one device enrollment notification is configured and assigned.`n`n"
        } else {
            $ResultMarkdown = "❌ No device enrollment notification is configured or assigned in Intune.`n`n"
        }

        if ($EnrollmentNotifications.Count -gt 0) {
            $ResultMarkdown += "## Device Enrollment Notifications`n`n"
            $ResultMarkdown += "| Policy Name | Assigned |`n"
            $ResultMarkdown += "| :---------- | :------- |`n"

            foreach ($policy in $EnrollmentNotifications) {
                $assigned = if ($policy.assignments -and $policy.assignments.Count -gt 0) { '✅ Yes' } else { '❌ No' }
                $ResultMarkdown += "| $($policy.displayName) | $assigned |`n"
            }
        }

        $Status = if ($Passed) { 'Passed' } else { 'Failed' }
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status $Status -ResultMarkdown $ResultMarkdown -Risk 'Medium' -Name 'Device enrollment notifications are enforced to ensure user awareness and secure onboarding' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'

    } catch {
        $ErrorMessage = Get-CippException -Exception $_
        Write-LogMessage -API 'Tests' -tenant $Tenant -message "Failed to run test: $($ErrorMessage.NormalizedError)" -sev Error -LogData $ErrorMessage
        Add-CippTestResult -TenantFilter $Tenant -TestId $TestId -TestType 'Identity' -Status 'Failed' -ResultMarkdown "Error running test: $($ErrorMessage.NormalizedError)" -Risk 'Medium' -Name 'Device enrollment notifications are enforced to ensure user awareness and secure onboarding' -UserImpact 'Medium' -ImplementationEffort 'Low' -Category 'Tenant'
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA24572.ps1' 52
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA24824.ps1' -1

function Invoke-CippTestZTNA24824 {
    <#
    .SYNOPSIS
    Checks if Conditional Access policies block access from noncompliant devices

    .DESCRIPTION
    Verifies that enabled Conditional Access policies exist that require device compliance,
    covering all platforms (Windows, macOS, iOS, Android) or a policy with no platform filter.

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested
    try {
        # Get CA policies from cache
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $CAPolicies) {
            $TestParams = @{
                TestId               = 'ZTNA24824'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'Unable to retrieve Conditional Access policies from cache.'
                Risk                 = 'High'
                Name                 = 'CA policies block access from noncompliant devices'
                UserImpact           = 'Medium'
                ImplementationEffort = 'Medium'
                Category             = 'Device security'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Filter for enabled policies with compliantDevice control
        $CompliantDevicePolicies = [System.Collections.Generic.List[object]]::new()
        foreach ($policy in $CAPolicies) {
            if ($policy.state -eq 'enabled' -and
                $policy.grantControls -and
                $policy.grantControls.builtInControls -and
                ($policy.grantControls.builtInControls -contains 'compliantDevice')) {
                $CompliantDevicePolicies.Add($policy)
            }
        }

        if ($CompliantDevicePolicies.Count -eq 0) {
            $TestParams = @{
                TestId               = 'ZTNA24824'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Failed'
                ResultMarkdown       = "❌ **Fail**: No Conditional Access policies found that block access from noncompliant devices.`n`n[Create policies](https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/ConditionalAccessBlade/~/Policies)"
                Risk                 = 'High'
                Name                 = 'CA policies block access from noncompliant devices'
                UserImpact           = 'Medium'
                ImplementationEffort = 'Medium'
                Category             = 'Device security'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Track platform coverage
        $PlatformCoverage = @{
            'windows' = $false
            'macOS'   = $false
            'iOS'     = $false
            'android' = $false
        }
        $AllPlatformsPolicy = $false

        $PolicyDetails = [System.Collections.Generic.List[object]]::new()

        foreach ($policy in $CompliantDevicePolicies) {
            $platforms = 'All platforms'

            if ($policy.conditions.platforms.includePlatforms) {
                if ($policy.conditions.platforms.includePlatforms -contains 'all') {
                    $AllPlatformsPolicy = $true
                    $platforms = 'All platforms'
                } else {
                    $platformList = $policy.conditions.platforms.includePlatforms -join ', '
                    $platforms = $platformList

                    # Track individual platform coverage
                    foreach ($platform in $policy.conditions.platforms.includePlatforms) {
                        $lowerPlatform = $platform.ToLower()
                        if ($PlatformCoverage.ContainsKey($lowerPlatform)) {
                            $PlatformCoverage[$lowerPlatform] = $true
                        }
                    }
                }
            } else {
                # No platform filter = applies to all platforms
                $AllPlatformsPolicy = $true
            }

            $PolicyDetails.Add([PSCustomObject]@{
                    Name      = $policy.displayName
                    Platforms = $platforms
                })
        }

        # Check if all platforms are covered (either by a single policy or combination)
        $AllCovered = $AllPlatformsPolicy -or (
            $PlatformCoverage['windows'] -and
            $PlatformCoverage['macOS'] -and
            $PlatformCoverage['iOS'] -and
            $PlatformCoverage['android']
        )

        $Status = if ($AllCovered) { 'Passed' } else { 'Failed' }

        # Build result markdown
        if ($Status -eq 'Passed') {
            $ResultMarkdown = "✅ **Pass**: Conditional Access policies block noncompliant devices across all platforms.`n`n"
        } else {
            $ResultMarkdown = "❌ **Fail**: Conditional Access policies do not cover all device platforms.`n`n"
            $missingPlatforms = [System.Collections.Generic.List[string]]::new()
            foreach ($key in $PlatformCoverage.Keys) {
                if (-not $PlatformCoverage[$key]) {
                    $missingPlatforms.Add($key)
                }
            }
            if ($missingPlatforms.Count -gt 0) {
                $ResultMarkdown += "**Missing platform coverage**: $($missingPlatforms -join ', ')`n`n"
            }
        }

        $ResultMarkdown += "## Compliant device policies`n`n"
        $ResultMarkdown += "| Policy Name | Platforms |`n"
        $ResultMarkdown += "| :---------- | :-------- |`n"

        foreach ($detail in $PolicyDetails) {
            $ResultMarkdown += "| $($detail.Name) | $($detail.Platforms) |`n"
        }

        $ResultMarkdown += "`n[Review policies](https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/ConditionalAccessBlade/~/Policies)"

        $TestParams = @{
            TestId               = 'ZTNA24824'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'High'
            Name                 = 'CA policies block access from noncompliant devices'
            UserImpact           = 'Medium'
            ImplementationEffort = 'Medium'
            Category             = 'Device security'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA24824'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'High'
            Name                 = 'CA policies block access from noncompliant devices'
            UserImpact           = 'Medium'
            ImplementationEffort = 'Medium'
            Category             = 'Device security'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA24824 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA24824.ps1' 176
#Region './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA24827.ps1' -1

function Invoke-CippTestZTNA24827 {
    <#
    .SYNOPSIS
    Checks if Conditional Access policies block unmanaged mobile apps

    .DESCRIPTION
    Verifies that enabled Conditional Access policies exist that require compliant applications
    for iOS and Android platforms, preventing unmanaged apps from accessing corporate data.

    .FUNCTIONALITY
    Internal
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Tenant
    )
    #Tested - Device

    try {
        # Get CA policies from cache
        $CAPolicies = Get-CIPPTestData -TenantFilter $Tenant -Type 'ConditionalAccessPolicies'

        if (-not $CAPolicies) {
            $TestParams = @{
                TestId               = 'ZTNA24827'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Skipped'
                ResultMarkdown       = 'Unable to retrieve Conditional Access policies from cache.'
                Risk                 = 'Medium'
                Name                 = 'CA policies block unmanaged mobile apps'
                UserImpact           = 'Medium'
                ImplementationEffort = 'Medium'
                Category             = 'Application security'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Filter for enabled policies with compliantApplication control for mobile platforms
        $CompliantAppPolicies = [System.Collections.Generic.List[object]]::new()
        foreach ($policy in $CAPolicies) {
            if ($policy.state -eq 'enabled' -and
                $policy.grantControls -and
                $policy.grantControls.builtInControls -and
                ($policy.grantControls.builtInControls -contains 'compliantApplication')) {

                # Check if policy applies to iOS or Android
                $appliesToMobile = $false
                if ($policy.conditions.platforms.includePlatforms) {
                    if ($policy.conditions.platforms.includePlatforms -contains 'all' -or
                        $policy.conditions.platforms.includePlatforms -contains 'iOS' -or
                        $policy.conditions.platforms.includePlatforms -contains 'android') {
                        $appliesToMobile = $true
                    }
                } else {
                    # No platform filter = applies to all platforms including mobile
                    $appliesToMobile = $true
                }

                if ($appliesToMobile) {
                    $CompliantAppPolicies.Add($policy)
                }
            }
        }

        if ($CompliantAppPolicies.Count -eq 0) {
            $TestParams = @{
                TestId               = 'ZTNA24827'
                TenantFilter         = $Tenant
                TestType             = 'Identity'
                Status               = 'Failed'
                ResultMarkdown       = "❌ **Fail**: No Conditional Access policies found that block unmanaged mobile apps.`n`n[Create policies](https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/ConditionalAccessBlade/~/Policies)"
                Risk                 = 'Medium'
                Name                 = 'CA policies block unmanaged mobile apps'
                UserImpact           = 'Medium'
                ImplementationEffort = 'Medium'
                Category             = 'Application security'
            }
            Add-CippTestResult @TestParams
            return
        }

        # Track platform coverage for iOS and Android
        $PlatformCoverage = @{
            'iOS'     = $false
            'android' = $false
        }
        $AllPlatformsPolicy = $false

        $PolicyDetails = [System.Collections.Generic.List[object]]::new()

        foreach ($policy in $CompliantAppPolicies) {
            $platforms = 'All platforms'

            if ($policy.conditions.platforms.includePlatforms) {
                if ($policy.conditions.platforms.includePlatforms -contains 'all') {
                    $AllPlatformsPolicy = $true
                    $platforms = 'All platforms'
                } else {
                    $platformList = $policy.conditions.platforms.includePlatforms -join ', '
                    $platforms = $platformList

                    # Track individual platform coverage
                    if ($policy.conditions.platforms.includePlatforms -contains 'iOS') {
                        $PlatformCoverage['iOS'] = $true
                    }
                    if ($policy.conditions.platforms.includePlatforms -contains 'android') {
                        $PlatformCoverage['android'] = $true
                    }
                }
            } else {
                # No platform filter = applies to all platforms
                $AllPlatformsPolicy = $true
            }

            $PolicyDetails.Add([PSCustomObject]@{
                    Name      = $policy.displayName
                    Platforms = $platforms
                })
        }

        # Check if both iOS and Android are covered
        $BothCovered = $AllPlatformsPolicy -or ($PlatformCoverage['iOS'] -and $PlatformCoverage['android'])

        $Status = if ($BothCovered) { 'Passed' } else { 'Failed' }

        # Build result markdown
        if ($Status -eq 'Passed') {
            $ResultMarkdown = "✅ **Pass**: Conditional Access policies block unmanaged apps on both iOS and Android platforms.`n`n"
        } else {
            $ResultMarkdown = "❌ **Fail**: Conditional Access policies do not cover all mobile platforms.`n`n"
            $missingPlatforms = [System.Collections.Generic.List[string]]::new()
            if (-not $PlatformCoverage['iOS']) {
                $missingPlatforms.Add('iOS')
            }
            if (-not $PlatformCoverage['android']) {
                $missingPlatforms.Add('android')
            }
            if ($missingPlatforms.Count -gt 0) {
                $ResultMarkdown += "**Missing platform coverage**: $($missingPlatforms -join ', ')`n`n"
            }
        }

        $ResultMarkdown += "## Compliant application policies`n`n"
        $ResultMarkdown += "| Policy Name | Platforms |`n"
        $ResultMarkdown += "| :---------- | :-------- |`n"

        foreach ($detail in $PolicyDetails) {
            $ResultMarkdown += "| $($detail.Name) | $($detail.Platforms) |`n"
        }

        $ResultMarkdown += "`n[Review policies](https://entra.microsoft.com/#view/Microsoft_AAD_ConditionalAccess/ConditionalAccessBlade/~/Policies)"

        $TestParams = @{
            TestId               = 'ZTNA24827'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = $Status
            ResultMarkdown       = $ResultMarkdown
            Risk                 = 'Medium'
            Name                 = 'CA policies block unmanaged mobile apps'
            UserImpact           = 'Medium'
            ImplementationEffort = 'Medium'
            Category             = 'Application security'
        }
        Add-CippTestResult @TestParams

    } catch {
        $TestParams = @{
            TestId               = 'ZTNA24827'
            TenantFilter         = $Tenant
            TestType             = 'Identity'
            Status               = 'Failed'
            ResultMarkdown       = "❌ **Error**: $($_.Exception.Message)"
            Risk                 = 'Medium'
            Name                 = 'CA policies block unmanaged mobile apps'
            UserImpact           = 'Medium'
            ImplementationEffort = 'Medium'
            Category             = 'Application security'
        }
        Add-CippTestResult @TestParams
        Write-LogMessage -API 'ZeroTrustNetworkAccess' -tenant $Tenant -message "Test ZTNA24827 failed: $($_.Exception.Message)" -sev Error
    }
}
#EndRegion './Public/Tests/ZTNA/Identity/Invoke-CippTestZTNA24827.ps1' 187
